# Initial setup Zinspilot

# Zinspilot Application

Bundles and releases the Zinspilot application. Furthermore contains integration tests for the Zinspilot appliation.

## Running tests locally

Always make sure changes from the `master` are in your development branch:
```
> git checkout -b feature-some-awesome-feature
> git fetch origin master
> git merge master
```

Package project to have everything in `target`:
```
> mvn clean package
```

Clean-up stale containers:
```
> ./dc.sh down
```

Run docker-compose application:
```
> ./dc.sh up -d
```

Wait until containers sucessfully start.
You can watch containers output with the command:
```
> ./dc.sh logs -f
```

`dc.sh` script is a simple wrapper around docker-compose so it works with any docker-compose commands.

To execute tests from IDE:
run `testng-suit.xml` file as TestNG suite using IntelliJ IDEA TestNG Plugin (https://testng.org/doc/idea.html)

### Run with local chromedriver

Make sure to configure shop cookies domain to localhost in `.env` file, otherwise login won't work.

The same applies if you want to test manually with any browser.


### Other services like Cure and reporting-service

Start and step the complete service environment: 
```
PROFILE='complete' ./dc.sh up -d

PROFILE='complete' ./dc.sh down
```

Start and stop the mockproxy environment: 
```
PROFILE='mockproxy' ./dc.sh up -d

PROFILE='mockproxy' ./dc.sh down
```


### Known issue

- `mvn clean` does not run due to permissions issue of `minio` container in `target/docker-compose/s3` directory. Workaround is to `sudo rm -rm target`. Long term solution requires investigation.
