#!/bin/sh

if [ -z "$PROFILE" ]
then
  SHOP_COOKIE_DOMAIN=localhost docker-compose --project-directory target/classes/docker-compose \
    -f target/classes/docker-compose/docker-compose.yml \
    $@
else
  echo "Using profile '${PROFILE}'"
  SHOP_COOKIE_DOMAIN=localhost docker-compose --project-directory target/classes/docker-compose \
    -f target/classes/docker-compose/docker-compose.yml \
    -f target/classes/docker-compose/docker-compose.override.${PROFILE}.yml \
    $@
fi

