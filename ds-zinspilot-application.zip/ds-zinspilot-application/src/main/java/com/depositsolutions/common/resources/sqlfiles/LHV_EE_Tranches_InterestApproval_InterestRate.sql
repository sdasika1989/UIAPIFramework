--LHV

--Dumping data for 'b2c_product_tranche' table

USE `comonea_b2c`;
LOCK TABLES `b2c_product_tranche` WRITE;
/*!40000 ALTER TABLE `b2c_product_tranche` DISABLE KEYS */;
INSERT INTO `comonea_b2c`.`b2c_product_tranche` (`id`, `creationDate`, `lastModifiedDate`, `cut_off_amount_currency`, `cut_off_amount`, `depositType`, `endDate`, `max_amount_currency`, `max_amount`, `payInDeadline`, `transactionDate`, `productIdentifier`, `productName`, `productState`, `startDate`, `uuid`, `viewState`, `description`, `min_amount_currency`, `min_amount`, `marketing_rank`, `interestProduct_id`, `investmentChangeOnly`, `interestTaxation`, `canBeProlongated`, `noticePeriodInDays`) VALUES ('21307', '2020-10-16 14:55:16', '2021-03-29 01:00:17', 'EUR', '1000000.00', 'FIXED_TERM', '2022-04-19', 'EUR', '100000.00', '2021-04-12 00:00:00', '2021-04-12 16:00:00', 'LHVBEE22XXX-FG1Y-2021-04-15', '', 'CREATED', '2021-04-15', 'a1402c07-c1f6-432f-9df1-b7c27b914220', 'PUBLISHED', 'Das Festgeld der AS LHV Pank ist eine Termineinlage, bei der ein vorab vereinbarter Anlagebetrag zwischen {minPayInAmount} EUR und {maxPayInAmount} mit einer festen Laufzeit von {duration} und einem festen Zinssatz von {interestRate}% p.a. angelegt wird.', 'EUR', '1.00', '87', '320', '0', 'SERVICE_BANK', b'0', b'0');
INSERT INTO `comonea_b2c`.`b2c_product_tranche` (`id`, `creationDate`, `lastModifiedDate`, `cut_off_amount_currency`, `cut_off_amount`, `depositType`, `endDate`, `max_amount_currency`, `max_amount`, `payInDeadline`, `transactionDate`, `productIdentifier`, `productName`, `productState`, `startDate`, `uuid`, `viewState`, `description`, `min_amount_currency`, `min_amount`, `marketing_rank`, `interestProduct_id`, `investmentChangeOnly`, `interestTaxation`, `canBeProlongated`, `noticePeriodInDays`) VALUES ('21275', '2020-10-16 14:55:14', '2021-04-19 09:08:21', 'EUR', '1000000.00', 'FIXED_TERM', '2021-11-02', 'EUR', '100000.00', '2021-04-28 00:00:00', '2021-04-28 16:00:00', 'LHVBEE22XXX-FG6M-2021-05-03', '', 'CREATED', '2021-05-03', 'a607ccaf-3be8-4564-942d-c325188c2fcc', 'PUBLISHED', 'Das Festgeld der AS LHV Pank ist eine Termineinlage, bei der ein vorab vereinbarter Anlagebetrag zwischen {minPayInAmount} EUR und {maxPayInAmount} mit einer festen Laufzeit von {duration} und einem festen Zinssatz von {interestRate}% p.a. angelegt wird.', 'EUR', '1.00', '144', '319', '0', 'SERVICE_BANK', b'0', b'0');
/*!40000 ALTER TABLE `b2c_product_tranche` ENABLE KEYS */;
UNLOCK TABLES;

--Dumping data for table 'b2c_interest_approval'

Use `comonea_b2c`;
LOCK TABLES `b2c_fixed_term_interest_approval` WRITE;
/*!40000 ALTER TABLE `b2c_fixed_term_interest_approval` DISABLE KEYS */;
INSERT INTO `comonea_b2c`.`b2c_fixed_term_interest_approval` (`id`, `creationDate`, `username`, `approvedOn`, `productTranche_id`) VALUES ('15845', '2021-04-09 15:11:23', 'fffa685932nbqrtl.adriano.walton@gmail.com', '2021-04-09 15:11:23', '21275');
INSERT INTO `comonea_b2c`.`b2c_fixed_term_interest_approval` (`id`, `creationDate`, `username`, `approvedOn`, `productTranche_id`) VALUES ('15625', '2021-03-26 15:18:47', 'fffa172985alikhf.ina.gunther@mail.de', '2021-03-26 15:18:47', '21307');
/*!40000 ALTER TABLE `b2c_fixed_term_interest_approval` ENABLE KEYS */;
UNLOCK TABLES;

--Dumping data for table 'b2c_interest_rate'

USE `comonea_b2c`;
LOCK TABLES `b2c_interest_rate` WRITE;
/*!40000 ALTER TABLE `b2c_interest_rate` DISABLE KEYS */;

INSERT INTO `comonea_b2c`.`b2c_interest_rate` (`id`, `creationDate`, `lastModifiedDate`, `rate`, `validFrom`, `product_id`) VALUES ('21605', '2020-10-16 14:55:14', '2021-01-07 08:48:46', '0.00060', '2020-10-16', '21275');
INSERT INTO `comonea_b2c`.`b2c_interest_rate` (`id`, `creationDate`, `lastModifiedDate`, `rate`, `validFrom`, `product_id`) VALUES ('21638', '2020-10-16 14:55:16', '2021-01-07 08:49:04', '0.00050', '2020-10-16', '21307');

/*!40000 ALTER TABLE `b2c_interest_rate` ENABLE KEYS */;
UNLOCK TABLES;

