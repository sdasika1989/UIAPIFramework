package com.depositsolutions.common.reusables;

import com.depositsolutions.common.utils.ConfigManager;

public class TestConstants {

  public static String testDataInjection =
      ConfigManager.getInstance().getString("testDataInjection");

  public static String SHOP_URL_CONFIG_KEY = "shopUrl";
  public static String SHOP_ADMIN_URL_CONFIG_KEY = "shopCacheUrl";
  public static String RUN_WITH_DOCKER_CONFIG_KEY = "runWithDocker";
  public static String BROWSER_CONFIG_KEY = "browser";
  public static String DRIVER_HOST_CONFIG_KEY = "driverHost";
  public static String DRIVER_PORT_CONFIG_KEY = "driverPort";
  public static String ENV_CONFIG_KEY = "env";
  public static String SUTOR_SFTP_DOWNLOAD = "sutorSftpDownloadPath";
  public static String SHOP_PASSWORD = "Dekaup10";
  public static final String IMPLICIT_TIME_OUT_KEY = "implicitTimeOut";
  public static final String SCREENSHOT_DIR_KEY = "screenshotsPath";
  public static final String CURRENT_WORKING_DIRECTORY = System.getProperty("user.dir");
  public static final String DOCKER_LOG_LEVEL = "logLevel";
}
