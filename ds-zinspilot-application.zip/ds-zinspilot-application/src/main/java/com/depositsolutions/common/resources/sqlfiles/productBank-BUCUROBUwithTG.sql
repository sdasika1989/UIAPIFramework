-- Dumping data for table `b2c_product_bank`,`b2c_product_tranche`,`b2c_product_tranche_call_alike_transfer`,`b2c_product_bank_interest_account` and 
--
-- WHERE:  bic='BUCUROBU-TG'

USE `comonea_b2c`;

-- For `b2c_product_bank`
LOCK TABLES `b2c_product_bank` WRITE;
/*!40000 ALTER TABLE `b2c_product_bank` DISABLE KEYS */;
INSERT INTO `b2c_product_bank` VALUES (10,'2017-01-19 10:36:13','2021-02-24 08:59:23','BUCUROBU','','Alpha Bank Romania S.A.','RO',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Bucharest Trade Register under no. J40/28415/1993, Sole Registration Number RO 5062063, registered under the no 601 in the Register of Personal Data Processing',NULL,'b7bbd76e-de2a-11e6-b6f9-000c29c84cff','Die Alpha Bank Romania S.A. wurde im Jahr 1993 in Zusammenarbeit mit der Europäischen Bank für Wiederaufbau und Entwicklung als Banca Bucuresti S.A. gegründet. Sie zählt zu den acht größten Banken in Rumänien und ist als Universalbank mit über 130 Filialen und 1.842 Mitarbeitern ein stark im Privat- und Firmenkundengeschäft verankertes Kreditinstitut.','EUR','100000.00','ALPHA BANK AE 99.91838%, EIRINI BRINTAKIS 0.08162%',NULL,'NO_TAX_DEDUCTION',NULL,'0.00000','CUSTOMER_INTEREST_ACCOUNT_BASED','FIDUCIARY_ACCOUNT_MODEL',NULL,NULL,'Alpha Bank',NULL,1,'-2','00:00:00','-1','16:00:00',0);
/*!40000 ALTER TABLE `b2c_product_bank` ENABLE KEYS */;
UNLOCK TABLES;

-- For `b2c_product_bank_validation_requirement`
LOCK TABLES `b2c_product_bank_validation_requirement` WRITE;
/*!40000 ALTER TABLE `b2c_product_bank_validation_requirement` DISABLE KEYS */;
INSERT INTO `b2c_product_bank_validation_requirement` VALUES ('7','2017-01-19 10:36:13',NULL,'GERMAN_TAX_ID','10','NONE',NULL,'1');
/*!40000 ALTER TABLE `b2c_product_bank_validation_requirement` ENABLE KEYS */;
UNLOCK TABLES;

-- For `b2c_product_bank_logo`
LOCK TABLES `b2c_product_bank_logo` WRITE;
/*!40000 ALTER TABLE `b2c_product_bank_logo` DISABLE KEYS */;
INSERT INTO `b2c_product_bank_logo` VALUES (13,'2021-01-26 10:29:53.000000',NULL,'<?xml version="1.0" encoding="utf-8"?>
                                                                                  <!-- Generator: Adobe Illustrator 19.2.1, SVG Export Plug-In . SVG Version: 6.00 Build 0)  -->
                                                                                  <svg version="1.1" id="Layer_1" xmlns="http://www.w3.org/2000/svg"  x="0px" y="0px"
                                                                                  	 viewBox="0 0 145 30.6" style="enable-background:new 0 0 145 30.6;" xml:space="preserve">
                                                                                  <style type="text/css">
                                                                                  	.st0{fill:#00386A;}
                                                                                  	.st1{fill:#FFFFFF;}
                                                                                  </style>
                                                                                  <g>
                                                                                  	<g>
                                                                                  		<polygon class="st0" points="30.6,30.6 30.6,0 0,0 0,30.6 30.6,30.6 		"/>
                                                                                  		<path class="st1" d="M26.5,15.4c0,8-4.6,11.2-11.2,11.2c-6.7,0-11.2-3.3-11.2-11.2c0-8,4.6-11.2,11.2-11.2
                                                                                  			C22,4.1,26.5,7.4,26.5,15.4L26.5,15.4z"/>
                                                                                  		<path class="st0" d="M5.8,15.4c0,6.8,3.4,9.5,9.5,9.5c6.1,0,9.5-2.8,9.5-9.5c0-6.8-3.5-9.5-9.5-9.5C9.2,5.8,5.8,8.6,5.8,15.4
                                                                                  			L5.8,15.4z"/>
                                                                                  		<path class="st1" d="M10.8,7.9l0,3.2h-3c-0.3,0.9-0.5,2.7-0.5,3.6l3.6,0v8.1c0.8,0.3,2.6,0.6,3.5,0.6v-6.2l5.4,5.5
                                                                                  			c0.6-0.2,2.5-1.8,2.7-2.4L17,14.7h6.4c0-1.2-0.3-2.7-0.6-3.6h-8.5V7.3C13.6,7.3,11,7.7,10.8,7.9L10.8,7.9z"/>
                                                                                  	</g>
                                                                                  	<g>
                                                                                  		<path d="M43.2,10.1l-5.3,10.2h1.8l1.5-2.7h5.4l1.4,2.7h1.9l-5.2-10.2H43.2L43.2,10.1z M43.9,12.1l2.1,4.1h-4.1L43.9,12.1
                                                                                  			L43.9,12.1z"/>
                                                                                  		<polygon points="51.2,10.1 51.2,20.4 58.1,20.4 58.1,18.9 52.9,18.9 52.9,10.1 51.2,10.1 		"/>
                                                                                  		<path d="M59.3,10.1v10.2H61v-3.8h2.8c1.9,0,4.4-0.3,4.4-3.3c0-2.3-1.8-3.1-3.4-3.1H59.3L59.3,10.1z M64.6,11.6
                                                                                  			c0.9,0,1.9,0.6,1.9,1.6c0,1.4-0.6,1.9-2.3,1.9H61v-3.5H64.6L64.6,11.6z"/>
                                                                                  		<polygon points="77.8,10.1 77.8,14.3 71.6,14.3 71.6,10.1 69.8,10.1 69.8,20.4 71.6,20.4 71.6,15.7 77.8,15.7 77.8,20.4
                                                                                  			79.6,20.4 79.6,10.1 77.8,10.1 		"/>
                                                                                  		<path d="M86.2,10.1l-5.3,10.2h1.8l1.5-2.7h5.4l1.4,2.7h1.9l-5.2-10.2H86.2L86.2,10.1z M86.8,12.1l2.1,4.1h-4.1L86.8,12.1
                                                                                  			L86.8,12.1z"/>
                                                                                  		<path d="M97.3,10.1v10.2h6.3c1.8,0,3.5-0.9,3.5-2.9c0-0.1-0.1-2.1-1.8-2.5c0.7-0.3,1.2-1,1.2-2.1c0-1.2-0.9-2.6-3.4-2.6H97.3
                                                                                  			L97.3,10.1z M103.1,15.7c1.6,0,2.3,0.5,2.3,1.7c0,1-0.7,1.5-2.1,1.5H99v-3.2H103.1L103.1,15.7z M103,11.6c1.2,0,1.8,0.4,1.8,1.2
                                                                                  			c0,0.8-0.2,1.6-2.3,1.6H99v-2.8H103L103,11.6z"/>
                                                                                  		<polygon points="120.9,20.4 122.5,20.4 122.5,11.8 129.6,20.4 131.4,20.4 131.4,10.1 129.9,10.1 129.9,18.1 123,10.1 120.9,10.1
                                                                                  			120.9,20.4 		"/>
                                                                                  		<polygon points="142.3,10.1 136.1,15.1 136.1,10.1 134.4,10.1 134.4,20.4 136.1,20.4 136.1,16.8 137.6,15.5 142.7,20.4 145,20.4
                                                                                  			138.9,14.6 144.3,10.1 142.3,10.1 		"/>
                                                                                  		<path d="M112.9,10.1l-5.3,10.2h1.8l1.5-2.7h5.4l1.4,2.7h1.9l-5.2-10.2H112.9L112.9,10.1z M113.6,12.1l2.1,4.1h-4.1L113.6,12.1
                                                                                  			L113.6,12.1z"/>
                                                                                  	</g>
                                                                                  </g>
                                                                                  <g>
                                                                                  	<path d="M107.5,23.8h3.2c1,0,1.4,0.7,1.4,1.4c0,0.6-0.3,1.1-0.9,1.3v0c0.5,0.1,0.7,0.5,0.8,1.1c0,1,0.1,1.2,0.2,1.4h-0.8
                                                                                  		c-0.1-0.1-0.1-0.4-0.2-1c-0.1-0.9-0.4-1.2-1-1.2h-2v2.2h-0.8V23.8z M110.5,26.2c0.8,0,0.9-0.5,0.9-0.8c0-0.5-0.3-0.8-0.9-0.8h-2.2
                                                                                  		v1.7H110.5z"/>
                                                                                  	<path d="M115.6,23.7c2.1,0,2.9,1.4,2.9,2.7s-0.8,2.7-2.9,2.7c-2.1,0-2.9-1.4-2.9-2.7S113.5,23.7,115.6,23.7z M115.6,24.4
                                                                                  		c-1.2,0-2.1,0.7-2.1,2.1c0,1.4,0.9,2.1,2.1,2.1s2.1-0.7,2.1-2.1C117.7,25.1,116.8,24.4,115.6,24.4z"/>
                                                                                  	<path d="M124.4,23.8h1.1v5.2h-0.8v-4.3h0l-2,4.3H122l-2-4.2h0v4.2h-0.8v-5.2h1.1l2.1,4.3L124.4,23.8z"/>
                                                                                  	<path d="M130,27.5h-2.6l-0.7,1.5h-0.8l2.4-5.2h0.9l2.4,5.2h-0.9L130,27.5z M128.7,24.6l-1,2.3h2L128.7,24.6z"/>
                                                                                  	<path d="M132.8,24.9L132.8,24.9l0,4.2H132v-5.2h0.9l3.4,4.2h0v-4.2h0.8v5.2h-0.9L132.8,24.9z"/>
                                                                                  	<path d="M138.2,23.8h0.8v5.2h-0.8V23.8z"/>
                                                                                  	<path d="M143.5,27.5h-2.6l-0.7,1.5h-0.8l2.4-5.2h0.9l2.4,5.2h-0.9L143.5,27.5z M142.2,24.6l-1,2.3h2L142.2,24.6z"/>
                                                                                  </g>
                                                                                  </svg>
','BUCUROBU.svg','BUCUROBU');
/*!40000 ALTER TABLE `b2c_product_bank_logo` ENABLE KEYS */;
UNLOCK TABLES;
	
-- For `b2c_interest_product`
LOCK TABLES `b2c_interest_product` WRITE;
/*!40000 ALTER TABLE `b2c_interest_product` DISABLE KEYS */;
INSERT INTO `b2c_interest_product` VALUES (32,'2017-01-19 10:37:49','2019-04-24 13:14:55','BUCUROBU-CALL','YEARLY','ENGLISH_ACT_365','CALL',NULL,'AlphaTG',10,'EUR','PROLONGATION','PAYOUT',NULL,0);
/*!40000 ALTER TABLE `b2c_interest_product` ENABLE KEYS */;
UNLOCK TABLES;

-- For `b2c_product_tranche`
LOCK TABLES `b2c_product_tranche` WRITE;
/*!40000 ALTER TABLE `b2c_product_tranche` DISABLE KEYS */;
INSERT INTO `b2c_product_tranche` VALUES (1088,'2017-01-19 10:37:49','2018-02-13 18:18:32',NULL,NULL,'DIRECT_ACCESS',NULL,'EUR','100000.00',NULL,NULL,'BUCUROBU-TG','',NULL,'CONNECTED',NULL,'f0e04908-de2a-11e6-b6f9-000c29c84cff','PUBLISHED',NULL,'EUR','1.00',175,32,0,'SERVICE_BANK',1,0,NULL);
/*!40000 ALTER TABLE `b2c_product_tranche` ENABLE KEYS */;
UNLOCK TABLES;

-- For `b2c_interest_rate`
LOCK TABLES `b2c_interest_rate` WRITE;
/*!40000 ALTER TABLE `b2c_interest_rate` DISABLE KEYS */;
INSERT INTO `b2c_interest_rate` VALUES (1,'2020-02-26 15:15:27',NULL,'0.00030','2020-03-16',1088);
/*!40000 ALTER TABLE `b2c_interest_rate` ENABLE KEYS */;
UNLOCK TABLES;

-- For `b2c_product_bank_interest_account`
LOCK TABLES `b2c_product_bank_interest_account` WRITE;
/*!40000 ALTER TABLE `b2c_product_bank_interest_account` DISABLE KEYS */;
INSERT INTO `b2c_product_bank_interest_account` VALUES (2396,'2017-01-19 09:37:49',NULL,'fffLily Beele','RO53BUCU8940695812271059','f0e2c62e-de2a-11e6-b6f9-000c29c84cff',1088,10,3,'BUCUROBU','BUCUROBU','RO53BUCU8940695812271059',0,'EUR',null);
/*!40000 ALTER TABLE `b2c_product_bank_interest_account` ENABLE KEYS */;
UNLOCK TABLES;

-- For `b2c_service_bank_product_mapping`
LOCK TABLES `b2c_service_bank_product_mapping` WRITE;
/*!40000 ALTER TABLE `b2c_service_bank_product_mapping` DISABLE KEYS */;
INSERT INTO `b2c_service_bank_product_mapping` VALUES (2400,'2017-01-19 09:37:49',NULL,2396,1088,5,3);
/*!40000 ALTER TABLE `b2c_service_bank_product_mapping` ENABLE KEYS */;
UNLOCK TABLES;

-- PB Dump completed
