-- Dumping data for table `b2c_product_bank`,`b2c_product_tranche`,`b2c_product_tranche_call_alike_transfer`,`b2c_product_bank_interest_account` and
--
-- WHERE:  bic='CPLUDES1XXX-TG'

USE `comonea_b2c`;
-- For `b2c_product_tranche`
LOCK TABLES `b2c_product_tranche` WRITE;
/*!40000 ALTER TABLE `b2c_product_tranche` DISABLE KEYS */;
INSERT INTO `b2c_product_tranche` VALUES ('16822', '2020-02-21 14:18:31', NULL, NULL, NULL, 'DIRECT_ACCESS', NULL, 'EUR', '95000.00', NULL, NULL, 'QLROSEHHXDS-TG', '', NULL, 'CONNECTED', NULL, '09e1f85b-54b5-11ea-821c-26e0a622eaa4', 'PUBLISHED', 'Das Flexgeld24 der Qliro ist eine Spareinlage, bei der ein frei definierbarer Anlagebetrag von bis zu {maxPayInAmount} EUR mit einem variablen Zinssatz von zurzeit {interestRate}% p.a. angelegt werden kann. Die Zinszahlung für das Produkt Flexgeld24 erfolgt zweimal monatlich. Anlagen können zu den Zinszahlungsterminen gestartet und beendet werden, d.h.: Der Kunde hat mit dem Flexgeld24 die Flexibilität, sein Geld jeweils zum 1. und zum 15. eines Monats bzw. dem darauffolgenden Bankarbeitstag ein- oder auszuzahlen. Bitte beachten Sie die Angaben im Produktinformationsblatt zur Hinterlegung von Ausweisdaten.', 'EUR', '1.00', '172', '354', '0', 'SERVICE_BANK', 1, 15, NULL);
/*!40000 ALTER TABLE `b2c_product_tranche` ENABLE KEYS */;
UNLOCK TABLES;

-- For `b2c_interest_rate`
LOCK TABLES `b2c_interest_rate` WRITE;
/*!40000 ALTER TABLE `b2c_interest_rate` DISABLE KEYS */;
INSERT INTO `b2c_interest_rate` VALUES (19,'2020-02-26 15:15:27',NULL,'0.00050','2020-03-16',16822);
/*!40000 ALTER TABLE `b2c_interest_rate` ENABLE KEYS */;
UNLOCK TABLES;

-- For `b2c_product_tranche_call_alike_transfer`
LOCK TABLES `b2c_product_tranche_call_alike_transfer` WRITE;
/*!40000 ALTER TABLE `b2c_product_tranche_call_alike_transfer` DISABLE KEYS */;
INSERT INTO `b2c_product_tranche_call_alike_transfer` VALUES (1697,'2020-11-23 17:09:16',NULL,'2022-03-15',NULL,16822,'CLOSED','CLOSED');
INSERT INTO `b2c_product_tranche_call_alike_transfer` VALUES (1698,'2020-11-23 17:09:16',NULL,'2022-03-31',NULL,16822,'OPEN','OPEN');
/*!40000 ALTER TABLE `b2c_product_tranche_call_alike_transfer` ENABLE KEYS */;
UNLOCK TABLES;

-- For `b2c_product_bank_interest_account`
LOCK TABLES `b2c_product_bank_interest_account` WRITE;
/*!40000 ALTER TABLE `b2c_product_bank_interest_account` DISABLE KEYS */;
INSERT INTO `b2c_product_bank_interest_account` VALUES ('24720', '2020-02-21 14:18:31', '2020-08-17 12:47:27', 'fffHennes Daimer', 'SE8595022384416651575261', '09e208b8-54b5-11ea-821c-26e0a622eaa4', '16822', '60', '3', 'NDEASESSXXX', 'NDEASESSXXX', 'SE8595022384416651575261', 0, 'EUR', NULL);
/*!40000 ALTER TABLE `b2c_product_bank_interest_account` ENABLE KEYS */;
UNLOCK TABLES;

-- For `b2c_service_bank_product_mapping`
LOCK TABLES `b2c_service_bank_product_mapping` WRITE;
/*!40000 ALTER TABLE `b2c_service_bank_product_mapping` DISABLE KEYS */;
INSERT INTO `b2c_service_bank_product_mapping` VALUES (7550,'2017-09-06 16:01:27',NULL,24720,16822,5,3);
/*!40000 ALTER TABLE `b2c_service_bank_product_mapping` ENABLE KEYS */;
UNLOCK TABLES;

-- For `b2c_document_depositors_information`
LOCK TABLES `b2c_document_depositors_information` WRITE;
/*!40000 ALTER TABLE `b2c_document_depositors_information` DISABLE KEYS */;
INSERT INTO `b2c_document_depositors_information` VALUES ( '125', '2021-06-17 14:08:35', NULL, 1, 'PRODUCT_BANK', 'QLROSEHHXDS','', 'ZP_IFE_Qliro..pdf', '2021-06-17', '1');
/*!40000 ALTER TABLE `b2c_document_depositors_information` ENABLE KEYS */;
UNLOCK TABLES;


-- For `b2c_document_product_information`
LOCK TABLES `b2c_document_product_information` WRITE;
/*!40000 ALTER TABLE `b2c_document_product_information` DISABLE KEYS */;
INSERT INTO `b2c_document_product_information` (`id`, `creationDate`, `lastModifiedDate`, `active`, `content`,`name`,`productTranche_id`,`template_id`,`validFrom`,`version`,`substitutionParamsJson`,`content_id`) VALUES ('10991', '2021-04-15 08:10:38', NULL, 1,'', 'ZP_Produktinformationsblatt_Creditplus_Flexgeld24.pdf', '16822', '19775', '2021-04-15', '6', '{\"interestRate\":\"0,01%\",\"documentCreationDate\":\"15.04.2021\",\"minAmount\":\"1\",\"textInterestRate\":\"Zinssatz ab 15.04.2021: 0,01% p.a.\",\"minAmountWithCUAndDot\":\"1 EUR.\",\"relationshipModel\":\"Treuhandanlage\",\"interestRateWithPa\":\"0,01% p.a.\",\"currentTextInterestRate\":\"Aktueller Zinsatz: 0,01% p.a. (seit: 15.04.2021)\",\"textNewInterestRate\":\"\",\"maxProductAmount\":\"1.000.000 EUR\",\"minProductAmount\":\"1 EUR\",\"noticePeriodInDays\":\"0\",\"minAmountWithCU\":\"1 EUR\",\"withholdingTaxRate\":\"0,00%\",\"investmentProtectionTresholdValidFrom\":\"01.01.2020\",\"maxAmountWithCU\":\"1.000.000 EUR\",\"cutOffAmountWithCurrency\":\"\",\"maxAmount\":\"1.000.000\",\"nextTextInterestRate\":\"\",\"investmentProtectionTresholdVolume\":\"44,88\"}',NULL);
/*!40000 ALTER TABLE `b2c_document_product_information` ENABLE KEYS */;
UNLOCK TABLES;

-- PB Dump completed
