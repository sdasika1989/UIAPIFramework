-- Dumping data for table `b2c_product_bank`,`b2c_product_tranche`,`b2c_product_tranche_call_alike_transfer`,`b2c_product_bank_interest_account` and 
--
-- WHERE:  bic='CPLUDES1XXX-TG'

USE `comonea_b2c`;
-- For `b2c_product_tranche`
LOCK TABLES `b2c_product_tranche` WRITE;
/*!40000 ALTER TABLE `b2c_product_tranche` DISABLE KEYS */;
INSERT INTO `b2c_product_tranche` VALUES ('13596', '2019-03-21 14:15:49', NULL, NULL, NULL, 'DIRECT_ACCESS', NULL, 'EUR', '100000.00', NULL, NULL, 'MOEYFRPPXXX-TG', '', NULL, 'CONNECTED', NULL, 'd399b0a7-4be3-11e9-8dae-26e0a622eaa4', 'PUBLISHED', 'Das Flexgeld24 der MMB ist eine Spareinlage, bei der ein frei definierbarer Anlagebetrag von bis zu {maxPayInAmount} EUR mit einem variablen Zinssatz von zurzeit {interestRate}% p.a. angelegt werden kann. Die Zinszahlung für das Produkt Flexgeld24 erfolgt zweimal monatlich. Anlagen können zu den Zinszahlungsterminen gestartet und beendet werden, d.h.: Der Kunde hat mit dem Flexgeld24 die Flexibilität, sein Geld jeweils zum 1. und zum 15. eines Monats bzw. dem darauffolgenden Bankarbeitstag ein- oder auszuzahlen. Bitte beachten Sie die Angaben im Produktinformationsblatt zur Hinterlegung von Ausweisdaten.', 'EUR', '1.00', '174', '312', '0', 'SERVICE_BANK', 1, 0, NULL);
/*!40000 ALTER TABLE `b2c_product_tranche` ENABLE KEYS */;
UNLOCK TABLES;

-- For `b2c_interest_rate`
LOCK TABLES `b2c_interest_rate` WRITE;
/*!40000 ALTER TABLE `b2c_interest_rate` DISABLE KEYS */;
INSERT INTO `b2c_interest_rate` VALUES (6,'2020-02-26 15:15:27',NULL,'0.00050','2020-03-16',13596);
/*!40000 ALTER TABLE `b2c_interest_rate` ENABLE KEYS */;
UNLOCK TABLES;

-- For `b2c_product_tranche_call_alike_transfer`
LOCK TABLES `b2c_product_tranche_call_alike_transfer` WRITE;
/*!40000 ALTER TABLE `b2c_product_tranche_call_alike_transfer` DISABLE KEYS */;
INSERT INTO `b2c_product_tranche_call_alike_transfer` VALUES (2997,'2020-11-23 17:09:16',NULL,'2022-03-15',NULL,13596,'CLOSED','CLOSED');
INSERT INTO `b2c_product_tranche_call_alike_transfer` VALUES (2998,'2020-11-23 17:09:16',NULL,'2022-03-31',NULL,13596,'OPEN','OPEN');
/*!40000 ALTER TABLE `b2c_product_tranche_call_alike_transfer` ENABLE KEYS */;
UNLOCK TABLES;

-- For `b2c_product_bank_interest_account`
LOCK TABLES `b2c_product_bank_interest_account` WRITE;
/*!40000 ALTER TABLE `b2c_product_bank_interest_account` DISABLE KEYS */;
INSERT INTO `b2c_product_bank_interest_account` VALUES ('20961', '2019-03-21 14:15:49', NULL, 'fffJulien vom Reuber', 'FR5830003031752788782090494', 'd39a3da8-4be3-11e9-8dae-26e0a622eaa4', '13596', '44', '3', 'MOEYFRPPXXX', 'MOEYFRPPXXX', 'FR1742799000092788782090158', 0, 'EUR', NULL);
/*!40000 ALTER TABLE `b2c_product_bank_interest_account` ENABLE KEYS */;
UNLOCK TABLES;

-- For `b2c_service_bank_product_mapping`
LOCK TABLES `b2c_service_bank_product_mapping` WRITE;
/*!40000 ALTER TABLE `b2c_service_bank_product_mapping` DISABLE KEYS */;
INSERT INTO `b2c_service_bank_product_mapping` VALUES (6551,'2017-09-06 16:01:27',NULL,20961,13596,5,3);
/*!40000 ALTER TABLE `b2c_service_bank_product_mapping` ENABLE KEYS */;
UNLOCK TABLES;

-- For `b2c_document_product_information`
LOCK TABLES `b2c_document_product_information` WRITE;
/*!40000 ALTER TABLE `b2c_document_product_information` DISABLE KEYS */;
INSERT INTO `b2c_document_product_information` (`id`, `creationDate`, `lastModifiedDate`, `active`, `content`,`name`,`productTranche_id`,`template_id`,`validFrom`,`version`,`substitutionParamsJson`,`content_id`) VALUES ('2291', '2021-04-15 08:10:38', NULL, 1,'', 'ZP_Produktinformationsblatt_MyMoney_Flexgeld24.pdf', '13596', '107', '2021-04-15', '6', '{\"interestRate\":\"0,01%\",\"documentCreationDate\":\"15.04.2021\",\"minAmount\":\"1\",\"textInterestRate\":\"Zinssatz ab 15.04.2021: 0,01% p.a.\",\"minAmountWithCUAndDot\":\"1 EUR.\",\"relationshipModel\":\"Treuhandanlage\",\"interestRateWithPa\":\"0,01% p.a.\",\"currentTextInterestRate\":\"Aktueller Zinsatz: 0,01% p.a. (seit: 15.04.2021)\",\"textNewInterestRate\":\"\",\"maxProductAmount\":\"1.000.000 EUR\",\"minProductAmount\":\"1 EUR\",\"noticePeriodInDays\":\"0\",\"minAmountWithCU\":\"1 EUR\",\"withholdingTaxRate\":\"0,00%\",\"investmentProtectionTresholdValidFrom\":\"01.01.2020\",\"maxAmountWithCU\":\"1.000.000 EUR\",\"cutOffAmountWithCurrency\":\"\",\"maxAmount\":\"1.000.000\",\"nextTextInterestRate\":\"\",\"investmentProtectionTresholdVolume\":\"44,88\"}',NULL);
/*!40000 ALTER TABLE `b2c_document_product_information` ENABLE KEYS */;
UNLOCK TABLES;

-- PB Dump completed
