-- Dumping data for table `b2c_product_bank`,`b2c_product_tranche`,`b2c_product_tranche_call_alike_transfer`,`b2c_product_bank_interest_account` and
--
-- WHERE:  bic='CPLUDES1XXX-FG'

USE `comonea_b2c`;


-- For `b2c_product_tranche`
LOCK TABLES `b2c_product_tranche` WRITE;
/*!40000 ALTER TABLE `b2c_product_tranche` DISABLE KEYS */;
INSERT INTO `b2c_product_tranche` (`id`, `creationDate`, `lastModifiedDate`, `cut_off_amount_currency`, `cut_off_amount`, `depositType`, `endDate`, `max_amount_currency`, `max_amount`, `payInDeadline`, `transactionDate`, `productIdentifier`, `productName`, `infoProduct`, `productState`, `startDate`, `uuid`, `viewState`, `description`, `min_amount_currency`, `min_amount`, `marketing_rank`, `interestProduct_id`, `investmentChangeOnly`, `interestTaxation`, `canBeProlongated`, `noticePeriodInDays`, `targetGroup`)
VALUES
	(25668, '2020-11-26 14:08:01', NULL, 'EUR', 1000000.00, 'FIXED_TERM', '2022-03-31', 'EUR', 100000.00, '2021-03-30 00:00:00', '2021-03-31 16:00:00', 'AGRLFR22XXX-FG2M-2021-03-31', '', NULL, 'CREATED', '2021-03-31', 'f7c43f8f-69ef-4b04-99e5-9cdb176af776', 'HIDDEN', 'Das Festgeld der CA Consumer Finance S.A. ist eine Termineinlage, bei der ein vorab vereinbarter Anlagebetrag zwischen {minPayInAmount} EUR und {maxPayInAmount} mit einer festen Laufzeit von {duration} und einem festen Zinssatz von {interestRate}% p.a. angelegt wird.', 'EUR', 1.00, 7500, 475, 0, 'SERVICE_BANK', 1, 0, NULL);
INSERT INTO `b2c_product_tranche` (`id`, `creationDate`, `lastModifiedDate`, `cut_off_amount_currency`, `cut_off_amount`, `depositType`, `endDate`, `max_amount_currency`, `max_amount`, `payInDeadline`, `transactionDate`, `productIdentifier`, `productName`, `infoProduct`, `productState`, `startDate`, `uuid`, `viewState`, `description`, `min_amount_currency`, `min_amount`, `marketing_rank`, `interestProduct_id`, `investmentChangeOnly`, `interestTaxation`, `canBeProlongated`, `noticePeriodInDays`, `targetGroup`)
VALUES
	(25669, '2020-11-26 14:08:01', NULL, 'EUR', 1000000.00, 'FIXED_TERM', '2023-03-31', 'EUR', 100000.00, '2022-03-30 00:00:00', '2022-03-31 16:00:00', 'AGRLFR22XXX-FG2M-2022-03-31', '', NULL, 'CREATED', '2022-03-31', 'f7c43f8f-69ef-4b04-95e5-9cdb176af776', 'PUBLISHED', 'Das Festgeld der CA Consumer Finance S.A. ist eine Termineinlage, bei der ein vorab vereinbarter Anlagebetrag zwischen {minPayInAmount} EUR und {maxPayInAmount} mit einer festen Laufzeit von {duration} und einem festen Zinssatz von {interestRate}% p.a. angelegt wird.', 'EUR', 1.00, 7500, 475, 0, 'SERVICE_BANK', 1, 0, NULL);

/*!40000 ALTER TABLE `b2c_product_tranche` ENABLE KEYS */;
UNLOCK TABLES;

-- For `b2c_interest_rate`
LOCK TABLES `b2c_interest_rate` WRITE;
/*!40000 ALTER TABLE `b2c_interest_rate` DISABLE KEYS */;
INSERT INTO `b2c_interest_rate` VALUES (81,'2020-02-26 15:15:27',NULL,'0.00020','2020-05-03',25669);
INSERT INTO `b2c_interest_rate` VALUES (14,'2020-02-26 15:15:27',NULL,'0.00010','2020-05-03',25668);
/*!40000 ALTER TABLE `b2c_interest_rate` ENABLE KEYS */;
UNLOCK TABLES;


-- For `b2c_fixed_term_interest_approval`
LOCK TABLES `b2c_fixed_term_interest_approval` WRITE;
/*!40000 ALTER TABLE `b2c_fixed_term_interest_approval` DISABLE KEYS */;
INSERT INTO `b2c_fixed_term_interest_approval` VALUES (6,'2020-12-02 15:15:27',NULL,'marco','2020-12-02 15:15:27',25669);
INSERT INTO `b2c_fixed_term_interest_approval` VALUES (56,'2020-12-02 15:15:27',NULL,'marco','2020-12-02 15:15:27',25668);

/*!40000 ALTER TABLE `b2c_fixed_term_interest_approval` ENABLE KEYS */;
UNLOCK TABLES;


-- For `b2c_product_bank_interest_account`
LOCK TABLES `b2c_product_bank_interest_account` WRITE;
/*!40000 ALTER TABLE `b2c_product_bank_interest_account` DISABLE KEYS */;
INSERT INTO `b2c_product_bank_interest_account` (`id`, `creationDate`, `lastModifiedDate`, `accountHolder`, `iban`, `uuid`, `product_id`, `productBank_id`, `serviceBankTransitAccount_id`, `bic`, `payInBic`, `payInIban`, `closed`, `currency`, `ultimateCreditorIban`)
VALUES
	(33962, '2020-11-26 14:08:01', '2020-11-26 14:20:05', 'fffTyler Burmeister', 'FR1930006000019688554743422', 'f8f12d4a-3dde-4932-8406-70734b21195a', 25668, 83, 3, 'AGRIFRPPXXX', 'AGRIFRPPXXX', 'FR1930006000019688554743422', 0, 'EUR', NULL);
INSERT INTO `b2c_product_bank_interest_account` (`id`, `creationDate`, `lastModifiedDate`, `accountHolder`, `iban`, `uuid`, `product_id`, `productBank_id`, `serviceBankTransitAccount_id`, `bic`, `payInBic`, `payInIban`, `closed`, `currency`, `ultimateCreditorIban`)
VALUES
	(33963, '2020-11-26 14:08:01', '2020-11-26 14:20:05', 'fffTyler Burmeister', 'FR1930006000019688554743422', 'f8f12p4a-3dde-4932-8406-70734b21195a', 25669, 83, 3, 'AGRIFRPPXXX', 'AGRIFRPPXXX', 'FR1930006000019688554743422', 0, 'EUR', NULL);

/*!40000 ALTER TABLE `b2c_product_bank_interest_account` ENABLE KEYS */;
UNLOCK TABLES;

-- For `b2c_service_bank_product_mapping`
LOCK TABLES `b2c_service_bank_product_mapping` WRITE;
/*!40000 ALTER TABLE `b2c_service_bank_product_mapping` DISABLE KEYS */;
INSERT INTO `b2c_service_bank_product_mapping` VALUES ('31140','2020-11-03 18:04:12',NULL,'33962','25668','5','3');
INSERT INTO `b2c_service_bank_product_mapping` VALUES ('3140','2020-11-03 18:04:12',NULL,'33963','25669','5','3');
/*!40000 ALTER TABLE `b2c_service_bank_product_mapping` ENABLE KEYS */;
UNLOCK TABLES;

-- For `b2c_document_depositors_information`
LOCK TABLES `b2c_document_depositors_information` WRITE;
/*!40000 ALTER TABLE `b2c_document_depositors_information` DISABLE KEYS */;
INSERT INTO `b2c_document_depositors_information` VALUES ( '185', '2021-06-17 14:08:35', NULL, 1, 'PRODUCT_BANK', 'AGRLFR22XXX','', 'ZP_IFE_Cacf_N.V..pdf', '2021-06-17', '1');
/*!40000 ALTER TABLE `b2c_document_depositors_information` ENABLE KEYS */;
UNLOCK TABLES;

-- For `b2c_document_product_information_content`)
LOCK TABLES `b2c_document_product_information_content` WRITE;
/*!40000 ALTER TABLE `b2c_document_product_information_content` DISABLE KEYS */;
INSERT INTO `b2c_document_product_information_content` VALUES ('2', '2021-04-15 08:10:38', NULL, '{\"interestRate\":\"0,01%\",\"documentCreationDate\":\"15.04.2021\",\"minAmount\":\"1\",\"textInterestRate\":\"Zinssatz ab 15.04.2021: 0,01% p.a.\",\"minAmountWithCUAndDot\":\"1 EUR.\",\"relationshipModel\":\"Treuhandanlage\",\"interestRateWithPa\":\"0,01% p.a.\",\"currentTextInterestRate\":\"Aktueller Zinsatz: 0,01% p.a. (seit: 15.04.2021)\",\"textNewInterestRate\":\"\",\"maxProductAmount\":\"1.000.000 EUR\",\"minProductAmount\":\"1 EUR\",\"noticePeriodInDays\":\"0\",\"minAmountWithCU\":\"1 EUR\",\"withholdingTaxRate\":\"0,00%\",\"investmentProtectionTresholdValidFrom\":\"01.01.2020\",\"maxAmountWithCU\":\"1.000.000 EUR\",\"cutOffAmountWithCurrency\":\"\",\"maxAmount\":\"1.000.000\",\"nextTextInterestRate\":\"\",\"investmentProtectionTresholdVolume\":\"44,88\"}');
/*!40000 ALTER TABLE `b2c_document_product_information_content` ENABLE KEYS */;
UNLOCK TABLES;

-- For `b2c_document_product_information`
LOCK TABLES `b2c_document_product_information` WRITE;
/*!40000 ALTER TABLE `b2c_document_product_information` DISABLE KEYS */;
INSERT INTO `b2c_document_product_information` (`id`, `creationDate`, `lastModifiedDate`, `active`, `content`,`name`,`productTranche_id`,`template_id`,`validFrom`,`version`,`substitutionParamsJson`,`content_id`) VALUES ('11291', '2021-04-15 08:10:38', NULL, 1,'', 'ZP_Produtinformationsblatt_Cacf_FG2M.pdf', '25669', '1975', '2021-04-15', '6', '{\"interestRate\":\"0,01%\",\"documentCreationDate\":\"15.04.2021\",\"minAmount\":\"1\",\"textInterestRate\":\"Zinssatz ab 15.04.2021: 0,01% p.a.\",\"minAmountWithCUAndDot\":\"1 EUR.\",\"relationshipModel\":\"Treuhandanlage\",\"interestRateWithPa\":\"0,01% p.a.\",\"currentTextInterestRate\":\"Aktueller Zinsatz: 0,01% p.a. (seit: 15.04.2021)\",\"textNewInterestRate\":\"\",\"maxProductAmount\":\"1.000.000 EUR\",\"minProductAmount\":\"1 EUR\",\"noticePeriodInDays\":\"0\",\"minAmountWithCU\":\"1 EUR\",\"withholdingTaxRate\":\"0,00%\",\"investmentProtectionTresholdValidFrom\":\"01.01.2020\",\"maxAmountWithCU\":\"1.000.000 EUR\",\"cutOffAmountWithCurrency\":\"\",\"maxAmount\":\"1.000.000\",\"nextTextInterestRate\":\"\",\"investmentProtectionTresholdVolume\":\"44,88\"}',2);
/*!40000 ALTER TABLE `b2c_document_product_information` ENABLE KEYS */;
UNLOCK TABLES;

-- Table Dump completed

