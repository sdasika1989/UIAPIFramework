package com.depositsolutions.common.restapi.services;

import static io.restassured.RestAssured.given;

import com.depositsolutions.common.restapi.helpers.Endpoints;
import com.depositsolutions.common.utils.ConfigManager;
import com.depositsolutions.common.utils.TestLogger;
import io.restassured.RestAssured;
import java.sql.SQLException;

public class Sbaff {

  public static Sbaff singleInstance = null;

  public static Sbaff getInstance() {
    if (singleInstance == null) {
      singleInstance = new Sbaff();
    }
    return singleInstance;
  }

  public void importCustomerToSbaffCD() {

    RestAssured.baseURI = ConfigManager.getInstance().getString("sbaff_cdUrl");

    given()
        .header("Content-Type", "application/json")
        .when()
        .post(Endpoints.sbaffCdCsvImport)
        .then()
        .log()
        .ifError()
        .assertThat()
        .statusCode(200);
    TestLogger.logInfo("API: Import customerlist.csv to sbaff_cd is successful");
  }

  public void exportCustomerSbaff(String CustNo) throws SQLException {
    RestAssured.baseURI = ConfigManager.getInstance().getString("sbaffUrl");

    given()
        .header("Content-Type", "application/json")
        .when()
        .post(Endpoints.DAOexport)
        .then()
        .log()
        .ifError()
        .assertThat()
        .statusCode(200);
    TestLogger.logInfo("API: digitalAccountOpening export is successful");
  }

  public void digitalAccountOpeningSbaff() {
    RestAssured.baseURI = ConfigManager.getInstance().getString("sbaffUrl");

    given()
        .header("Content-Type", "application/json")
        .when()
        .post(Endpoints.DAOimport)
        .then()
        .log()
        .ifError()
        .assertThat()
        .statusCode(200);
    TestLogger.logInfo("API: digitalAccountOpening import is successful");
  }
}
