package com.depositsolutions.common.reusables;

import com.depositsolutions.common.restapi.services.CoreBL;
import com.depositsolutions.common.restapi.services.ProdOps;
import com.depositsolutions.common.ui.helpers.WebUIOperations;
import com.depositsolutions.common.ui.zpuipageobjects.MailHogPO;
import com.depositsolutions.common.utils.TestLogger;
import java.time.LocalDate;
import org.testng.Assert;

public class ProdOpsServices {

  public static ProdOpsServices singleInstance = null;

  public static ProdOpsServices getInstance() {
    if (singleInstance == null) {
      singleInstance = new ProdOpsServices();
    }
    return singleInstance;
  }

  /*
   * This method calls sub-methods needs for Interest & Tax Booking for Call-a-Like
   * @param TrancheIdentifier
   * @param ValueDate
   */
  public void interestBooking(String TrancheIdentifier, LocalDate ValueDate, String CustomerEmail)
      throws InterruptedException {
    ProdOps.getInstance().bookInterest(TrancheIdentifier, ValueDate);
    ProdOps.getInstance().distributeInterest(TrancheIdentifier, ValueDate);
    CoreBL.getInstance().createInterestPayoutTickets(TrancheIdentifier, ValueDate);
    TestLogger.logInfo("Interest booking done sucessfully");
  }

  /*
   * This method calls sub-methods needs for Interest & Tax Booking and Prolongation for Fixed Term
   * @param TrancheIdentifier
   * @param ValueDate
   */
  public void interestBookingAndProlongation(
      String TrancheIdentifier, LocalDate ValueDate, String Type, String CustomerEmail)
      throws InterruptedException {
    ProdOps.getInstance().bookInterest(TrancheIdentifier, ValueDate);
    ProdOps.getInstance().distributeInterest(TrancheIdentifier, ValueDate);
    ProdOps.getInstance().initiateProlongation(TrancheIdentifier);
    MailHogPO.getInstance().openMailhog();
    if (Type.contains("PayOut")) {
      TestLogger.logMsg("Step-3a: Validate PayOut Email in MailHog");
      MailHogPO.getInstance().verifyEmail(CustomerEmail, "Auszahlung Ihrer Zinspilot Anlage");
    }
    ProdOps.getInstance().performProlongation(TrancheIdentifier);
    if (Type.contains("Prolongation")
        || Type.equalsIgnoreCase("PartialPayOut")
        || Type.equalsIgnoreCase("PartialIc")) {
      TestLogger.logMsg("Step-3b: Validate Prolongation Email in MailHog");
      Thread.sleep(2000);
      MailHogPO.getInstance().verifyEmail(CustomerEmail, "Ihre Festgeldanlage über Zinspilot");
    }

    MailHogPO.getInstance().closeMailhog();
    WebUIOperations.getInstance().switchTab(0);
    TestLogger.logInfo("Interest booking & Prolongation done sucessfully");
  }

  /*
   * This method calls sub-methods needed for processing tickets and validates the status in Database
   * @param TicketType
   * @param ServiceBank_BIC
   * @param CustomerTicket_id
   * @param TrancheIdentifier
   * @param CustomerEmail
   */
  public void ticketProcessing(
      String TicketType,
      String ServiceBank_BIC,
      String CustomerTicket_id,
      String TrancheIdentifier,
      String CustomerEmail) {
    String BankTicket_id;
    String PBankTicket_id;
    String IBankTicket_id;
    String SutorAccountId = DBReusables.getInstance().getSutorTransitAccountUUID(ServiceBank_BIC);
    String ProductAccountId =
        DBReusables.getInstance().getPbiaUUID(TrancheIdentifier, ServiceBank_BIC);
    String PB_BIC = DBReusables.getInstance().getPB_BIC_FromTrancheIdentifier(TrancheIdentifier);

    switch (TicketType) {
      case "INTEREST_TO_TRANSIT":
        String i2tITicket_id =
            DBReusables.getInstance()
                .getInterestTicket_id(DBReusables.getInstance().ci2tTable, CustomerEmail);
        ProdOps.getInstance().prepareTickets(TicketType, ProductAccountId, SutorAccountId);
        DBReusables.getInstance()
            .ticketStateValidation(
                CustomerTicket_id, "READY_FOR_AGGREGATION", DBReusables.getInstance().ci2tTable);
        DBReusables.getInstance()
            .ticketStateValidation(
                i2tITicket_id, "READY_FOR_AGGREGATION", DBReusables.getInstance().ci2tTable);
        ProdOps.getInstance().createTickets(TicketType, ProductAccountId, SutorAccountId, PB_BIC);
        DBReusables.getInstance()
            .ticketStateValidation(
                CustomerTicket_id, "ASSIGNED_TO_BANK_TICKET", DBReusables.getInstance().ci2tTable);
        DBReusables.getInstance()
            .ticketStateValidation(
                i2tITicket_id, "ASSIGNED_TO_BANK_TICKET", DBReusables.getInstance().ci2tTable);
        PBankTicket_id =
            DBReusables.getInstance()
                .getBankTransferTicketID(CustomerTicket_id, DBReusables.getInstance().ci2tTable);
        IBankTicket_id =
            DBReusables.getInstance()
                .getBankTransferTicketID(i2tITicket_id, DBReusables.getInstance().ci2tTable);
        Assert.assertNotNull(PBankTicket_id, "Principal Bank Tranfer ticket is not created");
        DBReusables.getInstance()
            .ticketStateValidation(PBankTicket_id, "CREATED", DBReusables.getInstance().bi2tTable);
        Assert.assertNotNull(IBankTicket_id, "Interest Bank Tranfer ticket is not created");
        DBReusables.getInstance()
            .ticketStateValidation(IBankTicket_id, "CREATED", DBReusables.getInstance().bi2tTable);
        ProdOps.getInstance()
            .ProcessTickets(TicketType, ServiceBank_BIC, ProductAccountId, SutorAccountId);
        DBReusables.getInstance()
            .ticketStateValidation(
                CustomerTicket_id, "ASSIGNED_TO_BANK_TICKET", DBReusables.getInstance().ci2tTable);
        DBReusables.getInstance()
            .ticketStateValidation(
                i2tITicket_id, "ASSIGNED_TO_BANK_TICKET", DBReusables.getInstance().ci2tTable);
        DBReusables.getInstance()
            .ticketStateValidation(
                PBankTicket_id, "SENT_TO_BANK", DBReusables.getInstance().bi2tTable);
        DBReusables.getInstance()
            .ticketStateValidation(
                IBankTicket_id, "SENT_TO_BANK", DBReusables.getInstance().bi2tTable);
        TestLogger.logInfo(
            "ProdOps Prepare,Generate and Process Ticket/s done successfully for TicketType:"
                + TicketType);
        break;
      case "TRANSIT_TO_CUSTOMER":
        String CustomerAccountId =
            DBReusables.getInstance()
                .getCTAUUID(CustomerTicket_id, DBReusables.getInstance().ct2cTable);
        String t2cITicket_id =
            DBReusables.getInstance()
                .getInterestTicket_id(DBReusables.getInstance().ct2cTable, CustomerEmail);
        ProdOps.getInstance().createTickets(TicketType, SutorAccountId, CustomerAccountId, PB_BIC);
        DBReusables.getInstance()
            .ticketStateValidation(
                CustomerTicket_id, "ASSIGNED_TO_BANK_TICKET", DBReusables.getInstance().ct2cTable);
        DBReusables.getInstance()
            .ticketStateValidation(
                t2cITicket_id, "ASSIGNED_TO_BANK_TICKET", DBReusables.getInstance().ct2cTable);
        PBankTicket_id =
            DBReusables.getInstance()
                .getBankTransferTicketID(CustomerTicket_id, DBReusables.getInstance().ct2cTable);
        IBankTicket_id =
            DBReusables.getInstance()
                .getBankTransferTicketID(t2cITicket_id, DBReusables.getInstance().ct2cTable);
        Assert.assertNotNull(PBankTicket_id, "Principal Bank Tranfer ticket is not created");
        DBReusables.getInstance()
            .ticketStateValidation(PBankTicket_id, "CREATED", DBReusables.getInstance().bt2cTable);
        Assert.assertNotNull(IBankTicket_id, "Interest Bank Tranfer ticket is not created");
        DBReusables.getInstance()
            .ticketStateValidation(IBankTicket_id, "CREATED", DBReusables.getInstance().bt2cTable);
        ProdOps.getInstance()
            .ProcessTickets(TicketType, ServiceBank_BIC, SutorAccountId, CustomerAccountId);
        DBReusables.getInstance()
            .ticketStateValidation(
                CustomerTicket_id, "ASSIGNED_TO_BANK_TICKET", DBReusables.getInstance().ct2cTable);
        DBReusables.getInstance()
            .ticketStateValidation(
                t2cITicket_id, "ASSIGNED_TO_BANK_TICKET", DBReusables.getInstance().ct2cTable);
        DBReusables.getInstance()
            .ticketStateValidation(
                PBankTicket_id, "SENT_TO_BANK", DBReusables.getInstance().bt2cTable);
        DBReusables.getInstance()
            .ticketStateValidation(
                IBankTicket_id, "SENT_TO_BANK", DBReusables.getInstance().bt2cTable);
        TestLogger.logInfo(
            "ProdOps Prepare,Generate and Process Ticket/s done successfully for TicketType:"
                + TicketType);
        break;
      case "TRANSIT_TO_INTEREST":
        ProdOps.getInstance().prepareTickets(TicketType, SutorAccountId, ProductAccountId);
        DBReusables.getInstance()
            .ticketStateValidation(
                CustomerTicket_id, "READY_FOR_AGGREGATION", DBReusables.getInstance().ct2iTable);
        ProdOps.getInstance().createTickets(TicketType, SutorAccountId, ProductAccountId, PB_BIC);
        DBReusables.getInstance()
            .ticketStateValidation(
                CustomerTicket_id, "ASSIGNED_TO_BANK_TICKET", DBReusables.getInstance().ct2iTable);
        BankTicket_id =
            DBReusables.getInstance()
                .getBankTransferTicketID(CustomerTicket_id, DBReusables.getInstance().ct2iTable);
        Assert.assertNotNull(BankTicket_id, "Bank Tranfer ticket is not created");
        DBReusables.getInstance()
            .ticketStateValidation(BankTicket_id, "CREATED", DBReusables.getInstance().bt2iTable);
        ProdOps.getInstance()
            .ProcessTickets(TicketType, ServiceBank_BIC, SutorAccountId, ProductAccountId);
        DBReusables.getInstance()
            .ticketStateValidation(
                CustomerTicket_id, "ASSIGNED_TO_BANK_TICKET", DBReusables.getInstance().ct2iTable);
        DBReusables.getInstance()
            .ticketStateValidation(
                BankTicket_id, "SENT_TO_BANK", DBReusables.getInstance().bt2iTable);
        TestLogger.logInfo(
            "ProdOps Prepare,Generate and Process Ticket/s done successfully for TicketType:"
                + TicketType);
        break;
    }
  }
  /*
   * This method calls sub-methods needed for processing of principal tickets and validates the status in Database
   * @param TicketType
   * @param ServiceBank_BIC
   * @param CustomerTicket_id
   * @param TrancheIdentifier
   * @param CustomerEmail
   */
  public void principalTicketProcessing(
      String TicketType,
      String ServiceBank_BIC,
      String CustomerTicket_id,
      String TrancheIdentifier,
      String CustomerEmail) {
    String PBankTicket_id;
    String SutorAccountId = DBReusables.getInstance().getSutorTransitAccountUUID(ServiceBank_BIC);
    String ProductAccountId =
        DBReusables.getInstance().getPbiaUUID(TrancheIdentifier, ServiceBank_BIC);
    String PB_BIC = DBReusables.getInstance().getPB_BIC_FromTrancheIdentifier(TrancheIdentifier);

    switch (TicketType) {
      case "INTEREST_TO_TRANSIT":
        ProdOps.getInstance().prepareTickets(TicketType, ProductAccountId, SutorAccountId);
        DBReusables.getInstance()
            .ticketStateValidation(
                CustomerTicket_id, "READY_FOR_AGGREGATION", DBReusables.getInstance().ci2tTable);
        ProdOps.getInstance().createTickets(TicketType, ProductAccountId, SutorAccountId, PB_BIC);
        DBReusables.getInstance()
            .ticketStateValidation(
                CustomerTicket_id, "ASSIGNED_TO_BANK_TICKET", DBReusables.getInstance().ci2tTable);
        PBankTicket_id =
            DBReusables.getInstance()
                .getBankTransferTicketID(CustomerTicket_id, DBReusables.getInstance().ci2tTable);
        Assert.assertNotNull(PBankTicket_id, "Principal Bank Tranfer ticket is not created");
        DBReusables.getInstance()
            .ticketStateValidation(PBankTicket_id, "CREATED", DBReusables.getInstance().bi2tTable);
        ProdOps.getInstance()
            .ProcessTickets(TicketType, ServiceBank_BIC, ProductAccountId, SutorAccountId);
        DBReusables.getInstance()
            .ticketStateValidation(
                CustomerTicket_id, "ASSIGNED_TO_BANK_TICKET", DBReusables.getInstance().ci2tTable);
        DBReusables.getInstance()
            .ticketStateValidation(
                PBankTicket_id, "SENT_TO_BANK", DBReusables.getInstance().bi2tTable);
        TestLogger.logInfo(
            "ProdOps Prepare,Generate and Process Ticket/s done successfully for TicketType:"
                + TicketType);
        break;
      case "TRANSIT_TO_CUSTOMER":
        String CustomerAccountId =
            DBReusables.getInstance()
                .getCTAUUID(CustomerTicket_id, DBReusables.getInstance().ct2cTable);
        ProdOps.getInstance().createTickets(TicketType, SutorAccountId, CustomerAccountId, PB_BIC);
        DBReusables.getInstance()
            .ticketStateValidation(
                CustomerTicket_id, "ASSIGNED_TO_BANK_TICKET", DBReusables.getInstance().ct2cTable);
        PBankTicket_id =
            DBReusables.getInstance()
                .getBankTransferTicketID(CustomerTicket_id, DBReusables.getInstance().ct2cTable);
        Assert.assertNotNull(PBankTicket_id, "Principal Bank Tranfer ticket is not created");
        DBReusables.getInstance()
            .ticketStateValidation(PBankTicket_id, "CREATED", DBReusables.getInstance().bt2cTable);
        ProdOps.getInstance()
            .ProcessTickets(TicketType, ServiceBank_BIC, SutorAccountId, CustomerAccountId);
        DBReusables.getInstance()
            .ticketStateValidation(
                CustomerTicket_id, "ASSIGNED_TO_BANK_TICKET", DBReusables.getInstance().ct2cTable);
        DBReusables.getInstance()
            .ticketStateValidation(
                PBankTicket_id, "SENT_TO_BANK", DBReusables.getInstance().bt2cTable);
        TestLogger.logInfo(
            "ProdOps Prepare,Generate and Process Ticket/s done successfully for TicketType:"
                + TicketType);
        break;
    }
  }
  /*
   * This method calls sub-methods needed for processing tickets and validates the status in Database
   * @param TicketType
   * @param ServiceBank_BIC
   * @param CustomerTicket_id
   * @param SourceTrancheIdentifier
   * @param CustomerEmail
   * @param TargetTrancheIdentifier
   */
  public void i2iticketProcessing(
      String TicketType,
      String ServiceBank_BIC,
      String CustomerTicket_id,
      String SourceTrancheIdentifier,
      String TargetTrancheIdentifier) {
    String sProductAccountId =
        DBReusables.getInstance().getPbiaUUID(SourceTrancheIdentifier, ServiceBank_BIC);
    String tProductAccountId =
        DBReusables.getInstance().getPbiaUUID(TargetTrancheIdentifier, ServiceBank_BIC);
    String PB_BIC =
        DBReusables.getInstance().getPB_BIC_FromTrancheIdentifier(SourceTrancheIdentifier);
    ProdOps.getInstance().prepareTickets(TicketType, sProductAccountId, tProductAccountId);
    DBReusables.getInstance()
        .ticketStateValidation(
            CustomerTicket_id, "READY_FOR_AGGREGATION", DBReusables.getInstance().ci2iTable);
    ProdOps.getInstance().createTickets(TicketType, sProductAccountId, tProductAccountId, PB_BIC);
    DBReusables.getInstance()
        .ticketStateValidation(
            CustomerTicket_id, "ASSIGNED_TO_BANK_TICKET", DBReusables.getInstance().ci2iTable);
    String BankTicket_id =
        DBReusables.getInstance()
            .getBankTransferTicketID(CustomerTicket_id, DBReusables.getInstance().ci2iTable);
    Assert.assertNotNull(BankTicket_id, "Bank Tranfer ticket is not created");
    DBReusables.getInstance()
        .ticketStateValidation(BankTicket_id, "CREATED", DBReusables.getInstance().bi2iTable);
    ProdOps.getInstance()
        .ProcessTickets(TicketType, ServiceBank_BIC, sProductAccountId, tProductAccountId);
    DBReusables.getInstance()
        .ticketStateValidation(CustomerTicket_id, "EXECUTED", DBReusables.getInstance().ci2iTable);
    DBReusables.getInstance()
        .ticketStateValidation(BankTicket_id, "EXECUTED", DBReusables.getInstance().bi2iTable);
    TestLogger.logInfo(
        "ProdOps Prepare,Generate and Process Ticket/s done successfully for TicketType:"
            + TicketType);
  }
}
