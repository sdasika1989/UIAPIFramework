USE `comonea_b2c`;

-- For `b2c_product_bank`
LOCK TABLES `b2c_product_bank` WRITE;
/*!40000 ALTER TABLE `b2c_product_bank` DISABLE KEYS */;
INSERT INTO `b2c_product_bank` VALUES (4,'2014-12-16 18:22:07','2019-06-19 12:55:48','CPLUDES1XXX',60030600,'CreditPlus Bank AG','DE','BDB','EUR',44880000.00,NULL,NULL,NULL,NULL,NULL,'HRB-Nr. 15624','DE 8 11 53 53 07','a0874981-0cc2-407a-83aa-3e9eb939b45c','CreditPlus Bank AG hat Ihren Hauptsitz in Stuttgart, wo sie 1960 gegründet wurde. Das Kerngeschäft der CreditPlus Bank ist das Konsumentenkreditgeschäft.','EUR',1000000.00,'100% CA Consumer Finance (Credit Agricole Gruppe)','2020-01-01',NULL,NULL,0.00000,'CUSTOMER_INTEREST_ACCOUNT_BASED','FIDUCIARY_ACCOUNT_MODEL',NULL,NULL,'CreditPlus',NULL,1,'-1','00:00:00',0,'09:00:00',0);
/*!40000 ALTER TABLE `b2c_product_bank` ENABLE KEYS */;
UNLOCK TABLES;

-- For `b2c_product_bank_logo`
LOCK TABLES `b2c_product_bank_logo` WRITE;
/*!40000 ALTER TABLE `b2c_product_bank_logo` DISABLE KEYS */;
INSERT INTO `b2c_product_bank_logo` VALUES (51,'2021-01-26 10:29:53.000000',NULL,'<?xml version="1.0" encoding="utf-8"?>
                                                                                  <!-- Generator: Adobe Illustrator 22.0.1, SVG Export Plug-In . SVG Version: 6.00 Build 0)  -->
                                                                                  <svg version="1.1" id="Calque_1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
                                                                                  	 viewBox="0 0 566.9 97.1" style="enable-background:new 0 0 566.9 97.1;" xml:space="preserve">
                                                                                  <style type="text/css">
                                                                                  	.st0{fill:#1AAEB7;}
                                                                                  	.st1{fill:#004B44;}
                                                                                  	.st2{fill:#EB3738;}
                                                                                  </style>
                                                                                  <g>
                                                                                  	<path class="st0" d="M0,53.7v-0.2c0-24,18.1-43.6,44-43.6c15.9,0,25.4,5.3,33.3,13L65.4,36.4c-6.5-5.9-13.1-9.5-21.6-9.5
                                                                                  		c-14.2,0-24.5,11.8-24.5,26.3v0.2c0,14.5,10,26.5,24.5,26.5c9.6,0,15.5-3.9,22.2-9.9L77.9,82c-8.7,9.3-18.3,15.1-34.6,15.1
                                                                                  		C18.4,97.1,0,77.9,0,53.7"/>
                                                                                  	<path class="st0" d="M84.7,31H103v13c3.7-8.9,9.8-14.7,20.6-14.2V49h-1c-12.2,0-19.6,7.4-19.6,22.8v23.9H84.7V31z"/>
                                                                                  	<path class="st0" d="M124.1,63.7v-0.2c0-18.4,13.1-33.6,31.9-33.6c21.6,0,31.5,16.8,31.5,35.1c0,1.4-0.1,3.1-0.2,4.8h-45
                                                                                  		c1.8,8.3,7.6,12.7,15.8,12.7c6.1,0,10.6-1.9,15.7-6.6l10.5,9.3c-6,7.5-14.7,12-26.4,12C138.5,97.1,124.1,83.4,124.1,63.7
                                                                                  		 M169.7,58.3c-1.1-8.2-5.9-13.7-13.6-13.7c-7.6,0-12.5,5.4-14,13.7H169.7z"/>
                                                                                  	<path class="st0" d="M192.2,63.4v-0.2c0-21.6,14.1-33.4,29.4-33.4c9.8,0,15.8,4.5,20.1,9.6V7.6h18.3v88h-18.3v-9.3
                                                                                  		c-4.5,6-10.6,10.5-20.1,10.5C206.6,96.8,192.2,85,192.2,63.4 M242,63.4v-0.2c0-10.7-7.1-17.8-15.7-17.8c-8.6,0-15.8,7-15.8,17.8
                                                                                  		v0.2c0,10.7,7.2,17.8,15.8,17.8C234.9,81.3,242,74.2,242,63.4"/>
                                                                                  	<path class="st0" d="M270.8,7.6h19.3v16.3h-19.3V7.6z M271.3,31h18.3v64.6h-18.3V31z"/>
                                                                                  	<path class="st0" d="M303.8,77.3V46.7h-7.7V31h7.7V14.5h18.3V31h15.2v15.7h-15.2v27.6c0,4.2,1.8,6.3,5.9,6.3c3.4,0,6.4-0.8,9-2.3
                                                                                  		V93c-3.9,2.3-8.3,3.7-14.5,3.7C311.4,96.7,303.8,92.2,303.8,77.3"/>
                                                                                  	<rect x="421" y="7.6" class="st0" width="18.3" height="88"/>
                                                                                  	<path class="st0" d="M450,72.8V31h18.3v36c0,8.7,4.1,13.1,11.1,13.1c7,0,11.4-4.5,11.4-13.1V31h18.3v64.6h-18.3v-9.2
                                                                                  		c-4.2,5.4-9.6,10.4-18.9,10.4C458.1,96.8,450,87.7,450,72.8"/>
                                                                                  	<path class="st0" d="M514.5,87.1l7.8-12.1c7,5.1,14.3,7.7,20.4,7.7c5.3,0,7.7-1.9,7.7-4.8v-0.2c0-4-6.3-5.3-13.4-7.5
                                                                                  		c-9-2.7-19.3-6.9-19.3-19.4v-0.2c0-13.1,10.6-20.5,23.6-20.5c8.2,0,17.1,2.8,24.1,7.5l-7,12.7c-6.4-3.7-12.8-6-17.5-6
                                                                                  		c-4.5,0-6.7,1.9-6.7,4.5v0.2c0,3.6,6.1,5.3,13.1,7.7c9,3,19.5,7.4,19.5,19.2V76c0,14.3-10.7,20.9-24.7,20.9
                                                                                  		C533.2,96.8,523.1,93.8,514.5,87.1"/>
                                                                                  	<rect x="347.9" y="88.3" class="st1" width="61.9" height="7.8"/>
                                                                                  	<g>
                                                                                  		<path class="st0" d="M383.4,0.5c-8.5,0-13.9,4-17.9,9.3V1.6h-16.3v74.6h16.3V51.5c3.9,4.6,9.2,8.6,17.9,8.6
                                                                                  			c13.6,0,26.1-10.5,26.1-29.7v-0.2c0-3.1-0.3-5.9-0.9-8.5L393.2,30c0,0.1,0,0.2,0,0.3v0.2c0,9.6-6.4,15.9-14,15.9
                                                                                  			c-7.6,0-13.9-6.3-13.9-15.9v-0.2c0-9.5,6.3-15.9,13.9-15.9c1.8,0,3.6,0.4,5.2,1.1L400.3,7C395.6,2.8,389.5,0.5,383.4,0.5z"/>
                                                                                  		<path class="st2" d="M373.7,19.6l3.4,7.7c1.8,3.4,4.7,4.3,7.5,2.9l29.1-15.6V0l-13.4,7l-15.9,8.4l-2.5,1.3
                                                                                  			C376.7,19.2,375.3,19.9,373.7,19.6z"/>
                                                                                  	</g>
                                                                                  </g>
                                                                                  </svg>
','CPLUDES1XXX.svg','CPLUDES1XXX');
/*!40000 ALTER TABLE `b2c_product_bank_logo` ENABLE KEYS */;
UNLOCK TABLES;

-- For `b2c_interest_product`
LOCK TABLES `b2c_interest_product` WRITE;
/*!40000 ALTER TABLE `b2c_interest_product` DISABLE KEYS */;
INSERT INTO `b2c_interest_product` VALUES ('187', '2017-09-06 16:01:26', '2018-11-23 13:26:40', 'CPLUDES1XXX-CALL_ALIKE', 'TWICE_A_MONTH', 'GERMAN_30_360', 'CALL_ALIKE','', 'CreditPlusTG', 4, 'EUR', 'PROLONGATION', 'PAYOUT','2017-11-23 13:26:40', 1);
INSERT INTO `b2c_interest_product` VALUES (5,'2015-08-06 18:28:10','2017-09-06 16:01:26','CPLUDES1XXX-FIXED_1Y','AFTER_TERM_END','GERMAN_30_360','FIXED_1Y',NULL,'CreditPlusFG12M',4,'EUR','PROLONGATION','PAYOUT',NULL,1);
INSERT INTO `b2c_interest_product` VALUES (15,'2015-08-06 18:28:10','2017-09-06 16:01:26','CPLUDES1XXX-FIXED_2Y','AFTER_TERM_END','GERMAN_30_360','FIXED_2Y',NULL,'CreditPlusFG24M',4,'EUR','PROLONGATION','PAYOUT',NULL,1);
/*!40000 ALTER TABLE `b2c_interest_product` ENABLE KEYS */;
UNLOCK TABLES;

-- For `b2c_document_depositors_information`
LOCK TABLES `b2c_document_depositors_information` WRITE;
/*!40000 ALTER TABLE `b2c_document_depositors_information` DISABLE KEYS */;
INSERT INTO `b2c_document_depositors_information` VALUES ('194', '2021-10-19 11:11:01', NULL, 1, 'PRODUCT_BANK', 'CPLUDES1XXX','', 'ZP_IFE_CreditPlus_Bank_AG.pdf', '2021-10-19', '1');
/*!40000 ALTER TABLE `b2c_document_depositors_information` ENABLE KEYS */;
UNLOCK TABLES;

-- For `b2c_document_product_information_template`
LOCK TABLES `b2c_document_product_information_template` WRITE;
/*!40000 ALTER TABLE `b2c_document_product_information_template` DISABLE KEYS */;
INSERT INTO `b2c_document_product_information_template` VALUES ('1075', '2021-03-17 13:32:21', NULL, 1, '', 'ZP_Produktinformationsblatt_Creditplus_Flexgeld24.pdf', 'DIRECT_ACCESS', '4', '2021-03-17', '4', NULL, '5', '187');
INSERT INTO `b2c_document_product_information_template` VALUES ('1073', '2021-03-17 13:25:37', '2021-06-08 14:24:43', 1, '', 'ZP_Produktsinformationsblatt_CreditPlus_FG.pdf', 'FIXED_TERM', '4', '2021-03-17', '5', NULL, '5', NULL);
/*!40000 ALTER TABLE `b2c_document_product_information_template` ENABLE KEYS */;
UNLOCK TABLES;
