package com.depositsolutions.common.ui.helpers;

import static ch.qos.logback.classic.Level.valueOf;
import static com.depositsolutions.common.reusables.TestConstants.DOCKER_LOG_LEVEL;
import static com.depositsolutions.common.utils.ConfigManager.getInstance;

import ch.qos.logback.classic.Logger;
import ch.qos.logback.classic.LoggerContext;
import ch.qos.logback.classic.encoder.PatternLayoutEncoder;
import ch.qos.logback.core.FileAppender;
import com.google.common.collect.ImmutableMap;
import de.comonea.testcontainers.ServiceInformation;
import de.comonea.testcontainers.compose.waitstrategies.DummyWaitStrategy;
import java.io.File;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.time.Duration;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import org.slf4j.LoggerFactory;
import org.testcontainers.containers.DockerComposeContainer;
import org.testcontainers.containers.output.Slf4jLogConsumer;
import org.testng.ISuite;
import org.testng.ISuiteListener;

public class DockerComposeDependant implements ISuiteListener {

  private static final org.slf4j.Logger LOGGER =
      LoggerFactory.getLogger(DockerComposeDependant.class);

  private final DockerComposeContainer<?> app;

  public DockerComposeDependant() {
    app = createDockerComposeContainer();
  }

  @Override
  public void onStart(ISuite suite) {
    LOGGER.info("Starting docker-compose application");
    app.start();
  }

  @Override
  public void onFinish(ISuite suite) {
    LOGGER.info("Stopping docker-compose application");
    app.stop();
  }

  public static final Path DOCKER_COMPOSE_FOLDER = Paths.get("target/classes/docker-compose");

  public static final List<String> DOCKER_COPOSE_FILES = getDockerComposeFiles();

  // core services

  public static final String DB_DOCKER_SERVICE_NAME = "percona_db";

  public static final String BL_DOCKER_SERVICE_NAME = "core_bl";

  public static final String ZP_BL_DOCKER_SERVICE_NAME = "zp_bl";

  public static final String DEPOSIT_DOCKER_SERVICE_NAME = "deposit";

  public static final String DRM_DOCKER_SERVICE_NAME = "contract-management";

  public static final String QUESTIONNAIRE_DOCKER_SERVICE_NAME = "customer-questionnaire";

  public static final String PRODUCT_DOCKER_SERVICE_NAME = "product";

  public static final String SBAFF_DOCKER_SERVICE_NAME = "sbaff";
  public static final String SBAFF_CD_DOCKER_SERVICE_NAME = "sbaff_cd";
  public static final String SBAFF_TRUSTOR_DOCKER_SERVICE_NAME = "sbaff-trustor";

  public static final String PRODOPS_DOCKER_SERVICE_NAME = "prodops";

  public static final String SPS_DOCKER_SERVICE_NAME = "sps";
  public static final String PUG_DOCKER_SERVICE_NAME = "pug";

  public static final String SHOP_SERVICE_NAME = "shop";

  public static final String MAILHOG = "mail-server";

  public static final String SUTOR_SFTP_SERVICE_NAME = "sftp-sutor-zp";
  public static final String SUTOR_SFTP_SPLITTER_SERVICE_NAME = "sftp-sutor-sm";

  public static Map<String, ServiceInformation> SERVICES_TO_PUBLISH = getServicesToPublish();

  public static List<String> getDockerComposeFiles() {
    return Arrays.asList("docker-compose.yml");
  }

  public static Path getDockerComposeFolder() {
    return DOCKER_COMPOSE_FOLDER;
  }

  public static Map<String, ServiceInformation> getServicesToPublish() {
    return ImmutableMap.<String, ServiceInformation>builder()
        .put(MAILHOG, createServiceInformation(8025, MAILHOG, "/"))
        .put(
            BL_DOCKER_SERVICE_NAME,
            createServiceInformation(8095, BL_DOCKER_SERVICE_NAME, "/health"))
        .put(DB_DOCKER_SERVICE_NAME, createServiceInformation(3306, DB_DOCKER_SERVICE_NAME, null))
        .put(
            PRODUCT_DOCKER_SERVICE_NAME,
            createServiceInformation(8040, PRODUCT_DOCKER_SERVICE_NAME, "/productBank"))
        .put(
            DEPOSIT_DOCKER_SERVICE_NAME,
            createServiceInformation(8049, DEPOSIT_DOCKER_SERVICE_NAME, "/event"))
        .put(
            SBAFF_DOCKER_SERVICE_NAME,
            createServiceInformation(8084, SBAFF_DOCKER_SERVICE_NAME, null))
        .put(
            SBAFF_CD_DOCKER_SERVICE_NAME,
            createServiceInformation(8064, SBAFF_CD_DOCKER_SERVICE_NAME, null))
        .put(
            SBAFF_TRUSTOR_DOCKER_SERVICE_NAME,
            createServiceInformation(8053, SBAFF_TRUSTOR_DOCKER_SERVICE_NAME, "/system/health"))
        .put(
            PRODOPS_DOCKER_SERVICE_NAME,
            createServiceInformation(8106, PRODOPS_DOCKER_SERVICE_NAME, "/login"))
        .put(
            DRM_DOCKER_SERVICE_NAME,
            createServiceInformation(8011, DRM_DOCKER_SERVICE_NAME, "/admin/actuator/health"))
        .put(
            QUESTIONNAIRE_DOCKER_SERVICE_NAME,
            createServiceInformation(
                8099, QUESTIONNAIRE_DOCKER_SERVICE_NAME, "/admin/actuator/health"))
        .put(
            SPS_DOCKER_SERVICE_NAME,
            createServiceInformation(8098, SPS_DOCKER_SERVICE_NAME, "/health"))
        .put(
            PUG_DOCKER_SERVICE_NAME,
            createServiceInformation(8008, PUG_DOCKER_SERVICE_NAME, "/login"))
        .put(SHOP_SERVICE_NAME, createServiceInformation(8196, SHOP_SERVICE_NAME, "/health"))
        .put(
            ZP_BL_DOCKER_SERVICE_NAME,
            createServiceInformation(9876, ZP_BL_DOCKER_SERVICE_NAME, "/health"))
        .put(
            SUTOR_SFTP_SPLITTER_SERVICE_NAME,
            createServiceInformation(8978, SUTOR_SFTP_SPLITTER_SERVICE_NAME, null))
        .put(SUTOR_SFTP_SERVICE_NAME, createServiceInformation(8079, SUTOR_SFTP_SERVICE_NAME, null))
        .build();
  }

  public static Map<String, String> getDockerComposeEnvVariables() {
    final String DOCKER_CONFIG_FILE = "DOCKER_CONFIG_FILE";
    String dockerConfigFile = System.getenv(DOCKER_CONFIG_FILE);
    if (dockerConfigFile == null || dockerConfigFile.isEmpty()) {
      return ImmutableMap.of();
    }
    return ImmutableMap.of(DOCKER_CONFIG_FILE, dockerConfigFile);
  }

  public static Integer getPortForService(String serviceName) {
    return SERVICES_TO_PUBLISH.get(serviceName).getExposedPort();
  }

  private static ServiceInformation createServiceInformation(
      int exposedPort, String serviceName, String healthPath) {
    ServiceInformation s = new ServiceInformation(exposedPort, createLogger(serviceName));
    if (healthPath != null) {
      s.setWaitStrategy(
          new HttpWaitStrategy()
              .forPath(healthPath)
              .forPort(exposedPort)
              .forStatusCode(200)
              .withReadTimeout(Duration.ofSeconds(5))
              .withStartupTimeout(Duration.ofMinutes(15)));
    }
    return s;
  }

  private static DockerComposeContainer<?> createDockerComposeContainer() {
    List<File> dockerComposeFiles = new ArrayList();
    Path dockerComposeFolder = getDockerComposeFolder();
    DOCKER_COPOSE_FILES.forEach(
        (fileName) -> {
          dockerComposeFiles.add(dockerComposeFolder.resolve(fileName).toFile());
        });
    DockerComposeContainer<?> result = new DockerComposeContainer(dockerComposeFiles);

    for (Entry<String, ServiceInformation> serviceToPublish : getServicesToPublish().entrySet()) {
      String serviceName = serviceToPublish.getKey();
      ServiceInformation serviceInformation = serviceToPublish.getValue();
      Integer exposedPort = serviceInformation.getExposedPort();
      result.withExposedService(
          serviceName,
          1,
          exposedPort,
          serviceInformation.getWaitStrategy().orElseGet(DummyWaitStrategy::new));
      //      result.withTailChildContainers(true);
      //      result.withEnv(env);
      //      result.withPull(withPull);
      if (serviceInformation.getLogger().isPresent()) {
        LOGGER.info(
            "Service {} logs to {}", serviceName, serviceInformation.getLogger().get().getName());
        result.withLogConsumer(
            serviceName, new Slf4jLogConsumer(serviceInformation.getLogger().get()));
      }
    }
    return result;
  }

  private static Logger createLogger(String serviceName) {
    Logger logger = (Logger) LoggerFactory.getLogger(serviceName);
    LoggerContext lc = (LoggerContext) LoggerFactory.getILoggerFactory();
    PatternLayoutEncoder ple = new PatternLayoutEncoder();
    FileAppender fileAppender = new FileAppender<>();
    fileAppender.setFile(serviceName + ".log");
    fileAppender.setEncoder(ple);
    fileAppender.setAppend(false);
    fileAppender.setContext(lc);
    fileAppender.start();

    logger.addAppender(fileAppender);
    ple.setPattern("%date %level [%thread] %logger{10} [%file:%line] %msg%n");
    ple.setContext(lc);
    ple.start();
    logger.setLevel(valueOf(getInstance().getString(DOCKER_LOG_LEVEL)));
    return logger;
  }
}
