package com.depositsolutions.common.ui.helpers;

import com.depositsolutions.common.utils.ConfigManager;
import com.depositsolutions.common.utils.TestLogger;
import java.util.ArrayList;
import java.util.List;
import java.util.function.Function;
import org.openqa.selenium.*;
import org.openqa.selenium.interactions.Action;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

public class WebUIOperations extends BaseTestClassUI {
  public static WebUIOperations singleInstance = null;
  WebDriverWait wait =
      new WebDriverWait(
          DRIVER, Long.parseLong(ConfigManager.getInstance().getString("explicitTimeOut")));

  public static WebUIOperations getInstance() {
    if (singleInstance == null) {
      singleInstance = new WebUIOperations();
    }
    return singleInstance;
  }

  public void waitForElementAndClick(WebElement element) {
    try {
      wait.until((Function<WebDriver, WebElement>) ExpectedConditions.visibilityOf(element));
      if (element.isDisplayed()) {
        element.click();
      }
    } catch (Exception e) {
      System.out.println("Script failed with Exception" + e);
    }
  }

  public void verifyElementIsPresent(WebElement element, String webElementName) {
    try {
      wait.until((Function<WebDriver, WebElement>) ExpectedConditions.visibilityOf(element));
      if (element.isDisplayed()) {

        TestLogger.logInfo(webElementName + " Element is Present");
      }
    } catch (Exception e) {
      TestLogger.logInfo("Script failed with Exception" + e);
    }
  }

  public void sendKeys(WebElement element, String key) {

    try {
      wait.until((Function<WebDriver, WebElement>) ExpectedConditions.visibilityOf(element));
      if (element.isDisplayed()) {
        element.clear();
        element.sendKeys(key);
      }
    } catch (Exception e) {
      System.out.println("Script failed with Exception" + e);
    }
  }

  public void dragAndDrop(WebElement sourcePopupWebElement, WebElement targetTextWebElement) {
    Actions builder = new Actions(DRIVER);
    Action dragAndDrop =
        builder
            .clickAndHold(sourcePopupWebElement)
            .moveToElement(targetTextWebElement)
            .release(targetTextWebElement)
            .build();
    dragAndDrop.perform();
    TestLogger.logInfo("Drag and Drop Successful");
  }

  public void selectDropdownByText(WebElement selectName, String value) {
    Select DropDown = new Select(selectName);
    wait.until(ExpectedConditions.visibilityOf(selectName));
    DropDown.selectByVisibleText(value);
    TestLogger.logInfo(value + " is selected from Dropdown");
  }

  public void selectDropdownByValue(WebElement selectName, String value) {
    Select DropDown = new Select(selectName);
    wait.until(ExpectedConditions.visibilityOf(selectName));
    DropDown.selectByValue(value);
    TestLogger.logInfo(value + " is selected from Dropdown");
  }

  public void switchTab(int tabIndex) {
    ArrayList<String> tabs = new ArrayList<String>(DRIVER.getWindowHandles());
    DRIVER.switchTo().window(tabs.get(tabIndex));
    TestLogger.logInfo("Switch Tab Successful");
  }

  public void scrollDownThePage() {
    JavascriptExecutor Scroll = (JavascriptExecutor) DRIVER;
    Scroll.executeScript("window.scrollBy(0,250)", "");
  }

  public String getFirstSelectedOption(WebElement element) {
    Select select = new Select(element);
    String selectedValue = select.getFirstSelectedOption().getText();
    return selectedValue;
  }

  public String waitToGetFirstSelectedOption(WebElement selectElement) {
    Select select = new Select(selectElement);
    wait.until(ExpectedConditions.visibilityOf(selectElement));
    return select.getFirstSelectedOption().getText();
  }

  public void handleWindowPopup(String action) {
    // Switching to Alert
    Alert alert = DRIVER.switchTo().alert();
    if (action.equalsIgnoreCase("OK")) {
      // Accepting alert
      alert.accept();
    } else {
      // Dismiss alert
      alert.dismiss();
    }
  }

  public void scrollUpThePage() {
    JavascriptExecutor Scroll = (JavascriptExecutor) DRIVER;
    Scroll.executeScript("window.scrollBy(0,-250)", "");
  }

  public void verifyElementPresence(List<WebElement> element, String presence) {
    List<WebElement> elements = element;
    if (presence.equalsIgnoreCase("present")) {
      Assert.assertTrue(elements.size() > 0 && elements.get(0).isDisplayed());
    } else {
      Assert.assertFalse(elements.size() > 0 && elements.get(0).isDisplayed());
    }
  }
}
