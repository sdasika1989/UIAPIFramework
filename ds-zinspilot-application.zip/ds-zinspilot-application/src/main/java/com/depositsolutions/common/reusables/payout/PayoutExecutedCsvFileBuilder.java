package com.depositsolutions.common.reusables.payout;

import com.depositsolutions.common.reusables.PaymentServices;
import de.depositsolutions.common.IBAN;
import java.math.BigDecimal;
import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import org.apache.commons.lang3.builder.ToStringBuilder;

public class PayoutExecutedCsvFileBuilder {

  private List<SutorPayoutResponseItem> items = new ArrayList<>();

  public PayoutExecutedCsvFileBuilder addItem(SutorPayoutResponseItem sutorPayoutResponseItem) {
    items.add(sutorPayoutResponseItem);
    return this;
  }

  public String buildToCsv() {

    final StringBuilder result =
        new StringBuilder(
            "Comonea-Kundennummer;Zinspilot-Kontonummer;Verwendungszweck Comonea;Rueckzahlung;Zinsen;Anrechenbare Quellensteuer;Versteuerung eingeschaltet;BIC Produktbank;KESt;KiSt;Soli;interest_payment_date;withholding_tax;uniquePayoutOrderId\n");

    final String SEPARATOR = ";";

    for (SutorPayoutResponseItem sutorPayoutResponseItem : items) {
      result.append(sutorPayoutResponseItem.getComoneaKundennummer());
      result.append(SEPARATOR);
      result.append(sutorPayoutResponseItem.getZinspilotKontonummer());
      result.append(SEPARATOR);
      result.append(sutorPayoutResponseItem.getVerwendungszweck());
      result.append(SEPARATOR);
      result.append(toString(sutorPayoutResponseItem.getAmount()));
      result.append(SEPARATOR);
      result.append(toString(sutorPayoutResponseItem.getZinsen()));
      result.append(SEPARATOR);
      result.append(toString(sutorPayoutResponseItem.getQuellensteuer()));
      result.append(SEPARATOR);
      result.append(toString(sutorPayoutResponseItem.getVersteuert()));
      result.append(SEPARATOR);
      result.append(sutorPayoutResponseItem.getProductbankBIC());
      result.append(SEPARATOR);
      result.append(toString(sutorPayoutResponseItem.getKest()));
      result.append(SEPARATOR);
      result.append(toString(sutorPayoutResponseItem.getKist()));
      result.append(SEPARATOR);
      result.append(toString(sutorPayoutResponseItem.getSoli()));
      result.append(SEPARATOR);
      result.append(sutorPayoutResponseItem.getInterestpaymentdate());
      result.append(SEPARATOR);
      result.append(sutorPayoutResponseItem.getWithholdingtax());
      result.append(SEPARATOR);
      result.append(sutorPayoutResponseItem.getUniquePayoutOrderId());
      result.append(System.lineSeparator());
    }

    return result.toString();
  }

  static String toString(BigDecimal amount) {
    DecimalFormat df =
        new DecimalFormat("##00.00", DecimalFormatSymbols.getInstance(Locale.GERMAN));
    df.setParseBigDecimal(true);
    String result = df.format(amount);
    return result;
  }

  static String toString(boolean versteuert) {
    if (versteuert) {
      return "1";
    } else {
      return "0";
    }
  }

  public static class SutorPayoutResponseItem {

    private final String comoneaKundennummer;

    private final String zinspilotKontonummer;

    private final String verwendungszweck;

    private final BigDecimal amount;

    private final BigDecimal zinsen;

    private final BigDecimal quellensteuer;

    private final boolean versteuert;

    private final String productbankBIC;

    private final BigDecimal kest;

    private final BigDecimal kist;

    private final BigDecimal soli;

    private final String interestpaymentdate;

    private final String withholdingtax;

    public boolean isVersteuert() {
      return versteuert;
    }

    public String getInterestpaymentdate() {
      return interestpaymentdate;
    }

    public String getWithholdingtax() {
      return withholdingtax;
    }

    public String getUniquePayoutOrderId() {
      return uniquePayoutOrderId;
    }

    private final String uniquePayoutOrderId;

    public SutorPayoutResponseItem(
        final String comoneaKundennummer,
        final String zinspilotKontonummer,
        final String verwendungszweck,
        final BigDecimal amount,
        final BigDecimal zinsen,
        final BigDecimal quellensteuer,
        final boolean versteuert,
        final String productbankBIC,
        final BigDecimal kest,
        final BigDecimal kist,
        final BigDecimal soli,
        final String interestpaymentdate,
        final String withholdingtax,
        final String uniquePayoutOrderId) {
      this.comoneaKundennummer = comoneaKundennummer;
      this.zinspilotKontonummer = zinspilotKontonummer;
      this.verwendungszweck = verwendungszweck;
      this.amount = amount;
      this.zinsen = zinsen;
      this.quellensteuer = quellensteuer;
      this.versteuert = versteuert;
      this.productbankBIC = productbankBIC;
      this.kest = kest;
      this.kist = kist;
      this.soli = soli;
      this.interestpaymentdate = interestpaymentdate;
      this.withholdingtax = withholdingtax;
      this.uniquePayoutOrderId = uniquePayoutOrderId;
    }

    public SutorPayoutResponseItem(
        final PaymentServices.TransitToCustomerDetails transitToCustomerDetails) {
      this.comoneaKundennummer = transitToCustomerDetails.getCustomerNumber();
      this.zinspilotKontonummer =
          new IBAN(transitToCustomerDetails.getIban()).getBankAccountNumber();
      this.verwendungszweck =
          transitToCustomerDetails.getPbBic() + "__" + transitToCustomerDetails.getUuid();
      this.amount = transitToCustomerDetails.getMoneyAmount();
      this.zinsen =
          transitToCustomerDetails.getCategory().equalsIgnoreCase("PRINCIPAL")
              ? BigDecimal.ZERO
              : transitToCustomerDetails.getMoneyAmount();
      this.quellensteuer = BigDecimal.ZERO;
      this.versteuert = transitToCustomerDetails.getCategory().equalsIgnoreCase("GROSS_INTEREST");
      this.productbankBIC = transitToCustomerDetails.getPbBic();
      this.kest = BigDecimal.ZERO;
      this.kist = BigDecimal.ZERO;
      this.soli = BigDecimal.ZERO;
      this.interestpaymentdate = LocalDate.now().toString();
      this.withholdingtax = BigDecimal.ZERO.toString();
      this.uniquePayoutOrderId = transitToCustomerDetails.getUuid();
    }

    public String getComoneaKundennummer() {
      return comoneaKundennummer;
    }

    public String getZinspilotKontonummer() {
      return zinspilotKontonummer;
    }

    public String getVerwendungszweck() {
      return verwendungszweck;
    }

    public BigDecimal getAmount() {
      return amount;
    }

    public BigDecimal getZinsen() {
      return zinsen;
    }

    public BigDecimal getQuellensteuer() {
      return quellensteuer;
    }

    public boolean getVersteuert() {
      return versteuert;
    }

    public String getProductbankBIC() {
      return productbankBIC;
    }

    public BigDecimal getKest() {
      return kest;
    }

    public BigDecimal getKist() {
      return kist;
    }

    public BigDecimal getSoli() {
      return soli;
    }
  }

  public static class PayoutExecuted {
    private String fileUuid;

    public BigDecimal getMoneyAmount() {
      return moneyAmount;
    }

    @Override
    public String toString() {
      return new ToStringBuilder(this)
          .append("fileUuid", fileUuid)
          .append("moneyAmount", moneyAmount)
          .append("category", category)
          .toString();
    }

    public void setMoneyAmount(BigDecimal moneyAmount) {
      this.moneyAmount = moneyAmount;
    }

    private BigDecimal moneyAmount;

    public String getFileUuid() {
      return fileUuid;
    }

    public void setFileUuid(String fileUuid) {
      this.fileUuid = fileUuid;
    }

    public String getCategory() {
      return category;
    }

    private String category;
  }
}
