package com.depositsolutions.common.ui.helpers;

public class TestProperties {}
