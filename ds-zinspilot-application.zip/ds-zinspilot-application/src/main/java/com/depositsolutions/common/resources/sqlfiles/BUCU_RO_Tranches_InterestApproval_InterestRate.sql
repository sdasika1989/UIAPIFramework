--BUCU

--Dumping data for 'b2c_product_tranche' table

USE `comonea_b2c`;
LOCK TABLES `b2c_product_tranche` WRITE;
/*!40000 ALTER TABLE `b2c_product_tranche` DISABLE KEYS */;
INSERT INTO `comonea_b2c`.`b2c_product_tranche` (`id`, `creationDate`, `lastModifiedDate`, `cut_off_amount_currency`, `cut_off_amount`, `depositType`, `endDate`, `max_amount_currency`, `max_amount`, `payInDeadline`, `transactionDate`, `productIdentifier`, `productName`, `productState`, `startDate`, `uuid`, `viewState`, `description`, `min_amount_currency`, `min_amount`, `marketing_rank`, `interestProduct_id`, `investmentChangeOnly`, `interestTaxation`, `canBeProlongated`, `noticePeriodInDays`) VALUES ('25101', '2020-11-18 17:30:29', '2021-03-30 01:00:17', 'EUR', '1000000.00', 'FIXED_TERM', '2022-10-17', 'EUR', '100000.00', '2021-04-13 00:00:00', '2021-04-14 16:00:00', 'BUCUROBU-FG18M-2021-04-15', '', 'CREATED', '2021-04-15', 'ee6a45fb-669d-4f4f-bf5e-d0aa30317113', 'PUBLISHED', 'Das Festgeld der Alpha Bank Romania S.A. ist eine Termineinlage, bei der ein vorab vereinbarter Anlagebetrag zwischen {minPayInAmount} EUR und {maxPayInAmount} mit einer festen Laufzeit von {duration} und einem festen Zinssatz von {interestRate}% p.a. angelegt wird.', 'EUR', '1.00', '82', '48', '0', 'SERVICE_BANK', b'1', b'0');
INSERT INTO `comonea_b2c`.`b2c_product_tranche` (`id`, `creationDate`, `lastModifiedDate`, `cut_off_amount_currency`, `cut_off_amount`, `depositType`, `endDate`, `max_amount_currency`, `max_amount`, `payInDeadline`, `transactionDate`, `productIdentifier`, `productName`, `productState`, `startDate`, `uuid`, `viewState`, `description`, `min_amount_currency`, `min_amount`, `marketing_rank`, `interestProduct_id`, `investmentChangeOnly`, `interestTaxation`, `canBeProlongated`, `noticePeriodInDays`) VALUES ('25072', '2020-11-18 17:30:27', '2021-03-30 01:00:17', 'EUR', '1000000.00', 'FIXED_TERM', '2022-04-19', 'EUR', '100000.00', '2021-04-13 00:00:00', '2021-04-14 16:00:00', 'BUCUROBU-FG1Y-2021-04-15', '', 'CREATED', '2021-04-15', 'f186358a-9e7b-45a7-b9e0-03e7c964162e', 'PUBLISHED', 'Das Festgeld der Alpha Bank Romania S.A. ist eine Termineinlage, bei der ein vorab vereinbarter Anlagebetrag zwischen {minPayInAmount} EUR und {maxPayInAmount} mit einer festen Laufzeit von {duration} und einem festen Zinssatz von {interestRate}% p.a. angelegt wird.', 'EUR', '1.00', '178', '34', '0', 'SERVICE_BANK', b'1', b'0');
INSERT INTO `comonea_b2c`.`b2c_product_tranche` (`id`, `creationDate`, `lastModifiedDate`, `cut_off_amount_currency`, `cut_off_amount`, `depositType`, `endDate`, `max_amount_currency`, `max_amount`, `payInDeadline`, `transactionDate`, `productIdentifier`, `productName`, `productState`, `startDate`, `uuid`, `viewState`, `description`, `min_amount_currency`, `min_amount`, `marketing_rank`, `interestProduct_id`, `investmentChangeOnly`, `interestTaxation`, `canBeProlongated`, `noticePeriodInDays`) VALUES ('25132', '2020-11-18 17:30:33', '2021-03-30 01:00:17', 'EUR', '1000000.00', 'FIXED_TERM', '2023-04-18', 'EUR', '100000.00', '2021-04-13 00:00:00', '2021-04-14 16:00:00', 'BUCUROBU-FG2Y-2021-04-15', '', 'CREATED', '2021-04-15', '5f214fe2-8164-4164-b9e4-23a6af6a16d7', 'PUBLISHED', 'Das Festgeld der Alpha Bank Romania S.A. ist eine Termineinlage, bei der ein vorab vereinbarter Anlagebetrag zwischen {minPayInAmount} EUR und {maxPayInAmount} mit einer festen Laufzeit von {duration} und einem festen Zinssatz von {interestRate}% p.a. angelegt wird.', 'EUR', '1.00', '70', '35', '0', 'SERVICE_BANK', b'1', b'0');
INSERT INTO `comonea_b2c`.`b2c_product_tranche` (`id`, `creationDate`, `lastModifiedDate`, `cut_off_amount_currency`, `cut_off_amount`, `depositType`, `endDate`, `max_amount_currency`, `max_amount`, `payInDeadline`, `transactionDate`, `productIdentifier`, `productName`, `productState`, `startDate`, `uuid`, `viewState`, `description`, `min_amount_currency`, `min_amount`, `marketing_rank`, `interestProduct_id`, `investmentChangeOnly`, `interestTaxation`, `canBeProlongated`, `noticePeriodInDays`) VALUES ('25040', '2020-11-18 17:30:23', '2021-03-30 01:00:17', 'EUR', '1000000.00', 'FIXED_TERM', '2021-10-15', 'EUR', '100000.00', '2021-04-13 00:00:00', '2021-04-14 16:00:00', 'BUCUROBU-FG6M-2021-04-15', '', 'CREATED', '2021-04-15', 'e701989d-fd48-481f-ad2c-15ef7c1673b2', 'PUBLISHED', 'Das Festgeld der Alpha Bank Romania S.A. ist eine Termineinlage, bei der ein vorab vereinbarter Anlagebetrag zwischen {minPayInAmount} EUR und {maxPayInAmount} mit einer festen Laufzeit von {duration} und einem festen Zinssatz von {interestRate}% p.a. angelegt wird.', 'EUR', '1.00', '143', '33', '0', 'SERVICE_BANK', b'1', b'0');
INSERT INTO `comonea_b2c`.`b2c_product_tranche` (`id`, `creationDate`, `lastModifiedDate`, `depositType`, `max_amount_currency`, `max_amount`, `productIdentifier`, `productName`, `productState`, `uuid`, `viewState`, `min_amount_currency`, `min_amount`, `marketing_rank`, `interestProduct_id`, `investmentChangeOnly`, `interestTaxation`, `canBeProlongated`, `noticePeriodInDays`) VALUES ('1088', '2017-01-19 10:37:49', '2018-02-13 18:18:32', 'DIRECT_ACCESS', 'EUR', '100000.00', 'BUCUROBU-TG', '', 'CONNECTED', 'f0e04908-de2a-11e6-b6f9-000c29c84cff', 'PUBLISHED', 'EUR', '1.00', '175', '32', '0', 'SERVICE_BANK', b'1', b'0');
/*!40000 ALTER TABLE `b2c_product_tranche` ENABLE KEYS */;
UNLOCK TABLES;

--Dumping data for table 'b2c_interest_approval'

Use `comonea_b2c`;
LOCK TABLES `b2c_fixed_term_interest_approval` WRITE;
/*!40000 ALTER TABLE `b2c_fixed_term_interest_approval` DISABLE KEYS */;
INSERT INTO `comonea_b2c`.`b2c_fixed_term_interest_approval` (`id`, `creationDate`, `username`, `approvedOn`, `productTranche_id`) VALUES ('15636', '2021-03-26 15:21:35', 'fffa346580eayjxd.shawn.hardy@gmx.de', '2021-03-26 15:21:35', '25040');
INSERT INTO `comonea_b2c`.`b2c_fixed_term_interest_approval` (`id`, `creationDate`, `username`, `approvedOn`, `productTranche_id`) VALUES ('15638', '2021-03-26 15:21:35', 'fffa346580eayjxd.shawn.hardy@gmx.de', '2021-03-26 15:21:35', '25072');
INSERT INTO `comonea_b2c`.`b2c_fixed_term_interest_approval` (`id`, `creationDate`, `username`, `approvedOn`, `productTranche_id`) VALUES ('15637', '2021-03-26 15:21:35', 'fffa346580eayjxd.shawn.hardy@gmx.de', '2021-03-26 15:21:35', '25101');
INSERT INTO `comonea_b2c`.`b2c_fixed_term_interest_approval` (`id`, `creationDate`, `username`, `approvedOn`, `productTranche_id`) VALUES ('15639', '2021-03-26 15:21:35', 'fffa346580eayjxd.shawn.hardy@gmx.de', '2021-03-26 15:21:35', '25132');
/*!40000 ALTER TABLE `b2c_fixed_term_interest_approval` ENABLE KEYS */;
UNLOCK TABLES;

--Dumping data for table 'b2c_interest_rate'

USE `comonea_b2c`;
LOCK TABLES `b2c_interest_rate` WRITE;
/*!40000 ALTER TABLE `b2c_interest_rate` DISABLE KEYS */;
INSERT INTO `comonea_b2c`.`b2c_interest_rate` (`id`, `creationDate`, `rate`, `validFrom`, `product_id`) VALUES ('27656', '2021-02-15 12:09:47', '0.00250', '2021-03-15', '1088');
INSERT INTO `comonea_b2c`.`b2c_interest_rate` (`id`, `creationDate`, `lastModifiedDate`, `rate`, `validFrom`, `product_id`) VALUES ('25377', '2020-11-18 17:30:23', '2021-02-24 16:10:01', '0.00060', '2020-11-18', '25040');
INSERT INTO `comonea_b2c`.`b2c_interest_rate` (`id`, `creationDate`, `lastModifiedDate`, `rate`, `validFrom`, `product_id`) VALUES ('25409', '2020-11-18 17:30:27', '2021-02-24 16:10:14', '0.00300', '2020-11-18', '25072');
INSERT INTO `comonea_b2c`.`b2c_interest_rate` (`id`, `creationDate`, `lastModifiedDate`, `rate`, `validFrom`, `product_id`) VALUES ('25438', '2020-11-18 17:30:29', '2020-12-23 09:34:51', '0.00060', '2020-11-18', '25101');
INSERT INTO `comonea_b2c`.`b2c_interest_rate` (`id`, `creationDate`, `lastModifiedDate`, `rate`, `validFrom`, `product_id`) VALUES ('25469', '2020-11-18 17:30:33', '2020-12-23 09:35:30', '0.00240', '2020-11-18', '25132');
/*!40000 ALTER TABLE `b2c_interest_rate` ENABLE KEYS */;
UNLOCK TABLES;

