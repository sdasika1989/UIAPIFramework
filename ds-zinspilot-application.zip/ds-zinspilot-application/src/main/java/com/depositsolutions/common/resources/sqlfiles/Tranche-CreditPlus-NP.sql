-- Dumping data for table `b2c_product_bank`,`b2c_product_tranche`,`b2c_product_tranche_call_alike_transfer`,`b2c_product_bank_interest_account` and 
--
-- WHERE:  bic='CPLUDES1XXX-TG'

USE `comonea_b2c`;
-- For `b2c_product_tranche`
LOCK TABLES `b2c_product_tranche` WRITE;
/*!40000 ALTER TABLE `b2c_product_tranche` DISABLE KEYS */;
INSERT INTO `b2c_product_tranche` VALUES (5073,'2017-09-06 16:01:27','2018-02-13 18:18:32',NULL,NULL,'DIRECT_ACCESS',NULL,'EUR','1000000.00',NULL,NULL,'CPLUDES1XXX-TG-33','',NULL,'CONNECTED',NULL,'a39c002e-931c-11e7-baeb-000c293bd496','PUBLISHED','Das Flexgeld24 der CreditPlus Bank AG ist eine Spareinlage, bei der ein frei definierbarer Anlagebetrag von bis zu {maxPayInAmount} EUR mit einem variablen Zinssatz von zurzeit {interestRate}% p.a. angelegt werden kann. Die Zinszahlung für das Produkt Flexgeld24 erfolgt zweimal monatlich. Anlagen können zu den Zinszahlungsterminen gestartet und beendet werden, d.h.: Der Kunde hat mit dem Flexgeld24 die Flexibilität, sein Geld jeweils zum 1. und zum 15. eines Monats bzw. dem darauffolgenden Bankarbeitstag ein- oder auszuzahlen. Bitte beachten Sie die Angaben im Produktinformationsblatt zur Hinterlegung von Ausweisdaten.','EUR','1.00',170,187,0,'SERVICE_BANK',1,33,NULL);
/*!40000 ALTER TABLE `b2c_product_tranche` ENABLE KEYS */;
UNLOCK TABLES;

-- For `b2c_interest_rate`
LOCK TABLES `b2c_interest_rate` WRITE;
/*!40000 ALTER TABLE `b2c_interest_rate` DISABLE KEYS */;
INSERT INTO `b2c_interest_rate` VALUES (1,'2020-02-26 15:15:27',NULL,'0.00050','2020-03-16',5073);
/*!40000 ALTER TABLE `b2c_interest_rate` ENABLE KEYS */;
UNLOCK TABLES;

-- For `b2c_product_tranche_call_alike_transfer`
LOCK TABLES `b2c_product_tranche_call_alike_transfer` WRITE;
/*!40000 ALTER TABLE `b2c_product_tranche_call_alike_transfer` DISABLE KEYS */;
INSERT INTO `b2c_product_tranche_call_alike_transfer` VALUES (1997,'2020-11-23 17:09:16',NULL,'2022-03-15',NULL,5073,'CLOSED','CLOSED');
INSERT INTO `b2c_product_tranche_call_alike_transfer` VALUES (1998,'2020-11-23 17:09:16',NULL,'2022-03-31',NULL,5073,'OPEN','OPEN');
/*!40000 ALTER TABLE `b2c_product_tranche_call_alike_transfer` ENABLE KEYS */;
UNLOCK TABLES;

-- For `b2c_product_bank_interest_account`
LOCK TABLES `b2c_product_bank_interest_account` WRITE;
/*!40000 ALTER TABLE `b2c_product_bank_interest_account` DISABLE KEYS */;
INSERT INTO `b2c_product_bank_interest_account` VALUES (7544,'2017-09-06 16:01:27',NULL,'fffLily Beele','DE29600306006565060610','a39c1788-931c-11e7-baeb-000c293bd496',5073,4,3,'CPLUDES1XXX','CPLUDES1XXX','DE29600306006565060610',0,'EUR',null);
/*!40000 ALTER TABLE `b2c_product_bank_interest_account` ENABLE KEYS */;
UNLOCK TABLES;

-- For `b2c_service_bank_product_mapping`
LOCK TABLES `b2c_service_bank_product_mapping` WRITE;
/*!40000 ALTER TABLE `b2c_service_bank_product_mapping` DISABLE KEYS */;
INSERT INTO `b2c_service_bank_product_mapping` VALUES (7551,'2017-09-06 16:01:27',NULL,7544,5073,5,3);
/*!40000 ALTER TABLE `b2c_service_bank_product_mapping` ENABLE KEYS */;
UNLOCK TABLES;

-- For `b2c_document_product_information`
LOCK TABLES `b2c_document_product_information` WRITE;
/*!40000 ALTER TABLE `b2c_document_product_information` DISABLE KEYS */;
INSERT INTO `b2c_document_product_information` (`id`, `creationDate`, `lastModifiedDate`, `active`, `content`,`name`,`productTranche_id`,`template_id`,`validFrom`,`version`,`substitutionParamsJson`,`content_id`) VALUES ('112291', '2021-04-15 08:10:38', NULL, 1,'', 'ZP_Produktinformationsblatt_Creditplus_Flexgeld24.pdf', '5073', '1075', '2021-04-15', '6', '{\"interestRate\":\"0,01%\",\"documentCreationDate\":\"15.04.2021\",\"minAmount\":\"1\",\"textInterestRate\":\"Zinssatz ab 15.04.2021: 0,01% p.a.\",\"minAmountWithCUAndDot\":\"1 EUR.\",\"relationshipModel\":\"Treuhandanlage\",\"interestRateWithPa\":\"0,01% p.a.\",\"currentTextInterestRate\":\"Aktueller Zinsatz: 0,01% p.a. (seit: 15.04.2021)\",\"textNewInterestRate\":\"\",\"maxProductAmount\":\"1.000.000 EUR\",\"minProductAmount\":\"1 EUR\",\"noticePeriodInDays\":\"0\",\"minAmountWithCU\":\"1 EUR\",\"withholdingTaxRate\":\"0,00%\",\"investmentProtectionTresholdValidFrom\":\"01.01.2020\",\"maxAmountWithCU\":\"1.000.000 EUR\",\"cutOffAmountWithCurrency\":\"\",\"maxAmount\":\"1.000.000\",\"nextTextInterestRate\":\"\",\"investmentProtectionTresholdVolume\":\"44,88\"}',NULL);
/*!40000 ALTER TABLE `b2c_document_product_information` ENABLE KEYS */;
UNLOCK TABLES;

-- PB Dump completed
