package com.depositsolutions.common.reusables;

import static com.depositsolutions.common.reusables.TestConstants.CURRENT_WORKING_DIRECTORY;

import com.depositsolutions.common.reusables.payout.PayoutExecuted;
import com.depositsolutions.common.utils.ConfigManager;
import com.depositsolutions.common.utils.TestLogger;
import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.sql.SQLException;
import java.text.DateFormat;
import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.temporal.ChronoField;
import java.util.*;
import java.util.concurrent.ThreadLocalRandom;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.jdbc.datasource.init.ScriptUtils;
import org.sql2o.Connection;
import org.sql2o.Sql2o;
import org.sql2o.converters.Converter;
import org.sql2o.converters.joda.LocalDateConverter;
import org.sql2o.quirks.NoQuirks;
import org.testng.Assert;

public class DBReusables {
  public static DBReusables singleInstance = null;
  public final String ct2iTable = "b2c_customer_transfer_ticket_t_to_i";
  public final String ci2tTable = "b2c_customer_transfer_ticket_i_to_t";
  public final String ct2cTable = "b2c_customer_transfer_ticket_t_to_c";
  public final String ci2iTable = "b2c_customer_transfer_ticket_i_to_i";
  public final String cProTable = "b2c_customer_transfer_ticket_prolongation";
  public final String bt2iTable = "b2c_bank_transfer_ticket_t_to_i";
  public final String bi2iTable = "b2c_bank_transfer_ticket_i_to_i";
  public final String bi2tTable = "b2c_bank_transfer_ticket_i_to_t";
  public final String bt2cTable = "b2c_bank_transfer_ticket_t_to_c";
  public final String bProTable = "b2c_bank_transfer_ticket_prolongation";
  public final String b2c_schema = ConfigManager.getInstance().getString("b2c_schema");
  public final String sps_schema = ConfigManager.getInstance().getString("sps_schema");
  private static Connection connection;

  public static DBReusables getInstance() {
    if (singleInstance == null) {
      singleInstance = new DBReusables();
    }
    return singleInstance;
  }

  public void executeSqlScript(String SQLFileName) {
    try {
      TestLogger.logInfo("Executing SQL" + SQLFileName);
      File filepath =
          new File(
              CURRENT_WORKING_DIRECTORY
                  + "/src/main/java/com/depositsolutions/common/resources/sqlfiles/"
                  + SQLFileName);
      String sqlFile = new String(Files.readAllBytes(filepath.toPath()));

      try (Connection con = createSqlConnection().open()) {
        ScriptUtils.executeSqlScript(
            con.getJdbcConnection(), new ByteArrayResource(sqlFile.getBytes()));
      }
    } catch (IOException e) {
      throw new RuntimeException("Could not execute " + SQLFileName, e);
    }
  }

  public void dbConnect() {
    if (connection == null) {
      // To connect to the db with own user/AD credentials, set env variables, or values from excel
      // will be used
      Sql2o sql2o = createSqlConnection();
      TestLogger.logInfo("DBConnection is being established");
      connection = sql2o.open();
      Assert.assertNotNull(connection, "Unable to connect to DataBase");
    }
  }

  private Sql2o createSqlConnection() {
    final Map<Class, Converter> mappers = new HashMap<>();
    mappers.put(LocalDate.class, new LocalDateConverter());
    final String DB_Url = ConfigManager.getInstance().getString("DBConnectionUrl");
    final String username = ConfigManager.getInstance().getString("DBUser");
    final String password = ConfigManager.getInstance().getString("DBPassword");
    return new Sql2o(DB_Url, username, password, new NoQuirks(mappers));
  }

  public String getSpsImportFileStatus(String FileName) {
    String query =
        "SELECT state FROM " + sps_schema + ".bc_import_file where fileName='" + FileName + "';";
    return connection.createQuery(query).executeAndFetchFirst(String.class);
  }

  public String getInterestPercentage(String TrancheIdentifier) {
    String query =
        "SELECT rate FROM "
            + b2c_schema
            + ".b2c_interest_rate ir join "
            + b2c_schema
            + ".b2c_product_tranche pt on ir.product_id=pt.id where pt.productIdentifier='"
            + TrancheIdentifier
            + "' order by ir.creationDate desc;";
    String result = connection.createQuery(query).executeAndFetchFirst(String.class);
    double formatedResult = Double.parseDouble(result);
    NumberFormat numberFormat = NumberFormat.getInstance(Locale.GERMANY);
    numberFormat.setMinimumFractionDigits(2);
    return numberFormat.format(formatedResult * 100) + "%";
  }

  public void validateIFE(String TrancheIdentifier, String CustomerEmail) {
    String query =
        "SELECT i.bic FROM "
            + b2c_schema
            + ".b2c_document_depositors_information_accepted a join "
            + b2c_schema
            + ".b2c_document_depositors_information i on i.id=a.document_id join "
            + b2c_schema
            + ".b2c_customer c on c.id=a.customer_id where =c.emailAddress'"
            + CustomerEmail
            + "' order by a.creationDate desc;";
    String result = connection.createQuery(query).executeAndFetchFirst(String.class);
    Assert.assertEquals(
        result, getPB_BIC_FromTrancheIdentifier(TrancheIdentifier), "entry not created");
  }

  public String getActivationCode(String CustomerEmail) {
    String query =
        "SELECT ac.code FROM "
            + b2c_schema
            + ".b2c_customer c join "
            + b2c_schema
            + ".b2c_customer_activation_code ac on c.id=ac.customer_id where c.emailAddress='"
            + CustomerEmail
            + "';";
    return connection.createQuery(query).executeAndFetchFirst(String.class);
  }

  public String getCustomerState(String CustomerEmail) {
    String query =
        "select customerState from "
            + b2c_schema
            + ".b2c_customer where emailAddress='"
            + CustomerEmail
            + "';";
    return connection.createQuery(query).executeAndFetchFirst(String.class);
  }

  public String getCustomerProlongationType(String CIA, String amount) {
    String query =
        "select prolongationType from "
            + b2c_schema
            + ".b2c_cia_fixed_term_end_process_data where active=1 and customerInterestAccount_id='"
            + CIA
            + "' and payout_amount='"
            + amount
            + "';";
    return connection.createQuery(query).executeAndFetchFirst(String.class);
  }

  public String getCustomerProlongationEntry(String CIA) {
    String query =
        "select prolongationType from "
            + b2c_schema
            + ".b2c_cia_fixed_term_end_process_data where active=1 and customerInterestAccount_id='"
            + CIA
            + "';";
    return connection.createQuery(query).executeAndFetchFirst(String.class);
  }

  public String getProcessState(String CustNo) {
    String query =
        "SELECT processState FROM sbaff.account_opening where CustomerNumber='"
            + CustNo
            + "' order by creationDate desc;";
    return connection.createQuery(query).executeAndFetchFirst(String.class);
  }

  public String getReferenceID(String CustomerNum) {
    String query =
        "SELECT identProviderReferenceId FROM sbaff.account_opening where customerNumber='"
            + CustomerNum
            + "';";
    return connection.createQuery(query).executeAndFetchFirst(String.class);
  }

  public void UpdatePayOutAssignment(String TrancheIdentifier, String action) {

    String call_alike_transfer_id = call_alike_transfer_id(TrancheIdentifier);
    String query =
        "update "
            + b2c_schema
            + ".b2c_product_tranche_call_alike_transfer set payOutAssignment ='"
            + action
            + "' where id = '"
            + call_alike_transfer_id
            + "';";
    connection.createQuery(query).executeUpdate();
    TestLogger.logInfo("PayOutAssignment changed successfully to " + action);
  }

  public void shiftEarliestTransferToToday(String ticket_id, String tableName) {

    String query =
        "UPDATE "
            + b2c_schema
            + "."
            + tableName
            + " SET earliestTransferDate = NOW() where id='"
            + ticket_id
            + "';";

    connection.createQuery(query).executeUpdate();
    TestLogger.logInfo("Changed EarliestTransferDate as Today for table " + tableName);
  }

  public String getCTA(String CustomerEmail) {

    String query =
        "select cta.id from "
            + b2c_schema
            + ".b2c_customer_transit_account cta join "
            + b2c_schema
            + ".b2c_customer_depot cd on cta.`depot_id`=cd.id "
            + "join "
            + b2c_schema
            + ".b2c_customer_service_bank_affiliation csba on cd.serviceBankAffiliation_id = csba.id join "
            + b2c_schema
            + ".b2c_customer c on c.id = csba.customer_id and c.emailAddress = '"
            + CustomerEmail
            + "';";

    return connection.createQuery(query).executeAndFetchFirst(String.class);
  }

  public String getMaturityCode(String payInCode) {

    String query =
        "select maturityCode from "
            + b2c_schema
            + ".b2c_interest_product where payInCode='"
            + payInCode
            + "';";

    return connection.createQuery(query).executeAndFetchFirst(String.class);
  }

  public String getProductIdentifierFromInterestProduct(String TrancheIdentifier) {

    String query =
        "select ip.productIdentifier from "
            + b2c_schema
            + ".b2c_interest_product ip join "
            + b2c_schema
            + ".b2c_product_tranche pt on ip.id=pt.interestProduct_id where pt.productIdentifier='"
            + TrancheIdentifier
            + "';";
    return connection.createQuery(query).executeAndFetchFirst(String.class);
  }

  public String getTrancheEndDate(String TrancheIdentifier) {
    String query =
        "select endDate from "
            + b2c_schema
            + ".b2c_product_tranche where productIdentifier='"
            + TrancheIdentifier
            + "';";
    return connection.createQuery(query).executeAndFetchFirst(String.class);
  }

  public String getTrancheStartDate(String TrancheIdentifier) {
    String maturityCode = getMaturityCode(getPayInCodeFromTrancheIdentifier(TrancheIdentifier));

    if (maturityCode.equalsIgnoreCase("CALL")) {
      LocalDate today = LocalDate.now();
      int day = today.get(ChronoField.DAY_OF_WEEK);
      LocalDate date;
      if (day == 6) {
        date = today.plusDays(2);
      } else if (day == 7) {
        date = today.plusDays(1);
      } else {
        date = today;
      }
      return date.toString();

    } else if (maturityCode.equalsIgnoreCase("CALL_ALIKE")) {
      String query =
          "select ct.transferDate from "
              + b2c_schema
              + ".b2c_product_tranche_call_alike_transfer ct join "
              + b2c_schema
              + ".b2c_product_tranche pt on pt.id=ct.productTranche_id where pt.productIdentifier='"
              + TrancheIdentifier
              + "' and ct.transferDate>CURDATE() and ct.payInAssignment='OPEN' order by transferDate asc LIMIT 1;";

      return connection.createQuery(query).executeAndFetchFirst(String.class);
    } else {
      String query =
          "select startDate from "
              + b2c_schema
              + ".b2c_product_tranche where productIdentifier='"
              + TrancheIdentifier
              + "';";
      return connection.createQuery(query).executeAndFetchFirst(String.class);
    }
  }

  public String getTicketAmount(String ticket_id, String tableName) {

    String query =
        "select moneyAmount from " + b2c_schema + "." + tableName + " where id=" + ticket_id + ";";
    return connection.createQuery(query).executeAndFetchFirst(String.class);
  }

  public String getTicket_uuid(String ticket_id, String tableName) {

    String query =
        "Select uuid from " + b2c_schema + "." + tableName + " where id='" + ticket_id + "';";

    return connection.createQuery(query).executeAndFetchFirst(String.class);
  }

  public String getCustomerInterestAccount_id(String ticket_id, String tableName) {

    String query =
        "select customerInterestAccount_id from "
            + b2c_schema
            + "."
            + tableName
            + " where id="
            + ticket_id
            + ";";

    return connection.createQuery(query).executeAndFetchFirst(String.class);
  }

  public String getTargetInterestAccount_id(String ticket_id, String tableName) {

    String query =
        "select targetCustomerInterestAccount_id from "
            + b2c_schema
            + "."
            + tableName
            + " where id="
            + ticket_id
            + ";";

    return connection.createQuery(query).executeAndFetchFirst(String.class);
  }

  public String getSourceInterestAccount_id(String ticket_id, String tableName) {

    String query =
        "select sourceCustomerInterestAccount_id from "
            + b2c_schema
            + "."
            + tableName
            + " where id="
            + ticket_id
            + ";";

    return connection.createQuery(query).executeAndFetchFirst(String.class);
  }

  public String getEmailState(String CustomerNumber) {
    String query =
        "select status from "
            + b2c_schema
            + ".b2c_email where customerNumber='"
            + CustomerNumber
            + "' and mailType like '%InvestmentMail%';";
    return connection.createQuery(query).executeAndFetchFirst(String.class);
  }

  public String getPBIABookingAmount(
      String TicketType, String TrancheIdentifier, String ServiceBank_BIC) {
    String PBIA = getPBIA(TrancheIdentifier, ServiceBank_BIC);
    String query =
        "select amount from "
            + b2c_schema
            + ".b2c_product_bank_interest_account_booking where bookingType='"
            + TicketType
            + "' and productBankInterestAccount_id='"
            + PBIA
            + "' order by creationDate desc LIMIT 1;";
    return connection.createQuery(query).executeAndFetchFirst(String.class);
  }

  public String getSBTABookingAmount(String TicketType, String ServiceBank_BIC) {
    String SBTA = getSutorTransitAccountID(ServiceBank_BIC);
    String query =
        "select amount from "
            + b2c_schema
            + ".b2c_service_bank_transit_account_booking where bookingType='"
            + TicketType
            + "' and serviceBankTransitAccount_id='"
            + SBTA
            + "' order by creationDate desc LIMIT 1;";
    return connection.createQuery(query).executeAndFetchFirst(String.class);
  }

  public String get2ndSBTABookingAmount(String TicketType, String ServiceBank_BIC) {
    String SBTA = getSutorTransitAccountID(ServiceBank_BIC);
    String query =
        "select amount from "
            + b2c_schema
            + ".b2c_service_bank_transit_account_booking where bookingType='"
            + TicketType
            + "' and serviceBankTransitAccount_id='"
            + SBTA
            + "' order by creationDate desc LIMIT 1,1;";
    return connection.createQuery(query).executeAndFetchFirst(String.class);
  }

  public String getCustomerTransitAccount_id(String ticket_id, String tableName) {

    String query =
        "select customerTransitAccount_id from "
            + b2c_schema
            + "."
            + tableName
            + " where id="
            + ticket_id
            + ";";

    return connection.createQuery(query).executeAndFetchFirst(String.class);
  }

  public String getRequestedValueDate(String ticket_id, String tableName) {

    String query =
        "Select RequestedValueDate from "
            + b2c_schema
            + "."
            + tableName
            + " where id='"
            + ticket_id
            + "';";

    return connection.createQuery(query).executeAndFetchFirst(String.class);
  }

  public String formatCurrency(String amount) {
    amount = Aformat(amount);
    double formatedPayAmount = Double.parseDouble(amount);
    String curPayAmount =
        DecimalFormat.getCurrencyInstance(Locale.GERMANY).format(formatedPayAmount);
    return curPayAmount;
  }

  public String formatCurrency1(String amount) {
    amount = Aformat(amount);
    double formatedPayAmount = Double.parseDouble(amount);
    String curPayAmount = DecimalFormat.getCurrencyInstance(Locale.UK).format(formatedPayAmount);
    return curPayAmount;
  }

  public String getCIABookingAmount(String TicketType, String CIA) {
    String query =
        "select amount from "
            + b2c_schema
            + ".b2c_customer_interest_account_booking where bookingType='"
            + TicketType
            + "' and customerInterestAccount_id='"
            + CIA
            + "' order by creationDate desc LIMIT 1;";
    return connection.createQuery(query).executeAndFetchFirst(String.class);
  }

  public String getCIABookingAmountWithBST(String TicketType, String CIA, String bookingSubType) {
    String query =
        "select amount from "
            + b2c_schema
            + ".b2c_customer_interest_account_booking where bookingType='"
            + TicketType
            + "' and bookingSubType='"
            + bookingSubType
            + "' and customerInterestAccount_id='"
            + CIA
            + "' order by creationDate desc LIMIT 1;";
    return connection.createQuery(query).executeAndFetchFirst(String.class);
  }

  public String getCTABookingAmount(String TicketType, String CustomerEmail) {
    String CTA = getCTA(CustomerEmail);
    String query =
        "select amount from "
            + b2c_schema
            + ".b2c_customer_transit_account_booking where bookingType='"
            + TicketType
            + "' and customerTransitAccount_id='"
            + CTA
            + "' order by creationDate desc LIMIT 1;";
    return connection.createQuery(query).executeAndFetchFirst(String.class);
  }

  public String get2ndCTABookingAmount(String TicketType, String CustomerEmail) {
    String CTA = getCTA(CustomerEmail);
    String query =
        "select amount from "
            + b2c_schema
            + ".b2c_customer_transit_account_booking where bookingType='"
            + TicketType
            + "' and customerTransitAccount_id='"
            + CTA
            + "' order by creationDate desc LIMIT 1,1;";
    return connection.createQuery(query).executeAndFetchFirst(String.class);
  }

  public String getCTABookingAmountWithBST(
      String TicketType, String bookingSubType, String CustomerEmail) {
    String CTA = getCTA(CustomerEmail);
    String query =
        "select amount from "
            + b2c_schema
            + ".b2c_customer_transit_account_booking where bookingType='"
            + TicketType
            + "' and bookingSubType='"
            + bookingSubType
            + "' and customerTransitAccount_id='"
            + CTA
            + "' order by creationDate desc LIMIT 1;";
    return connection.createQuery(query).executeAndFetchFirst(String.class);
  }

  public String getStatusCIABCR(String CIA) {

    String query =
        "select status from "
            + b2c_schema
            + ".b2c_customer_interest_account_balance_change_request where customerInterestAccount_id='"
            + CIA
            + "' order by creationDate desc LIMIT 1;";
    return connection.createQuery(query).executeAndFetchFirst(String.class);
  }

  public String getCIAB_Balance(String TrancheIdentifier, String CustomerEmail) {

    String query =
        "SELECT sum(ciab.amount) as balance FROM "
            + b2c_schema
            + ".b2c_product_tranche pt "
            + "JOIN "
            + b2c_schema
            + ".b2c_product_bank_interest_account pbia ON pt.id = pbia.product_id "
            + "JOIN "
            + b2c_schema
            + ".b2c_customer_interest_account cia ON cia.productBankInterestAccount_id = pbia.id "
            + "JOIN "
            + b2c_schema
            + ".b2c_customer_interest_account_booking ciab on cia.id = ciab.customerInterestAccount_id "
            + "JOIN "
            + b2c_schema
            + ".b2c_customer_depot cd ON cia.depot_id = cd.id "
            + "JOIN "
            + b2c_schema
            + ".b2c_customer_service_bank_affiliation csba ON csba.id = cd.serviceBankAffiliation_id "
            + "JOIN "
            + b2c_schema
            + ".b2c_customer c ON c.id = csba.customer_id "
            + "WHERE pt.productIdentifier ='"
            + TrancheIdentifier
            + "' and cia.closed=false "
            + "and c.emailAddress='"
            + CustomerEmail
            + "';";

    return connection.createQuery(query).executeAndFetchFirst(String.class);
  }

  public void getCIA_status(String CIA, String state) {

    String query =
        "select closed from " + b2c_schema + ".b2c_customer_interest_account where id=" + CIA + ";";

    String Result = connection.createQuery(query).executeAndFetchFirst(String.class);
    Assert.assertEquals(Result, state, "CIA state is not correct");
  }

  public String getProlongation_status(String TrancheIdentifier) {

    String query =
        "select canBeProlongated from "
            + b2c_schema
            + ".b2c_product_tranche where productIdentifier='"
            + TrancheIdentifier
            + "';";

    return connection.createQuery(query).executeAndFetchFirst(String.class);
  }

  public void UpdateProlongation_status(String TrancheIdentifier, String value) {

    String query =
        "update "
            + b2c_schema
            + ".b2c_product_tranche set canBeProlongated ="
            + value
            + " where productIdentifier='"
            + TrancheIdentifier
            + "';";

    connection.createQuery(query).executeUpdate();
    TestLogger.logInfo("Product Bank Prolongation setting changed successfully");
  }

  public String getProdID(String ticket_id, String tableName) {

    String query =
        "select productTranche_id from "
            + b2c_schema
            + "."
            + tableName
            + " where id="
            + ticket_id
            + ";";

    return connection.createQuery(query).executeAndFetchFirst(String.class);
  }

  public String getProductTrancheId(String TrancheIdentifier) {

    String query =
        "SELECT id from "
            + b2c_schema
            + ".b2c_product_tranche where productIdentifier ='"
            + TrancheIdentifier
            + "';";

    return connection.createQuery(query).executeAndFetchFirst(String.class);
  }

  public String getPayInCodeFromTrancheIdentifier(String TrancheIdentifier) {

    String query =
        "select ip.`payInCode` from "
            + b2c_schema
            + ".b2c_product_tranche pt join "
            + b2c_schema
            + ".b2c_interest_product ip on pt.`interestProduct_id` = ip.`id`\n"
            + " WHERE pt.`productIdentifier` = '"
            + TrancheIdentifier
            + "';";

    return connection.createQuery(query).executeAndFetchFirst(String.class);
  }

  public String getEarliestTransferDate(String ticket_id, String tableName) {

    String query =
        "Select earliestTransferDate from "
            + b2c_schema
            + "."
            + tableName
            + " where id='"
            + ticket_id
            + "';";

    return connection.createQuery(query).executeAndFetchFirst(String.class);
  }

  public String getanticipateTrancheCloseByDays(String TrancheIdentifier) {

    String query =
        "select ip.anticipateTrancheCloseByDays from "
            + b2c_schema
            + ".b2c_product_tranche pt join "
            + b2c_schema
            + ".b2c_interest_product ip on pt.interestProduct_id = ip.id"
            + " WHERE pt.productIdentifier = '"
            + TrancheIdentifier
            + "';";
    return connection.createQuery(query).executeAndFetchFirst(String.class);
  }

  public String getPB_BIC_FromTrancheIdentifier(String TrancheIdentifier) {

    String query =
        "select pb.bic from "
            + b2c_schema
            + ".b2c_product_tranche pt join "
            + b2c_schema
            + ".b2c_interest_product ip on pt.interestProduct_id = ip.`id`"
            + " join "
            + b2c_schema
            + ".b2c_product_bank pb on pb.id=ip.productBank_id "
            + " WHERE pt.`productIdentifier` = '"
            + TrancheIdentifier
            + "';";

    return connection.createQuery(query).executeAndFetchFirst(String.class);
  }

  public String getSutorTransitAccountIban(String ServiceBank_BIC) {
    String query =
        "select sbta.`iban` from "
            + b2c_schema
            + ".b2c_service_bank_transit_account sbta join "
            + b2c_schema
            + ".b2c_service_bank sb on sbta.`serviceBank_id` = sb.id\n"
            + " where sb.`bic` = '"
            + ServiceBank_BIC
            + "';";
    return connection.createQuery(query).executeAndFetchFirst(String.class);
  }

  public String getSutorTransitAccountID(String ServiceBank_BIC) {
    String query =
        "select sbta.`id` from "
            + b2c_schema
            + ".b2c_service_bank_transit_account sbta join "
            + b2c_schema
            + ".b2c_service_bank sb on sbta.`serviceBank_id` = sb.id\n"
            + " where sb.`bic` = '"
            + ServiceBank_BIC
            + "';";
    return connection.createQuery(query).executeAndFetchFirst(String.class);
  }

  public String getTrancheUUID(String TrancheIdentifier) {
    String query =
        "select uuid from "
            + b2c_schema
            + ".b2c_product_tranche where `productIdentifier` = '"
            + TrancheIdentifier
            + "';";
    return connection.createQuery(query).executeAndFetchFirst(String.class);
  }

  public String getSutorTransitAccountUUID(String ServiceBank_BIC) {
    String query =
        "select sbta.uuid from "
            + b2c_schema
            + ".b2c_service_bank_transit_account sbta join "
            + b2c_schema
            + ".b2c_service_bank sb on sbta.serviceBank_id = sb.id"
            + " where sb.bic='"
            + ServiceBank_BIC
            + "';";
    return connection.createQuery(query).executeAndFetchFirst(String.class);
  }

  public String getCustomerNumber(String CustomerEmail) {
    String query =
        "select customerNumber from "
            + b2c_schema
            + ".b2c_customer where emailAddress ='"
            + CustomerEmail
            + "';";
    return connection.createQuery(query).executeAndFetchFirst(String.class);
  }

  public String getCustomerEmail(String customerNumber) {
    String query =
        "select emailAddress from "
            + b2c_schema
            + ".b2c_customer where customerNumber ='"
            + customerNumber
            + "';";
    return connection.createQuery(query).executeAndFetchFirst(String.class);
  }

  public String getCIA(String CustomerNumer, String TrancheIdentifier, String ServiceBank_BIC) {
    String PBIA = getPBIA(TrancheIdentifier, ServiceBank_BIC);
    String depot_id = getDepotID(CustomerNumer);
    String query =
        "select id from "
            + b2c_schema
            + ".b2c_customer_interest_account where productBankInterestAccount_id ='"
            + PBIA
            + "' and depot_id='"
            + depot_id
            + "';";
    return connection.createQuery(query).executeAndFetchFirst(String.class);
  }

  public String getCIA_UUID(String CIA) {
    String query =
        "select uuid from "
            + b2c_schema
            + ".b2c_customer_interest_account where id ='"
            + CIA
            + "';";
    return connection.createQuery(query).executeAndFetchFirst(String.class);
  }

  public String getPBIA(String TrancheIdentifier, String ServiceBank_BIC) {
    String query =
        "select pbia.`id` from "
            + b2c_schema
            + ".b2c_product_tranche pt join "
            + b2c_schema
            + ".b2c_product_bank_interest_account pbia on pt.`id` = pbia.`product_id`"
            + " join "
            + b2c_schema
            + ".b2c_service_bank_transit_account sbta on sbta.`id` = pbia.`serviceBankTransitAccount_id` join "
            + b2c_schema
            + ".b2c_service_bank sb on sbta.`serviceBank_id` = sb.id"
            + " where sb.`bic` = '"
            + ServiceBank_BIC
            + "' and pt.`productIdentifier` = '"
            + TrancheIdentifier
            + "';";
    return connection.createQuery(query).executeAndFetchFirst(String.class);
  }

  public String getPbiaIban(String TrancheIdentifier, String ServiceBank_BIC) {
    String query =
        "select pbia.`iban` from "
            + b2c_schema
            + ".b2c_product_tranche pt join "
            + b2c_schema
            + ".b2c_product_bank_interest_account pbia on pt.`id` = pbia.`product_id`\n"
            + "join "
            + b2c_schema
            + ".b2c_service_bank_transit_account sbta on sbta.`id` = pbia.`serviceBankTransitAccount_id` join "
            + b2c_schema
            + ".b2c_service_bank sb on sbta.`serviceBank_id` = sb.id\n"
            + "where sb.`bic` = '"
            + ServiceBank_BIC
            + "' and pt.`productIdentifier` = '"
            + TrancheIdentifier
            + "';";
    return connection.createQuery(query).executeAndFetchFirst(String.class);
  }

  public String getPbiaUUID(String TrancheIdentifier, String ServiceBank_BIC) {
    String query =
        "select pbia.`uuid` from "
            + b2c_schema
            + ".b2c_product_tranche pt join "
            + b2c_schema
            + ".b2c_product_bank_interest_account pbia on pt.`id` = pbia.`product_id`"
            + " join "
            + b2c_schema
            + ".b2c_service_bank_transit_account sbta on sbta.`id` = pbia.`serviceBankTransitAccount_id` join "
            + b2c_schema
            + ".b2c_service_bank sb on sbta.`serviceBank_id` = sb.id"
            + " where sb.`bic` = '"
            + ServiceBank_BIC
            + "' and pt.`productIdentifier` = '"
            + TrancheIdentifier
            + "';";
    return connection.createQuery(query).executeAndFetchFirst(String.class);
  }

  public String getDepotID(String customerNumber) {

    String query =
        "select cd.id from "
            + b2c_schema
            + ".b2c_customer_depot cd "
            + " join "
            + b2c_schema
            + ".b2c_customer_service_bank_affiliation csba on cd.serviceBankAffiliation_id = csba.id"
            + " join "
            + b2c_schema
            + ".b2c_customer c on c.id = csba.customer_id and c.customerNumber = '"
            + customerNumber
            + "';";

    return connection.createQuery(query).executeAndFetchFirst(String.class);
  }

  public String getCustomerServiceBankIban(String customerNumber) {

    String query =
        "select dba.iban from "
            + b2c_schema
            + ".b2c_depot_bank_account dba "
            + "    join "
            + b2c_schema
            + ".b2c_customer_depot cd on dba.id = cd.bankAccount_id"
            + "    join "
            + b2c_schema
            + ".b2c_customer_service_bank_affiliation csba on cd.serviceBankAffiliation_id = csba.id"
            + "    join "
            + b2c_schema
            + ".b2c_customer c on c.id = csba.customer_id and c.customerNumber = '"
            + customerNumber
            + "';";

    return connection.createQuery(query).executeAndFetchFirst(String.class);
  }

  public String getCustomerServiceBankID(String customerNumber) {

    String query =
        "select dba.id from "
            + b2c_schema
            + ".b2c_depot_bank_account dba "
            + "    join "
            + b2c_schema
            + ".b2c_customer_depot cd on dba.id = cd.bankAccount_id"
            + "    join "
            + b2c_schema
            + ".b2c_customer_service_bank_affiliation csba on cd.serviceBankAffiliation_id = csba.id"
            + "    join "
            + b2c_schema
            + ".b2c_customer c on c.id = csba.customer_id and c.customerNumber = '"
            + customerNumber
            + "';";

    return connection.createQuery(query).executeAndFetchFirst(String.class);
  }

  public String getCTAUUID(String CustomerTicket_id, String table) {
    String bankAccount_id = getTicketSutorDepotBankAccount_id(CustomerTicket_id, table);
    String query =
        "select uuid from "
            + b2c_schema
            + ".b2c_depot_bank_account where id='"
            + bankAccount_id
            + "';";
    return connection.createQuery(query).executeAndFetchFirst(String.class);
  }

  public String call_alike_transfer_id(String TrancheIdentifier) {

    String query =
        "select ct.id from "
            + b2c_schema
            + ".b2c_product_tranche_call_alike_transfer ct join "
            + b2c_schema
            + ".b2c_product_tranche pt on pt.id=ct.productTranche_id where pt.productIdentifier='"
            + TrancheIdentifier
            + "' and ct.transferDate>CURDATE() order by transferDate asc LIMIT 1;";

    return connection.createQuery(query).executeAndFetchFirst(String.class);
  }

  public String getBankName_FromTrancheIdentifier(String TrancheIdentifier) {

    String query =
        "select pb.bankName from "
            + b2c_schema
            + ".b2c_product_tranche pt join "
            + b2c_schema
            + ".b2c_interest_product ip on pt.interestProduct_id = ip.`id`"
            + " join "
            + b2c_schema
            + ".b2c_product_bank pb on pb.id=ip.productBank_id "
            + " WHERE pt.`productIdentifier` = '"
            + TrancheIdentifier
            + "';";

    return connection.createQuery(query).executeAndFetchFirst(String.class);
  }

  public String getCustomerTicket_id(String tableName, String CustomerEmail) {
    String CTA = getCTA(CustomerEmail);
    if (tableName.equalsIgnoreCase("b2c_customer_transfer_ticket_t_to_i")) {
      String query =
          "select id from "
              + b2c_schema
              + "."
              + tableName
              + " where customerTransitAccount_id='"
              + CTA
              + "' and creationDate>CURDATE() order by creationDate desc LIMIT 1;";
      return connection.createQuery(query).executeAndFetchFirst(String.class);
    } else {
      String query =
          "select id from "
              + b2c_schema
              + "."
              + tableName
              + " where customerTransitAccount_id='"
              + CTA
              + "' and creationDate>CURDATE()  and category='PRINCIPAL' order by creationDate desc LIMIT 1;";
      return connection.createQuery(query).executeAndFetchFirst(String.class);
    }
  }

  public String getCustomerTicket(String tableName, String CustomerEmail) {
    String CTA = getCTA(CustomerEmail);

    String query =
        "select id from "
            + b2c_schema
            + "."
            + tableName
            + " where customerTransitAccount_id='"
            + CTA
            + "' and creationDate>CURDATE() order by creationDate desc LIMIT 1;";
    return connection.createQuery(query).executeAndFetchFirst(String.class);
  }

  public String getProlongationOrI2iTicket_id(String table, String CIA, String TCIA) {
    if (TCIA == null) {
      String query =
          "select id from "
              + b2c_schema
              + "."
              + table
              + " where sourceCustomerInterestAccount_id='"
              + CIA
              + "' and creationDate>CURDATE() order by creationDate desc LIMIT 1;";
      return connection.createQuery(query).executeAndFetchFirst(String.class);
    } else {
      String query =
          "select id from "
              + b2c_schema
              + "."
              + table
              + " where sourceCustomerInterestAccount_id='"
              + CIA
              + "' and targetCustomerInterestAccount_id='"
              + TCIA
              + "' and creationDate>CURDATE() order by creationDate desc LIMIT 1;";
      return connection.createQuery(query).executeAndFetchFirst(String.class);
    }
  }

  public String getInterestTicket_id(String tableName, String CustomerEmail) {
    String CTA = getCTA(CustomerEmail);
    String query =
        "select id from "
            + b2c_schema
            + "."
            + tableName
            + " where customerTransitAccount_id='"
            + CTA
            + "' and creationDate>CURDATE() and category='GROSS_INTEREST' order by creationDate desc LIMIT 1;";
    return connection.createQuery(query).executeAndFetchFirst(String.class);
  }

  public String getCustomerEmail() {

    String query =
        "select emailAddress from "
            + b2c_schema
            + ".b2c_customer order by creationDate desc LIMIT 1;";
    return connection.createQuery(query).executeAndFetchFirst(String.class);
  }

  public String getRamdomPayInAmount(String TrancheIdentifier) {

    String query1 =
        "select min_amount from "
            + b2c_schema
            + ".b2c_product_tranche where productIdentifier='"
            + TrancheIdentifier
            + "';";
    String query2 =
        "select max_amount from "
            + b2c_schema
            + ".b2c_product_tranche where productIdentifier='"
            + TrancheIdentifier
            + "';";
    Double min = connection.createQuery(query1).executeAndFetchFirst(Double.class);
    int minval = (int) Math.round(min);
    Double max = connection.createQuery(query2).executeAndFetchFirst(Double.class);
    int maxval = (int) Math.round(max);
    String amount = decimalFormat(ThreadLocalRandom.current().nextInt(minval, (maxval + 1)));
    amount = Aformat(amount);
    return amount;
  }

  public String Aformat(String amount) {
    if (amount.contains(",")) {
      amount = amount.replace(",", ".");
    }
    return amount;
  }

  public String getTrancheIdentifier(String str) {

    String query =
        "select productIdentifier from "
            + b2c_schema
            + ".b2c_product_tranche where viewState='PUBLISHED' and productIdentifier like '%"
            + str
            + "%' order by creationDate desc LIMIT 1;";
    return connection.createQuery(query).executeAndFetchFirst(String.class);
  }

  public String getPIBString(String TrancheIdentifier) {
    String tranche_id = getProductTrancheId(TrancheIdentifier);
    String query1 =
        "select validFrom from "
            + b2c_schema
            + ".b2c_document_product_information where productTranche_id="
            + tranche_id
            + ";";
    String r1 = connection.createQuery(query1).executeAndFetchFirst(String.class);
    String query2 =
        "select version from "
            + b2c_schema
            + ".b2c_document_product_information where productTranche_id="
            + tranche_id
            + ";";
    String r2 = connection.createQuery(query2).executeAndFetchFirst(String.class);
    String query3 =
        "select name from "
            + b2c_schema
            + ".b2c_document_product_information where productTranche_id="
            + tranche_id
            + ";";
    String r3 = connection.createQuery(query3).executeAndFetchFirst(String.class);
    return r1 + "/" + r2 + "/" + r3;
  }

  public String getPreviousTrancheIdentifier(String str) {

    String query =
        "select productIdentifier from "
            + b2c_schema
            + ".b2c_product_tranche where viewState='HIDDEN' and productIdentifier like '%"
            + str
            + "%' order by creationDate desc LIMIT 1;";
    return connection.createQuery(query).executeAndFetchFirst(String.class);
  }

  public String getBankTransferTicketID(String ticket_id, String tableName) {
    String query;
    if (tableName.equalsIgnoreCase("b2c_customer_transfer_ticket_t_to_i")) {
      query =
          "select bankTransitTicket_id from "
              + b2c_schema
              + "."
              + tableName
              + "  where id ="
              + ticket_id
              + ";";
    } else {
      query =
          "select bankTransferTicket_id from "
              + b2c_schema
              + "."
              + tableName
              + "  where id ="
              + ticket_id
              + ";";
    }
    return connection.createQuery(query).executeAndFetchFirst(String.class);
  }

  public String getTicketState(String ticket_id, String tableName) {
    String query = null;

    if (tableName.contains("customer_transfer")) {

      query =
          "SELECT state.state FROM "
              + b2c_schema
              + "."
              + tableName
              + " ctt join "
              + b2c_schema
              + ".b2c_customer_ticket_execution_state state on ctt.`state_id` = state.`id` \n"
              + "WHERE ctt.id = '"
              + ticket_id
              + "';";
    } else if (tableName.contains("bank_transfer")) {
      query =
          "SELECT state.state FROM "
              + b2c_schema
              + "."
              + tableName
              + " ctt join "
              + b2c_schema
              + ".b2c_bank_ticket_execution_state state on ctt.`state_id` = state.`id` \n"
              + "WHERE ctt.id = '"
              + ticket_id
              + "';";
    }
    return connection.createQuery(query).executeAndFetchFirst(String.class);
  }

  public void ValidateCIT(String CIA, String state) {

    String query =
        "SELECT state.state FROM "
            + b2c_schema
            + ".b2c_customer_closing_investment_ticket cit join "
            + b2c_schema
            + ".b2c_customer_closing_investment_execution_state state on cit.`state_id` = state.`id` "
            + "WHERE cit.customerInterestAccount_id = '"
            + CIA
            + "';";

    String Result = connection.createQuery(query).executeAndFetchFirst(String.class);
    Assert.assertEquals(Result, state, "Customer closing investment Ticket State is not " + state);
    System.out.println("Customer closing investment Ticket State is " + state);
  }

  public String getTicketStateMessage(String ticket_id, String tableName) {

    String query =
        "SELECT state.message FROM "
            + b2c_schema
            + "."
            + tableName
            + " ctt join "
            + b2c_schema
            + ".b2c_customer_ticket_execution_state state on ctt.`state_id` = state.`id` \n"
            + "WHERE ctt.id = '"
            + ticket_id
            + "';";

    return connection.createQuery(query).executeAndFetchFirst(String.class);
  }

  public String getTicketCategory(String ticket_id, String tableName) {

    String query =
        "SELECT category FROM " + b2c_schema + "." + tableName + " WHERE id = '" + ticket_id + "';";

    return connection.createQuery(query).executeAndFetchFirst(String.class);
  }

  public String getTicketSutorDepotBankAccount_id(String ticket_id, String tableName) {

    String query =
        "SELECT depotBankAccount_id FROM "
            + b2c_schema
            + "."
            + tableName
            + " WHERE id = '"
            + ticket_id
            + "';";

    return connection.createQuery(query).executeAndFetchFirst(String.class);
  }

  public String getTicketDependency_id(String ticket_id, String tableName) {

    String query =
        "SELECT dependency_id FROM "
            + b2c_schema
            + "."
            + tableName
            + " WHERE id = '"
            + ticket_id
            + "';";

    return connection.createQuery(query).executeAndFetchFirst(String.class);
  }

  public List<PaymentServices.InterestToTransitInvestmentDetails> geti2tTickets(
      String BankTicket_id) {
    String query =
        " SELECT i2t.category,i2t.moneyAmount,i2t.uuid,i2ts.`state` FROM "
            + b2c_schema
            + ".b2c_bank_transfer_ticket_i_to_t i2t join "
            + b2c_schema
            + ".b2c_bank_ticket_execution_state i2ts on i2t.`state_id` = i2ts.`id` WHERE i2t.id =  "
            + BankTicket_id
            + ";";
    return connection
        .createQuery(query)
        .executeAndFetch(PaymentServices.InterestToTransitInvestmentDetails.class);
  }

  public List<PaymentServices.TransitToCustomerDetails> gett2cTickets(
      String t2cPBankTicket_id, String t2cIBankTicket_id) {
    String query =
        "SELECT bt2c.`moneyAmount`,bt2c.`uuid`,dba.`iban`, bt2c.`customerNumber`,bt2c.`category`,cstate.`state` as cstate,bstate.`state` as bstate,pbia.`bic` as pbBic from "
            + b2c_schema
            + ".b2c_bank_transfer_ticket_t_to_c bt2c \n"
            + "join "
            + b2c_schema
            + ".b2c_customer_transfer_ticket_t_to_c ct2c on bt2c.`id` = ct2c.`bankTransferTicket_id`\n"
            + "join "
            + b2c_schema
            + ".b2c_depot_bank_account dba on dba.`id` = bt2c.`customerBankAccount_id`\n"
            + "join "
            + b2c_schema
            + ".b2c_bank_ticket_execution_state bstate on bstate.`id` = bt2c.`state_id`\n"
            + "join "
            + b2c_schema
            + ".b2c_customer_ticket_execution_state cstate on cstate.`id` = ct2c.`state_id`\n"
            + "join "
            + b2c_schema
            + ".b2c_product_tranche pt on bt2c.`productTranche_id` = pt.`id`\n"
            + "join "
            + b2c_schema
            + ".b2c_product_bank_interest_account pbia on pbia.`product_id` = pt.`id`\n"
            + "join "
            + b2c_schema
            + ".b2c_service_bank_transit_account sbta on bt2c.`serviceBankTransitAccount_id` = sbta.`id`\n"
            + "join "
            + b2c_schema
            + ".b2c_service_bank sb on sbta.`serviceBank_id` = sb.`id`\n"
            + "WHERE sb.`bic` = 'MHSBDEHBXXX' and ct2c.`bankTransferTicket_id` in ('"
            + t2cPBankTicket_id
            + "','"
            + t2cIBankTicket_id
            + "') group by uuid;";

    return connection
        .createQuery(query)
        .executeAndFetch(PaymentServices.TransitToCustomerDetails.class);
  }

  public List<PayoutExecuted> getPayoutInformation(String trancheIdentifier) {
    String query =
        "SELECT btof.uuid AS fileUuid,bto.`category` ,sum(bto.amount) as moneyAmount FROM "
            + sps_schema
            + ".bc_bank_transfer_order_file btof JOIN "
            + sps_schema
            + ".bc_bank_transfer_order bto ON bto.`bankTransferOrderFile_id` = btof.`id`"
            + "WHERE bto.`tranche_identifier` = '"
            + trancheIdentifier
            + "' "
            + "AND btof.`type` = 'PAYOUT_CSV_SUTOR_SFTP' group By bto.`category`;";
    return connection.createQuery(query).executeAndFetch(PayoutExecuted.class);
  }

  public List<PaymentServices.TransitToInterestInvestmentDetails> gett2iTickets(
      String BankTicket_id) {
    String query =
        "SELECT t2i.moneyAmount,t2i.uuid,t2is.`state` FROM "
            + b2c_schema
            + ".b2c_bank_transfer_ticket_t_to_i t2i join "
            + b2c_schema
            + ".b2c_bank_ticket_execution_state t2is on t2i.`state_id` = t2is.`id` WHERE t2i.id = "
            + BankTicket_id
            + ";";
    return connection
        .createQuery(query)
        .executeAndFetch(PaymentServices.TransitToInterestInvestmentDetails.class);
  }

  public void ticketStateValidation(String ticket_id, String ExpectedState, String tableName) {
    String ActualState = getTicketState(ticket_id, tableName);
    Assert.assertEquals(ActualState, ExpectedState, "Ticket State is not " + ExpectedState);
  }

  public String formatDate(String pattern) {
    DateFormat dateFormat = new SimpleDateFormat(pattern);
    Date date = new Date();
    return dateFormat.format(date);
  }

  public String decimalFormat(int amount) {

    DecimalFormat twoPlaces = new DecimalFormat("0.00");
    return twoPlaces.format(amount);
  }

  public void closeDBCon() throws SQLException {
    connection.close();
    TestLogger.logInfo("Closing DB Connection");
  }

  public void updateProlongationStrategy(String TrancheIdentifier, String action) {
    String query =
        "update "
            + b2c_schema
            + ".b2c_interest_product set prolongationStrategy ='"
            + action
            + "' where id =(select interestProduct_id from b2c_product_tranche WHERE `productIdentifier` = '"
            + TrancheIdentifier
            + "');";
    connection.createQuery(query).executeUpdate();
    TestLogger.logInfo("ProlongationStrategy changed successfully to " + action);
  }

  public void checkQUE(String type, String option) {

    String query = "select text from cq.cq_answers where question_code='" + type + "';";

    String result = connection.createQuery(query).executeAndFetchFirst(String.class);

    Assert.assertTrue(result.equalsIgnoreCase(option));
  }

  public String checkSOF(String CustomerEmail) {

    String query =
        "select tsof.source_of_funds from "
            + b2c_schema
            + ".sbtr_trustor_source_of_funds tsof "
            + "join "
            + b2c_schema
            + ".b2c_customer_service_bank_affiliation csba on tsof.serviceBankAffiliation_id = csba.id join "
            + b2c_schema
            + ".b2c_customer c on c.id = csba.customer_id and c.emailAddress = '"
            + CustomerEmail
            + "';";

    return connection.createQuery(query).executeAndFetchFirst(String.class);
  }

  public String checkDRM() {

    String query = "select s.state from cm.state s order by creationDate desc LIMIT 1;";

    return connection.createQuery(query).executeAndFetchFirst(String.class);
  }

  public void setDrmStatus(String Status) {

    String query =
        "update cm.state s set s.state ='" + Status + "' order by creationDate desc LIMIT 1;";

    connection.createQuery(query).executeUpdate();
    String query1 = "select s.state from cm.state s order by creationDate desc LIMIT 1;";
    String Result = connection.createQuery(query1).executeAndFetchFirst(String.class);
    Assert.assertEquals(Result, Status, "Did not DRM Status successfully");
    TestLogger.logInfo("DRM Status successfully changed to " + Status);
  }

  public void getCIA_sof(String CIA) {

    String query =
        "select sourceOfFunds_id from "
            + b2c_schema
            + ".b2c_customer_interest_account where id="
            + CIA
            + ";";

    String Result = connection.createQuery(query).executeAndFetchFirst(String.class);
    Assert.assertEquals(Result, "1", "SOF saved in CIA table");
  }

  public boolean checkIfCustomerExistByEmail(String email) {
    try (Connection con = createSqlConnection().open()) {
      String query =
          String.format(
              "SELECT count(1) from %s.b2c_customer WHERE emailAddress='%s'", b2c_schema, email);
      return con.createQuery(query).executeScalar(Integer.class) >= 1;
    }
  }

  public void createNewUser() {
    this.executeSqlScript("customer.sql");
  }

  public String getBankName(String str1) {
    String query =
        "select b.bankName from comonea_b2c.b2c_product_bank b join comonea_b2c.b2c_product_bank_logo l on b.bic=l.productBankbic where l.productBankBic like '"
            + str1
            + "%'";

    return connection.createQuery(query).executeAndFetchFirst(String.class);
  }

  public String getColumnValueFromSbaffAccountOpening(String column) {
    String query = "select " + column + " from sbaff.account_opening";
    return connection.createQuery(query).executeAndFetchFirst(String.class);
  }

  public void updateSbaffAccountOpeningTable(
      String columnName, String columnValue, String condition) {

    String query =
        "UPDATE `sbaff`.`account_opening` SET  `"
            + columnName
            + "` ='"
            + columnValue
            + "' "
            + " "
            + ""
            + ""
            + condition
            + "";
    TestLogger.logMsg(query);
    connection.createQuery(query).executeUpdate();
  }

  public String validationRequirement(String TrancheIdentifier, String value) {
    String pb_id = getPB_id_FromTrancheIdentifier(TrancheIdentifier);
    String query =
        "SELECT validationRequirement FROM "
            + b2c_schema
            + ".b2c_product_bank_validation_requirement where productBank_id='"
            + pb_id
            + "' and validationRequirement='"
            + value
            + "' ;";
    String result = connection.createQuery(query).executeAndFetchFirst(String.class);
    String value1 = "";
    TestLogger.logInfo(result);
    try {
      if (result != null || result.equalsIgnoreCase(value)) {
        value1 = "true";

      } else value1 = "false";
    } catch (NullPointerException e) {
      TestLogger.logInfo(e.getMessage());
    }
    return value1;
  }

  public String getPB_id_FromTrancheIdentifier(String TrancheIdentifier) {

    String query =
        "select pb.id from "
            + b2c_schema
            + ".b2c_product_tranche pt join "
            + b2c_schema
            + ".b2c_interest_product ip on pt.interestProduct_id = ip.`id`"
            + " join "
            + b2c_schema
            + ".b2c_product_bank pb on pb.id=ip.productBank_id "
            + " WHERE pt.`productIdentifier` = '"
            + TrancheIdentifier
            + "';";
    return connection.createQuery(query).executeAndFetchFirst(String.class);
  }

  public void insertDataintotrustorServiceBankData(String column, String data) {

    String idQuery = "select id from " + b2c_schema + ".b2c_trustor";
    String id = connection.createQuery(idQuery).executeAndFetchFirst(String.class);

    String query =
        "update "
            + b2c_schema
            + ".b2c_trustor_service_bank_data set "
            + "`"
            + column
            + "`='"
            + data
            + "'"
            + " where `id` = '"
            + id
            + "';";
    TestLogger.logMsg(query);
    connection.createQuery(query).executeUpdate();
    TestLogger.logInfo("Data Successfully Executed");
  }

  public void insertDataintotrustorServiceBankData(String dateChange) {

    String idQuery = "select id from " + b2c_schema + ".b2c_trustor";
    String id = connection.createQuery(idQuery).executeAndFetchFirst(String.class);

    String query =
        "update "
            + b2c_schema
            + ".b2c_trustor_service_bank_data set "
            + "`"
            + dateChange
            + "`=NULL"
            + " where `id` = '"
            + id
            + "';";
    TestLogger.logMsg(query);
    connection.createQuery(query).executeUpdate();
    TestLogger.logInfo("Data Successfully Executed");
  }

  public void executeSql(String query) {

    connection.createQuery(query).executeUpdate();
  }
}
