package com.depositsolutions.common.ui.zpuipageobjects;

import static com.depositsolutions.common.reusables.TestConstants.SHOP_URL_CONFIG_KEY;
import static io.restassured.RestAssured.given;

import com.depositsolutions.common.reusables.TestConstants;
import com.depositsolutions.common.ui.helpers.BaseTestClassUI;
import com.depositsolutions.common.ui.helpers.WebUIOperations;
import com.depositsolutions.common.utils.ConfigManager;
import com.depositsolutions.common.utils.TestLogger;
import io.restassured.RestAssured;
import io.restassured.response.Response;
import java.util.concurrent.TimeUnit;
import org.openqa.selenium.By;
import org.rnorth.ducttape.unreliables.Unreliables;

public class ShopLoginLogoutPO extends BaseTestClassUI {
  public static ShopLoginLogoutPO singleInstance = null;

  public By zpUserName = By.id("signin-email");
  public By zpPassword = By.id("signin-password");
  public By zpLogin = By.id("btn-login-large-screens");
  public By zpLogout = By.linkText("Abmelden");
  public By zpIntPopUp = By.id("ZP_Shop_Accept");

  public By zpProductList = By.id("productList");
  public By zpShopRegisterLink = By.id("btn-registration-from-login-page");
  public By zpForgotPasswordLink =
      By.xpath(
          "//input[@id='signin-password']/ancestor::div[1]/following-sibling::div[1]/div[1]/a");
  public By forgotPassword = By.id("emailAddress");
  public By customerName = By.xpath("//div[@class='logged-in-nav-name']/a");
  public By bankenLink = By.linkText("BANKEN");
  public By autoenvPopup = By.id("uc-btn-accept-banner");

  public static ShopLoginLogoutPO getInstance() {
    if (singleInstance == null) {
      singleInstance = new ShopLoginLogoutPO();
    }
    return singleInstance;
  }

  /*
   * This method removes shop cache
   * @param shop_cache
   * @throws InterruptedException
   */
  public void shopCache() throws InterruptedException {
    RestAssured.baseURI = ConfigManager.getInstance().getString("shopCacheUrl");
    given().when().post("/cacheControl").then().log().ifError().assertThat().statusCode(200);
    Thread.sleep(600);
    DRIVER.navigate().refresh();
    TestLogger.logInfo("Shop cache refreshed");
  }
  /*
   * This method opens Zp Shop login page
   * @param Env
   * @param customerEmail
   */
  public void ShopLoginPage(String env) {
    launchUrl(ConfigManager.getInstance().getString(SHOP_URL_CONFIG_KEY));

    if (env.equalsIgnoreCase("zp_int")) {
      DRIVER.findElement(ShopLoginLogoutPO.getInstance().zpIntPopUp).click();
      TestLogger.logInfo("Handled Integration Environment Popup");
    } else if (env.equalsIgnoreCase("auto")) {
      if (doesWebElementExist((ShopLoginLogoutPO.getInstance().autoenvPopup))) {
        DRIVER.findElement(ShopLoginLogoutPO.getInstance().autoenvPopup).click();
        TestLogger.logInfo("Handled Automation Environment Popup");
      }
    }
    waitTillBrowserLoads();
    TestLogger.logInfo("Shop Login Page launched Successful");
  }

  /*
   * This method opens Zp Shop and logs in with customer
   * @param Env
   * @param customerEmail
   */
  public void shopLogin(String Env, String customerEmail) {
    String shopManagementUrl =
        ConfigManager.getInstance().getString(TestConstants.SHOP_ADMIN_URL_CONFIG_KEY);
    Unreliables.retryUntilTrue(
        5,
        TimeUnit.MINUTES,
        () -> {
          Thread.sleep(1000);

          RestAssured.baseURI = shopManagementUrl;
          Response resp = RestAssured.get("/health");
          return "UP".equals(resp.body().jsonPath().getString("status"));
        });

    Unreliables.retryUntilSuccess(
        5,
        TimeUnit.MINUTES,
        () -> {
          Thread.sleep(2000);

          ShopLoginPage(Env);
          DRIVER.findElement(zpUserName).sendKeys(customerEmail);
          DRIVER.findElement(zpPassword).sendKeys(TestConstants.SHOP_PASSWORD);

          DRIVER.findElement(zpLogin).submit();

          waitTillBrowserLoads();
          return null;
        });

    TestLogger.logInfo("Shop Login Successful");
  }

  public void shopLogin(String Env, String customerEmail, String password) {
    String shopManagementUrl =
        ConfigManager.getInstance().getString(TestConstants.SHOP_ADMIN_URL_CONFIG_KEY);
    Unreliables.retryUntilTrue(
        5,
        TimeUnit.MINUTES,
        () -> {
          Thread.sleep(1000);

          RestAssured.baseURI = shopManagementUrl;
          Response resp = RestAssured.get("/health");
          return "UP".equals(resp.body().jsonPath().getString("status"));
        });

    Unreliables.retryUntilSuccess(
        5,
        TimeUnit.MINUTES,
        () -> {
          Thread.sleep(2000);

          ShopLoginPage(Env);
          DRIVER.findElement(zpUserName).sendKeys(customerEmail);
          DRIVER.findElement(zpPassword).sendKeys(password);

          DRIVER.findElement(zpLogin).submit();

          waitTillBrowserLoads();
          return null;
        });

    TestLogger.logInfo("Shop Login Successful");
  }

  /*
      * This method logs out of Zp Shop

  */
  public void shopLogOut() {
    WebUIOperations.getInstance()
        .verifyElementIsPresent(getWebElement(zpLogout), "Shop Logout link");
    DRIVER.findElement(zpLogout).click();
    TestLogger.logInfo("Logged out of Shop successfully");
  }

  public void verifyProductListIsDisplayed() {
    WebUIOperations.getInstance()
        .verifyElementIsPresent(getWebElement(zpProductList), "Product List");
  }

  public String getCustomerInfo() {
    String profileName = "";
    if (getWebElement(customerName).isDisplayed())
      profileName = getWebElement(customerName).getText().toString();

    return profileName;
  }
}
