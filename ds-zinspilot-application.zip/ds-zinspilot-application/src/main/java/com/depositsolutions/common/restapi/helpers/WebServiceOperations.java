package com.depositsolutions.common.restapi.helpers;

import io.restassured.path.json.JsonPath;

public class WebServiceOperations {
  public static WebServiceOperations singleInstance = null;

  public static WebServiceOperations getInstance() {
    if (singleInstance == null) {
      singleInstance = new WebServiceOperations();
    }
    return singleInstance;
  }

  public JsonPath convertStringToJson(String response) {
    JsonPath js = new JsonPath(response);
    return js;
  }
}
