package com.depositsolutions.common.ui.helpers;

import static com.depositsolutions.common.reusables.TestConstants.*;

import com.depositsolutions.common.utils.ConfigManager;
import com.depositsolutions.common.utils.TestLogger;
import java.io.File;
import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.TimeUnit;
import org.apache.commons.io.FileUtils;
import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.edge.EdgeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxOptions;
import org.openqa.selenium.remote.CapabilityType;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.safari.SafariDriver;
import org.openqa.selenium.safari.SafariOptions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.rnorth.ducttape.unreliables.Unreliables;
import org.testng.util.Strings;

public abstract class BaseTestClassUI {

  private static final String DRIVER_HOST =
      ConfigManager.getInstance().getString(DRIVER_HOST_CONFIG_KEY);
  private static final String DRIVER_PORT =
      ConfigManager.getInstance().getString(DRIVER_PORT_CONFIG_KEY);
  private static final Long IMPLICIT_TIME_OUT =
      Long.parseLong(ConfigManager.getInstance().getString(IMPLICIT_TIME_OUT_KEY));
  private static final String SCREENSHOTS_DIR =
      CURRENT_WORKING_DIRECTORY + ConfigManager.getInstance().getString(SCREENSHOT_DIR_KEY);
  public static WebDriver DRIVER;

  protected String sTestCaseID;
  protected final String RUN_WITH_DOCKER =
      ConfigManager.getInstance().getString(RUN_WITH_DOCKER_CONFIG_KEY);
  protected final String BROWSER = ConfigManager.getInstance().getString(BROWSER_CONFIG_KEY);
  protected final String ENV = ConfigManager.getInstance().getString(ENV_CONFIG_KEY);

  public void setUpForTest(String url) {

    try {
      launchBrowser();
      launchUrl(url);
    } catch (Exception e) {
      e.printStackTrace();
    }
  }

  public static void takeScreenshot(String fileName) {
    TakesScreenshot ts = ((TakesScreenshot) DRIVER);
    File srcFile = ts.getScreenshotAs(OutputType.FILE);
    try {
      String finalName = fileName + "-" + UUID.randomUUID().toString().substring(0, 6);
      File destFile = new File(String.format("%s/%s.png", SCREENSHOTS_DIR, finalName));
      FileUtils.copyFile(srcFile, destFile);
      TestLogger.logInfo("Took screenshot: " + finalName + ".png");
    } catch (IOException e) {
      e.printStackTrace();
    }
  }

  /**
   * Launches the testURl
   *
   * @param url
   */
  public void launchUrl(String url) {
    DRIVER.get(url);
    DRIVER.manage().window().maximize();
  }

  public static WebElement getWebElement(By by) {
    return DRIVER.findElement(by);
  }

  public boolean doesWebElementExist(By by) {
    try {
      DRIVER.findElement(by);
      return true;
    } catch (NoSuchElementException e) {
      return false;
    }
  }

  private static ChromeOptions getChromeOptions(File downloadDirectory) {
    Map<String, Object> chromePrefs = new HashMap<String, Object>();
    chromePrefs.put("profile.default_content_settings.popups", 0);
    chromePrefs.put("download.default_directory", "/home/seluser/Downloads");

    ChromeOptions options = new ChromeOptions();
    chromePrefs.put("download.prompt_for_download", false);
    chromePrefs.put("pdfjs.disabled", true);
    options.setHeadless(true);
    options.setExperimentalOption("prefs", chromePrefs);

    String seleniumProxy = ConfigManager.getInstance().getString("seleniumProxy");
    if (Strings.isNotNullAndNotEmpty(seleniumProxy)) {
      Proxy proxy = new Proxy();
      String proxyHostPort = seleniumProxy.replace("http://", "");
      proxy.setHttpProxy(proxyHostPort);
      proxy.setSslProxy(proxyHostPort);
      proxy.setNoProxy(
          "shop,mail-server,pug,mock_typo3,prodops,gunda2,.deposit-solutions.com,.deposit,localhost,127.0.0.1");
      options.setCapability("proxy", proxy);
    }

    return options;
  }

  /** Launches the browser based on the option or browser type selected */
  public void launchBrowser() {
    TestLogger.logInfo("runWithDocker: " + RUN_WITH_DOCKER);
    TestLogger.logInfo("browser: " + BROWSER);
    // Check if parameter passed as 'Chrome'
    if (BROWSER.contains("chrome")) {
      if (RUN_WITH_DOCKER.equalsIgnoreCase("true")) {

        TestLogger.logInfo("Running with docker and " + BROWSER);

        File downloadDir =
            new File(
                    BaseTestClassUI.class
                        .getResource("/docker-compose/browser-download/.placeholder")
                        .getPath())
                .getParentFile();

        DesiredCapabilities cap = DesiredCapabilities.chrome();
        cap.setCapability(CapabilityType.ACCEPT_SSL_CERTS, true);
        cap.setCapability(ChromeOptions.CAPABILITY, getChromeOptions(downloadDir));
        ChromeOptions options = new ChromeOptions();

        HashMap<String, Object> chromePref = new HashMap<>();

        chromePref.put("download.default_directory", File.separator + "target" + File.separator);
        options.setHeadless(true);
        options.setExperimentalOption("prefs", chromePref);
        RemoteWebDriver driver =
            Unreliables.retryUntilSuccess(
                10,
                () ->
                    new RemoteWebDriver(
                        new URL("http://" + DRIVER_HOST + ":" + DRIVER_PORT + "/wd/hub"), cap));
        int timeoutUnit = 120;
        TimeUnit timeUnit = TimeUnit.SECONDS;
        driver.manage().timeouts().pageLoadTimeout(timeoutUnit, timeUnit);
        TestLogger.logInfo(
            "start chrome driver with pageLoadTimeout: unit "
                + timeoutUnit
                + " of timeUnit "
                + timeUnit);
        this.DRIVER = driver;

      } else {
        System.setProperty("webdriver.chrome.driver", "/usr/local/bin/chromedriver");
        ChromeOptions options = new ChromeOptions();

        HashMap<String, Object> chromePref = new HashMap<>();

        chromePref.put("download.default_directory", "/tmp");

        options.setExperimentalOption("prefs", chromePref);
        // set path to chromedriver.exe

        // create chrome instance
        //        ChromeOptions options = new ChromeOptions();
        options.addArguments("--incognito");
        DRIVER = new ChromeDriver(options);
      }
    }
    // Check if parameter passed as 'Safari'
    else if (BROWSER.equalsIgnoreCase("Safari")) {
      if (System.getProperty("runWithDocker").equalsIgnoreCase("true")) {
        Capabilities caps = new SafariOptions();
        DRIVER = getDriver(DRIVER_PORT, caps);
      } else {
        SafariOptions options = new SafariOptions();
        options.setCapability("safari.cleanSession", true);
        DRIVER = new SafariDriver(options);
      }
    }
    // Check if parameter passed as 'Firefox'
    else if (BROWSER.equalsIgnoreCase("Firefox")) {
      if (System.getProperty("runWithDocker").equalsIgnoreCase("true")) {
        Capabilities caps = new FirefoxOptions();
        DRIVER = getDriver(DRIVER_PORT, caps);
      } else {
        System.setProperty("webdriver.gecko.driver", "geckodriver");
        FirefoxOptions options = new FirefoxOptions();
        options.addArguments("-private");
        DRIVER = new FirefoxDriver(options);
      }
    }
    // Check if parameter passed as 'Edge'
    else if (BROWSER.equalsIgnoreCase("Edge")) {
      if (System.getProperty("runWithDocker").equalsIgnoreCase("true")) {
        Capabilities caps = new EdgeOptions();
        DRIVER = getDriver(DRIVER_PORT, caps);
      } else {
        System.setProperty("webdriver.edge.driver", "msedgedriver");
        DRIVER = new EdgeDriver();
      }
    } else {
      // If no browser passed throw exception
      try {
        throw new Exception("Browser is not correct");
      } catch (Exception e) {
        e.printStackTrace();
      }
    }
    DRIVER.manage().timeouts().implicitlyWait(IMPLICIT_TIME_OUT, TimeUnit.SECONDS);
  }

  private static WebDriver getDriver(String port, Capabilities caps) {

    try {
      final String WEBDRIVER_HUB_URL = "http://" + DRIVER_HOST + ":" + port + "/wd/hub";
      TestLogger.logInfo("Connecting to remote web driver: " + WEBDRIVER_HUB_URL);
      return new RemoteWebDriver(new URL(WEBDRIVER_HUB_URL), caps);
    } catch (MalformedURLException e) {
      throw new RuntimeException(e);
    }
  }

  // Explicit wait till page loads
  public void waitTillBrowserLoads() {
    WebDriverWait wait = new WebDriverWait(DRIVER, 30);
    try {
      wait.until(
          webDriver ->
              ((JavascriptExecutor) webDriver)
                  .executeScript("return document.readyState")
                  .equals("complete"));
    } catch (Exception e) {
      System.out.println("Script failed with Exception" + e);
    }
  }

  public void closeAllBrowsers() {
    DRIVER.quit();
  }
}
