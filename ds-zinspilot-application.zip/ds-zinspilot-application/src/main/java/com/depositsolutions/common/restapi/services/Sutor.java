package com.depositsolutions.common.restapi.services;

import static io.restassured.RestAssured.given;

import com.depositsolutions.common.restapi.helpers.Endpoints;
import com.depositsolutions.common.utils.ConfigManager;
import com.depositsolutions.common.utils.TestLogger;
import io.restassured.RestAssured;

public class Sutor {
  public static Sutor singleInstance = null;
  private String sftp_sutor_splitter_url =
      ConfigManager.getInstance().getString("sftp_sutor_splitter_url");

  public static Sutor getInstance() {
    if (singleInstance == null) {
      singleInstance = new Sutor();
    }
    return singleInstance;
  }

  public void outgoingSutorSplitterSFTP() {
    RestAssured.baseURI = sftp_sutor_splitter_url;

    given()
        .header("Content-Type", "application/json")
        .when()
        .post(Endpoints.filerouterOutgoing)
        .then()
        .log()
        .ifError()
        .assertThat()
        .statusCode(200);
    TestLogger.logInfo("API: Sutor Splitter Outgoing File Router is successful");
  }

  public void receivedSutorSplitterSFTP() {
    RestAssured.baseURI = sftp_sutor_splitter_url;

    given()
        .header("Content-Type", "application/json")
        .when()
        .post(Endpoints.filerouterReceived)
        .then()
        .log()
        .ifError()
        .assertThat()
        .statusCode(200);
    TestLogger.logInfo("API: Sutor Splitter Received File Router is successful");
  }
}
