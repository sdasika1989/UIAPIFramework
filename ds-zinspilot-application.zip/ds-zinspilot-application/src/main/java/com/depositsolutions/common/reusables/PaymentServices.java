package com.depositsolutions.common.reusables;

import static java.util.stream.Collectors.toList;

import com.depositsolutions.common.restapi.helpers.WebServiceOperations;
import com.depositsolutions.common.restapi.services.CoreBL;
import com.depositsolutions.common.restapi.services.Deposit;
import com.depositsolutions.common.restapi.services.Gunda;
import com.depositsolutions.common.restapi.services.Sps;
import com.depositsolutions.common.reusables.payout.PayoutExecuted;
import com.depositsolutions.common.reusables.payout.PayoutExecutedCsvFileBuilder;
import com.depositsolutions.common.ui.helpers.BaseTestClassUI;
import com.depositsolutions.common.ui.helpers.WebUIOperations;
import com.depositsolutions.common.ui.zpuipageobjects.GundaPO;
import com.depositsolutions.common.ui.zpuipageobjects.MailHogPO;
import com.depositsolutions.common.ui.zpuipageobjects.MeineAnlagenPO;
import com.depositsolutions.common.ui.zpuipageobjects.ShopLoginLogoutPO;
import com.depositsolutions.common.utils.ConfigManager;
import com.depositsolutions.common.utils.TestLogger;
import de.depositsolutions.common.IBAN;
import java.awt.AWTException;
import java.math.BigDecimal;
import java.sql.SQLException;
import java.text.DecimalFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.stream.Collectors;
import org.testng.Assert;

public class PaymentServices extends BaseTestClassUI {
  private String testDataInjection = ConfigManager.getInstance().getString("testDataInjection");
  protected String SERVICEBANK_TRANSITACCOUNT_IBAN;
  protected String PRODUCTBANK_INTERESTACCOUNT_IBAN;
  protected String SERVICEBANK_TRANSITACCOUNT_IDENTIFIER;
  protected String SERVICEBANK_TRANSITACCOUNT_KONTONUMMER;
  public String i2tTicketType = "INTEREST_TO_TRANSIT";
  public String t2cTicketType = "TRANSIT_TO_CUSTOMER";
  public String ServiceBank_BIC = "MHSBDEHBXXX";
  public static PaymentServices singleInstance = null;

  public static PaymentServices getInstance() {
    if (singleInstance == null) {
      singleInstance = new PaymentServices();
    }
    return singleInstance;
  }

  public class InterestToTransitInvestmentDetails {

    private BigDecimal moneyAmount;

    private String uuid;

    private String category;

    public String getState() {
      return state;
    }

    private String state;

    public InterestToTransitInvestmentDetails(
        BigDecimal moneyAmount, String uuid, String state, String category) {
      this.moneyAmount = moneyAmount;
      this.uuid = uuid;
      this.state = state;
      this.category = category;
    }

    public BigDecimal getMoneyAmount() {
      return moneyAmount;
    }

    public String getUuid() {
      return uuid;
    }

    public String getCategory() {
      return category;
    }
  }

  public class TransitToInterestInvestmentDetails {

    private BigDecimal moneyAmount;

    public TransitToInterestInvestmentDetails(BigDecimal moneyAmount, String uuid, String state) {
      this.moneyAmount = moneyAmount;
      this.uuid = uuid;
      this.state = state;
    }

    @Override
    public String toString() {
      return "TransitToInterestInvestmentDetails{"
          + "moneyAmount="
          + moneyAmount
          + ", uuid='"
          + uuid
          + '\''
          + ", state='"
          + state
          + '\''
          + '}';
    }

    private String uuid;

    public BigDecimal getMoneyAmount() {
      return moneyAmount;
    }

    public String getUuid() {
      return uuid;
    }

    public String getState() {
      return state;
    }

    private String state;
  }

  public static class TransitToCustomerDetails {

    private BigDecimal moneyAmount;

    @Override
    public String toString() {
      return "TransitToCustomerDetails{"
          + "moneyAmount="
          + moneyAmount
          + ", uuid='"
          + uuid
          + '\''
          + ", iban='"
          + iban
          + '\''
          + ", customerNumber='"
          + customerNumber
          + '\''
          + ", category='"
          + category
          + '\''
          + ", cstate='"
          + cstate
          + '\''
          + ", bstate='"
          + bstate
          + '\''
          + '}';
    }

    private String uuid;

    private String iban;

    public BigDecimal getMoneyAmount() {
      return moneyAmount;
    }

    public String getUuid() {
      return uuid;
    }

    public String getIban() {
      return iban;
    }

    public String getCustomerNumber() {
      return customerNumber;
    }

    public String getCategory() {
      return category;
    }

    public String getCstate() {
      return cstate;
    }

    public String getBstate() {
      return bstate;
    }

    private String customerNumber;

    private String category;

    private String cstate;

    public TransitToCustomerDetails(
        BigDecimal moneyAmount,
        String uuid,
        String iban,
        String customerNumber,
        String category,
        String cstate,
        String bstate,
        String pbBic) {
      this.moneyAmount = moneyAmount;
      this.uuid = uuid;
      this.iban = iban;
      this.customerNumber = customerNumber;
      this.category = category;
      this.cstate = cstate;
      this.bstate = bstate;
      this.pbBic = pbBic;
    }

    private String bstate;

    public String getPbBic() {
      return pbBic;
    }

    private String pbBic;
  }

  public void mocki2tBookingsCsv(List<InterestToTransitInvestmentDetails> t2iTickets)
      throws InterruptedException {
    for (InterestToTransitInvestmentDetails ticket : t2iTickets) {
      i2tBookingsCsv(ticket);
    }
  }

  public void mockt2iBookingsCsv(List<TransitToInterestInvestmentDetails> t2iTickets)
      throws InterruptedException {
    for (TransitToInterestInvestmentDetails ticket : t2iTickets) {
      t2iBookingsCsv(ticket);
    }
  }

  public void mockt2cBookingsCsv(List<PayoutExecuted> payoutExecuteds) throws InterruptedException {
    for (PayoutExecuted current : payoutExecuteds) {
      t2cBookingsCsv(current);
    }
  }

  /*
   * This method creates i2t booking csv and process till it reaches b2c
   * @param interestToTransitInvestmentDetails
   */
  private void i2tBookingsCsv(InterestToTransitInvestmentDetails interestToTransitInvestmentDetails)
      throws InterruptedException {
    String csvContent =
        SpsServices.getInstance()
            .generateDepositCSVContent(
                GVC._060,
                interestToTransitInvestmentDetails.getUuid(),
                SERVICEBANK_TRANSITACCOUNT_IBAN,
                "",
                interestToTransitInvestmentDetails.getMoneyAmount().toString(),
                "PayOut_csv");
    String FileName =
        SutorServices.getInstance()
            .putBookingCSVFile(csvContent, SERVICEBANK_TRANSITACCOUNT_KONTONUMMER);
    try {
      Thread.sleep(1000);
    } catch (InterruptedException e) {
      e.printStackTrace();
    }
    Sps.getInstance().importBankstatements();
    // SPS import file validation
    SpsServices.getInstance().validateImportFile(FileName, "PROCESSED");
    CoreBL.getInstance().importBankstatements();
  }

  /*
   * This method creates t2i booking csv and process till it reaches b2c
   * @param transitToInterestInvestmentDetails
   */
  private void t2iBookingsCsv(TransitToInterestInvestmentDetails transitToInterestInvestmentDetails)
      throws InterruptedException {
    String csvContent =
        SpsServices.getInstance()
            .generateDepositCSVContent(
                GVC._351,
                transitToInterestInvestmentDetails.getUuid(),
                SERVICEBANK_TRANSITACCOUNT_IBAN,
                PRODUCTBANK_INTERESTACCOUNT_IBAN,
                transitToInterestInvestmentDetails.getMoneyAmount().negate().toString(),
                "PayIn_csv");
    String FileName =
        SutorServices.getInstance()
            .putBookingCSVFile(csvContent, SERVICEBANK_TRANSITACCOUNT_KONTONUMMER);
    try {
      Thread.sleep(1000);
    } catch (InterruptedException e) {
      e.printStackTrace();
    }
    Sps.getInstance().importBankstatements();
    // SPS import file validation
    SpsServices.getInstance().validateImportFile(FileName, "PROCESSED");
    CoreBL.getInstance().importBankstatements();
  }

  /*
   * This method creates t2c booking csv and process till it reaches b2c
   * @param payoutExecuted
   */
  private void t2cBookingsCsv(PayoutExecuted payoutExecuted) throws InterruptedException {
    String csvContent =
        SpsServices.getInstance()
            .generateDepositCSVContent(
                GVC._391,
                "payout_customer-" + payoutExecuted.getFileUuid(),
                SERVICEBANK_TRANSITACCOUNT_IBAN,
                "",
                payoutExecuted.getMoneyAmount().negate().toString(),
                "PayIn_csv");
    String FileName =
        SutorServices.getInstance()
            .putBookingCSVFile(csvContent, SERVICEBANK_TRANSITACCOUNT_KONTONUMMER);
    try {
      Thread.sleep(1000);
    } catch (InterruptedException e) {
      e.printStackTrace();
    }
    Sps.getInstance().importBankstatements();
    // SPS import file validation
    SpsServices.getInstance().validateImportFile(FileName, "PROCESSED");
    CoreBL.getInstance().importBankstatements();
  }

  /*
   * This method validates CIAnPBIABookings for PayOut
   * @param TicketType
   * @param Amount
   * @param CIA
   * @param ServiceBank_BIC
   * @param TrancheIdentifier
   */
  public void payOutvalidateCIAnPBIABookings(
      String TicketType,
      String Amount,
      String CIA,
      String TrancheIdentifier,
      String ServiceBank_BIC) {
    Assert.assertEquals(
        DBReusables.getInstance().getCIABookingAmount(TicketType, CIA),
        Amount,
        "Customer Interest Bookings not created");
    Assert.assertEquals(
        DBReusables.getInstance()
            .getPBIABookingAmount(TicketType, TrancheIdentifier, ServiceBank_BIC),
        Amount,
        "Product Bank Interest Bookings not created");
  }

  /*
   * This method validates CTAnSBTAnCIAnPBIABookings for PayOut
   * @param TicketType
   * @param PayOutAmount
   * @param InterestAmount
   * @param ServiceBank_BIC
   * @param customerEmail
   * @param CIA
   * @param TrancheIdentifier
   */
  public void payOutValidateCTAnSBTAnCIAnPBIABookings(
      String TicketType,
      String InterestAmount,
      String PayOutAmount,
      String CIA,
      String TrancheIdentifier,
      String ServiceBank_BIC,
      String customerEmail,
      String PayOutType) {
    Assert.assertEquals(
        DBReusables.getInstance().getCIABookingAmountWithBST(TicketType, CIA, "INTEREST"),
        "-" + InterestAmount,
        "Customer Interest Bookings not created");
    // Assert.assertEquals(DBReusables.getInstance().getPBIABookingAmount(TicketType,
    // TrancheIdentifier, ServiceBank_BIC), "-" + (Double.parseDouble(InterestAmount) +
    // (Double.parseDouble(PayOutAmount))), "Product Bank Interest Bookings not created");
    if (!PayOutType.equalsIgnoreCase("FullProlongation")) {
      Assert.assertEquals(
          DBReusables.getInstance().getCIABookingAmountWithBST(TicketType, CIA, "PRINCIPAL"),
          "-" + PayOutAmount,
          "Customer Interest Bookings not created");
    }
    TestLogger.logInfo(
        "Amount successfully debited from Customer and Product Bank Interest Account Bookings");

    Assert.assertEquals(
        DBReusables.getInstance().getCTABookingAmountWithBST(TicketType, "INTEREST", customerEmail),
        InterestAmount,
        "Customer Transit Account Bookings not created");
    // Assert.assertEquals(DBReusables.getInstance().getSBTABookingAmount(TicketType,
    // ServiceBank_BIC), String.valueOf(Double.parseDouble(InterestAmount) +
    // (Double.parseDouble(PayOutAmount))), "Service Bank Transit Account Bookings not created");
    if (!PayOutType.equalsIgnoreCase("FullProlongation")) {
      Assert.assertEquals(
          DBReusables.getInstance()
              .getCTABookingAmountWithBST(TicketType, "PRINCIPAL", customerEmail),
          PayOutAmount,
          "Customer Transit Account Bookings not created");
    }
    TestLogger.logInfo(
        "Amount successfully credited to Customer and Service Bank Transit Account Bookings");
  }

  /*
   * This method validates CTAnSBTAnCIAnPBIABookings for PayOut
   * @param methosName
   * @param TicketType
   * @param PayOutAmount
   * @param InterestAmount
   * @param ServiceBank_BIC
   * @param customerEmail
   * @param CIA
   * @param TrancheIdentifier
   */
  public void icValidateCTAnSBTAnCIAnPBIABookings(
      String methodName,
      String TicketType,
      String InterestAmount,
      String PayOutAmount,
      String CIA,
      String TrancheIdentifier,
      String ServiceBank_BIC,
      String customerEmail) {
    Assert.assertEquals(
        DBReusables.getInstance().getCIABookingAmountWithBST(TicketType, CIA, "INTEREST"),
        "-" + InterestAmount,
        "Customer Interest Bookings not created");
    // Assert.assertEquals(DBReusables.getInstance().getPBIABookingAmount(TicketType,
    // TrancheIdentifier, ServiceBank_BIC), "-" + (Double.parseDouble(InterestAmount) +
    // (Double.parseDouble(PayOutAmount))), "Product Bank Interest Bookings not created");
    if (methodName.contains("DefaultPayOut")) {
      Assert.assertEquals(
          DBReusables.getInstance().getCIABookingAmountWithBST(TicketType, CIA, "PRINCIPAL"),
          "-" + PayOutAmount,
          "Customer Interest Bookings not created");
    }
    TestLogger.logInfo(
        "Amount successfully debited from Customer and Product Bank Interest Account Bookings");

    Assert.assertEquals(
        DBReusables.getInstance().getCTABookingAmountWithBST(TicketType, "INTEREST", customerEmail),
        InterestAmount,
        "Customer Transit Account Bookings not created");
    // Assert.assertEquals(DBReusables.getInstance().getSBTABookingAmount(TicketType,
    // ServiceBank_BIC), String.valueOf(Double.parseDouble(InterestAmount) +
    // (Double.parseDouble(PayOutAmount))), "Service Bank Transit Account Bookings not created");
    if (methodName.contains("DefaultPayOut")) {
      Assert.assertEquals(
          DBReusables.getInstance()
              .getCTABookingAmountWithBST(TicketType, "PRINCIPAL", customerEmail),
          PayOutAmount,
          "Customer Transit Account Bookings not created");
    }
    TestLogger.logInfo(
        "Amount successfully credited to Customer and Service Bank Transit Account Bookings");
  }

  /*
   * This method validates CTAnSBTABookings for PayOut
   * @param TicketType
   * @param PayOutAmount
   * @param InterestAmount
   * @param ServiceBank_BIC
   * @param customerEmail
   */
  public void payOutValidateCTAnSBTABookings(
      String TicketType,
      String PayOutAmount,
      String InterestAmount,
      String ServiceBank_BIC,
      String customerEmail,
      String ChangeType) {

    if (ChangeType.equalsIgnoreCase("FullProlongation") || ChangeType.contains("Ic")) {
      Assert.assertEquals(
          DBReusables.getInstance().getCTABookingAmount(TicketType, customerEmail),
          "-" + InterestAmount,
          "Customer Transit Account Bookings not created");
      Assert.assertEquals(
          DBReusables.getInstance().getSBTABookingAmount(TicketType, ServiceBank_BIC),
          "-" + InterestAmount,
          "Service Bank Transit Account Bookings not created");

    } else {
      Assert.assertEquals(
          DBReusables.getInstance().get2ndCTABookingAmount(TicketType, customerEmail),
          "-" + InterestAmount,
          "Customer Transit Account Bookings not created");
      Assert.assertEquals(
          DBReusables.getInstance().get2ndSBTABookingAmount(TicketType, ServiceBank_BIC),
          "-" + InterestAmount,
          "Service Bank Transit Account Bookings not created");
      Assert.assertEquals(
          DBReusables.getInstance().getCTABookingAmount(TicketType, customerEmail),
          "-" + PayOutAmount,
          "Customer Transit Account Bookings not created");
      Assert.assertEquals(
          DBReusables.getInstance().getSBTABookingAmount(TicketType, ServiceBank_BIC),
          "-" + PayOutAmount,
          "Service Bank Transit Account Bookings not created");
    }
    TestLogger.logInfo(
        "Amount successfully credited to Customer and Service Bank Transit Account Bookings");
  }

  /*
   * This method validates CTAnSBTAnCIAnPBIABookings for PayIn
   * @param TicketType
   * @param PayInAmount
   * @param ServiceBank_BIC
   * @param customerEmail
   * @param CIA
   * @param TrancheIdentifier
   */
  public void payInValidateCTAnSBTAnCIAnPBIABookings(
      String TicketType,
      String PayInAmount,
      String CIA,
      String TrancheIdentifier,
      String ServiceBank_BIC,
      String customerEmail) {
    Assert.assertEquals(
        DBReusables.getInstance().getCTABookingAmount(TicketType, customerEmail),
        "-" + PayInAmount,
        "Customer Transit Account Bookings not created");
    Assert.assertEquals(
        DBReusables.getInstance().getSBTABookingAmount(TicketType, ServiceBank_BIC),
        "-" + PayInAmount,
        "Service Bank Transit Account Bookings not created");
    TestLogger.logInfo(
        "Amount successfully debited from Customer and Service Bank Transit Account Bookings");
    Assert.assertEquals(
        DBReusables.getInstance().getCIABookingAmount(TicketType, CIA),
        PayInAmount,
        "Customer Interest Bookings not created");
    Assert.assertEquals(
        DBReusables.getInstance()
            .getPBIABookingAmount(TicketType, TrancheIdentifier, ServiceBank_BIC),
        PayInAmount,
        "Product Bank Interest Bookings not created");
    TestLogger.logInfo(
        "Amount successfully credited to Customer and Product Bank Interest Account Bookings");
  }

  /*
   * This method validates CTAnSBTAnCIAnPBIABookings for PayIn
   * @param TicketType
   * @param PayInAmount
   * @param ServiceBank_BIC
   * @param customerEmail
   * @param CIA
   * @param TrancheIdentifier
   */
  public void i2iValidateCIAnPBIABookings(
      String TicketType,
      String IcAmount,
      String TCIA,
      String TargetTrancheIdentifier,
      String ServiceBank_BIC,
      String CIA,
      String SourceTrancheIdentifier) {
    Assert.assertEquals(
        DBReusables.getInstance().getCIABookingAmount(TicketType, TCIA),
        IcAmount,
        "Customer Interest Bookings not created");
    Assert.assertEquals(
        DBReusables.getInstance()
            .getPBIABookingAmount(TicketType, TargetTrancheIdentifier, ServiceBank_BIC),
        IcAmount,
        "Product Bank Interest Bookings not created");
    Assert.assertEquals(
        DBReusables.getInstance().getCIABookingAmount(TicketType, CIA),
        "-" + IcAmount,
        "Customer Interest Bookings not created");
    Assert.assertEquals(
        DBReusables.getInstance()
            .getPBIABookingAmount(TicketType, SourceTrancheIdentifier, ServiceBank_BIC),
        "-" + IcAmount,
        "Product Bank Interest Bookings not created");

    TestLogger.logInfo(
        "Amount successfully debited from Customer and Product Bank Interest Account Bookings for Source");
    TestLogger.logInfo(
        "Amount successfully credited to Customer and Product Bank Interest Account Bookings for Target");
  }

  /*
   * This method validates CTAnSBTABookings for PayIn
   * @param TicketType
   * @param PayInAmount
   * @param ServiceBank_BIC
   * @param customerEmail
   */
  public void payInValidateCTAnSBTABookings(
      String TicketType, String PayInAmount, String ServiceBank_BIC, String customerEmail)
      throws InterruptedException {
    Assert.assertEquals(
        DBReusables.getInstance().getCTABookingAmount(TicketType, customerEmail),
        PayInAmount,
        "Customer Transit Account Bookings not created");
    Assert.assertEquals(
        DBReusables.getInstance().getSBTABookingAmount(TicketType, ServiceBank_BIC),
        PayInAmount,
        "Service Bank Transit Account Bookings not created");
    TestLogger.logInfo(
        "Amount successfully credited to Customer and Service Bank Transit Account Bookings");
  }

  /*
   * This method creates Payin/deposit till it reaches b2c
   * @param payinCode
   * @param customerAccountNumber
   * @param amount
   */
  public void customerPayin(String payinCode, String customerAccountNumber, String amount)
      throws InterruptedException {
    String csvContent =
        SpsServices.getInstance()
            .generateDepositCSVContent(
                GVC._360,
                payinCode,
                SERVICEBANK_TRANSITACCOUNT_IBAN,
                customerAccountNumber,
                amount,
                "PayIn_csv");
    String FileName =
        SutorServices.getInstance()
            .putBookingCSVFile(csvContent, SERVICEBANK_TRANSITACCOUNT_KONTONUMMER);
    try {
      Thread.sleep(1000);
    } catch (InterruptedException e) {
      e.printStackTrace();
    }
    Sps.getInstance().importBankstatements();
    // SPS import file validation
    SpsServices.getInstance().validateImportFile(FileName, "PROCESSED");
    CoreBL.getInstance().importBankstatements();
  }

  /*
   * This method creates and process payoutExecuted files till b2c
   * @param transitToCustomerDetails
   * @param payoutExecuted
   */
  protected void createAndPutPayoutCustomerExecuted(
      List<TransitToCustomerDetails> transitToCustomerDetails, PayoutExecuted payoutExecuted)
      throws InterruptedException {
    PayoutExecutedCsvFileBuilder payoutInterest = new PayoutExecutedCsvFileBuilder();
    List<TransitToCustomerDetails> currentTickets =
        transitToCustomerDetails.stream()
            .filter(i -> i.getCategory().equalsIgnoreCase(payoutExecuted.getCategory()))
            .collect(toList());
    BigDecimal totalAmount =
        currentTickets.stream()
            .filter(i -> i.getCategory().equalsIgnoreCase(payoutExecuted.getCategory()))
            .map(TransitToCustomerDetails::getMoneyAmount)
            .reduce(BigDecimal.ZERO, BigDecimal::add);
    BigDecimal totalInterest =
        currentTickets.stream()
            .filter(i -> i.getCategory().equalsIgnoreCase("GROSS_INTEREST"))
            .map(TransitToCustomerDetails::getMoneyAmount)
            .reduce(BigDecimal.ZERO, BigDecimal::add);
    for (TransitToCustomerDetails transitToCustomerDetail : currentTickets) {
      payoutInterest.addItem(
          new PayoutExecutedCsvFileBuilder.SutorPayoutResponseItem(transitToCustomerDetail));
    }
    payoutInterest.addItem(
        new PayoutExecutedCsvFileBuilder.SutorPayoutResponseItem(
            "",
            "",
            "",
            totalAmount,
            totalInterest,
            BigDecimal.ZERO,
            false,
            "",
            BigDecimal.ZERO,
            BigDecimal.ZERO,
            BigDecimal.ZERO,
            "",
            "",
            ""));
    String FileName =
        SutorServices.getInstance()
            .putPayoutExecuted(
                payoutInterest.buildToCsv(), UUID.fromString(payoutExecuted.getFileUuid()));
    try {
      Thread.sleep(1000);
    } catch (InterruptedException e) {
      e.printStackTrace();
    }
    Sps.getInstance().importPayout();
    // SPS import file validation
    SpsServices.getInstance().validateImportFile(FileName, "IMPORTED");
    CoreBL.getInstance().importBankstatements();
  }

  /*
   * This method does t2i ticket/s processing
   * @param BankTicket_id
   * @param CustomerTicket_id
   */
  public void btot2iProcessing(String BankTicket_id, String CustomerTicket_id)
      throws SQLException, ClassNotFoundException, InterruptedException {
    List<TransitToInterestInvestmentDetails> t2iTickets =
        DBReusables.getInstance().gett2iTickets(BankTicket_id).stream()
            .filter(i -> i.getState() != null && i.getState().equals("SENT_TO_BANK"))
            .collect(Collectors.toList());
    mockt2iBookingsCsv(t2iTickets);
    DBReusables.getInstance()
        .ticketStateValidation(CustomerTicket_id, "EXECUTED", DBReusables.getInstance().ct2iTable);
    DBReusables.getInstance()
        .ticketStateValidation(BankTicket_id, "EXECUTED", DBReusables.getInstance().bt2iTable);
    TestLogger.logInfo("Customer and Bank Transfer Ticket Executed successfully");
  }

  /*
   * This method does i2t ticket/s processing
   * @param i2tPBankTicket_id
   * @param i2tPTicket_id
   * @param i2tIBankTicket_id
   * @param i2tITicket_id
   */
  public void btoi2tProcessing(
      String i2tPBankTicket_id,
      String i2tPTicket_id,
      String i2tIBankTicket_id,
      String i2tITicket_id)
      throws InterruptedException {
    List<InterestToTransitInvestmentDetails> i2tTickets =
        DBReusables.getInstance().geti2tTickets(i2tPBankTicket_id).stream()
            .filter(i -> i.getState() != null && i.getState().equals("SENT_TO_BANK"))
            .collect(Collectors.toList());
    mocki2tBookingsCsv(i2tTickets);
    DBReusables.getInstance()
        .ticketStateValidation(i2tPTicket_id, "EXECUTED", DBReusables.getInstance().ci2tTable);
    DBReusables.getInstance()
        .ticketStateValidation(i2tPBankTicket_id, "EXECUTED", DBReusables.getInstance().bi2tTable);
    if (i2tITicket_id != null) {
      DBReusables.getInstance()
          .ticketStateValidation(i2tITicket_id, "EXECUTED", DBReusables.getInstance().ci2tTable);
      DBReusables.getInstance()
          .ticketStateValidation(
              i2tIBankTicket_id, "EXECUTED", DBReusables.getInstance().bi2tTable);
    }
    TestLogger.logInfo(
        "I2T Principal/Interest Customer and Bank Transfer Ticket Executed successfully");
  }

  /*
   * This method does t2c ticket/s processing
   * @param t2cPBankTicket_id
   * @param t2cPTicket_id
   * @param t2cIBankTicket_id
   * @param t2cITicket_id
   * @param SourceTrancheIdentifier
   * @param Category
   */
  public void btot2cProcessing(
      String t2cPBankTicket_id,
      String t2cPTicket_id,
      String t2cIBankTicket_id,
      String t2cITicket_id,
      String SourceTrancheIdentifier)
      throws InterruptedException {
    List<TransitToCustomerDetails> t2cTickets =
        DBReusables.getInstance().gett2cTickets(t2cPBankTicket_id, t2cIBankTicket_id).stream()
            .filter(i -> i.getBstate() != null && i.getBstate().equals("SENT_TO_BANK"))
            .collect(toList());
    Thread.sleep(1000);
    mockt2cBookingsCsv(DBReusables.getInstance().getPayoutInformation(SourceTrancheIdentifier));
    for (PayoutExecuted payoutExecuted :
        DBReusables.getInstance().getPayoutInformation(SourceTrancheIdentifier)) {
      createAndPutPayoutCustomerExecuted(t2cTickets, payoutExecuted);
    }
    DBReusables.getInstance()
        .ticketStateValidation(t2cPTicket_id, "EXECUTED", DBReusables.getInstance().ct2cTable);
    DBReusables.getInstance()
        .ticketStateValidation(t2cPBankTicket_id, "EXECUTED", DBReusables.getInstance().bt2cTable);
    if (t2cITicket_id != null) {
      DBReusables.getInstance()
          .ticketStateValidation(t2cITicket_id, "EXECUTED", DBReusables.getInstance().ct2cTable);
      DBReusables.getInstance()
          .ticketStateValidation(
              t2cIBankTicket_id, "EXECUTED", DBReusables.getInstance().bt2cTable);
    }
    TestLogger.logInfo(
        "T2C Principal/Interest Customer and Bank Transfer Ticket Executed successfully");
  }

  /*
   * This method validates customer ticket
   * @param CIA
   * @param CustomerNumber
   * @param ServiceBank_BIC
   * @param CustomerTicket_id
   * @param table
   * @param TrancheIdentifier
   * @param Amount
   * @param Category
   */
  public void validateCustomerTicket(
      String CustomerTicket_id,
      String CIA,
      String CustomerNumber,
      String ServiceBank_BIC,
      String table,
      String Amount,
      String Category,
      String TrancheIdentifier) {
    Assert.assertNotNull(CustomerTicket_id, "Customer ticket is not created");
    String CustomerTicket_uuid = DBReusables.getInstance().getTicket_uuid(CustomerTicket_id, table);

    TestLogger.logInfo("Customer ticket ID is : " + CustomerTicket_id);
    TestLogger.logInfo("Customer ticket UUID is : " + CustomerTicket_uuid);

    switch (table) {
      case "b2c_customer_transfer_ticket_t_to_i":
        validateCIA(
            CIA, CustomerNumber, ServiceBank_BIC, CustomerTicket_id, table, TrancheIdentifier);
        Assert.assertEquals(
            DBReusables.getInstance().getTicketState(CustomerTicket_id, table),
            "VALID",
            "Customer ticket state is INVALID with reason : "
                + DBReusables.getInstance().getTicketStateMessage(CustomerTicket_id, table));
        break;
      case "b2c_customer_transfer_ticket_i_to_t":
        validateCIA(
            CIA, CustomerNumber, ServiceBank_BIC, CustomerTicket_id, table, TrancheIdentifier);
        Assert.assertEquals(
            DBReusables.getInstance().getTicketState(CustomerTicket_id, table),
            "CREATED",
            "Customer ticket state is INVALID with reason : "
                + DBReusables.getInstance().getTicketStateMessage(CustomerTicket_id, table));
        if (!Category.equalsIgnoreCase("null")) {
          Assert.assertEquals(
              DBReusables.getInstance().getTicketCategory(CustomerTicket_id, table),
              Category,
              "mismatch of category");
        }
        break;
      case "b2c_customer_transfer_ticket_t_to_c":
        Assert.assertEquals(
            DBReusables.getInstance().getTicketState(CustomerTicket_id, table),
            "CREATED",
            "Customer ticket state is INVALID with reason : "
                + DBReusables.getInstance().getTicketStateMessage(CustomerTicket_id, table));
        Assert.assertEquals(
            DBReusables.getInstance().getTicketCategory(CustomerTicket_id, table),
            Category,
            "mismatch of category");
        Assert.assertEquals(
            DBReusables.getInstance().getTicketSutorDepotBankAccount_id(CustomerTicket_id, table),
            DBReusables.getInstance().getCustomerServiceBankID(CustomerNumber),
            "mismatch of depotBankAccount_id");
        break;
    }
    Assert.assertEquals(
        DBReusables.getInstance().getCustomerTransitAccount_id(CustomerTicket_id, table),
        DBReusables.getInstance()
            .getCTA(DBReusables.getInstance().getCustomerEmail(CustomerNumber)),
        "mismatch of CTA for " + CustomerNumber);
    if (Category.equalsIgnoreCase("GROSS_INTEREST")) {
      Assert.assertNotNull(
          DBReusables.getInstance().getTicketAmount(CustomerTicket_id, table),
          "Interest Amount is null");
    } else {
      Assert.assertEquals(
          DBReusables.getInstance().getTicketAmount(CustomerTicket_id, table),
          Amount,
          "Amount does not match");
    }
    if (TrancheIdentifier.contains("-FG") && !table.equals("b2c_customer_transfer_ticket_t_to_i")) {
      Assert.assertEquals(
          DBReusables.getInstance().getRequestedValueDate(CustomerTicket_id, table),
          DBReusables.getInstance().getTrancheEndDate(TrancheIdentifier),
          "RequestedValueDate does not match");
    } else {
      Assert.assertEquals(
          DBReusables.getInstance().getRequestedValueDate(CustomerTicket_id, table),
          DBReusables.getInstance().getTrancheStartDate(TrancheIdentifier),
          "RequestedValueDate does not match");
    }
    Assert.assertEquals(
        DBReusables.getInstance().getProdID(CustomerTicket_id, table),
        DBReusables.getInstance().getProductTrancheId(TrancheIdentifier),
        "Product Tranche does not match");
    // earliest transferdate is validated if its lessthan or equal to (request value date -
    // anticipateTrancheCloseByDays)
    LocalDate ETD =
        LocalDate.parse(
            (CharSequence)
                DBReusables.getInstance().getEarliestTransferDate(CustomerTicket_id, table));
    Assert.assertTrue(
        ETD.isBefore(expEarliestTransferDate(table, TrancheIdentifier))
            || ETD.isEqual(expEarliestTransferDate(table, TrancheIdentifier)),
        "EarliestTransferDate does not match");
    TestLogger.logInfo("Successfully validated Data from " + table + " table");
  }

  /*
   * This method validates Prolongation ticket
   * @param CustomerNumber
   * @param ServiceBank_BIC
   * @param CustomerTicket_id
   * @param table
   * @param SourceTrancheIdentifier
   * @param TargetTrancheIdentifier
   * @param Amount
   * @param CIA
   * @param TCIA
   */
  public void validateProlongationOrI2iTicket(
      String CustomerTicket_id,
      String CustomerNumber,
      String ServiceBank_BIC,
      String table,
      String Amount,
      String SourceTrancheIdentifier,
      String TargetTrancheIdentifier,
      String CIA,
      String TCIA) {
    Assert.assertNotNull(CustomerTicket_id, "Customer ticket is not created");
    TestLogger.logInfo("Customer ticket ID is : " + CustomerTicket_id);

    Assert.assertEquals(
        DBReusables.getInstance().getRequestedValueDate(CustomerTicket_id, table),
        DBReusables.getInstance().getTrancheStartDate(TargetTrancheIdentifier),
        "RequestedValueDate does not match");
    if (table.contains("prolongation")) {
      Assert.assertEquals(
          DBReusables.getInstance().getProdID(CustomerTicket_id, table),
          DBReusables.getInstance().getProductTrancheId(SourceTrancheIdentifier),
          "Product Tranche does not match");
      DBReusables.getInstance().ticketStateValidation(CustomerTicket_id, "EXECUTED", table);
      DBReusables.getInstance()
          .ticketStateValidation(
              DBReusables.getInstance().getBankTransferTicketID(CustomerTicket_id, table),
              "EXECUTED",
              DBReusables.getInstance().bProTable);
    } else {
      Assert.assertEquals(
          DBReusables.getInstance().getProdID(CustomerTicket_id, table),
          DBReusables.getInstance().getProductTrancheId(TargetTrancheIdentifier),
          "Product Tranche does not match");
      DBReusables.getInstance().ticketStateValidation(CustomerTicket_id, "VALID", table);
    }
    validateProlongationOrI2iTicketCIA(
        CustomerNumber,
        ServiceBank_BIC,
        CustomerTicket_id,
        table,
        SourceTrancheIdentifier,
        TargetTrancheIdentifier,
        CIA,
        TCIA);
    Assert.assertEquals(
        DBReusables.getInstance().getTicketAmount(CustomerTicket_id, table),
        Amount,
        "Amount does not match");
    LocalDate ETD =
        LocalDate.parse(
            (CharSequence)
                DBReusables.getInstance().getEarliestTransferDate(CustomerTicket_id, table));
    Assert.assertTrue(
        ETD.isBefore(expEarliestTransferDate(table, SourceTrancheIdentifier))
            || ETD.isEqual(expEarliestTransferDate(table, SourceTrancheIdentifier)),
        "EarliestTransferDate does not match");
    TestLogger.logInfo("Successfully validated Data from " + table + " table");
  }

  /*
   * This method calculates Earliest Transfer Date
   * @param table
   * @param TrancheIdentifier
   * current logic is (request value date - anticipateTrancheCloseByDays) needs to include joly day calendar here
   */
  public LocalDate expEarliestTransferDate(String table, String TrancheIdentifier) {
    LocalDate startDate;
    if (TrancheIdentifier.contains("-FG") && !table.equals("b2c_customer_transfer_ticket_t_to_i")) {
      startDate =
          LocalDate.parse(
              (CharSequence) DBReusables.getInstance().getTrancheEndDate(TrancheIdentifier));
    } else {
      startDate =
          LocalDate.parse(
              (CharSequence) DBReusables.getInstance().getTrancheStartDate(TrancheIdentifier));
    }
    LocalDate expEarliestTransferDate =
        startDate.minusDays(
            Long.parseLong(
                DBReusables.getInstance().getanticipateTrancheCloseByDays(TrancheIdentifier)));
    return expEarliestTransferDate;
  }

  /*
   * This method validates CIA for PayIN
   * @param CIA
   * @param CustomerNumber
   * @param ServiceBank_BIC
   * @param CustomerTicket_id
   * @param table
   * @param TrancheIdentifier
   */
  public void validateCIA(
      String CIA,
      String CustomerNumber,
      String ServiceBank_BIC,
      String CustomerTicket_id,
      String table,
      String TrancheIdentifier) {
    if (CIA == null) {
      String newCIA =
          DBReusables.getInstance().getCIA(CustomerNumber, TrancheIdentifier, ServiceBank_BIC);
      Assert.assertNotNull(newCIA, "Customer Interest Account is not created");
      TestLogger.logInfo("Customer Interest Account ID created is : " + newCIA);

    } else {
      Assert.assertEquals(
          DBReusables.getInstance().getCustomerInterestAccount_id(CustomerTicket_id, table),
          CIA,
          "mismatch of CIA for " + CustomerNumber);
    }
  }

  /*
   * This method validates CIA for Prolongation
   * @param CustomerNumber
   * @param ServiceBank_BIC
   * @param CustomerTicket_id
   * @param table
   * @param SourceTrancheIdentifier
   * @param TargetTrancheIdentifier
   * @param TCIA
   * @param CIA
   */
  public void validateProlongationOrI2iTicketCIA(
      String CustomerNumber,
      String ServiceBank_BIC,
      String CustomerTicket_id,
      String table,
      String SourceTrancheIdentifier,
      String TargetTrancheIdentifier,
      String CIA,
      String TCIA) {
    if (CIA == null) {
      String newCIA =
          DBReusables.getInstance()
              .getCIA(CustomerNumber, SourceTrancheIdentifier, ServiceBank_BIC);
      Assert.assertNotNull(newCIA, "Customer Interest Account is not created");
      TestLogger.logInfo("New Customer Interest Account ID created is : " + newCIA);

    } else {
      Assert.assertEquals(
          DBReusables.getInstance().getSourceInterestAccount_id(CustomerTicket_id, table),
          CIA,
          "mismatch of source CIA for " + CustomerNumber);
    }
    if (TCIA == null) {
      String newCIA =
          DBReusables.getInstance()
              .getCIA(CustomerNumber, TargetTrancheIdentifier, ServiceBank_BIC);
      Assert.assertNotNull(newCIA, "Customer Interest Account is not created");
      TestLogger.logInfo("New Customer Interest Account ID created is : " + newCIA);

    } else {
      Assert.assertEquals(
          DBReusables.getInstance().getTargetInterestAccount_id(CustomerTicket_id, table),
          CIA,
          "mismatch of target CIA for " + CustomerNumber);
    }
  }

  /*
   * This method fetchs Service Band and Product Bank Iban
   * @param ServiceBank_BIC
   * @param TrancheIdentifier
   */
  public void SBandPB_IBAN(String ServiceBank_BIC, String TrancheIdentifier) {
    SERVICEBANK_TRANSITACCOUNT_IBAN =
        DBReusables.getInstance().getSutorTransitAccountIban(ServiceBank_BIC);
    PRODUCTBANK_INTERESTACCOUNT_IBAN =
        DBReusables.getInstance().getPbiaIban(TrancheIdentifier, ServiceBank_BIC);
    IBAN sbta = new IBAN(SERVICEBANK_TRANSITACCOUNT_IBAN);
    SERVICEBANK_TRANSITACCOUNT_IDENTIFIER =
        sbta.getBankSortCode() + "/" + sbta.getBankAccountNumber();
    SERVICEBANK_TRANSITACCOUNT_KONTONUMMER = sbta.getBankAccountNumber();
    TestLogger.logInfo("Fetched Service Band and Product Bank Iban successfully");
  }

  /*
   * This is Payin Method for FAM/DRM Bank
   * @param trancheIdentifier
   * @param customerEmail
   * @param payInAmount
   */
  public void payIn(String trancheIdentifier, String customerEmail, String payInAmount)
      throws SQLException, ClassNotFoundException, InterruptedException {
    String Category = "PAY_IN";
    String TicketType = "TRANSIT_TO_INTEREST";
    // calling SB & PB Iban method
    SBandPB_IBAN(ServiceBank_BIC, trancheIdentifier);

    TestLogger.logMsg("Step-1: Get CustomerNumber,MultiPurposeText and CounterPartAccNumber");
    String CustomerNumber = DBReusables.getInstance().getCustomerNumber(customerEmail);
    String MULTI_PURPOSE_TEXT =
        DBReusables.getInstance().getPayInCodeFromTrancheIdentifier(trancheIdentifier);
    String COUNTER_PART_ACCOUNT_NUMBER =
        new IBAN(DBReusables.getInstance().getCustomerServiceBankIban(CustomerNumber))
            .getBankAccountNumber();
    String CIA =
        DBReusables.getInstance().getCIA(CustomerNumber, trancheIdentifier, ServiceBank_BIC);
    String FormatedPayInAmount =
        (DBReusables.getInstance()
            .formatCurrency(payInAmount)
            .substring(0, DBReusables.getInstance().formatCurrency(payInAmount).indexOf(" ")));

    // Payin ticket creation
    TestLogger.logMsg("Step-2: Create Payin Ticket");
    customerPayin(MULTI_PURPOSE_TEXT, COUNTER_PART_ACCOUNT_NUMBER, payInAmount);

    // Ticket validations
    TestLogger.logMsg("Step-3: Validate Customer Ticket");
    String CustomerTicket_id =
        DBReusables.getInstance()
            .getCustomerTicket_id(DBReusables.getInstance().ct2iTable, customerEmail);

    validateCustomerTicket(
        CustomerTicket_id,
        CIA,
        CustomerNumber,
        ServiceBank_BIC,
        DBReusables.getInstance().ct2iTable,
        payInAmount,
        Category,
        trancheIdentifier);

    TestLogger.logMsg("Step-4: Validate CTA and SBTA Bookings");
    payInValidateCTAnSBTABookings(Category, payInAmount, ServiceBank_BIC, customerEmail);

    // Shop validation
    TestLogger.logMsg("Step-5: Validate Inprogress ticket in Shop");
    MeineAnlagenPO.getInstance().getInvestmentDetails(trancheIdentifier, customerEmail);
    MeineAnlagenPO.getInstance()
        .validateShopBookings(
            2,
            DateTimeFormatter.ofPattern("dd.MM.yyyy")
                    .format(
                        LocalDate.parse(
                            (CharSequence)
                                DBReusables.getInstance().getTrancheStartDate(trancheIdentifier)))
                + " vorgemerkt Einzahlung * "
                + FormatedPayInAmount);
    MeineAnlagenPO.getInstance()
        .validateShopHint(
            "Ihr Anlagebetrag wird von Ihrer ZINSPILOT-Partnerbank zum Anlagestart automatisch bei der "
                + DBReusables.getInstance().getBankName_FromTrancheIdentifier(trancheIdentifier)
                + " angelegt.");

    // Gunda validation
    TestLogger.logMsg("Step-6: Validate Inprogress ticket in Gunda");
    int num =
        GundaServices.getInstance()
            .getInprogressTicket_Array(
                CustomerNumber,
                DBReusables.getInstance()
                    .getTicket_uuid(CustomerTicket_id, DBReusables.getInstance().ct2iTable));
    Assert.assertEquals(
        (WebServiceOperations.getInstance()
            .convertStringToJson(Gunda.getInstance().Gunda_GetCustomer(CustomerNumber))
            .getString("notExecutedTickets[" + num + "].productIdentifier")),
        trancheIdentifier,
        "Gunda TrancheIdentifier is not correct");
    Assert.assertEquals(
        (WebServiceOperations.getInstance()
            .convertStringToJson(Gunda.getInstance().Gunda_GetCustomer(CustomerNumber))
            .getString("notExecutedTickets[" + num + "].ticketType")),
        "TRANSIT_TO_INTEREST",
        "Gunda ticketType is not correct");
    Assert.assertEquals(
        (WebServiceOperations.getInstance()
            .convertStringToJson(Gunda.getInstance().Gunda_GetCustomer(CustomerNumber))
            .getString("notExecutedTickets[" + num + "].ticketState")),
        "VALID",
        "Gunda ticketState is not correct");
    Assert.assertEquals(
        (WebServiceOperations.getInstance()
            .convertStringToJson(Gunda.getInstance().Gunda_GetCustomer(CustomerNumber))
            .getString("notExecutedTickets[" + num + "].expectedValueDate")),
        DBReusables.getInstance().getTrancheStartDate(trancheIdentifier),
        "Gunda expectedValueDate is not correct");
    Assert.assertEquals(
        (WebServiceOperations.getInstance()
            .convertStringToJson(Gunda.getInstance().Gunda_GetCustomer(CustomerNumber))
            .getString("notExecutedTickets[" + num + "].amount")),
        DBReusables.getInstance()
                .formatCurrency1(payInAmount)
                .substring(1, DBReusables.getInstance().formatCurrency1(payInAmount).length())
            + " EUR",
        "Gunda amount is not correct");

    // Email validation
    TestLogger.logMsg("Step-7: Validate Email in MailHog");
    MailHogPO.getInstance().openMailhog();
    MailHogPO.getInstance()
        .verifyEmail(
            customerEmail, "Einzahlungsbestätigung Ihres Anlagebetrags auf Ihrem ZINSPILOT-Konto");
    MailHogPO.getInstance().closeMailhog();
    WebUIOperations.getInstance().switchTab(0);

    // Changing EarliestTransferDate
    DBReusables.getInstance()
        .shiftEarliestTransferToToday(CustomerTicket_id, DBReusables.getInstance().ct2iTable);

    // prodops Ticket Processing
    TestLogger.logMsg("Step-8: ProdOps t2i Ticket Processing");
    ProdOpsServices.getInstance()
        .ticketProcessing(
            TicketType, ServiceBank_BIC, CustomerTicket_id, trancheIdentifier, customerEmail);

    // t2i Ticket Processing
    TestLogger.logMsg("Step-9: Processing t2i BTO Ticket ");
    String BankTicket_id =
        DBReusables.getInstance()
            .getBankTransferTicketID(CustomerTicket_id, DBReusables.getInstance().ct2iTable);
    btot2iProcessing(BankTicket_id, CustomerTicket_id);
    // CIA & PBIA booking/s validation
    TestLogger.logMsg("Step-10: Validate CTA,SBTA,CIA and PBIA Bookings");
    CIA = DBReusables.getInstance().getCIA(CustomerNumber, trancheIdentifier, ServiceBank_BIC);
    payInValidateCTAnSBTAnCIAnPBIABookings(
        TicketType, payInAmount, CIA, trancheIdentifier, ServiceBank_BIC, customerEmail);
    // shop validation
    TestLogger.logMsg("Step-11: Validate completed ticket in Shop");
    MeineAnlagenPO.getInstance().getInvestmentDetails(trancheIdentifier, customerEmail);
    MeineAnlagenPO.getInstance()
        .validateShopBookings(
            1,
            DBReusables.getInstance().formatDate("dd.MM.yyyy")
                + " "
                + DBReusables.getInstance().formatDate("dd.MM.yyyy")
                + " Einzahlung "
                + FormatedPayInAmount);

    // Gunda validation
    TestLogger.logMsg("Step-12: Validate completed ticket in Gunda");
    String FinalTotalBalanceAmount =
        DBReusables.getInstance().getCIAB_Balance(trancheIdentifier, customerEmail);
    Assert.assertEquals(
        (WebServiceOperations.getInstance()
            .convertStringToJson(Gunda.getInstance().Gunda_GetCustomer(CustomerNumber))
            .getString(
                "affiliations[0].customerInterestAccountsDetails["
                    + GundaServices.getInstance().getCIA_Array(CustomerNumber, CIA)
                    + "].interestAccount.productIdentifier")),
        trancheIdentifier,
        "Gunda TrancheIdentifier is not correct");
    Assert.assertEquals(
        (WebServiceOperations.getInstance()
            .convertStringToJson(Gunda.getInstance().Gunda_GetCustomer(CustomerNumber))
            .getString(
                "affiliations[0].customerInterestAccountsDetails["
                    + GundaServices.getInstance().getCIA_Array(CustomerNumber, CIA)
                    + "].interestAccount.balance")),
        DBReusables.getInstance()
                .formatCurrency1(FinalTotalBalanceAmount)
                .substring(
                    1, DBReusables.getInstance().formatCurrency1(FinalTotalBalanceAmount).length())
            + " EUR",
        "Gunda amount is not correct");
  }

  /*
   * This is PayOut Method for FAM/DRM Bank
   * @param methodName
   * @param SourceTrancheIdentifier
   * @param PayOutAmount
   * @param CustomerEmail
   * @param PayOutType
   * @param TargetTrancheIdentifier
   */
  public void PayOut(
      String methodName,
      String SourceTrancheIdentifier,
      String PayOutAmount,
      String CustomerEmail,
      String PayOutType,
      String TargetTrancheIdentifier)
      throws InterruptedException, SQLException, ClassNotFoundException, AWTException {
    DecimalFormat twoPlaces = new DecimalFormat("0.00");
    String TCIA = null,
        i2tPTicket_id = "",
        i2tPBankTicket_id = "",
        t2cPTicket_id = "",
        t2cPBankTicket_id = "";
    // calling SB & PB Iban method
    SBandPB_IBAN(ServiceBank_BIC, SourceTrancheIdentifier);
    String CustomerNumber = DBReusables.getInstance().getCustomerNumber(CustomerEmail);
    String CIA =
        DBReusables.getInstance().getCIA(CustomerNumber, SourceTrancheIdentifier, ServiceBank_BIC);
    String TotalBalanceAmount =
        DBReusables.getInstance().getCIAB_Balance(SourceTrancheIdentifier, CustomerEmail);
    String FormatedTotalBalanceAmount =
        (DBReusables.getInstance()
            .formatCurrency(TotalBalanceAmount)
            .substring(
                0, DBReusables.getInstance().formatCurrency(TotalBalanceAmount).indexOf(" ")));

    if (PayOutType.equalsIgnoreCase("FullPayOut")) {
      PayOutAmount = TotalBalanceAmount;
    } else if (PayOutType.equalsIgnoreCase("FullProlongation")) {
      PayOutAmount = "0.00";
    }

    if (SourceTrancheIdentifier.contains("-FG")) {
      TCIA =
          DBReusables.getInstance()
              .getCIA(CustomerNumber, TargetTrancheIdentifier, ServiceBank_BIC);
    }
    String FormatedPayOutAmount =
        (DBReusables.getInstance()
            .formatCurrency(PayOutAmount)
            .substring(0, DBReusables.getInstance().formatCurrency(PayOutAmount).indexOf(" ")));
    String ProlongationAmount =
        String.valueOf(
            twoPlaces.format(
                Double.parseDouble(TotalBalanceAmount) - (Double.parseDouble(PayOutAmount))));
    ProlongationAmount = DBReusables.getInstance().Aformat(ProlongationAmount);
    String FormatedProlongationAmount =
        (DBReusables.getInstance()
            .formatCurrency(ProlongationAmount)
            .substring(
                0, DBReusables.getInstance().formatCurrency(ProlongationAmount).indexOf(" ")));
    // Shop Login
    ShopLoginLogoutPO.getInstance().shopLogin(ENV, CustomerEmail);
    MeineAnlagenPO.getInstance().getInvestmentDetails(SourceTrancheIdentifier, CustomerEmail);
    if (SourceTrancheIdentifier.contains("-TG")) {
      TestLogger.logMsg("Step-1: Create PayOut");
      if (methodName.contains("Shop")) {
        // Pay Out from Shop
        MeineAnlagenPO.getInstance().initiatePayOutShop(FormatedPayOutAmount, PayOutType, CIA);
      } else {
        GundaPO.getInstance()
            .gundaPayOut(SourceTrancheIdentifier, FormatedPayOutAmount, CustomerNumber);
      }
      // Email validation
      TestLogger.logMsg("Step-3: Validate PayOut Email in MailHog");
      MailHogPO.getInstance().openMailhog();
      MailHogPO.getInstance().verifyEmail(CustomerEmail, "Auszahlung Ihrer Zinspilot Anlage");
      MailHogPO.getInstance().closeMailhog();
      WebUIOperations.getInstance().switchTab(0);
      // validate for closing investment ticket
      if (FormatedTotalBalanceAmount.equalsIgnoreCase(FormatedPayOutAmount)
          && !SourceTrancheIdentifier.equalsIgnoreCase("AGRLFR22XXX-TG")) {
        DBReusables.getInstance().ValidateCIT(CIA, "CREATED");
      }

    } else {
      if (!methodName.contains("Default")) {
        TestLogger.logMsg("Step-1: Set Customer PayOut/Prolongation Setting");
        if (methodName.contains("Shop")) {
          // Pay Out/Prolongation Settings from Shop
          MeineAnlagenPO.getInstance()
              .shopProlongationSettings(SourceTrancheIdentifier, PayOutType, FormatedPayOutAmount);
        } else {
          GundaPO.getInstance()
              .gundaProlongationSettings(
                  SourceTrancheIdentifier, PayOutType, FormatedPayOutAmount, CustomerNumber, CIA);
        }
      }

      // Interest Booking and Prolongation
      TestLogger.logMsg("Step-2: Execute InterestBooking and Prolongation");
      ProdOpsServices.getInstance()
          .interestBookingAndProlongation(
              SourceTrancheIdentifier,
              LocalDate.parse(DBReusables.getInstance().getTrancheEndDate(SourceTrancheIdentifier)),
              PayOutType,
              CustomerEmail);
    }

    if (SourceTrancheIdentifier.contains("-TG")) {
      String ValueDate = DBReusables.getInstance().getTrancheStartDate(SourceTrancheIdentifier);

      // close PayOutAssignment
      DBReusables.getInstance().UpdatePayOutAssignment(SourceTrancheIdentifier, "CLOSED");

      // Interest Booking
      TestLogger.logMsg("Step-2: Execute InterestBooking");
      ProdOpsServices.getInstance()
          .interestBooking(SourceTrancheIdentifier, LocalDate.parse(ValueDate), CustomerEmail);
    }

    if (!PayOutType.equalsIgnoreCase("FullProlongation")) {

      // Principal Tickets
      i2tPTicket_id =
          DBReusables.getInstance()
              .getCustomerTicket_id(DBReusables.getInstance().ci2tTable, CustomerEmail);
      t2cPTicket_id =
          DBReusables.getInstance()
              .getCustomerTicket_id(DBReusables.getInstance().ct2cTable, CustomerEmail);

      // Principal Ticket validations
      TestLogger.logMsg("Step-4: Validate Principal Ticket/s");
      TestLogger.logInfo("***i2t Principal PayOut ticket validation***");
      validateCustomerTicket(
          i2tPTicket_id,
          CIA,
          CustomerNumber,
          ServiceBank_BIC,
          DBReusables.getInstance().ci2tTable,
          PayOutAmount,
          "PRINCIPAL",
          SourceTrancheIdentifier);
      TestLogger.logInfo("***t2c Principal PayOut ticket validation***");
      Assert.assertEquals(
          DBReusables.getInstance()
              .getTicketDependency_id(t2cPTicket_id, DBReusables.getInstance().ct2cTable),
          i2tPTicket_id,
          "t2c ticket dependency did not match i2t ticket/Valid t2c ticket is not create");
      validateCustomerTicket(
          t2cPTicket_id,
          CIA,
          CustomerNumber,
          ServiceBank_BIC,
          DBReusables.getInstance().ct2cTable,
          PayOutAmount,
          "PRINCIPAL",
          SourceTrancheIdentifier);
    }
    if (SourceTrancheIdentifier.contains("-FG") && (PayOutType.equalsIgnoreCase("PartialPayOut"))) {
      // Prolongation Tickets

      String ProlTicket_id =
          DBReusables.getInstance()
              .getProlongationOrI2iTicket_id(DBReusables.getInstance().cProTable, CIA, TCIA);

      // Prolongation Ticket validations
      TestLogger.logMsg("Step-5: Validate Prolongation Ticket");
      TestLogger.logInfo("***Prolongation ticket validation***");
      validateProlongationOrI2iTicket(
          ProlTicket_id,
          CustomerNumber,
          ServiceBank_BIC,
          DBReusables.getInstance().cProTable,
          ProlongationAmount,
          SourceTrancheIdentifier,
          TargetTrancheIdentifier,
          CIA,
          TCIA);
    }

    // Interest Tickets
    String i2tITicket_id =
        DBReusables.getInstance()
            .getInterestTicket_id(DBReusables.getInstance().ci2tTable, CustomerEmail);
    String t2cITicket_id =
        DBReusables.getInstance()
            .getInterestTicket_id(DBReusables.getInstance().ct2cTable, CustomerEmail);
    String InterestAmount =
        DBReusables.getInstance()
            .getTicketAmount(i2tITicket_id, DBReusables.getInstance().ci2tTable);
    String FormatedInterestAmount =
        (DBReusables.getInstance()
            .formatCurrency(
                DBReusables.getInstance()
                    .getTicketAmount(i2tITicket_id, DBReusables.getInstance().ci2tTable))
            .substring(
                0,
                DBReusables.getInstance()
                    .formatCurrency(
                        DBReusables.getInstance()
                            .getTicketAmount(i2tITicket_id, DBReusables.getInstance().ci2tTable))
                    .indexOf(" ")));
    String TotalAmount =
        String.valueOf(
            twoPlaces.format(
                Double.parseDouble(InterestAmount) + (Double.parseDouble(PayOutAmount))));
    String FormatedTotalAmount =
        (DBReusables.getInstance()
            .formatCurrency(TotalAmount)
            .substring(0, DBReusables.getInstance().formatCurrency(TotalAmount).indexOf(" ")));

    // Interest Ticket validations
    TestLogger.logMsg("Step-6: Validate Interest Ticket/s");
    TestLogger.logInfo("***i2t Interest PayOut ticket validation***");
    validateCustomerTicket(
        i2tITicket_id,
        CIA,
        CustomerNumber,
        ServiceBank_BIC,
        DBReusables.getInstance().ci2tTable,
        PayOutAmount,
        "GROSS_INTEREST",
        SourceTrancheIdentifier);
    TestLogger.logInfo("***t2c Interest PayOut ticket validation***");
    Assert.assertEquals(
        DBReusables.getInstance()
            .getTicketDependency_id(t2cITicket_id, DBReusables.getInstance().ct2cTable),
        i2tITicket_id,
        "t2c ticket dependency did not match i2t ticket/Valid t2c ticket is not create");
    validateCustomerTicket(
        t2cITicket_id,
        CIA,
        CustomerNumber,
        ServiceBank_BIC,
        DBReusables.getInstance().ct2cTable,
        PayOutAmount,
        "GROSS_INTEREST",
        SourceTrancheIdentifier);

    // CIA & PBIA Bookings validation
    TestLogger.logMsg("Step-7: Validate CIA and PBIA Bookings");
    payOutvalidateCIAnPBIABookings(
        "INTEREST", InterestAmount, CIA, SourceTrancheIdentifier, ServiceBank_BIC);
    TestLogger.logInfo(
        "Interest Amount successfully added to Customer/Product Bank Interest Account Bookings for CIA id "
            + CIA);
    if (SourceTrancheIdentifier.contains("-FG")
        && (PayOutType.equalsIgnoreCase("PartialPayOut")
            || PayOutType.equalsIgnoreCase("FullProlongation"))
        && !FormatedTotalBalanceAmount.equalsIgnoreCase(FormatedPayOutAmount)) {
      payOutvalidateCIAnPBIABookings(
          "PROLONGATION", "-" + ProlongationAmount, CIA, SourceTrancheIdentifier, ServiceBank_BIC);
      TestLogger.logInfo(
          "Prolongation Amount successfully deducted from Customer/Product Bank Interest Account Bookings for CIA id "
              + CIA);
      payOutvalidateCIAnPBIABookings(
          "PROLONGATION",
          ProlongationAmount,
          DBReusables.getInstance()
              .getCIA(CustomerNumber, TargetTrancheIdentifier, ServiceBank_BIC),
          TargetTrancheIdentifier,
          ServiceBank_BIC);
      TestLogger.logInfo(
          "Prolongation Amount successfully added to Customer/Product Bank Interest Account Bookings for CIA id "
              + DBReusables.getInstance()
                  .getCIA(CustomerNumber, TargetTrancheIdentifier, ServiceBank_BIC));
    }

    // Shop Validation
    TestLogger.logMsg("Step-8: Validate Inprogress ticket in Shop");
    MeineAnlagenPO.getInstance()
        .payOutValidateInprogressTicketBookings(
            CustomerEmail,
            PayOutType,
            SourceTrancheIdentifier,
            FormatedTotalBalanceAmount,
            FormatedInterestAmount,
            FormatedPayOutAmount,
            TargetTrancheIdentifier,
            FormatedProlongationAmount);
    // Gunda validation
    TestLogger.logMsg("Step-9: Validate Inprogress ticket in Gunda");
    GundaServices.getInstance()
        .payOutValidateInprogressTicket(
            CustomerNumber,
            i2tPTicket_id,
            SourceTrancheIdentifier,
            PayOutAmount,
            i2tITicket_id,
            InterestAmount,
            TargetTrancheIdentifier,
            PayOutType);

    // Changing EarliestTransferDate
    if (!PayOutType.equalsIgnoreCase("FullProlongation")) {
      TestLogger.logInfo("***i2t Principal PayOut ticket ***");
      DBReusables.getInstance()
          .shiftEarliestTransferToToday(i2tPTicket_id, DBReusables.getInstance().ci2tTable);
    }
    TestLogger.logInfo("***i2t Interest PayOut ticket ***");
    DBReusables.getInstance()
        .shiftEarliestTransferToToday(i2tITicket_id, DBReusables.getInstance().ci2tTable);

    // prodops Ticket Processing for i2t
    TestLogger.logMsg("Step-10: ProdOps i2t Ticket Processing");
    if (!PayOutType.equalsIgnoreCase("FullProlongation")) {
      ProdOpsServices.getInstance()
          .ticketProcessing(
              i2tTicketType,
              ServiceBank_BIC,
              i2tPTicket_id,
              SourceTrancheIdentifier,
              CustomerEmail);
    } else {
      ProdOpsServices.getInstance()
          .ticketProcessing(
              i2tTicketType,
              ServiceBank_BIC,
              i2tITicket_id,
              SourceTrancheIdentifier,
              CustomerEmail);
    }
    // i2t Ticket Processing
    if (!PayOutType.equalsIgnoreCase("FullProlongation")) {
      i2tPBankTicket_id =
          DBReusables.getInstance()
              .getBankTransferTicketID(i2tPTicket_id, DBReusables.getInstance().ci2tTable);
    }
    String i2tIBankTicket_id =
        DBReusables.getInstance()
            .getBankTransferTicketID(i2tITicket_id, DBReusables.getInstance().ci2tTable);
    TestLogger.logMsg("Step-11: Processing i2t BTO Ticket ");
    if (!PayOutType.equalsIgnoreCase("FullProlongation")) {
      btoi2tProcessing(i2tPBankTicket_id, i2tPTicket_id, i2tIBankTicket_id, i2tITicket_id);
    } else {
      btoi2tProcessing(i2tIBankTicket_id, i2tITicket_id, i2tIBankTicket_id, i2tITicket_id);
    }

    // CIA,PBIA,CTA & SBTA booking/s validation
    TestLogger.logMsg("Step-12: Validate CTA,SBTA,CIA and PBIA Bookings");
    payOutValidateCTAnSBTAnCIAnPBIABookings(
        i2tTicketType,
        InterestAmount,
        PayOutAmount,
        CIA,
        SourceTrancheIdentifier,
        ServiceBank_BIC,
        CustomerEmail,
        PayOutType);
    // shop validation
    TestLogger.logMsg("Step-13: Validate Inprogress ticket in Shop post i2t ticket's processing");
    MeineAnlagenPO.getInstance()
        .payOutValidatePost_i2t(
            CustomerEmail,
            CIA,
            PayOutType,
            SourceTrancheIdentifier,
            FormatedTotalBalanceAmount,
            FormatedTotalAmount,
            FormatedPayOutAmount,
            FormatedInterestAmount);

    // Changing EarliestTransferDate
    if (!PayOutType.equalsIgnoreCase("FullProlongation")) {
      TestLogger.logInfo("***t2c Principal PayOut ticket ***");
      DBReusables.getInstance()
          .shiftEarliestTransferToToday(t2cPTicket_id, DBReusables.getInstance().ct2cTable);
    }
    TestLogger.logInfo("***t2c Interest PayOut ticket ***");
    DBReusables.getInstance()
        .shiftEarliestTransferToToday(t2cITicket_id, DBReusables.getInstance().ct2cTable);

    // prodops Ticket Processing for t2c
    TestLogger.logMsg("Step-14: ProdOps t2c Ticket Processing");
    if (!PayOutType.equalsIgnoreCase("FullProlongation")) {
      ProdOpsServices.getInstance()
          .ticketProcessing(
              t2cTicketType,
              ServiceBank_BIC,
              t2cPTicket_id,
              SourceTrancheIdentifier,
              CustomerEmail);
    } else {
      ProdOpsServices.getInstance()
          .ticketProcessing(
              t2cTicketType,
              ServiceBank_BIC,
              t2cITicket_id,
              SourceTrancheIdentifier,
              CustomerEmail);
    }
    // t2c Ticket Processing
    if (!PayOutType.equalsIgnoreCase("FullProlongation")) {
      t2cPBankTicket_id =
          DBReusables.getInstance()
              .getBankTransferTicketID(t2cPTicket_id, DBReusables.getInstance().ct2cTable);
    }
    String t2cIBankTicket_id =
        DBReusables.getInstance()
            .getBankTransferTicketID(t2cITicket_id, DBReusables.getInstance().ct2cTable);
    TestLogger.logMsg("Step-15: Processing t2c BTO Ticket ");
    if (!PayOutType.equalsIgnoreCase("FullProlongation")) {
      btot2cProcessing(
          t2cPBankTicket_id,
          t2cPTicket_id,
          t2cIBankTicket_id,
          t2cITicket_id,
          SourceTrancheIdentifier);
    } else {
      btot2cProcessing(
          t2cIBankTicket_id,
          t2cITicket_id,
          t2cIBankTicket_id,
          t2cITicket_id,
          SourceTrancheIdentifier);
    }

    // SBTA and CTA booking validation
    TestLogger.logMsg("Step-16: Validate CTA and SBTA Bookings");
    payOutValidateCTAnSBTABookings(
        "PAY_OUT", PayOutAmount, InterestAmount, ServiceBank_BIC, CustomerEmail, PayOutType);
    // Shop Validation
    TestLogger.logMsg("Step-17: Validate completed ticket in Shop");
    MeineAnlagenPO.getInstance()
        .payOutValidatePost_t2c(
            CIA,
            PayOutType,
            SourceTrancheIdentifier,
            FormatedTotalBalanceAmount,
            FormatedTotalAmount,
            FormatedPayOutAmount);

    // Gunda validation
    TestLogger.logMsg("Step-18: Validate completed ticket in Gunda");
    GundaServices.getInstance()
        .payOutValidatePost_i2tort2c(CustomerNumber, CIA, SourceTrancheIdentifier);
    if (SourceTrancheIdentifier.contains("-TG")) {
      // Revert PayOutAssignment to Open
      DBReusables.getInstance().UpdatePayOutAssignment(SourceTrancheIdentifier, "OPEN");
    }
  }

  /*
   * This is Investment Change Method
   * @param methodName
   * @param SourceTrancheIdentifier
   * @param IcAmount
   * @param CustomerEmail
   * @param IcType
   * @param ProlongationTrancheIdentifier
   * @param TargetTrancheIdentifier
   */
  public void InvestmentChange(
      String methodName,
      String SourceTrancheIdentifier,
      String IcAmount,
      String CustomerEmail,
      String IcType,
      String TargetTrancheIdentifier,
      String ProlongationTrancheIdentifier)
      throws InterruptedException, SQLException, ClassNotFoundException, AWTException {
    DecimalFormat twoPlaces = new DecimalFormat("0.00");
    String ServiceBank_BIC = "MHSBDEHBXXX";
    String i2tTicketType = "INTEREST_TO_TRANSIT";
    String t2cTicketType = "TRANSIT_TO_CUSTOMER";
    String Category = "PAY_IN";
    String TicketType = "TRANSIT_TO_INTEREST";
    String i2iTicketType = "INTEREST_TO_INTEREST";
    String PCIA = null,
        i2tPTicket_id = "",
        i2tPBankTicket_id = "",
        PayOutAmount = "",
        i2iTicket_id = "",
        PayInTicket_id = "";
    // calling SB & PB Iban method
    SBandPB_IBAN(ServiceBank_BIC, SourceTrancheIdentifier);
    String CustomerNumber = DBReusables.getInstance().getCustomerNumber(CustomerEmail);
    String CIA =
        DBReusables.getInstance().getCIA(CustomerNumber, SourceTrancheIdentifier, ServiceBank_BIC);
    String TCIA =
        DBReusables.getInstance().getCIA(CustomerNumber, TargetTrancheIdentifier, ServiceBank_BIC);
    String TotalBalanceAmount =
        DBReusables.getInstance().getCIAB_Balance(SourceTrancheIdentifier, CustomerEmail);
    String FormatedTotalBalanceAmount =
        (DBReusables.getInstance()
            .formatCurrency(TotalBalanceAmount)
            .substring(
                0, DBReusables.getInstance().formatCurrency(TotalBalanceAmount).indexOf(" ")));

    if (IcType.equalsIgnoreCase("FullIC")) {
      IcAmount = TotalBalanceAmount;
    }

    if (SourceTrancheIdentifier.contains("-FG")) {
      PCIA =
          DBReusables.getInstance()
              .getCIA(CustomerNumber, ProlongationTrancheIdentifier, ServiceBank_BIC);
    }
    String FormatedIcAmount =
        (DBReusables.getInstance()
            .formatCurrency(IcAmount)
            .substring(0, DBReusables.getInstance().formatCurrency(IcAmount).indexOf(" ")));
    String ProlongationAmount =
        String.valueOf(
            twoPlaces.format(
                Double.parseDouble(TotalBalanceAmount) - (Double.parseDouble(IcAmount))));
    ProlongationAmount = DBReusables.getInstance().Aformat(ProlongationAmount);
    String FormatedProlongationAmount =
        (DBReusables.getInstance()
            .formatCurrency(ProlongationAmount)
            .substring(
                0, DBReusables.getInstance().formatCurrency(ProlongationAmount).indexOf(" ")));

    if (methodName.contains("External")) {
      PayOutAmount = IcAmount;
    } else {
      PayOutAmount = "0.00";
    }

    ShopLoginLogoutPO.getInstance().shopLogin(ENV, CustomerEmail);
    MeineAnlagenPO.getInstance().getInvestmentDetails(SourceTrancheIdentifier, CustomerEmail);
    TestLogger.logMsg("Step-1: Investment Change Mapping and Create IC from UI");
    // Investment Change Mapping
    Deposit.getInstance().investmentChangeMapping(SourceTrancheIdentifier, TargetTrancheIdentifier);
    // Initiating IC from UI
    if (methodName.contains("Shop")) {
      // IC from Shop
      MeineAnlagenPO.getInstance()
          .initiateInvestmentChangeShop(
              SourceTrancheIdentifier, TargetTrancheIdentifier, FormatedIcAmount);

    } else {
      // IC from Gunda
      GundaPO.getInstance()
          .gundaIc(
              SourceTrancheIdentifier, TargetTrancheIdentifier, FormatedIcAmount, CustomerNumber);
    }

    if (methodName.contains("External")) {

      // Principal Tickets
      i2tPTicket_id =
          DBReusables.getInstance()
              .getCustomerTicket(DBReusables.getInstance().ci2tTable, CustomerEmail);

      // Principal Ticket validations
      TestLogger.logMsg("Validate i2t Principal Ticket/s");
      TestLogger.logInfo("***i2t Principal PayOut ticket validation***");
      validateCustomerTicket(
          i2tPTicket_id,
          CIA,
          CustomerNumber,
          ServiceBank_BIC,
          DBReusables.getInstance().ci2tTable,
          IcAmount,
          "null",
          SourceTrancheIdentifier);
      // PayIn Ticket validations
      TestLogger.logInfo("*** Target PayIn ticket Validation ***");
      TestLogger.logMsg("Step-2: Validate t2i Customer Ticket");
      PayInTicket_id =
          DBReusables.getInstance()
              .getCustomerTicket_id(DBReusables.getInstance().ct2iTable, CustomerEmail);

      validateCustomerTicket(
          PayInTicket_id,
          TCIA,
          CustomerNumber,
          ServiceBank_BIC,
          DBReusables.getInstance().ct2iTable,
          IcAmount,
          Category,
          TargetTrancheIdentifier);

      // Shop validation
      TestLogger.logMsg("Step-3: Validate t2i Inprogress ticket in Shop and Gunda");
      MeineAnlagenPO.getInstance().getInvestmentDetails(TargetTrancheIdentifier, CustomerEmail);
      if (SourceTrancheIdentifier.contains("TG")) {
        MeineAnlagenPO.getInstance()
            .validateShopBookings(
                2,
                DateTimeFormatter.ofPattern("dd.MM.yyyy")
                        .format(
                            LocalDate.parse(
                                (CharSequence)
                                    DBReusables.getInstance()
                                        .getTrancheStartDate(TargetTrancheIdentifier)))
                    + " vorgemerkt Anlagewechsel vom "
                    + MeineAnlagenPO.getInstance().getProductType(SourceTrancheIdentifier)
                    + " "
                    + DBReusables.getInstance()
                        .getBankName_FromTrancheIdentifier(SourceTrancheIdentifier)
                    + " * "
                    + FormatedIcAmount);
      } else {
        MeineAnlagenPO.getInstance()
            .validateShopBookings(
                2,
                DateTimeFormatter.ofPattern("dd.MM.yyyy")
                        .format(
                            LocalDate.parse(
                                (CharSequence)
                                    DBReusables.getInstance()
                                        .getTrancheStartDate(TargetTrancheIdentifier)))
                    + " vorgemerkt Anlagewechsel vom "
                    + MeineAnlagenPO.getInstance().getProductType(SourceTrancheIdentifier)
                    + " "
                    + DBReusables.getInstance()
                        .getBankName_FromTrancheIdentifier(SourceTrancheIdentifier)
                    + " "
                    + MeineAnlagenPO.getInstance().getProductDuration(SourceTrancheIdentifier)
                    + " * "
                    + FormatedIcAmount);
      }
      MeineAnlagenPO.getInstance()
          .validateShopHint(
              "Ihr Anlagebetrag wird von Ihrer ZINSPILOT-Partnerbank zum Anlagestart automatisch bei der "
                  + DBReusables.getInstance()
                      .getBankName_FromTrancheIdentifier(TargetTrancheIdentifier)
                  + " angelegt.");
      // Gunda validation
      TestLogger.logMsg("Step-4: Validate t2i Inprogress ticket in Gunda");
      int num =
          GundaServices.getInstance()
              .getInprogressTicket_Array(
                  CustomerNumber,
                  DBReusables.getInstance()
                      .getTicket_uuid(i2tPTicket_id, DBReusables.getInstance().ci2tTable));
      Assert.assertEquals(
          (WebServiceOperations.getInstance()
              .convertStringToJson(Gunda.getInstance().Gunda_GetCustomer(CustomerNumber))
              .getString("notExecutedTickets[" + num + "].productIdentifier")),
          TargetTrancheIdentifier,
          "Gunda TrancheIdentifier is not correct");
      Assert.assertEquals(
          (WebServiceOperations.getInstance()
              .convertStringToJson(Gunda.getInstance().Gunda_GetCustomer(CustomerNumber))
              .getString("notExecutedTickets[" + num + "].ticketType")),
          "INTEREST_TO_TRANSIT_TO_INTEREST",
          "Gunda ticketType is not correct");
      Assert.assertEquals(
          (WebServiceOperations.getInstance()
              .convertStringToJson(Gunda.getInstance().Gunda_GetCustomer(CustomerNumber))
              .getString("notExecutedTickets[" + num + "].ticketState")),
          "VALID",
          "Gunda ticketState is not correct");
      Assert.assertEquals(
          (WebServiceOperations.getInstance()
              .convertStringToJson(Gunda.getInstance().Gunda_GetCustomer(CustomerNumber))
              .getString("notExecutedTickets[" + num + "].sourceProductIdentifier")),
          SourceTrancheIdentifier,
          "Gunda SourceTrancheIdentifier is not correct");
      Assert.assertEquals(
          (WebServiceOperations.getInstance()
              .convertStringToJson(Gunda.getInstance().Gunda_GetCustomer(CustomerNumber))
              .getString("notExecutedTickets[" + num + "].amount")),
          DBReusables.getInstance()
                  .formatCurrency1(IcAmount)
                  .substring(1, DBReusables.getInstance().formatCurrency1(IcAmount).length())
              + " EUR",
          "Gunda amount is not correct");
      Assert.assertEquals(
          (WebServiceOperations.getInstance()
              .convertStringToJson(Gunda.getInstance().Gunda_GetCustomer(CustomerNumber))
              .getString("notExecutedTickets[" + num + "].expectedValueDate")),
          DBReusables.getInstance().getTrancheStartDate(TargetTrancheIdentifier),
          "Gunda expectedValueDate is not correct");

    } else {
      // I2I Ticket validations
      i2iTicket_id =
          DBReusables.getInstance()
              .getProlongationOrI2iTicket_id(DBReusables.getInstance().ci2iTable, CIA, TCIA);

      TestLogger.logMsg("Step-2: Validate I2I Ticket");
      TestLogger.logInfo("***I2I ticket validation***");
      validateProlongationOrI2iTicket(
          i2iTicket_id,
          CustomerNumber,
          ServiceBank_BIC,
          DBReusables.getInstance().ci2iTable,
          IcAmount,
          SourceTrancheIdentifier,
          TargetTrancheIdentifier,
          CIA,
          TCIA);

      // Shop validation
      TestLogger.logMsg("Step-3: Validate i2i Inprogress ticket in Shop");
      MeineAnlagenPO.getInstance().getInvestmentDetails(TargetTrancheIdentifier, CustomerEmail);
      if (SourceTrancheIdentifier.contains("TG")) {
        MeineAnlagenPO.getInstance()
            .validateShopBookings(
                2,
                DateTimeFormatter.ofPattern("dd.MM.yyyy")
                        .format(
                            LocalDate.parse(
                                (CharSequence)
                                    DBReusables.getInstance()
                                        .getTrancheStartDate(TargetTrancheIdentifier)))
                    + " vorgemerkt Anlagewechsel vom "
                    + MeineAnlagenPO.getInstance().getProductType(SourceTrancheIdentifier)
                    + " "
                    + DBReusables.getInstance()
                        .getBankName_FromTrancheIdentifier(SourceTrancheIdentifier)
                    + " * "
                    + FormatedIcAmount);
      } else {
        MeineAnlagenPO.getInstance()
            .validateShopBookings(
                2,
                DateTimeFormatter.ofPattern("dd.MM.yyyy")
                        .format(
                            LocalDate.parse(
                                (CharSequence)
                                    DBReusables.getInstance()
                                        .getTrancheStartDate(TargetTrancheIdentifier)))
                    + " vorgemerkt Anlagewechsel vom "
                    + MeineAnlagenPO.getInstance().getProductType(SourceTrancheIdentifier)
                    + " "
                    + DBReusables.getInstance()
                        .getBankName_FromTrancheIdentifier(SourceTrancheIdentifier)
                    + " "
                    + MeineAnlagenPO.getInstance().getProductDuration(SourceTrancheIdentifier)
                    + " * "
                    + FormatedIcAmount);
      }
      MeineAnlagenPO.getInstance()
          .validateShopHint(
              "Ihr Anlagebetrag wird von Ihrer ZINSPILOT-Partnerbank zum Anlagestart automatisch bei der "
                  + DBReusables.getInstance()
                      .getBankName_FromTrancheIdentifier(TargetTrancheIdentifier)
                  + " angelegt.");

      // Gunda validation
      TestLogger.logMsg("Step-4: Validate i2i Inprogress ticket in Gunda");
      int num =
          GundaServices.getInstance()
              .getInprogressTicket_Array(
                  CustomerNumber,
                  DBReusables.getInstance()
                      .getTicket_uuid(i2iTicket_id, DBReusables.getInstance().ci2iTable));
      Assert.assertEquals(
          (WebServiceOperations.getInstance()
              .convertStringToJson(Gunda.getInstance().Gunda_GetCustomer(CustomerNumber))
              .getString("notExecutedTickets[" + num + "].productIdentifier")),
          TargetTrancheIdentifier,
          "Gunda TrancheIdentifier is not correct");
      Assert.assertEquals(
          (WebServiceOperations.getInstance()
              .convertStringToJson(Gunda.getInstance().Gunda_GetCustomer(CustomerNumber))
              .getString("notExecutedTickets[" + num + "].ticketType")),
          "INTEREST_TO_INTEREST",
          "Gunda ticketType is not correct");
      Assert.assertEquals(
          (WebServiceOperations.getInstance()
              .convertStringToJson(Gunda.getInstance().Gunda_GetCustomer(CustomerNumber))
              .getString("notExecutedTickets[" + num + "].ticketState")),
          "VALID",
          "Gunda ticketState is not correct");
      Assert.assertEquals(
          (WebServiceOperations.getInstance()
              .convertStringToJson(Gunda.getInstance().Gunda_GetCustomer(CustomerNumber))
              .getString("notExecutedTickets[" + num + "].expectedValueDate")),
          DBReusables.getInstance().getTrancheStartDate(TargetTrancheIdentifier),
          "Gunda expectedValueDate is not correct");
      Assert.assertEquals(
          (WebServiceOperations.getInstance()
              .convertStringToJson(Gunda.getInstance().Gunda_GetCustomer(CustomerNumber))
              .getString("notExecutedTickets[" + num + "].amount")),
          DBReusables.getInstance()
                  .formatCurrency1(IcAmount)
                  .substring(1, DBReusables.getInstance().formatCurrency1(IcAmount).length())
              + " EUR",
          "Gunda amount is not correct");
    }
    // Bug-ZA-655
    // Email validation
    TestLogger.logMsg("Step-5: Validate Email in MailHog");
    MailHogPO.getInstance().openMailhog();
    MailHogPO.getInstance().verifyEmail(CustomerEmail, "Ihr Anlagewechsel bei Zinspilot");
    MailHogPO.getInstance().closeMailhog();
    WebUIOperations.getInstance().switchTab(0);

    if (SourceTrancheIdentifier.contains("-TG")) {
      String ValueDate = DBReusables.getInstance().getTrancheStartDate(SourceTrancheIdentifier);

      // close PayOutAssignment
      DBReusables.getInstance().UpdatePayOutAssignment(SourceTrancheIdentifier, "CLOSED");

      // Interest Booking
      TestLogger.logMsg("Step-6: Execute InterestBooking");
      ProdOpsServices.getInstance()
          .interestBooking(SourceTrancheIdentifier, LocalDate.parse(ValueDate), CustomerEmail);

    } else {
      // Interest Booking and Prolongation
      TestLogger.logMsg("Step-6: Execute InterestBooking and Prolongation");
      ProdOpsServices.getInstance()
          .interestBookingAndProlongation(
              SourceTrancheIdentifier,
              LocalDate.parse(DBReusables.getInstance().getTrancheEndDate(SourceTrancheIdentifier)),
              IcType,
              CustomerEmail);
    }

    if (SourceTrancheIdentifier.contains("-FG")
        && IcType.equalsIgnoreCase("PartialIC")
        && !FormatedTotalBalanceAmount.equalsIgnoreCase(FormatedIcAmount)) {
      // Prolongation Tickets

      String ProlTicket_id =
          DBReusables.getInstance()
              .getProlongationOrI2iTicket_id(DBReusables.getInstance().cProTable, CIA, PCIA);

      // Prolongation Ticket validations
      TestLogger.logMsg("Validate Prolongation Ticket");
      TestLogger.logInfo("***Prolongation ticket validation***");
      validateProlongationOrI2iTicket(
          ProlTicket_id,
          CustomerNumber,
          ServiceBank_BIC,
          DBReusables.getInstance().cProTable,
          ProlongationAmount,
          SourceTrancheIdentifier,
          ProlongationTrancheIdentifier,
          CIA,
          PCIA);
    }

    // Interest Tickets
    String i2tITicket_id =
        DBReusables.getInstance()
            .getInterestTicket_id(DBReusables.getInstance().ci2tTable, CustomerEmail);
    String t2cITicket_id =
        DBReusables.getInstance()
            .getInterestTicket_id(DBReusables.getInstance().ct2cTable, CustomerEmail);
    String InterestAmount =
        DBReusables.getInstance()
            .getTicketAmount(i2tITicket_id, DBReusables.getInstance().ci2tTable);
    String FormatedInterestAmount =
        (DBReusables.getInstance()
            .formatCurrency(
                DBReusables.getInstance()
                    .getTicketAmount(i2tITicket_id, DBReusables.getInstance().ci2tTable))
            .substring(
                0,
                DBReusables.getInstance()
                    .formatCurrency(
                        DBReusables.getInstance()
                            .getTicketAmount(i2tITicket_id, DBReusables.getInstance().ci2tTable))
                    .indexOf(" ")));

    // Interest Ticket validations
    TestLogger.logMsg("Step-7: Validate Interest Ticket/s");
    TestLogger.logInfo("***i2t Interest PayOut ticket validation***");
    validateCustomerTicket(
        i2tITicket_id,
        CIA,
        CustomerNumber,
        ServiceBank_BIC,
        DBReusables.getInstance().ci2tTable,
        IcAmount,
        "GROSS_INTEREST",
        SourceTrancheIdentifier);
    TestLogger.logInfo("***t2c Interest PayOut ticket validation***");
    Assert.assertEquals(
        DBReusables.getInstance()
            .getTicketDependency_id(t2cITicket_id, DBReusables.getInstance().ct2cTable),
        i2tITicket_id,
        "t2c ticket dependency did not match i2t ticket/Valid t2c ticket is not create");
    validateCustomerTicket(
        t2cITicket_id,
        CIA,
        CustomerNumber,
        ServiceBank_BIC,
        DBReusables.getInstance().ct2cTable,
        IcAmount,
        "GROSS_INTEREST",
        SourceTrancheIdentifier);

    // CIA & PBIA Bookings validation
    TestLogger.logMsg("Step-8: Validate CIA and PBIA Bookings");
    payOutvalidateCIAnPBIABookings(
        "INTEREST", InterestAmount, CIA, SourceTrancheIdentifier, ServiceBank_BIC);
    TestLogger.logInfo(
        "Interest Amount successfully added to Customer/Product Bank Interest Account Bookings for CIA id "
            + CIA);
    if (SourceTrancheIdentifier.contains("-FG")
        && IcType.equalsIgnoreCase("PartialIc")
        && !FormatedTotalBalanceAmount.equalsIgnoreCase(FormatedIcAmount)) {
      payOutvalidateCIAnPBIABookings(
          "PROLONGATION", "-" + ProlongationAmount, CIA, SourceTrancheIdentifier, ServiceBank_BIC);
      TestLogger.logInfo(
          "Prolongation Amount successfully deducted from Customer/Product Bank Interest Account Bookings for CIA id "
              + CIA);
      payOutvalidateCIAnPBIABookings(
          "PROLONGATION",
          ProlongationAmount,
          DBReusables.getInstance()
              .getCIA(CustomerNumber, ProlongationTrancheIdentifier, ServiceBank_BIC),
          ProlongationTrancheIdentifier,
          ServiceBank_BIC);
      TestLogger.logInfo(
          "Prolongation Amount successfully added to Customer/Product Bank Interest Account Bookings for CIA id "
              + DBReusables.getInstance()
                  .getCIA(CustomerNumber, ProlongationTrancheIdentifier, ServiceBank_BIC));
    }

    // Shop Validation
    TestLogger.logMsg("Step-9: Validate Inprogress ticket in Shop");
    MeineAnlagenPO.getInstance()
        .icValidateInprogressTicketBookings(
            methodName,
            CustomerEmail,
            IcType,
            SourceTrancheIdentifier,
            FormatedTotalBalanceAmount,
            FormatedInterestAmount,
            FormatedIcAmount,
            ProlongationTrancheIdentifier,
            FormatedProlongationAmount,
            TargetTrancheIdentifier);

    // Gunda validation
    TestLogger.logMsg("Step-10: Validate Inprogress ticket in Gunda");
    GundaServices.getInstance()
        .icValidateInprogressTicket(
            CustomerNumber,
            SourceTrancheIdentifier,
            i2tITicket_id,
            InterestAmount,
            TargetTrancheIdentifier,
            t2cITicket_id);

    // validate for closing investment ticket
    if (FormatedTotalBalanceAmount.equalsIgnoreCase(FormatedIcAmount)
        || IcType.equalsIgnoreCase("FullIc")) {
      TestLogger.logMsg("Validate Closing Investment Ticket");
      DBReusables.getInstance().ValidateCIT(CIA, "CREATED");
    }
    // Changing EarliestTransferDate
    TestLogger.logInfo("***i2t Interest PayOut ticket ***");
    DBReusables.getInstance()
        .shiftEarliestTransferToToday(i2tITicket_id, DBReusables.getInstance().ci2tTable);

    if (methodName.contains("External")) {
      // Changing EarliestTransferDate
      TestLogger.logInfo("***i2t Principal PayOut ticket ***");
      DBReusables.getInstance()
          .shiftEarliestTransferToToday(i2tPTicket_id, DBReusables.getInstance().ci2tTable);
      TestLogger.logInfo("*** Target PayIn ticket ***");
      // Changing EarliestTransferDate
      DBReusables.getInstance()
          .shiftEarliestTransferToToday(PayInTicket_id, DBReusables.getInstance().ct2iTable);

      // prodops Ticket Processing for i2t
      TestLogger.logMsg("Step-11: ProdOps i2t Ticket Processing");
      ProdOpsServices.getInstance()
          .ticketProcessing(
              i2tTicketType,
              ServiceBank_BIC,
              i2tPTicket_id,
              SourceTrancheIdentifier,
              CustomerEmail);
    } else {
      // prodops Ticket Processing for i2t
      TestLogger.logMsg("Step-11: ProdOps i2t Ticket Processing");
      ProdOpsServices.getInstance()
          .ticketProcessing(
              i2tTicketType,
              ServiceBank_BIC,
              i2tITicket_id,
              SourceTrancheIdentifier,
              CustomerEmail);
    }
    // i2t Ticket Processing

    if (methodName.contains("External")) {
      i2tPBankTicket_id =
          DBReusables.getInstance()
              .getBankTransferTicketID(i2tPTicket_id, DBReusables.getInstance().ci2tTable);
    }

    String i2tIBankTicket_id =
        DBReusables.getInstance()
            .getBankTransferTicketID(i2tITicket_id, DBReusables.getInstance().ci2tTable);
    TestLogger.logMsg("Step-12: Processing i2t BTO Ticket ");
    if (methodName.contains("External")) {
      btoi2tProcessing(i2tPBankTicket_id, i2tPTicket_id, i2tIBankTicket_id, i2tITicket_id);
    } else {

      btoi2tProcessing(i2tIBankTicket_id, i2tITicket_id, i2tIBankTicket_id, i2tITicket_id);
    }

    // CIA,PBIA,CTA & SBTA booking/s validation
    TestLogger.logMsg(
        "Step-13: Validate CTA,SBTA,CIA and PBIA Bookings post i2t ticket's processing");
    icValidateCTAnSBTAnCIAnPBIABookings(
        methodName,
        i2tTicketType,
        InterestAmount,
        PayOutAmount,
        CIA,
        SourceTrancheIdentifier,
        ServiceBank_BIC,
        CustomerEmail);
    // shop validation
    TestLogger.logMsg("Step-14: Validate Inprogress ticket in Shop post i2t ticket's processing");
    MeineAnlagenPO.getInstance()
        .icValidatePost_i2t(
            methodName,
            CustomerEmail,
            SourceTrancheIdentifier,
            FormatedIcAmount,
            FormatedInterestAmount);

    // Gunda Validation
    GundaServices.getInstance()
        .payOutValidatePost_i2tort2c(CustomerNumber, CIA, SourceTrancheIdentifier);

    if (methodName.contains("External")) {

      TestLogger.logInfo("*** Target PayIn ticket Processing ***");
      // prodops Ticket Processing
      TestLogger.logMsg("Step-15: ProdOps t2i Ticket Processing");
      ProdOpsServices.getInstance()
          .ticketProcessing(
              TicketType, ServiceBank_BIC, PayInTicket_id, TargetTrancheIdentifier, CustomerEmail);

      // t2i Ticket Processing
      TestLogger.logMsg("Step-16: Processing t2i BTO Ticket ");
      String BankTicket_id =
          DBReusables.getInstance()
              .getBankTransferTicketID(PayInTicket_id, DBReusables.getInstance().ct2iTable);
      btot2iProcessing(BankTicket_id, PayInTicket_id);
      // CIA & PBIA booking/s validation
      TestLogger.logMsg("Step-17: Validate CTA,SBTA,CIA and PBIA Bookings");
      TCIA =
          DBReusables.getInstance()
              .getCIA(CustomerNumber, TargetTrancheIdentifier, ServiceBank_BIC);
      payInValidateCTAnSBTAnCIAnPBIABookings(
          TicketType, IcAmount, TCIA, TargetTrancheIdentifier, ServiceBank_BIC, CustomerEmail);
      // shop validation
      TestLogger.logMsg("Step-18: Validate completed ticket in Shop and Gunda");

      MeineAnlagenPO.getInstance().getInvestmentDetails(SourceTrancheIdentifier, CustomerEmail);
      MeineAnlagenPO.getInstance().validatePendingPayOutMessage("present", FormatedInterestAmount);
      MeineAnlagenPO.getInstance().getInvestmentDetails(TargetTrancheIdentifier, CustomerEmail);
      MeineAnlagenPO.getInstance()
          .validateShopBookings(
              1,
              DBReusables.getInstance().formatDate("dd.MM.yyyy")
                  + " "
                  + DBReusables.getInstance().formatDate("dd.MM.yyyy")
                  + " Einzahlung "
                  + FormatedIcAmount);

      // Gunda validation
      String FinalTotalBalanceAmount =
          DBReusables.getInstance().getCIAB_Balance(TargetTrancheIdentifier, CustomerEmail);
      Assert.assertEquals(
          (WebServiceOperations.getInstance()
              .convertStringToJson(Gunda.getInstance().Gunda_GetCustomer(CustomerNumber))
              .getString(
                  "affiliations[0].customerInterestAccountsDetails["
                      + GundaServices.getInstance().getCIA_Array(CustomerNumber, TCIA)
                      + "].interestAccount.productIdentifier")),
          TargetTrancheIdentifier,
          "Gunda TrancheIdentifier is not correct");
      Assert.assertEquals(
          (WebServiceOperations.getInstance()
              .convertStringToJson(Gunda.getInstance().Gunda_GetCustomer(CustomerNumber))
              .getString(
                  "affiliations[0].customerInterestAccountsDetails["
                      + GundaServices.getInstance().getCIA_Array(CustomerNumber, TCIA)
                      + "].interestAccount.balance")),
          DBReusables.getInstance()
                  .formatCurrency1(IcAmount)
                  .substring(1, DBReusables.getInstance().formatCurrency1(IcAmount).length())
              + " EUR",
          "Gunda amount is not correct");

    } else {

      // Changing EarliestTransferDate
      DBReusables.getInstance()
          .shiftEarliestTransferToToday(i2iTicket_id, DBReusables.getInstance().ci2iTable);

      // prodops Ticket Processing
      TestLogger.logMsg("Step-15: ProdOps i2i Ticket Processing");
      ProdOpsServices.getInstance()
          .i2iticketProcessing(
              i2iTicketType,
              ServiceBank_BIC,
              i2iTicket_id,
              SourceTrancheIdentifier,
              TargetTrancheIdentifier);

      // CIA & PBIA booking/s validation
      TestLogger.logMsg("Step-16: Validate CIA and PBIA Bookings");
      TCIA =
          DBReusables.getInstance()
              .getCIA(CustomerNumber, TargetTrancheIdentifier, ServiceBank_BIC);
      i2iValidateCIAnPBIABookings(
          i2iTicketType,
          IcAmount,
          TCIA,
          TargetTrancheIdentifier,
          ServiceBank_BIC,
          CIA,
          SourceTrancheIdentifier);
      // shop validation
      TestLogger.logMsg("Step-17: Validate completed ticket in Shop");
      MeineAnlagenPO.getInstance().getInvestmentDetails(SourceTrancheIdentifier, CustomerEmail);
      MeineAnlagenPO.getInstance().validatePendingPayOutMessage("present", FormatedInterestAmount);
      MeineAnlagenPO.getInstance().getInvestmentDetails(TargetTrancheIdentifier, CustomerEmail);
      MeineAnlagenPO.getInstance()
          .validateShopBookings(
              1,
              DBReusables.getInstance().formatDate("dd.MM.yyyy")
                  + " "
                  + DateTimeFormatter.ofPattern("dd.MM.yyyy")
                      .format(
                          LocalDate.parse(
                              (CharSequence)
                                  DBReusables.getInstance()
                                      .getTrancheStartDate(TargetTrancheIdentifier)))
                  + " Anlagewechsel "
                  + FormatedIcAmount);

      // Gunda validation
      TestLogger.logMsg("Step-18: Validate completed ticket in Gunda");
      String FinalTotalBalanceAmount =
          DBReusables.getInstance().getCIAB_Balance(TargetTrancheIdentifier, CustomerEmail);
      Assert.assertEquals(
          (WebServiceOperations.getInstance()
              .convertStringToJson(Gunda.getInstance().Gunda_GetCustomer(CustomerNumber))
              .getString(
                  "affiliations[0].customerInterestAccountsDetails["
                      + GundaServices.getInstance().getCIA_Array(CustomerNumber, TCIA)
                      + "].interestAccount.productIdentifier")),
          TargetTrancheIdentifier,
          "Gunda TrancheIdentifier is not correct");
      Assert.assertEquals(
          (WebServiceOperations.getInstance()
              .convertStringToJson(Gunda.getInstance().Gunda_GetCustomer(CustomerNumber))
              .getString(
                  "affiliations[0].customerInterestAccountsDetails["
                      + GundaServices.getInstance().getCIA_Array(CustomerNumber, TCIA)
                      + "].interestAccount.balance")),
          DBReusables.getInstance()
                  .formatCurrency1(FinalTotalBalanceAmount)
                  .substring(
                      1,
                      DBReusables.getInstance().formatCurrency1(FinalTotalBalanceAmount).length())
              + " EUR",
          "Gunda amount is not correct");
    }
    // validate for source closing
    if (FormatedTotalBalanceAmount.equalsIgnoreCase(FormatedIcAmount)
        || IcType.equalsIgnoreCase("FullIc")) {
      // CIA Open validation
      DBReusables.getInstance().getCIA_status(CIA, "false");
      // Running camunda process-closing investment ticket
      CoreBL.getInstance()
          .camundaClosingInvestmentTicket(
              DBReusables.getInstance().getTrancheStartDate(TargetTrancheIdentifier));
      TestLogger.logMsg("Validate Source Product in Shop");
      TestLogger.logMsg("Validate Closing Investment Ticket");
      DBReusables.getInstance().ValidateCIT(CIA, "EXECUTED");
      // CIA closed validation
      DBReusables.getInstance().getCIA_status(CIA, "true");
      MeineAnlagenPO.getInstance().validateClosedTranche(SourceTrancheIdentifier, CIA);
    }

    if (SourceTrancheIdentifier.contains("-TG")) {
      // Checking the balance of source
      if (methodName.contains("Partial")) {
        DRIVER.findElement(MeineAnlagenPO.getInstance().ZP_MeineAnlagen).click();
        Assert.assertEquals(
            MeineAnlagenPO.getInstance().MAamount(SourceTrancheIdentifier),
            DBReusables.getInstance()
                .formatCurrency(
                    DBReusables.getInstance()
                        .getCIAB_Balance(SourceTrancheIdentifier, CustomerEmail)),
            "Invested Amount doest not match");
        TestLogger.logInfo("Shop Total Balance Validation for Source Tranche is done successfully");
      }
      // Revert PayOutAssignment to Open
      DBReusables.getInstance().UpdatePayOutAssignment(SourceTrancheIdentifier, "OPEN");
    }

    TestLogger.logInfo("***t2c Interest PayOut ticket ***");
    DBReusables.getInstance()
        .shiftEarliestTransferToToday(t2cITicket_id, DBReusables.getInstance().ct2cTable);

    // prodops Ticket Processing for t2c
    TestLogger.logMsg("Step-19: ProdOps t2c Ticket Processing");

    ProdOpsServices.getInstance()
        .ticketProcessing(
            t2cTicketType, ServiceBank_BIC, t2cITicket_id, SourceTrancheIdentifier, CustomerEmail);

    // t2c Ticket Processing
    String t2cIBankTicket_id =
        DBReusables.getInstance()
            .getBankTransferTicketID(t2cITicket_id, DBReusables.getInstance().ct2cTable);
    TestLogger.logMsg("Step-20: Processing t2c BTO Ticket ");
    btot2cProcessing(
        t2cIBankTicket_id,
        t2cITicket_id,
        t2cIBankTicket_id,
        t2cITicket_id,
        SourceTrancheIdentifier);
    // SBTA and CTA booking validation
    TestLogger.logMsg("Step-21: Validate CTA and SBTA Bookings post t2c ticket's processing");
    payOutValidateCTAnSBTABookings(
        "PAY_OUT", IcAmount, InterestAmount, ServiceBank_BIC, CustomerEmail, IcType);

    // Shop Validation
    if (SourceTrancheIdentifier.contains("FG")
        && !FormatedTotalBalanceAmount.equalsIgnoreCase(FormatedIcAmount)) {
      TestLogger.logMsg("Validate Source Product in Shop");
      // CIA closed validation
      DBReusables.getInstance().getCIA_status(CIA, "true");
      MeineAnlagenPO.getInstance().validateClosedTranche(SourceTrancheIdentifier, CIA);
    }
  }

  /*
  Invalid payin creation method
   */
  public Map<String, String> invalidPayIn(
      String CustomerEmail, String TrancheIdentifier, String PayInAmount)
      throws InterruptedException {

    String table = DBReusables.getInstance().ct2iTable;
    // Shop Login
    ShopLoginLogoutPO.getInstance().shopLogin(ENV, CustomerEmail);

    // calling SB & PB Iban method
    SBandPB_IBAN(ServiceBank_BIC, TrancheIdentifier);

    TestLogger.logMsg("Step-1: Get CustomerNumber,MultiPurposeText and CounterPartAccNumber");
    String CustomerNumber = DBReusables.getInstance().getCustomerNumber(CustomerEmail);
    String MULTI_PURPOSE_TEXT =
        DBReusables.getInstance().getPayInCodeFromTrancheIdentifier(TrancheIdentifier);
    String COUNTER_PART_ACCOUNT_NUMBER =
        new IBAN(DBReusables.getInstance().getCustomerServiceBankIban(CustomerNumber))
            .getBankAccountNumber();
    String FormatedPayInAmount =
        (DBReusables.getInstance()
            .formatCurrency(PayInAmount)
            .substring(0, DBReusables.getInstance().formatCurrency(PayInAmount).indexOf(" ")));

    // Payin ticket creation
    TestLogger.logMsg("Step-2: Create Invalid Payin Ticket");
    customerPayin(MULTI_PURPOSE_TEXT, COUNTER_PART_ACCOUNT_NUMBER, PayInAmount);

    // PayIn Ticket
    String CustomerTicket_id = DBReusables.getInstance().getCustomerTicket_id(table, CustomerEmail);

    // DB Validation
    TestLogger.logMsg("Step-3: Validate Customer Ticket");
    Assert.assertEquals(
        DBReusables.getInstance().getTicketState(CustomerTicket_id, table),
        "INVALID",
        "Customer ticket state is VALID with reason");
    TestLogger.logInfo(
        "Customer Ticket is Invalid with Reason: "
            + DBReusables.getInstance().getTicketStateMessage(CustomerTicket_id, table));

    // Gunda validation
    TestLogger.logMsg("Step-4: Validate Inprogress ticket in Gunda");
    int num =
        GundaServices.getInstance()
            .getInprogressTicket_Array(
                CustomerNumber, DBReusables.getInstance().getTicket_uuid(CustomerTicket_id, table));
    Assert.assertEquals(
        (WebServiceOperations.getInstance()
            .convertStringToJson(Gunda.getInstance().Gunda_GetCustomer(CustomerNumber))
            .getString("notExecutedTickets[" + num + "].productIdentifier")),
        TrancheIdentifier,
        "Gunda TrancheIdentifier is not correct");
    Assert.assertEquals(
        (WebServiceOperations.getInstance()
            .convertStringToJson(Gunda.getInstance().Gunda_GetCustomer(CustomerNumber))
            .getString("notExecutedTickets[" + num + "].ticketType")),
        "TRANSIT_TO_INTEREST",
        "Gunda ticketType is not correct");
    Assert.assertEquals(
        (WebServiceOperations.getInstance()
            .convertStringToJson(Gunda.getInstance().Gunda_GetCustomer(CustomerNumber))
            .getString("notExecutedTickets[" + num + "].ticketState")),
        "INVALID",
        "Gunda ticketState is not correct");
    Map<String, String> actualMap =
        WebServiceOperations.getInstance()
            .convertStringToJson(Gunda.getInstance().Gunda_GetCustomer(CustomerNumber))
            .getMap("notExecutedTickets[" + num + "].validationErrors");

    // Email validation.Email link functionality is still under discussion
    TestLogger.logMsg("Step-5: Validate Email in MailHog");
    MailHogPO.getInstance().openMailhog();
    MailHogPO.getInstance()
        .verifyEmail(CustomerEmail, "Ihre Einzahlung für ein Zinspilot Anlageangebot");
    // Need to add the email content
    MailHogPO.getInstance().closeMailhog();
    WebUIOperations.getInstance().switchTab(0);

    // Shop validation
    TestLogger.logMsg("Step-6: Validate Inprogress ticket in Shop");
    MeineAnlagenPO.getInstance().getInvestmentDetails(TrancheIdentifier, CustomerEmail);
    // Bugs tool tip and Hint error ZA-522 and ZA-672
    MeineAnlagenPO.getInstance()
        .validateShopBookings(
            2,
            DateTimeFormatter.ofPattern("dd.MM.yyyy")
                    .format(
                        LocalDate.parse(
                            (CharSequence)
                                DBReusables.getInstance().getTrancheStartDate(TrancheIdentifier)))
                + " Eingreifen erforderlich Einzahlung "
                + FormatedPayInAmount
                + " €");
    // MeineAnlagenPO.getInstance().validateShopHint("Ihr Anlagebetrag wird von Ihrer
    // ZINSPILOT-Partnerbank zum Anlagestart automatisch bei der " +
    // DBReusables.getInstance().getBankName_FromTrancheIdentifier(trancheIdentifier) + "
    // angelegt.");
    return actualMap;
  }

  /*
   * This is Call PayOut Method without Interest Booking for FAM/DRM Bank
   * @param methodName
   * @param SourceTrancheIdentifier
   * @param PayOutAmount
   * @param CustomerEmail
   * @param PayOutType
   * @param TargetTrancheIdentifier
   */
  public void CallPayOut(
      String methodName,
      String SourceTrancheIdentifier,
      String PayOutAmount,
      String CustomerEmail,
      String PayOutType)
      throws InterruptedException, SQLException, ClassNotFoundException, AWTException {
    String i2tTicketType = "INTEREST_TO_TRANSIT", t2cTicketType = "TRANSIT_TO_CUSTOMER";
    ;
    // calling SB & PB Iban method
    SBandPB_IBAN(ServiceBank_BIC, SourceTrancheIdentifier);
    String CustomerNumber = DBReusables.getInstance().getCustomerNumber(CustomerEmail);
    String CIA =
        DBReusables.getInstance().getCIA(CustomerNumber, SourceTrancheIdentifier, ServiceBank_BIC);
    String TotalBalanceAmount =
        DBReusables.getInstance().getCIAB_Balance(SourceTrancheIdentifier, CustomerEmail);
    String FormatedTotalBalanceAmount =
        (DBReusables.getInstance()
            .formatCurrency(TotalBalanceAmount)
            .substring(
                0, DBReusables.getInstance().formatCurrency(TotalBalanceAmount).indexOf(" ")));

    if (PayOutType.equalsIgnoreCase("FullPayOut")) {
      PayOutAmount = TotalBalanceAmount;
    }

    String FormatedPayOutAmount =
        (DBReusables.getInstance()
            .formatCurrency(PayOutAmount)
            .substring(0, DBReusables.getInstance().formatCurrency(PayOutAmount).indexOf(" ")));
    // Shop Login
    ShopLoginLogoutPO.getInstance().shopLogin(ENV, CustomerEmail);
    MeineAnlagenPO.getInstance().getInvestmentDetails(SourceTrancheIdentifier, CustomerEmail);
    TestLogger.logMsg("Step-1: Create PayOut");
    if (methodName.contains("Shop")) {
      // Pay Out from Shop
      MeineAnlagenPO.getInstance().initiatePayOutShop(FormatedPayOutAmount, PayOutType, CIA);
    } else {
      GundaPO.getInstance()
          .gundaPayOut(SourceTrancheIdentifier, FormatedPayOutAmount, CustomerNumber);
      ShopLoginLogoutPO.getInstance().shopCache();
    }
    // Email validation
    TestLogger.logMsg("Step-3: Validate PayOut Email in MailHog");
    MailHogPO.getInstance().openMailhog();
    MailHogPO.getInstance().verifyEmail(CustomerEmail, "Auszahlung Ihrer Zinspilot Anlage");
    MailHogPO.getInstance().closeMailhog();
    WebUIOperations.getInstance().switchTab(0);
    // validate for closing investment ticket
    if (FormatedTotalBalanceAmount.equalsIgnoreCase(FormatedPayOutAmount)) {
      DBReusables.getInstance().ValidateCIT(CIA, "CREATED");
    }

    String TotalAmount = PayOutAmount;
    String FormatedTotalAmount =
        (DBReusables.getInstance()
            .formatCurrency(TotalAmount)
            .substring(0, DBReusables.getInstance().formatCurrency(TotalAmount).indexOf(" ")));

    // Principal Tickets
    String i2tPTicket_id =
        DBReusables.getInstance()
            .getCustomerTicket_id(DBReusables.getInstance().ci2tTable, CustomerEmail);
    String t2cPTicket_id =
        DBReusables.getInstance()
            .getCustomerTicket_id(DBReusables.getInstance().ct2cTable, CustomerEmail);

    // Principal Ticket validations
    TestLogger.logMsg("Step-4: Validate Principal Ticket/s");
    TestLogger.logInfo("***i2t Principal PayOut ticket validation***");
    validateCustomerTicket(
        i2tPTicket_id,
        CIA,
        CustomerNumber,
        ServiceBank_BIC,
        DBReusables.getInstance().ci2tTable,
        PayOutAmount,
        "PRINCIPAL",
        SourceTrancheIdentifier);
    TestLogger.logInfo("***t2c Principal PayOut ticket validation***");
    Assert.assertEquals(
        DBReusables.getInstance()
            .getTicketDependency_id(t2cPTicket_id, DBReusables.getInstance().ct2cTable),
        i2tPTicket_id,
        "t2c ticket dependency did not match i2t ticket/Valid t2c ticket is not create");
    validateCustomerTicket(
        t2cPTicket_id,
        CIA,
        CustomerNumber,
        ServiceBank_BIC,
        DBReusables.getInstance().ct2cTable,
        PayOutAmount,
        "PRINCIPAL",
        SourceTrancheIdentifier);

    // Shop Validation
    TestLogger.logMsg("Step-8: Validate Inprogress ticket in Shop");
    MeineAnlagenPO.getInstance()
        .validateShopBookings(
            2,
            DateTimeFormatter.ofPattern("dd.MM.yyyy")
                    .format(
                        LocalDate.parse(
                            (CharSequence)
                                DBReusables.getInstance()
                                    .getTrancheStartDate(SourceTrancheIdentifier)))
                + " vorgemerkt Auszahlung -"
                + FormatedPayOutAmount);

    // Gunda validation
    TestLogger.logMsg("Step-9: Validate Inprogress ticket in Gunda");
    int num =
        GundaServices.getInstance()
            .getInprogressTicket_Array(
                CustomerNumber,
                DBReusables.getInstance()
                    .getTicket_uuid(i2tPTicket_id, DBReusables.getInstance().ci2tTable));
    Assert.assertEquals(
        (WebServiceOperations.getInstance()
            .convertStringToJson(Gunda.getInstance().Gunda_GetCustomer(CustomerNumber))
            .getString("notExecutedTickets[" + num + "].productIdentifier")),
        SourceTrancheIdentifier,
        "Gunda TrancheIdentifier is not correct");
    Assert.assertEquals(
        (WebServiceOperations.getInstance()
            .convertStringToJson(Gunda.getInstance().Gunda_GetCustomer(CustomerNumber))
            .getString("notExecutedTickets[" + num + "].ticketType")),
        i2tTicketType,
        "Gunda ticketType is not correct");
    Assert.assertEquals(
        (WebServiceOperations.getInstance()
            .convertStringToJson(Gunda.getInstance().Gunda_GetCustomer(CustomerNumber))
            .getString("notExecutedTickets[" + num + "].ticketState")),
        "CREATED",
        "Gunda ticketState is not correct");
    Assert.assertEquals(
        (WebServiceOperations.getInstance()
            .convertStringToJson(Gunda.getInstance().Gunda_GetCustomer(CustomerNumber))
            .getString("notExecutedTickets[" + num + "].gundaTicketCategory")),
        "PRINCIPAL",
        "Gunda gundaTicketCategory is not correct");
    Assert.assertEquals(
        (WebServiceOperations.getInstance()
            .convertStringToJson(Gunda.getInstance().Gunda_GetCustomer(CustomerNumber))
            .getString("notExecutedTickets[" + num + "].amount")),
        DBReusables.getInstance()
                .formatCurrency1(PayOutAmount)
                .substring(1, DBReusables.getInstance().formatCurrency1(PayOutAmount).length())
            + " EUR",
        "Gunda amount is not correct");

    int num1 =
        GundaServices.getInstance()
            .getInprogressTicket_Array(
                CustomerNumber,
                DBReusables.getInstance()
                    .getTicket_uuid(i2tPTicket_id, DBReusables.getInstance().ct2cTable));
    Assert.assertEquals(
        (WebServiceOperations.getInstance()
            .convertStringToJson(Gunda.getInstance().Gunda_GetCustomer(CustomerNumber))
            .getString("notExecutedTickets[" + num1 + "].productIdentifier")),
        SourceTrancheIdentifier,
        "Gunda TrancheIdentifier is not correct");
    Assert.assertEquals(
        (WebServiceOperations.getInstance()
            .convertStringToJson(Gunda.getInstance().Gunda_GetCustomer(CustomerNumber))
            .getString("notExecutedTickets[" + num1 + "].ticketType")),
        t2cTicketType,
        "Gunda ticketType is not correct");
    Assert.assertEquals(
        (WebServiceOperations.getInstance()
            .convertStringToJson(Gunda.getInstance().Gunda_GetCustomer(CustomerNumber))
            .getString("notExecutedTickets[" + num1 + "].ticketState")),
        "CREATED",
        "Gunda ticketState is not correct");
    Assert.assertEquals(
        (WebServiceOperations.getInstance()
            .convertStringToJson(Gunda.getInstance().Gunda_GetCustomer(CustomerNumber))
            .getString("notExecutedTickets[" + num1 + "].gundaTicketCategory")),
        "PRINCIPAL",
        "Gunda gundaTicketCategory is not correct");
    Assert.assertEquals(
        (WebServiceOperations.getInstance()
            .convertStringToJson(Gunda.getInstance().Gunda_GetCustomer(CustomerNumber))
            .getString("notExecutedTickets[" + num1 + "].amount")),
        DBReusables.getInstance()
                .formatCurrency1(PayOutAmount)
                .substring(1, DBReusables.getInstance().formatCurrency1(PayOutAmount).length())
            + " EUR",
        "Gunda amount is not correct");

    Assert.assertEquals(
        (WebServiceOperations.getInstance()
            .convertStringToJson(Gunda.getInstance().Gunda_GetCustomer(CustomerNumber))
            .getString("notExecutedTickets[" + num + "].expectedValueDate")),
        DBReusables.getInstance().getTrancheStartDate(SourceTrancheIdentifier),
        "Gunda expectedValueDate is not correct");
    Assert.assertEquals(
        (WebServiceOperations.getInstance()
            .convertStringToJson(Gunda.getInstance().Gunda_GetCustomer(CustomerNumber))
            .getString("notExecutedTickets[" + num1 + "].expectedValueDate")),
        DBReusables.getInstance().getTrancheStartDate(SourceTrancheIdentifier),
        "Gunda expectedValueDate is not correct");

    // prodops Ticket Processing for i2t
    TestLogger.logMsg("Step-10: ProdOps i2t Ticket Processing");
    ProdOpsServices.getInstance()
        .principalTicketProcessing(
            i2tTicketType, ServiceBank_BIC, i2tPTicket_id, SourceTrancheIdentifier, CustomerEmail);

    // i2t Ticket Processing

    String i2tPBankTicket_id =
        DBReusables.getInstance()
            .getBankTransferTicketID(i2tPTicket_id, DBReusables.getInstance().ci2tTable);

    TestLogger.logMsg("Step-11: Processing i2t BTO Ticket ");
    btoi2tProcessing(i2tPBankTicket_id, i2tPTicket_id, i2tPBankTicket_id, i2tPTicket_id);

    // CIA,PBIA,CTA & SBTA booking/s validation
    TestLogger.logMsg("Step-12: Validate CTA,SBTA,CIA and PBIA Bookings");
    Assert.assertEquals(
        DBReusables.getInstance()
            .getPBIABookingAmount(i2tTicketType, SourceTrancheIdentifier, ServiceBank_BIC),
        "-" + PayOutAmount,
        "Product Bank Interest Bookings not created");
    Assert.assertEquals(
        DBReusables.getInstance().getCIABookingAmountWithBST(i2tTicketType, CIA, "PRINCIPAL"),
        "-" + PayOutAmount,
        "Customer Interest Bookings not created");
    TestLogger.logInfo(
        "Amount successfully debited from Customer and Product Bank Interest Account Bookings");
    Assert.assertEquals(
        DBReusables.getInstance().getSBTABookingAmount(i2tTicketType, ServiceBank_BIC),
        PayOutAmount,
        "Service Bank Transit Account Bookings not created");
    Assert.assertEquals(
        DBReusables.getInstance()
            .getCTABookingAmountWithBST(i2tTicketType, "PRINCIPAL", CustomerEmail),
        PayOutAmount,
        "Customer Transit Account Bookings not created");
    TestLogger.logInfo(
        "Amount successfully credited to Customer and Service Bank Transit Account Bookings");

    // shop validation
    TestLogger.logMsg("Step-13: Validate Inprogress ticket in Shop post i2t ticket's processing");
    ShopLoginLogoutPO.getInstance().shopCache();
    MeineAnlagenPO.getInstance().validatePendingPayOutMessage("present", FormatedTotalAmount);
    MeineAnlagenPO.getInstance()
        .validateShopBookings(
            1,
            DBReusables.getInstance().formatDate("dd.MM.yyyy")
                + " "
                + DBReusables.getInstance().formatDate("dd.MM.yyyy")
                + " Auszahlung -"
                + FormatedPayOutAmount);

    // prodops Ticket Processing for t2c
    TestLogger.logMsg("Step-14: ProdOps t2c Ticket Processing");

    ProdOpsServices.getInstance()
        .principalTicketProcessing(
            t2cTicketType, ServiceBank_BIC, t2cPTicket_id, SourceTrancheIdentifier, CustomerEmail);

    // t2c Ticket Processing

    String t2cPBankTicket_id =
        DBReusables.getInstance()
            .getBankTransferTicketID(t2cPTicket_id, DBReusables.getInstance().ct2cTable);

    TestLogger.logMsg("Step-15: Processing t2c BTO Ticket ");

    btot2cProcessing(
        t2cPBankTicket_id,
        t2cPTicket_id,
        t2cPBankTicket_id,
        t2cPTicket_id,
        SourceTrancheIdentifier);

    // SBTA and CTA booking validation
    TestLogger.logMsg("Step-16: Validate CTA and SBTA Bookings");

    Assert.assertEquals(
        DBReusables.getInstance().getCTABookingAmount("PAY_OUT", CustomerEmail),
        "-" + PayOutAmount,
        "Customer Transit Account Bookings not created");
    Assert.assertEquals(
        DBReusables.getInstance().getSBTABookingAmount("PAY_OUT", ServiceBank_BIC),
        "-" + PayOutAmount,
        "Service Bank Transit Account Bookings not created");
    TestLogger.logInfo(
        "Amount successfully credited to Customer and Service Bank Transit Account Bookings");

    // Shop Validation
    TestLogger.logMsg("Step-17: Validate completed ticket in Shop");
    ShopLoginLogoutPO.getInstance().shopCache();
    MeineAnlagenPO.getInstance().validatePendingPayOutMessage("absent", FormatedTotalAmount);
    MeineAnlagenPO.getInstance().validateTranche(SourceTrancheIdentifier, "present");

    // CIA closed validation
    DBReusables.getInstance().getCIA_status(CIA, "false");

    // Gunda validation
    TestLogger.logMsg("Step-18: Validate completed ticket in Gunda");
    GundaServices.getInstance()
        .payOutValidatePost_i2tort2c(CustomerNumber, CIA, SourceTrancheIdentifier);
  }

  /*
   * this method hold the GVC codes
   */
  public static final class GVC {

    /** Transfer */
    public static String _351 = "351";

    /** Direct Debit Refund */
    public static String _309 = "309";

    /** Direct Debit */
    public static String _305 = "305";

    /** Pay out to customer */
    public static String _391 = "391";

    /** Arbitrary transfer (eg. settle direct refund fees manually) */
    public static String _051 = "051";

    /** Customer payin for ZP & C24 */
    public static String _360 = "360";

    /** Customer payin for ZP & C24 */
    public static String _060 = "060";
  }
}
