package com.depositsolutions.common.restapi.helpers;

public class Endpoints {
  public static final String investmentChangeMapping =
      "/investmentChangePossibilities/productView/batchCreation";
  public static final String importBankstatements_sps = "/sutor/bankstatementintradaycsv/import";
  public static final String importBankstatements_b2c = "/backoffice/bankstatement/import";
  public static final String importPayout = "/sutor/payoutcsv/import";
  public static final String bookInterest = "/interestAndTaxesBooking";
  public static final String distributeInterest = "/interestAndTaxesBooking/distribution";
  public static final String interestPayoutTickets = "/createInterestPayoutTickets";
  public static final String prepareTickets = "/prodops/tickets/customer/prepare";
  public static final String createTickets = "/prodops/tickets/bank/banktransferticket";
  public static final String ProcessTickets =
      "/prodops/tickets/bank/process/serviceBankTransitAccount";
  public static final String filerouterOutgoing = "/outgoing/filerouter";
  public static final String filerouterReceived = "/digital-account-opening-received/filerouter";
  public static final String zpblCsvImport = "/customerServiceBankAffiliations/MHSBDEHBXXX";
  public static final String sbaffCdCsvImport = "/customerdata/MHSBDEHBXXX";
  public static final String DAOexport = "/affiliation/digitalAccountOpening/export";
  public static final String DAOimport = "/affiliation/digitalAccountOpening/import";
  public static final String camunda_CIT = "/ticket/closingInvestment/execute";
  public static final String gundaValidate = "/ticket/validation";
}
