package com.depositsolutions.common.ui.zpuipageobjects;

import com.depositsolutions.common.ui.helpers.BaseTestClassUI;
import com.depositsolutions.common.ui.helpers.WebUIOperations;
import com.depositsolutions.common.utils.TestLogger;
import java.util.List;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

public class ProdOpsPO extends BaseTestClassUI {
  public static ProdOpsPO singleInstance = null;
  public static final By PRODOPS_LOGIN_LINK = By.id("form-login-input-username");
  public static final By LOGIN_LINK = By.id("link-login");
  public static final By PRODOPS_PASSWORD_LINK = By.id("form-login-input-password");
  public static final By PRODOPS_LOGIN_BUTTON = By.id("form-button-login");
  public static final By INVESTMENT_CHANGE_LINK = By.id("menu-link-investment-change");
  public static final By SUTOR_BANK_LINK = By.id("ticket-prepare-link-servicebank-MHSBDEHBXXX");
  public static final By SOURCE_BANK_BIC = By.name("sourceProductBankBic");
  public static final By SOURCEBANK_PRODUCT_IDENTIFIER = By.name("sourceProductIdentifier");
  public static final By TARGET_BANK_BIC = By.id("new_mapping_product_bank_bic");
  public static final By TARGET_BANK_PRODUCT_IDENTIFIER = By.id("new_mapping_product_identifiers");

  public static final By TRANCHES = By.id("menu-link-tranches");
  public static final By SHOWBANKS = By.id("productBankButton");
  public static final By EDIT_INTEREST = By.xpath("//*[@id='interestRate']/form/button/i");
  public static final By START_DATE = By.id("startDate");
  public static final By INTEREST_RATE = By.id("rate");
  public static final By SAVE_DETAILS =
      By.xpath(
          "//*[@id='page-wrapper']/div[3]/div/form/button[contains(text(),' Änderungen prüfen')]");
  public static final By SAVE = By.xpath("//*[@id='page-wrapper']/div/div[3]/form/button");
  // [contains(text(),' Änderungen speichern')]
  public static final By CONFIRM_CHANGEOF_INTEREST =
      By.xpath("//*[contains(@id ,'confirmInterestRate-CEKVBE81XXX-FG1Y')]");
  // By.xpath("//*[@id='CEKVBE81XXX-FIXED_1Y']/table/tbody/tr/td[8]/button");
  // [contains(text(),'Bestätigen')]
  public static final By PUBLISH_CHANGES =
      By.xpath("//*[contains(@id,'toggleViewState-CEKVBE81XXX-FG1Y')]");
  // [contains(id,'toggleViewState-CEKVBE81XXX-FG1Y')]

  public static ProdOpsPO getInstance() {
    if (singleInstance == null) {
      singleInstance = new ProdOpsPO();
    }
    return singleInstance;
  }

  /*
   * This method performs Login to Prodops with URL, UserName and Password as parameters
   * @param userName
   * @param password
   * @param url
   */
  public void prodOpsLogin(String userName, String password, String url) {
    TestLogger.logInfo("Launch Prodops URl and login to Application");
    ((JavascriptExecutor) DRIVER).executeScript("window.open()");
    WebUIOperations.getInstance().switchTab(1);
    launchUrl(url);

    WebUIOperations.getInstance().waitForElementAndClick(DRIVER.findElement(LOGIN_LINK));
    WebUIOperations.getInstance().sendKeys(DRIVER.findElement(PRODOPS_LOGIN_LINK), userName);
    WebUIOperations.getInstance().sendKeys(DRIVER.findElement(PRODOPS_PASSWORD_LINK), password);
    WebUIOperations.getInstance().waitForElementAndClick(DRIVER.findElement(PRODOPS_LOGIN_BUTTON));
    TestLogger.logInfo("Login is successful for PropOps");
  }

  /*
   * This method performs Investment Change Mapping from prodops UI
   * @param sourceBIC
   * @param sourceProductIdentifier
   * @param targetBIC
   * @param targetProductIdentifier
   * this method is not complete as we are using api
   */
  public void mapInvestmentChange(
      String sourceBIC,
      String sourceProductIdentifier,
      String targetBIC,
      String targetProductIdentifier) {
    TestLogger.logMsg("Click on Investment Changes Link and select BIC and Product Identifier");
    WebUIOperations.getInstance()
        .waitForElementAndClick(DRIVER.findElement(INVESTMENT_CHANGE_LINK));
    WebUIOperations.getInstance().waitForElementAndClick(DRIVER.findElement(SUTOR_BANK_LINK));
    WebUIOperations.getInstance()
        .selectDropdownByText(DRIVER.findElement(SOURCE_BANK_BIC), sourceBIC);
    WebUIOperations.getInstance()
        .selectDropdownByText(
            DRIVER.findElement(SOURCEBANK_PRODUCT_IDENTIFIER), sourceProductIdentifier);

    WebUIOperations.getInstance()
        .selectDropdownByText(DRIVER.findElement(TARGET_BANK_BIC), targetBIC);

    Select select = new Select(DRIVER.findElement(TARGET_BANK_PRODUCT_IDENTIFIER));
    List<WebElement> list = select.getOptions();
    if (select.isMultiple()) {}

    WebUIOperations.getInstance()
        .selectDropdownByText(
            DRIVER.findElement(TARGET_BANK_PRODUCT_IDENTIFIER), targetProductIdentifier);
  }
}
