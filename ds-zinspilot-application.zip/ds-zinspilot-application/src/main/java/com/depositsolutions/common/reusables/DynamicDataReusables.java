package com.depositsolutions.common.reusables;

import com.github.javafaker.Faker;
import org.iban4j.CountryCode;
import org.iban4j.Iban;

public class DynamicDataReusables {

  public String firstName;
  public String surName;
  public String emailAddress;
  public String password;
  public String saluation;
  public String title;
  public String phone;
  public String BANK_ACC_NUMBER_DE;
  public String IBAN_DE;
  public String BANK_CODE_DE;

  Faker faker = new Faker();
  public static DynamicDataReusables singleInstance = null;

  public static DynamicDataReusables getInstance() {
    if (singleInstance == null) {
      singleInstance = new DynamicDataReusables();
    }
    return singleInstance;
  }
  /*
   * This method generates inputs needed for Registration process
   */
  public void generateInputs() {
    saluation = "Herr";
    title = "Dr.";
    firstName = faker.name().firstName();
    surName = faker.name().lastName();
    emailAddress = firstName + faker.number().digits(3) + "@autotest.com";
    password = "Dekaup10";
    phone = "9887762" + faker.number().digits(3);
  }
  /*
   * This method generates CustomerIban(Reference Account)
   * @param cusNo
   * @return
   */
  public String CustomerIban(String cusNo) {
    BANK_CODE_DE = "50010517";
    String iban = generateIban(cusNo, BANK_CODE_DE);
    return iban;
  }
  /*
   * This method generates Customer Iban at Sutor(Customer Transit Account)
   * @param cusNo
   * @return
   */
  public String CTAIban(String cusNo) {
    BANK_CODE_DE = "20230800";
    String iban = generateIban(cusNo, BANK_CODE_DE);
    return iban;
  }
  /*
   * This method generates iban
   * @param cusNo
   * @param BankCode
   * @return
   */
  public String generateIban(String cusNo, String BankCode) {
    BANK_ACC_NUMBER_DE = "00" + cusNo;
    BANK_CODE_DE = BankCode;
    Iban iban =
        new Iban.Builder()
            .countryCode(CountryCode.DE)
            .bankCode(BANK_CODE_DE)
            .accountNumber(BANK_ACC_NUMBER_DE)
            .build();
    IBAN_DE = String.valueOf(iban);
    return IBAN_DE;
  }
}
