-- Dumping data for table `b2c_service_bank` `b2c_reporting_distribution_channel_service_bank_mapping` and `b2c_service_bank_transit_account`
--
-- WHERE:  bic='MHSBDEHBXXX'

USE `comonea_b2c`;

-- For `b2c_service_bank`
LOCK TABLES `b2c_service_bank` WRITE;
/*!40000 ALTER TABLE `b2c_service_bank` DISABLE KEYS */;
INSERT INTO `b2c_service_bank` VALUES (5,'2015-04-24 12:37:48',NULL,'MHSBDEHBXXX','','Sutor Bank','DE','BDB','EUR',1867000.00,NULL,NULL,NULL,NULL,NULL,'HRA 25379HRA 25379','DE155617009','f348a7ce-ea6d-11e4-b6f7-000c29c84cff','NO_RESTRICTIONS',NULL,NULL,'Die Sutor Bank öffnet allen die Türen zur Welt des professionellen Vermögensaufbaus.<br/>\nDie Hamburger Sutor Bank, gegründet 1921, ist eine der wenigen bis heute unabhängigen Privatbanken Deutschlands. Sie unterstützt mit ihrer Vermögensverwaltung den unkomplizierten Einstieg in den Kapitalmarkt, leistet individuelle Vermögensberatung und managt Stiftungen.<br/>\nTypisch für die Sutor Bank ist, dass seit jeher verantwortlich mit dem Geld der Kunden umgegangen wird.</br>www.sutorbank.de<br/>\n<br/>\nSutor Bank<br/>\nHermannstr. 46<br/>\n20095 Hamburg<br/>\nTel.: 040 82223163<br/>\ninfo@sutorbank.de<br/>\nwww.sutorbank.de','2015-01-01','NEVER','FROM_SBTA','TO_SBTA','TO_CSBA_FROM_SBTA');
/*!40000 ALTER TABLE `b2c_service_bank` ENABLE KEYS */;
UNLOCK TABLES;

-- For `b2c_reporting_distribution_channel_service_bank_mapping`
LOCK TABLES `b2c_reporting_distribution_channel_service_bank_mapping` WRITE;
/*!40000 ALTER TABLE `b2c_reporting_distribution_channel_service_bank_mapping` DISABLE KEYS */;
INSERT INTO `b2c_reporting_distribution_channel_service_bank_mapping` VALUES (1,'2019-08-27 13:24:18',NULL,5,'ZINSPILOT',19);
/*!40000 ALTER TABLE `b2c_reporting_distribution_channel_service_bank_mapping` ENABLE KEYS */;
UNLOCK TABLES;

-- For `b2c_service_bank_transit_account`
LOCK TABLES `b2c_service_bank_transit_account` WRITE;
/*!40000 ALTER TABLE `b2c_service_bank_transit_account` DISABLE KEYS */;
INSERT INTO `b2c_service_bank_transit_account` VALUES (3,'2015-04-24 12:37:48',NULL,'fffGraf Bent vom Eisenlauer','DE33202308002550192379','f3561b34-ea6d-11e4-b6f7-000c29c84cff',5,NULL,'EUR');
/*!40000 ALTER TABLE `b2c_service_bank_transit_account` ENABLE KEYS */;
UNLOCK TABLES;

-- For `b2c_document_terms_and_conditions_company`
LOCK TABLES `b2c_document_terms_and_conditions_company` WRITE;
/*!40000 ALTER TABLE `b2c_document_terms_and_conditions_company` DISABLE KEYS */;
INSERT INTO `b2c_document_terms_and_conditions_company` VALUES ('12', '2020-04-28 07:23:55', '2020-04-28 07:23:55', 1, 'zinspilot','', 'zinspilot-agb_2020-04-21.pdf', '2020-04-21', '1');
/*!40000 ALTER TABLE `b2c_document_terms_and_conditions_company` ENABLE KEYS */;
UNLOCK TABLES;

-- For `b2c_document_depositors_information`
LOCK TABLES `b2c_document_depositors_information` WRITE;
/*!40000 ALTER TABLE `b2c_document_depositors_information` DISABLE KEYS */;
INSERT INTO `b2c_document_depositors_information` VALUES (30, '2017-04-06 14:40:57', '2017-04-06 14:41:31', 1, 'SERVICE_BANK', 'MHSBDEHBXXX','','Sutor-Informationsbogen.pdf','2017-03-29',1);
/*!40000 ALTER TABLE `b2c_document_depositors_information` ENABLE KEYS */;
UNLOCK TABLES;

-- For `b2c_document_terms_and_conditions_bank`
LOCK TABLES `b2c_document_terms_and_conditions_bank` WRITE;
/*!40000 ALTER TABLE `b2c_document_terms_and_conditions_bank` DISABLE KEYS */;
INSERT INTO `b2c_document_terms_and_conditions_bank` VALUES (44, '2019-05-06 12:13:45', NULL, 1, 'SERVICE_BANK', 'MHSBDEHBXXX','','Nutzungsvereinbarung-und-AGB-Sutor-Bank-Zinspilot_2022-01-01.pdf','2022-01-01',1,'TERMS_AND_CONDITIONS');
/*!40000 ALTER TABLE `b2c_document_terms_and_conditions_bank` ENABLE KEYS */;
UNLOCK TABLES;

USE `sbaff`;
-- For `service_bank_distribution_channel_mapping`
LOCK TABLES `service_bank_distribution_channel_mapping` WRITE;
/*!40000 ALTER TABLE `service_bank_distribution_channel_mapping` DISABLE KEYS */;
INSERT INTO `service_bank_distribution_channel_mapping` VALUES ('1', '2019-06-11 12:33:24', NULL, 'MHSBDEHBXXX', 'ZINSPILOT', '19');
/*!40000 ALTER TABLE `service_bank_distribution_channel_mapping` ENABLE KEYS */;
UNLOCK TABLES;

USE `sbaff_cd`;
-- For `sbaff_cd_service_bank_distribution_channel_mapping`
LOCK TABLES `sbaff_cd_service_bank_distribution_channel_mapping` WRITE;
/*!40000 ALTER TABLE `sbaff_cd_service_bank_distribution_channel_mapping` DISABLE KEYS */;
INSERT INTO `sbaff_cd_service_bank_distribution_channel_mapping` VALUES ('1', '2021-03-05 10:19:29', NULL, 'MHSBDEHBXXX', 'ZINSPILOT', '19');
/*!40000 ALTER TABLE `sbaff_cd_service_bank_distribution_channel_mapping` ENABLE KEYS */;
UNLOCK TABLES;


-- Service Bank Dump completed
