-- Truncate Below SPS Tables

SET FOREIGN_KEY_CHECKS=0;
TRUNCATE table sps.bc_bank_account;
TRUNCATE table sps.bc_bank_statement;
TRUNCATE table sps.bc_bank_statement_item;
TRUNCATE table sps.bc_bank_transfer_order;
TRUNCATE table sps.bc_bank_transfer_order_bounce_pay_in;
TRUNCATE table sps.bc_bank_transfer_order_c_to_t;
TRUNCATE table sps.bc_bank_transfer_order_file;
TRUNCATE table sps.bc_bank_transfer_order_i_to_t;
TRUNCATE table sps.bc_bank_transfer_order_old;
TRUNCATE table sps.bc_bank_transfer_order_prolongation;
TRUNCATE table sps.bc_bank_transfer_order_t_to_c;
TRUNCATE table sps.bc_bank_transfer_order_t_to_i;
TRUNCATE table sps.bc_import_file;
TRUNCATE table sps.bc_payout_executed_import;
TRUNCATE table sps.bc_payout_executed_item;
TRUNCATE table sps.bc_transit_account_booking;
TRUNCATE table sps.bc_transit_account_mapping;
SET FOREIGN_KEY_CHECKS=1;
