USE `comonea_b2c`;


-- For `b2c_product_bank`
LOCK TABLES `b2c_product_bank` WRITE;
/*!40000 ALTER TABLE `b2c_product_bank` DISABLE KEYS */;
INSERT INTO `b2c_product_bank` VALUES ('44', '2018-11-12 09:11:29', '2021-02-24 08:59:23', 'MOEYFRPPXXX', NULL, 'My Money Bank S.A.', 'FR', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Nanterre, 784 393 340 R.C.S. ', 'FR93 784393340', 'f0a65de6-e65a-11e8-bddf-26e0a622eaa4', NULL, 'EUR', '100000.00', NULL, NULL, NULL, NULL, '0.00000', 'CUSTOMER_INTEREST_ACCOUNT_BASED', 'FIDUCIARY_ACCOUNT_MODEL', NULL, NULL, 'My Money Bank', NULL, '1', '-2', '00:00:00', '-1', '10:00:00', '0');
/*!40000 ALTER TABLE `b2c_product_bank` ENABLE KEYS */;
UNLOCK TABLES;

-- For `b2c_product_bank_logo`
LOCK TABLES `b2c_product_bank_logo` WRITE;
/*!40000 ALTER TABLE `b2c_product_bank_logo` DISABLE KEYS */;
INSERT INTO `b2c_product_bank_logo` VALUES ('41', '2021-01-26 10:29:53.000000', NULL,'', 'MOEYFRPPXXX.svg', 'MOEYFRPPXXX');
/*!40000 ALTER TABLE `b2c_product_bank_logo` ENABLE KEYS */;
UNLOCK TABLES;

-- For `b2c_interest_product`
LOCK TABLES `b2c_interest_product` WRITE;
/*!40000 ALTER TABLE `b2c_interest_product` DISABLE KEYS */;
INSERT INTO `b2c_interest_product` VALUES ('312', '2019-03-21 14:15:48', NULL, 'MOEYFRPPXXX-CALL_ALIKE', 'TWICE_A_MONTH', 'PRECISE_ACT_ACT', 'CALL_ALIKE', NULL, 'MMBTG24', '44', 'EUR', 'PROLONGATION', 'PAYOUT', NULL, '1');
INSERT INTO `b2c_interest_product` VALUES ('287', '2018-11-12 09:11:30', NULL, 'MOEYFRPPXXX-FIXED_1Y', 'AFTER_TERM_END', 'PRECISE_ACT_ACT', 'FIXED_1Y', NULL, 'MMBFG12M', '44', 'EUR', 'PROLONGATION', 'PAYOUT', NULL, '1');
/*!40000 ALTER TABLE `b2c_interest_product` ENABLE KEYS */;
UNLOCK TABLES;

-- For `b2c_document_depositors_information`
LOCK TABLES `b2c_document_depositors_information` WRITE;
/*!40000 ALTER TABLE `b2c_document_depositors_information` DISABLE KEYS */;
INSERT INTO `b2c_document_depositors_information` VALUES ( '89', '2018-11-12 09:14:14', NULL, 1, 'PRODUCT_BANK', 'MOEYFRPPXXX','', 'MMB_IFE.pdf', '2018-10-29', '1');
/*!40000 ALTER TABLE `b2c_document_depositors_information` ENABLE KEYS */;
UNLOCK TABLES;

-- For `b2c_document_product_information_template`
LOCK TABLES `b2c_document_product_information_template` WRITE;
/*!40000 ALTER TABLE `b2c_document_product_information_template` DISABLE KEYS */;
INSERT INTO `b2c_document_product_information_template` VALUES ('107', '2021-03-17 13:32:21', NULL, 1, '', 'ZP_Produktinformationsblatt_MyMoney_Flexgeld24.pdf', 'DIRECT_ACCESS', '44', '2021-03-17', '4', NULL, '5', '187');
INSERT INTO `b2c_document_product_information_template` VALUES ('105', '2021-03-17 13:25:37', '2021-06-08 14:24:43', 1, '', 'ZP_Produktsinformationsblatt_MyMoney_FG.pdf', 'FIXED_TERM', '44', '2021-03-17', '5', NULL, '5', NULL);
/*!40000 ALTER TABLE `b2c_document_product_information_template` ENABLE KEYS */;
UNLOCK TABLES;
