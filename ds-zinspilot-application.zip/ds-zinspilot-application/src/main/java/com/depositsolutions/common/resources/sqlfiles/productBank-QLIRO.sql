-- Dumping data for table `b2c_product_bank`,`b2c_product_tranche`,`b2c_product_tranche_call_alike_transfer`,`b2c_product_bank_interest_account` and
--
-- WHERE:  bic='CKV-FG'

USE `comonea_b2c`;

-- For `b2c_product_bank`
LOCK TABLES `b2c_product_bank` WRITE;
/*!40000 ALTER TABLE `b2c_product_bank` DISABLE KEYS */;
INSERT INTO `b2c_product_bank` VALUES ('60', '2020-02-21 14:18:29', '2021-02-24 08:59:23', 'QLROSEHHXDS', NULL, 'Qliro AB', 'SE', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'org. Nr. 556962-2441', ' SE556962244101', '08ab3d69-54b5-11ea-821c-26e0a622eaa4', NULL, 'EUR', '95000.00', NULL, NULL, NULL, NULL, '0.00000', 'CUSTOMER_INTEREST_ACCOUNT_BASED', 'DIRECT_RELATIONSHIP_MODEL', NULL, NULL, 'Qliro  ', NULL, '1', '-1', '00:00:00', '-1', '10:00:00', '0');
/*!40000 ALTER TABLE `b2c_product_bank` ENABLE KEYS */;
UNLOCK TABLES;

-- For `b2c_product_bank_contact_details`
LOCK TABLES `b2c_product_bank_contact_details` WRITE;
/*!40000 ALTER TABLE `b2c_product_bank_contact_details` DISABLE KEYS */;INSERT INTO `b2c_product_bank_contact_details` (`id`, `creationDate`, `lastModifiedDate`, `productBank_id`, `emailAddress`, `addressLine1`, `postalCode`, `townName`, `countryCode`)
VALUES('5', '2020-02-21 14:18:29', NULL, '60', 'widerrufzinspilot@qliro.com', 'Sveavägen 151', '11346', 'Stockholm, Sweden', 'SE');
/*!40000 ALTER TABLE `b2c_product_bank_contact_details` ENABLE KEYS */;
UNLOCK TABLES;

-- For `b2c_product_bank_validation_requirement`
LOCK TABLES `b2c_product_bank_validation_requirement` WRITE;
/*!40000 ALTER TABLE `b2c_product_bank_validation_requirement` DISABLE KEYS */;
INSERT INTO `b2c_product_bank_validation_requirement` VALUES ('87','2017-01-19 10:36:13',NULL,'GERMAN_TAX_ID','60','NONE',NULL,'1');
INSERT INTO `b2c_product_bank_validation_requirement` VALUES ('272', '2020-07-31 09:38:01', NULL, 'PRODUCTBANK_QUESTIONS_ANSWERED', '60', 'NONE', NULL, '1');
INSERT INTO `b2c_product_bank_validation_requirement` VALUES ('23','2020-01-22 10:07:38',NULL,'VALID_DRM_CONTRACT','60','NONE',NULL,'1');
/*!40000 ALTER TABLE `b2c_product_bank_validation_requirement` ENABLE KEYS */;
UNLOCK TABLES;

-- For `b2c_product_bank_logo`
LOCK TABLES `b2c_product_bank_logo` WRITE;
/*!40000 ALTER TABLE `b2c_product_bank_logo` DISABLE KEYS */;
INSERT INTO `b2c_product_bank_logo` VALUES ('29', '2021-01-26 10:29:53.000000', NULL, '', 'QLROSEHHXDS.svg', 'QLROSEHHXDS');
/*!40000 ALTER TABLE `b2c_product_bank_logo` ENABLE KEYS */;
UNLOCK TABLES;

-- For `b2c_interest_product`
LOCK TABLES `b2c_interest_product` WRITE;
/*!40000 ALTER TABLE `b2c_interest_product` DISABLE KEYS */;
INSERT INTO `b2c_interest_product` VALUES ('354', '2020-02-21 14:18:30', NULL, 'QLROSEHHXDS-CALL_ALIKE', 'TWICE_A_MONTH', 'GERMAN_30_360', 'CALL_ALIKE', NULL, 'QLIROTG24', '60', 'EUR', 'PROLONGATION', 'PAYOUT', NULL, '1');
/*!40000 ALTER TABLE `b2c_interest_product` ENABLE KEYS */;
UNLOCK TABLES;

-- For `b2c_document_product_information_template`
LOCK TABLES `b2c_document_product_information_template` WRITE;
/*!40000 ALTER TABLE `b2c_document_product_information_template` DISABLE KEYS */;
INSERT INTO `b2c_document_product_information_template` VALUES ('19775', '2021-03-17 13:32:21', NULL, 1, '', 'ZP_Produktinformationsblatt_Qlrio_Flexgeld24.pdf', 'DIRECT_ACCESS', '60', '2021-03-17', '4', NULL, '5', '354');
/*!40000 ALTER TABLE `b2c_document_product_information_template` ENABLE KEYS */;
UNLOCK TABLES;

-- For `zp_messages`
LOCK TABLES `zp_messages` WRITE;
/*!40000 ALTER TABLE `zp_messages` DISABLE KEYS */;
INSERT INTO `zp_messages` (`id`, `creationDate`, `lastModifiedDate`, `message_key`, `message`)
VALUES(55, '2021-01-26 10:33:04.000000', NULL, 'high_yield.category.QLROSEHHXDS', '1');
/*!40000 ALTER TABLE `zp_messages` ENABLE KEYS */;
UNLOCK TABLES;

--drm
USE `cm`;
LOCK TABLES `dc_cancellation_timeout` WRITE;
/*!40000 ALTER TABLE `dc_cancellation_timeout` DISABLE KEYS */;
INSERT INTO `dc_cancellation_timeout` (`distributionChannel`, `days`)
VALUES('ZP', 45);
/*!40000 ALTER TABLE `dc_cancellation_timeout` ENABLE KEYS */;
UNLOCK TABLES;

LOCK TABLES `product_bank` WRITE;
/*!40000 ALTER TABLE `product_bank` DISABLE KEYS */;
INSERT INTO `product_bank` (`id`, `creationDate`, `lastModifiedDate`, `uuid`)
VALUES(44, '2020-01-07 08:25:13.101171', NULL, '08ab3d69-54b5-11ea-821c-26e0a622eaa4');
/*!40000 ALTER TABLE `product_bank` ENABLE KEYS */;
UNLOCK TABLES;

LOCK TABLES `terms` WRITE;
/*!40000 ALTER TABLE `terms` DISABLE KEYS */;
INSERT INTO `terms` (`id`, `creationDate`, `lastModifiedDate`, `uuid`, `productBank_id`, `validFrom`)
VALUES(516, '2021-06-17 14:17:46.418502', NULL, 'be8fe1ec-e1ca-4696-aa8d-ed19c2030f29', 44, '2021-06-17');
/*!40000 ALTER TABLE `terms` ENABLE KEYS */;
UNLOCK TABLES;

--questionary
USE `cq`;
LOCK TABLES `cq_product_bank` WRITE;
/*!40000 ALTER TABLE `cq_product_bank` DISABLE KEYS */;
INSERT INTO `cq_product_bank` (`id`, `creation_date`, `last_modified_date`, `bic`, `tenant`)
VALUES(31, '2020-01-09 09:26:44.000000', NULL, 'QLROSEHHXDS', 'ZINSPILOT');
/*!40000 ALTER TABLE `cq_product_bank` ENABLE KEYS */;
UNLOCK TABLES;


LOCK TABLES `cq_question_groups` WRITE;
/*!40000 ALTER TABLE `cq_question_groups` DISABLE KEYS */;
INSERT INTO `cq_question_groups` (`id`, `name`, `creation_date`, `last_modified_date`)
VALUES(1, 'DEFAULT', '2019-12-06 08:47:56.462756', NULL);
/*!40000 ALTER TABLE `cq_question_groups` ENABLE KEYS */;
UNLOCK TABLES;

LOCK TABLES `cq_question_types` WRITE;
/*!40000 ALTER TABLE `cq_question_types` DISABLE KEYS */;
INSERT INTO `cq_question_types` (`id`, `name`, `creation_date`, `last_modified_date`)
VALUES(10, 'OPTIONS', '2019-12-06 08:47:56.606533', NULL);
/*!40000 ALTER TABLE `cq_question_types` ENABLE KEYS */;
UNLOCK TABLES;

LOCK TABLES `cq_questions` WRITE;
/*!40000 ALTER TABLE `cq_questions` DISABLE KEYS */;
INSERT INTO `cq_questions` (`product_bank_id`, `question_text`, `code`, `description`, `group_id`, `type_id`, `max_length`, `order_value`, `creation_date`, `last_modified_date`, `is_active`, `is_mandatory`)
VALUES
   (31, 'Wie ist Ihr Familienstand?', 'MARITAL_STATUS', '', 1, 10, NULL, 10, '2020-08-27 15:13:19.316166', NULL, 1, 1),
   (31, 'Wählen Sie den passenden NACE-Code aus?', 'NACE_CODE', '', 1, 10, NULL, 30, '2020-08-27 15:13:19.318187', NULL, 1, 0),
   (31, 'In welcher Branche sind Sie beruflich tätig?', 'SECTOR_EMPLOYMENT', '', 1, 10, NULL, 40, '2020-08-27 15:13:19.319143', NULL, 1, 0),
   (31, 'Wie ist Ihre berufliche Situation?', 'TYPE_EMPLOYMENT', '', 1, 10, NULL, 20, '2020-08-27 15:13:19.317235', NULL, 1, 1);
/*!40000 ALTER TABLE `cq_questions` ENABLE KEYS */;
UNLOCK TABLES;

LOCK TABLES `cq_options` WRITE;
/*!40000 ALTER TABLE `cq_options` DISABLE KEYS */;
INSERT INTO `cq_options` (`id`, `product_bank_id`, `question_code`, `option_text`, `option_code`, `order_value`, `is_default_value`, `high_risk`, `creation_date`, `last_modified_date`)
VALUES
   	(2890, 31, 'MARITAL_STATUS', 'Ledig', '1', 10, 1, 0, '2020-08-27 15:13:19.989787', '2020-09-17 15:01:36.000000'),
   	(2891, 31, 'MARITAL_STATUS', 'Verheiratet', '2', 20, 0, 0, '2020-08-27 15:13:19.990170', NULL),
   	(2892, 31, 'MARITAL_STATUS', 'Verwitwet', '3', 30, 0, 0, '2020-08-27 15:13:19.990479', NULL),
   	(2893, 31, 'MARITAL_STATUS', 'Geschieden', '4', 40, 0, 0, '2020-08-27 15:13:19.990810', NULL),
   	(2923, 31, 'TYPE_EMPLOYMENT', 'Privatier', '41', 270, 1, 0, '2020-08-27 15:13:20.011378', NULL),
   	(2924, 31, 'TYPE_EMPLOYMENT', 'Rentner/in oder Pensionär/in', '42', 280, 0, 0, '2020-08-27 15:13:20.011682', NULL),
   	(2925, 31, 'TYPE_EMPLOYMENT', 'Richter/in', '18', 290, 0, 0, '2020-08-27 15:13:20.011984', NULL),
   	(2899, 31, 'TYPE_EMPLOYMENT', 'Arbeiter/in', '11', 30, 0, 0, '2020-08-27 15:13:19.993910', NULL),
   	(2927, 31, 'NACE_CODE', 'Anbau von Getreide (mit Ausnahme von Reis), Hülsenfrüchten und Ölsaaten', '1110', 10, 0, 0, '2020-08-27 15:13:20.012590', NULL),
   	(2928, 31, 'NACE_CODE', 'Reisanbau', '1120', 20, 0, 0, '2020-08-27 15:13:20.012930', NULL),
   	(3871, 31, 'NACE_CODE', 'Arbeitnehmer, Opfer eines Arbeitsunfalls oder einer Berufskrankheit, die eine Entschädigung oder eine Rente erhalten', '99902', 9450, 0, 0, '2020-08-27 15:13:20.408629', NULL),
   	(3872, 31, 'NACE_CODE', 'Arbeitnehmer, die andere Sozialleistungen genießen', '99903', 9460, 0, 0, '2020-08-27 15:13:20.409059', NULL),
   	(3873, 31, 'NACE_CODE', 'Auszubildende in einigen börsennotierten Unternehmen, die einem Sanierungsplan unterliegen', '99904', 9470, 0, 0, '2020-08-27 15:13:20.409497', NULL),
   	(3874, 31, 'NACE_CODE', 'Arbeitgeber von im Ausland beschäftigten Arbeitnehmern - ausländische Arbeitgeber, die Löhne an von einer Schwestergesellschaft in Belgien beschäftigte Arbeitnehmer zahlen', '99905', 9480, 0, 0, '2020-08-27 15:13:20.409920', NULL),
    (3885, 31, 'SECTOR_EMPLOYMENT', 'Handel - Textilien', '33', 110, 0, 0, '2020-08-27 15:13:20.415459', NULL),
   	(3886, 31, 'SECTOR_EMPLOYMENT', 'Handel - Tiere', '32', 120, 0, 0, '2020-08-27 15:13:20.415823', NULL),
   	(3887, 31, 'SECTOR_EMPLOYMENT', 'Handel - Waffen', '36', 130, 0, 0, '2020-08-27 15:13:20.416184', NULL),
   	(3888, 31, 'SECTOR_EMPLOYMENT', 'Immobilien', '70', 140, 0, 0, '2020-08-27 15:13:20.416548', NULL),
   	(3889, 31, 'SECTOR_EMPLOYMENT', 'Industrie - Chemie', '12', 150, 0, 0, '2020-08-27 15:13:20.416928', NULL);
/*!40000 ALTER TABLE `cq_options` ENABLE KEYS */;
UNLOCK TABLES;

LOCK TABLES `cq_mandatory_follow_up_questions` WRITE;
/*!40000 ALTER TABLE `cq_mandatory_follow_up_questions` DISABLE KEYS */;
INSERT INTO `cq_mandatory_follow_up_questions` (`id`, `product_bank_id`, `option_id`, `question_code`, `creation_date`, `last_modified_date`)
VALUES
   (23, 31, 2927, 'NACE_CODE', '2020-08-27 15:13:19.997368', NULL),
   (24, 31, 3874, 'NACE_CODE', '2020-08-27 15:13:19.998759', NULL),
   (30, 31, 3885, 'SECTOR_EMPLOYMENT', '2020-08-27 15:13:20.004064', NULL),
   (33, 31, 3889, 'SECTOR_EMPLOYMENT', '2020-08-27 15:13:20.009551', NULL);
/*!40000 ALTER TABLE `cq_mandatory_follow_up_questions` ENABLE KEYS */;
UNLOCK TABLES;

-- Table Dump completed
