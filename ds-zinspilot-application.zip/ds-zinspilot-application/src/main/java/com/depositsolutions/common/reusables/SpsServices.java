package com.depositsolutions.common.reusables;

import static com.depositsolutions.common.reusables.TestConstants.CURRENT_WORKING_DIRECTORY;

import com.depositsolutions.common.utils.TestLogger;
import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.time.LocalDateTime;
import java.util.concurrent.ThreadLocalRandom;
import org.testng.Assert;

public class SpsServices {
  public static SpsServices singleInstance = null;
  private String filepath =
      CURRENT_WORKING_DIRECTORY + "/src/main/java/com/depositsolutions/common/resources/csvfiles/";

  public static SpsServices getInstance() {
    if (singleInstance == null) {
      singleInstance = new SpsServices();
    }
    return singleInstance;
  }

  /*
   * This method generates Payout/PayIn Content and replaces it in the mentioned CSV file in resources folder
   * @param bookingCode
   * @param multiPurposeText
   * @param iban
   * @param counterPartIban
   * @param Amount
   * @return
   */
  public String generateDepositCSVContent(
      String bookingCode,
      String multiPurposeText,
      String iban,
      String counterPartIban,
      String Amount,
      String csvfile) {
    String bookingCsvContent;
    try {
      File PayOutTemplateFile = new File(filepath + csvfile);

      bookingCsvContent = new String(Files.readAllBytes(PayOutTemplateFile.toPath()));
      LocalDateTime now = LocalDateTime.now();
      String valueDate = DBReusables.getInstance().formatDate("yyyy-MM-dd");
      String bookingDate = DBReusables.getInstance().formatDate("yyyy-MM-dd");
      Amount = Amount.replace(".", ",");
      bookingCsvContent =
          bookingCsvContent.replace(
              "{uniqueId}", Integer.toString(ThreadLocalRandom.current().nextInt(0, 999999)));
      bookingCsvContent = bookingCsvContent.replace("{bookingCode}", bookingCode);
      bookingCsvContent = bookingCsvContent.replace("{multiPurposeText}", multiPurposeText);
      bookingCsvContent = bookingCsvContent.replace("{iban}", iban);
      bookingCsvContent = bookingCsvContent.replace("{counterPartIban}", counterPartIban);
      bookingCsvContent = bookingCsvContent.replace("{amount}", Amount);
      bookingCsvContent = bookingCsvContent.replace("{valueDate}", valueDate);
      bookingCsvContent = bookingCsvContent.replace("{bookingDate}", bookingDate);
    } catch (IOException e) {
      throw new RuntimeException("Could not generate content of bank statement", e);
    }
    TestLogger.logInfo(csvfile + " file generated successful");
    return bookingCsvContent;
  }

  /*
   * This method validates imported file status in sps Database
   * @param FileName
   */
  public void validateImportFile(String FileName, String status) throws InterruptedException {
    Thread.sleep(2000);
    Assert.assertEquals(
        DBReusables.getInstance().getSpsImportFileStatus(FileName),
        status,
        "Sutor Bank Statement is not imported");
  }
}
