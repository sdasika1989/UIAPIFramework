--Dumping data for table 'b2c_product_bank_validation_requirement'

USE `comonea_b2c`;
LOCK TABLES `b2c_product_bank_validation_requirement` WRITE;
/*!40000 ALTER TABLE `b2c_product_bank_validation_requirement` DISABLE KEYS */;
INSERT INTO `comonea_b2c`.`b2c_product_bank_validation_requirement` (`id`, `creationDate`, `lastModifiedDate`, `validationRequirement`, `productBank_id`, `validationRequirementValueType`, `specifier`, `performValidation`) VALUES ('1', '2020-02-21 14:18:29', '2020-02-21 14:18:29', 'PRODUCTBANK_QUESTIONS_ANSWERED ', '58', 'NONE', 'NULL', '1');
/*!40000 ALTER TABLE `b2c_product_bank_validation_requirement` ENABLE KEYS */;
UNLOCK TABLES;