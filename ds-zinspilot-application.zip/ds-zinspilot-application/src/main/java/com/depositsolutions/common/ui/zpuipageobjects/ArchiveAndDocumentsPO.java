package com.depositsolutions.common.ui.zpuipageobjects;

import com.depositsolutions.common.reusables.DBReusables;
import com.depositsolutions.common.ui.helpers.BaseTestClassUI;
import com.depositsolutions.common.ui.helpers.WebUIOperations;
import com.depositsolutions.common.utils.ConfigManager;
import com.depositsolutions.common.utils.TestLogger;
import java.util.List;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.testng.Assert;

public class ArchiveAndDocumentsPO extends BaseTestClassUI {
  public static ArchiveAndDocumentsPO singleInstance = null;

  public By ZP_ArchiveAndDocuments = By.partialLinkText("Archiv & Dokumen");
  public By BeendeteAnlagen = By.xpath("//h1[contains(text(),'Beendete Anlagen')]");
  public By PersonalDocumentRow = By.xpath("//body/div[4]/section[1]/div[2]/table[1]/tbody/tr");

  public String shopCacheUrl = ConfigManager.getInstance().getString("shopCacheUrl");

  public static ArchiveAndDocumentsPO getInstance() {
    if (singleInstance == null) {
      singleInstance = new ArchiveAndDocumentsPO();
    }
    return singleInstance;
  }

  /*
   * This method checks for Tranche in Archive And Documents
   * @param TrancheIdentifier
   * @param CIA
   */
  public void validateArchiveAndDocumentsTranche(String TrancheIdentifier, String CIA) {
    DRIVER.findElement(ZP_ArchiveAndDocuments).click();
    WebUIOperations.getInstance()
        .verifyElementIsPresent(DRIVER.findElement(BeendeteAnlagen), "BeendeteAnlagen");
    Assert.assertTrue(
        DRIVER
            .findElement(
                By.id(
                    "details-"
                        + DBReusables.getInstance()
                            .getPayInCodeFromTrancheIdentifier(TrancheIdentifier)
                        + "_"
                        + DBReusables.getInstance().getCIA_UUID(CIA)))
            .isDisplayed());
    TestLogger.logInfo(TrancheIdentifier + " successfully moved to Archive And Documents");
  }

  /*
   * This method checks for entries in Personal Document section
   * @param TrancheIdentifier
   */
  public void validatePersonalDocument(String expected, String flag) {
    DRIVER.findElement(ZP_ArchiveAndDocuments).click();
    List<WebElement> list = DRIVER.findElements(PersonalDocumentRow);
    if (flag.equalsIgnoreCase("present")) {
      Assert.assertTrue(
          list.stream().filter(e -> e.getText().equalsIgnoreCase(expected)).count() == 1,
          "missing document in Personal Document section: " + expected);
      TestLogger.logInfo(
          "Entry is as expected in Personal Document section of Archive And Documents Page");
    } else {
      Assert.assertTrue(
          list.stream().filter(e -> e.getText().equalsIgnoreCase(expected)).count() == 0,
          " document in Personal Document section: " + expected);
      TestLogger.logInfo(
          "Document vanished from Personal Document section of Archive And Documents Page");
    }
  }
}
