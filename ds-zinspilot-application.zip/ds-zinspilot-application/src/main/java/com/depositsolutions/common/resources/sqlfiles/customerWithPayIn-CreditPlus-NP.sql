USE `comonea_b2c`;

-- For `b2c_customer`









-- For `b2c_customer_interest_account`
LOCK TABLES `b2c_customer_interest_account` WRITE;
/*!40000 ALTER TABLE `b2c_customer_interest_account` DISABLE KEYS */;
INSERT INTO `b2c_customer_interest_account` VALUES (1,'2021-05-20 09:18:03',NULL,'3a9f0aec-9603-45f1-9a35-cd897e7a48d8',219,371,7544,0,0,NULL,NULL,NULL,'EUR',NULL,NULL);
/*!40000 ALTER TABLE `b2c_customer_interest_account` ENABLE KEYS */;
UNLOCK TABLES;

-- For `b2c_customer_interest_account_booking`
LOCK TABLES `b2c_customer_interest_account_booking` WRITE;
/*!40000 ALTER TABLE `b2c_customer_interest_account_booking` DISABLE KEYS */;
INSERT INTO `b2c_customer_interest_account_booking` VALUES (1,'2021-08-16 05:09:37',NULL,NULL,'Einzahlung fuer Produkt CreditPlusTG','TRANSIT_TO_INTEREST','5d140842-f81e-461d-b7ad-e77eac80dc91','EUR','10000.00','2021-10-15',1,NULL);
/*!40000 ALTER TABLE `b2c_customer_interest_account_booking` ENABLE KEYS */;
UNLOCK TABLES;

-- For `b2c_customer_transit_account_booking`
LOCK TABLES `b2c_customer_transit_account_booking` WRITE;
/*!40000 ALTER TABLE `b2c_customer_transit_account_booking` DISABLE KEYS */;
INSERT INTO `b2c_customer_transit_account_booking` VALUES (1,'2021-10-10 04:50:53',NULL,NULL,'CreditPlusTG','PAY_IN','b7047fe5-d915-4398-8035-54e255afab63','EUR','10000.00','2021-08-16',219,NULL);
INSERT INTO `b2c_customer_transit_account_booking` VALUES (2,'2021-10-15 04:51:08',NULL,NULL,'Einzahlung fuer Produkt CreditPlusTG','TRANSIT_TO_INTEREST','79917703-7862-41c6-b8ee-23ac764cbb96','EUR','-10000.00','2021-10-15',219,NULL);
/*!40000 ALTER TABLE `b2c_customer_transit_account_booking` ENABLE KEYS */;
UNLOCK TABLES;

-- For `b2c_service_bank_transit_account_booking`
LOCK TABLES `b2c_service_bank_transit_account_booking` WRITE;
/*!40000 ALTER TABLE `b2c_service_bank_transit_account_booking` DISABLE KEYS */;
INSERT INTO `b2c_service_bank_transit_account_booking` VALUES (1,'2021-10-10 04:50:53',NULL,NULL,'CreditPlusTG','PAY_IN','b7047fe5-d915-4398-8035-54e255afab63','EUR','10000.00','2021-08-16',NULL,NULL,3);
INSERT INTO `b2c_service_bank_transit_account_booking` VALUES (2,'2021-10-15 04:51:08',NULL,NULL,'Einzahlung fuer Produkt CreditPlusTG','TRANSIT_TO_INTEREST','79917703-7862-41c6-b8ee-23ac764cbb96','EUR','-10000.00','2021-10-15',NULL,NULL,3);
/*!40000 ALTER TABLE `b2c_service_bank_transit_account_booking` ENABLE KEYS */;
UNLOCK TABLES;

-- For `b2c_product_bank_interest_account_booking`
LOCK TABLES `b2c_product_bank_interest_account_booking` WRITE;
/*!40000 ALTER TABLE `b2c_product_bank_interest_account_booking` DISABLE KEYS */;
INSERT INTO `b2c_product_bank_interest_account_booking` VALUES (1,'2021-10-15 04:51:08',NULL,NULL,'Einzahlung fuer Produkt CreditPlusTG','TRANSIT_TO_INTEREST','a3ca5bb6-85dc-4ca3-b69e-b2d2bd489bd1','EUR','10000.00','2021-10-15',7544,NULL);
/*!40000 ALTER TABLE `b2c_product_bank_interest_account_booking` ENABLE KEYS */;
UNLOCK TABLES;
