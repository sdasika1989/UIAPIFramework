-- Dumping data for table `b2c_service_bank` `b2c_reporting_distribution_channel_service_bank_mapping` and `b2c_service_bank_transit_account`
--
-- WHERE:  bic='MHSBDEHBXXX'
TRUNCATE table sbaff.service_bank_distribution_channel_mapping;
TRUNCATE table sbaff_cd.sbaff_cd_service_bank_distribution_channel_mapping;

USE `sbaff`;
-- For `service_bank_distribution_channel_mapping`
LOCK TABLES `service_bank_distribution_channel_mapping` WRITE;
/*!40000 ALTER TABLE `service_bank_distribution_channel_mapping` DISABLE KEYS */;
INSERT INTO `service_bank_distribution_channel_mapping` VALUES ('1', '2019-06-11 12:33:24', NULL, 'MHSBDEHBXXX', 'ZINSPILOT', '19');
/*!40000 ALTER TABLE `service_bank_distribution_channel_mapping` ENABLE KEYS */;
UNLOCK TABLES;

USE `sbaff_cd`;
-- For `sbaff_cd_service_bank_distribution_channel_mapping`
LOCK TABLES `sbaff_cd_service_bank_distribution_channel_mapping` WRITE;
/*!40000 ALTER TABLE `sbaff_cd_service_bank_distribution_channel_mapping` DISABLE KEYS */;
INSERT INTO `sbaff_cd_service_bank_distribution_channel_mapping` VALUES ('1', '2021-03-05 10:19:29', NULL, 'MHSBDEHBXXX', 'ZINSPILOT', '19');
/*!40000 ALTER TABLE `sbaff_cd_service_bank_distribution_channel_mapping` ENABLE KEYS */;
UNLOCK TABLES;


-- Service Bank Dump completed
