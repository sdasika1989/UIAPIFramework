package com.depositsolutions.common.restapi.services;

import static io.restassured.RestAssured.given;

import com.depositsolutions.common.restapi.helpers.Endpoints;
import com.depositsolutions.common.utils.ConfigManager;
import com.depositsolutions.common.utils.TestLogger;
import io.restassured.RestAssured;

public class ZpBL {
  public static ZpBL singleInstance = null;

  public static ZpBL getInstance() {
    if (singleInstance == null) {
      singleInstance = new ZpBL();
    }
    return singleInstance;
  }

  public void importCustomerToZP_BL() {

    RestAssured.baseURI = ConfigManager.getInstance().getString("zpblUrl");
    ;

    given()
        .header("Content-Type", "application/json")
        .when()
        .post(Endpoints.zpblCsvImport)
        .then()
        .log()
        .ifError()
        .assertThat()
        .statusCode(200);
    TestLogger.logInfo("API: Import customerList.csv to b2c is successful");
  }
}
