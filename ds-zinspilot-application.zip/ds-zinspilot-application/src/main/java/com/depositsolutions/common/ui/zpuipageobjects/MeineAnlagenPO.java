package com.depositsolutions.common.ui.zpuipageobjects;

import com.depositsolutions.common.reusables.DBReusables;
import com.depositsolutions.common.ui.helpers.BaseTestClassUI;
import com.depositsolutions.common.ui.helpers.WebUIOperations;
import com.depositsolutions.common.utils.ConfigManager;
import com.depositsolutions.common.utils.TestLogger;
import java.awt.*;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.testng.Assert;

public class MeineAnlagenPO extends BaseTestClassUI {
  public static MeineAnlagenPO singleInstance = null;

  public By ZP_PayOut = By.id("payout-button");
  public By ZP_PayIn = By.id("btn-payin-top");
  public By DRM_hint = By.partialLinkText("Warum");
  public By ZP_IC = By.id("change-product-button-top");
  public By ZP_fullAmount = By.id("payOutType2");
  public By ZP_Amount = By.id("amount");
  public By ZP_submit = By.id("btn-payout-now");
  public By ZP_confirm = By.id("btn-change-now");
  public By ZP_cancel = By.xpath("//a[contains(text(),'Abbrechen')]");
  public By ZP_MeineAnlagen = By.linkText("Meine Anlagen");
  public By Prolongation = By.linkText("Prolongation anpassen");
  public By VertragEinsehen = By.linkText("Vertrag einsehen");
  public By FullProlongation = By.id("prolongationType-all");
  public By PartialProlongation = By.id("prolongationType-partial");
  public By NoProlongation = By.id("prolongationType-none");
  public By ProlongationSubmit1 =
      By.xpath("//body[1]/section[1]/div[1]/form[1]/footer[1]/div[2]/button[1]");
  public By ProlongationSubmit2 = By.xpath("//button[contains(text(),'Schließen')]");
  public By FG_PayOutAmount = By.id("payoutAmount");
  public By SuccessMessage = By.xpath("//div[@class='msg-success']");
  public By PayoutMessage = By.xpath("//p[@class='text-blue']");
  public By meinAnlagenHeaderText = By.xpath("//h1[contains(text(),'Meine Anlagen')]");
  public By zpProductDetails = By.xpath("//h1[contains(text(),'Umsätze/Verwalten')]");
  public By Auszahlung = By.xpath("//h2[text()='Auszahlung']");
  public By prolongationText = By.xpath("//div[@class='col-xs-10 col-xs-offset-1']");
  public By HintHeader = By.xpath("//strong[contains(text(),'* Hinweis:')]");
  public By HintText =
      By.xpath("//p[contains(text(),'Ihr Anlagebetrag wird von Ihrer ZINSPILOT-Partnerb')]");
  public By icPage1Text1 = By.xpath("//body/div[4]/section[1]/div[2]");
  public By icPage1Text2 = By.xpath("//body/div[4]/section[1]/div[3]");
  public By icPage1Text3 = By.xpath("//body/div[4]/section[1]/div[4]");
  public By icToolTip = By.xpath("//body/div[4]/section[1]/div[2]/div[1]/h2[1]/span[1]");
  public By icPage2Text = By.xpath("//body/div[4]/section[1]/div[2]/div[1]");
  public By drm_warningmsg = By.xpath("//div[@class='msg-warning']");
  public By drm_agreement = By.id("drmCheckboxWithoutActiveInvestment");
  public By drm_accept = By.id("proceedFromAcceptedDrmButton");
  public By Rekyc_Hint = By.xpath("/html/body/div[4]/section/div[1]/p/i/a");
  public static By NOTICEPERIOD_TEXT =
      By.xpath("//*[@id='productList']/li/form/div[1]/div/div[3]/div/p");
  public static By NOTICEPERIOD_MESSAGE =
      By.xpath("//*[@id='productList']/li/form/div[1]/div/div[4]/div/div/ul/li[3]");
  public static By STARTDATE_MESSAGE = By.xpath("//div[1]/div/div[4]/div/div/ul/li[2]/text()");

  public static By NP_TEXT =
      By.xpath("/html/body/div[4]/div/section/div/ul/li/div/div/div[1]/div/div");
  public static By NP_MESSAGE =
      By.xpath("/html/body/div[4]/div/section/div/ul/li/div/div/div[2]/div/ul/li[3]");
  String shopCacheUrl = ConfigManager.getInstance().getString("shopCacheUrl");

  public static MeineAnlagenPO getInstance() {
    if (singleInstance == null) {
      singleInstance = new MeineAnlagenPO();
    }
    return singleInstance;
  }

  /*
   * This method selects tranche from ProductDetails/product list page
   * @param TrancheIdentifier
   */
  public void verifyZPProductDetails(String TrancheIdentifier) {
    DRIVER.findElement(By.id("details-" + TrancheIdentifier)).click();
    WebUIOperations.getInstance()
        .verifyElementIsPresent(DRIVER.findElement(zpProductDetails), "ZP ProductDetails");
    TestLogger.logInfo("Bookings page is loaded successfully");
  }

  /*
   * This method gets amount text from shop ui
   * @param TrancheIdentifier
   */
  public String MAamount(String TrancheIdentifier) {
    String value = DRIVER.findElement(By.id(TrancheIdentifier + "-amount-value")).getText();
    return value;
  }

  /*
   * This method selects prolongation button
   */
  public void initiateProlongation() throws InterruptedException {
    ShopLoginLogoutPO.getInstance().shopCache();
    DRIVER.findElement(Prolongation).click();
  }

  /*
   * This method verify deposit amount
   * @param TrancheIdentifier
   * @param CustomerEmail
   */
  public void getInvestmentDetails(String TrancheIdentifier, String CustomerEmail)
      throws InterruptedException {
    DRIVER.findElement(ZP_MeineAnlagen).click();
    WebUIOperations.getInstance()
        .verifyElementIsPresent(DRIVER.findElement(meinAnlagenHeaderText), "Meine Anlagen Header");
    ShopLoginLogoutPO.getInstance().shopCache();
    if (DBReusables.getInstance().getCIAB_Balance(TrancheIdentifier, CustomerEmail) == null) {
      Assert.assertEquals(MAamount(TrancheIdentifier), "0,00 €", "Invested Amount doest not match");
    } else {
      Assert.assertEquals(
          MAamount(TrancheIdentifier),
          DBReusables.getInstance()
              .formatCurrency(
                  DBReusables.getInstance().getCIAB_Balance(TrancheIdentifier, CustomerEmail)),
          "Invested Amount doest not match");
    }

    TestLogger.logInfo("Shop Total Balance Validation is done successfully");

    verifyZPProductDetails(TrancheIdentifier);
    TestLogger.logInfo("Selected product from MeineAnlagen page");
  }

  /*
   * This method is sub flow to select payout amount for TG/Call from shop
   * @param amount
   * @param PayOutType
   * @param CIA
   */
  public void initiatePayOutShop_sub(String amount, String PayOutType, String CIA) {
    DRIVER.findElement(ZP_PayOut).click();
    TestLogger.logInfo("clicked Shop Payout button");
    WebUIOperations.getInstance()
        .verifyElementIsPresent(DRIVER.findElement(Auszahlung), "Auszahlung");

    if (PayOutType.equalsIgnoreCase("FullPayOut")) {
      DRIVER.findElement(ZP_fullAmount).click();

    } else {
      DRIVER.findElement(ZP_Amount).sendKeys(amount);
    }
    DRIVER.findElement(ZP_submit).click();
    Assert.assertEquals(
        DBReusables.getInstance().getStatusCIABCR(CIA),
        "ACTIVE",
        "CIA change request status did not match");
    TestLogger.logInfo("CIA change request status is Active");
  }

  /*
   * This method creates payout from shop for TG/Call
   * @param amount
   * @param PayOutType
   * @param CIA
   */
  public void initiatePayOutShop(String amount, String PayOutType, String CIA) {
    initiatePayOutShop_sub(amount, PayOutType, CIA);
    DRIVER.findElement(ZP_submit).click();
    TestLogger.logInfo("clicked Shop Payout submit button");
    Assert.assertEquals(
        DBReusables.getInstance().getStatusCIABCR(CIA),
        "USED",
        "CIA change request status did  not match");
    TestLogger.logInfo("CIA change request status is USED");
    Assert.assertTrue(
        DRIVER.findElement(SuccessMessage).isDisplayed(), "Shop Payout Message is not displayed");
    if (PayOutType.equalsIgnoreCase("FullPayOut")) {
      Assert.assertEquals(
          DRIVER.findElement(SuccessMessage).getText(),
          "Sie haben erfolgreich die Auszahlung ihres gesamten Anlagebetrags veranlasst. Ihre ZINSPILOT-Partnerbank wird Ihnen den Betrag umgehend entsprechend der Produktbedingungen auf Ihr Referenzkonto auszahlen.",
          "pay out successfull message is not correct");
    } else {
      Assert.assertEquals(
          DRIVER.findElement(SuccessMessage).getText(),
          "Vielen Dank für Ihren Auszahlungsauftrag. Die Auszahlung von "
              + amount
              + " € wird entsprechend der Produktbedingungen auf Ihr Referenzkonto veranlasst.",
          "pay out successfull message is not correct");
    }
    TestLogger.logInfo("Verified Pay-out message on shop");
    TestLogger.logInfo("successfully created Payout from Shop ");
  }

  /*
   * This method creates Investment Change from shop
   * @param SourceTrancheIdentifier
   * @param TargetTrancheIdentifier
   * @param amount
   */
  public void initiateInvestmentChangeShop(
      String SourceTrancheIdentifier, String TargetTrancheIdentifier, String amount)
      throws InterruptedException {
    ShopLoginLogoutPO.getInstance().shopCache();
    DRIVER.findElement(ZP_IC).click();

    DRIVER
        .findElement(
            By.id(
                "btn-change-product-"
                    + DBReusables.getInstance().getTrancheUUID(TargetTrancheIdentifier)))
        .click();
    if (DBReusables.getInstance()
        .validationRequirement(TargetTrancheIdentifier, "SOURCE_OF_FUNDS")
        .equalsIgnoreCase("true")) {
      // select SOF from Shop
      ProductDetailsPO.getInstance().selectingSourceOfFunds1("REGULAR_INCOME");
    }
    if (DBReusables.getInstance()
        .validationRequirement(TargetTrancheIdentifier, "PRODUCTBANK_QUESTIONS_ANSWERED")
        .equalsIgnoreCase("true")) {
      // select QUE from Shop
      ProductDetailsPO.getInstance().selectingQuestionary_CACF();
    }
    DRIVER.findElement(ZP_Amount).sendKeys(amount);
    DRIVER.findElement(ZP_confirm).click();
    if (DBReusables.getInstance()
        .validationRequirement(TargetTrancheIdentifier, "VALID_DRM_CONTRACT")
        .equalsIgnoreCase("true")) {
      // accept DRM from Shop
      DRIVER.findElement(drm_agreement).click();
      // check for ennable of DRM button
      Assert.assertEquals(
          DRIVER.findElement(ProductDetailsPO.getInstance().drm_accept).getAttribute("class"),
          "btn btn-info",
          "DRM button is not enabled");
      // accept DRM Contract
      DRIVER.findElement(drm_accept).click();
    }

    // Success message checking
    Assert.assertTrue(
        DRIVER.findElement(SuccessMessage).isDisplayed(), "Shop Payout Message is not displayed");
    String expected =
        "Wir haben Ihren Auftrag zum Anlagewechsel zum nächstmöglichen Termin vorgemerkt.\n"
            + "\n"
            + "Anlagebetrag: "
            + amount
            + " €\n";
    if (SourceTrancheIdentifier.contains("TG")) {
      expected =
          expected
              + "Auszahlung von: "
              + getProductType(SourceTrancheIdentifier)
              + " "
              + DBReusables.getInstance().getBankName_FromTrancheIdentifier(SourceTrancheIdentifier)
              + "\n";

    } else {
      expected =
          expected
              + "Auszahlung von: "
              + getProductType(SourceTrancheIdentifier)
              + "  "
              + getProductDuration(SourceTrancheIdentifier)
              + " "
              + DBReusables.getInstance().getBankName_FromTrancheIdentifier(SourceTrancheIdentifier)
              + "\n";
    }
    if (TargetTrancheIdentifier.contains("TG")) {
      expected =
          expected
              + "Einzahlung auf: "
              + getProductType(TargetTrancheIdentifier)
              + " "
              + DBReusables.getInstance().getBankName_FromTrancheIdentifier(TargetTrancheIdentifier)
              + " zu "
              + DBReusables.getInstance().getInterestPercentage(TargetTrancheIdentifier)
              + " p.a.\n";

    } else {
      expected =
          expected
              + "Einzahlung auf: "
              + getProductType(TargetTrancheIdentifier)
              + " "
              + DBReusables.getInstance().getBankName_FromTrancheIdentifier(TargetTrancheIdentifier)
              + " "
              + getProductDuration(TargetTrancheIdentifier)
              + " zu "
              + DBReusables.getInstance().getInterestPercentage(TargetTrancheIdentifier)
              + " p.a.\n";
    }
    expected =
        expected
            + "Ausführung zum: "
            + DateTimeFormatter.ofPattern("dd.MM.yyyy")
                .format(
                    LocalDate.parse(
                        (CharSequence)
                            DBReusables.getInstance()
                                .getTrancheStartDate(TargetTrancheIdentifier)));
    Assert.assertEquals(DRIVER.findElement(SuccessMessage).getText(), expected);
    TestLogger.logInfo("Verified IC message on shop");
    TestLogger.logInfo("successfully created IC from Shop ");
  }

  /*
   * This method checks IC text and tool tips on shop
   * @param TargetTrancheIdentifier
   */
  public void validateIcText(String TargetTrancheIdentifier) throws InterruptedException {
    ShopLoginLogoutPO.getInstance().shopCache();
    DRIVER.findElement(ZP_IC).click();
    Assert.assertEquals(
        DRIVER.findElement(icPage1Text1).getText(),
        "Anlagewechsel\n"
            + "Wechseln Sie direkt in ein anderes Anlageangebot und profitieren Sie von einer direkten Wiederanlage!",
        "Text is incorrect on Shop");
    Assert.assertEquals(
        DRIVER.findElement(icPage1Text2).getText(),
        "+ Attraktive Tages- und Festgeldangebote\n" + "+ Wahlweise Teil- oder Gesamtbetrag",
        "Text is incorrect on Shop");
    Assert.assertEquals(
        DRIVER.findElement(icPage1Text3).getText(),
        "Bitte beachten Sie:\n"
            + "Für ausgewählte ZINSPILOT-Produkte ist ein nahtloser Wechsel verfügbar, sofern die beteiligten Banken dies unterstützen. Ist kein gewünschtes Angebot dabei, ist für den Anlagewechsel nur eine Auszahlung der aktuellen Anlage und Neueinzahlung für das gewünschte Angebot möglich.\n"
            + "Voraussetzung für den erfolgreichen Anlagewechsel ist die Erfüllung aller Anlagevoraussetzungen bis drei Geschäftstage vor Anlagestarttermin um 10 Uhr. Informationen zu den Anlagevoraussetzungen finden Sie im Produktinformationsblatt der jeweiligen Bank sowie in den Informationen zu den Anlagevoraussetzungen.\n"
            + "Kann kein Anlagewechsel ausgeführt werden, erfolgt eine Auszahlung auf Ihr bei ZINSPILOT hinterlegtes Referenzkonto. Dies geschieht, wenn Anlagevoraussetzungen fehlen oder es zu etwaigen Verzögerungen bei der Bereitstellung des Geldes durch die abgebende Bank gab. Abgelehnte Wechsel innerhalb einer Anlagebank, die aus einem Tagesgeld/Flexgeld24 erfolgen, verbleiben in der ursprünglichen Anlage.",
        "Text is incorrect on Shop");
    Assert.assertEquals(
        DRIVER.findElement(icToolTip).getAttribute("data-original-title"),
        "<div>+ Wechseln Sie mit dem gesamten Anlagebetrag oder einem Teilbetrag ab 1€. </div><div>+ Mehrere Anlagewechsel in verschiedene Angebote sind möglich. </div><div>+ Sie können den Wechsel bis drei Geschäftstage vor Anlagestarttermin um 10 Uhr über unseren Kundenservice per E-Mail an service@zinspilot.de stornieren.</div>",
        "IC Page1 Tool Tip Text is incorrect on Shop");
    TestLogger.logInfo("successfully validated Text and Tool Tip on Page1 of Shop ");
    DRIVER
        .findElement(
            By.id(
                "btn-change-product-"
                    + DBReusables.getInstance().getTrancheUUID(TargetTrancheIdentifier)))
        .click();
    Assert.assertEquals(
        DRIVER.findElement(icPage2Text).getText(),
        "Anlagewechsel\n"
            + "Wechseln Sie mit dem Gesamt- oder einem Teilbetrag in ein anderes attraktives Produkt und profitieren Sie von direkter Wiederanlage!",
        " is incorrect on Shop");
    Assert.assertEquals(
        DRIVER.findElement(icToolTip).getAttribute("data-original-title"),
        "+ Wechseln Sie mit dem gesamten Anlagebetrag oder einem Teilbetrag ab 1€. <br />\n"
            + "                       + Mehrere Anlagewechsel in verschiedene Angebote sind möglich. <br />\n"
            + "                       + Sie können den Wechsel bis zur Ausführung jederzeit über unseren Kundenservice per E-Mail an service@zinspilot.de stornieren.",
        " is incorrect on Shop");

    TestLogger.logInfo("successfully validated Text and Tool Tip on Page2 of Shop ");
  }

  /*
   * This method checks for pending payout message
   * @param action
   * @param amount
   */
  public void validatePendingPayOutMessage(String action, String amount)
      throws InterruptedException {

    if (action.equalsIgnoreCase("present")) {
      Assert.assertTrue(DRIVER.findElement(PayoutMessage).isDisplayed());
      Assert.assertEquals(
          DRIVER.findElement(PayoutMessage).getText(),
          "Auszahlungen in Höhe von insgesamt "
              + amount
              + " € befinden sich momentan auf dem Transferkonto Ihrer Servicebank und werden Ihrem Referenzkonto "
              + "in Kürze gutgeschrieben. Liegt der Servicebank keine NV-Bescheinigung oder ein Freistellungsauftrag vor oder ist dieser Freistellungsauftrag ausgeschöpft, werden vor Gutschrift die auf Zinserträge anfallenden deutschen Steuern (Kapitalertragsteuer, Solidaritätszuschlag und ggf. Kirchensteuer) durch die Servicebank abgezogen.",
          "pending pay out message is not correct");

    } else {
      ShopLoginLogoutPO.getInstance().shopCache();
      Assert.assertEquals(
          DRIVER
              .findElement(By.xpath("//ul[@class='badges']/following-sibling::div[1]"))
              .getAttribute("class"),
          "form-group",
          "Pending Pay-out message still visible");
    }
    TestLogger.logInfo("Verified Pending PayOut/IC message on shop");
  }

  /*
   * This method cancel payout for TG from shop
   * @param amount
   * @param PayOutType
   * @param CIA
   */
  public void cancelPayOutShop(String amount, String PayOutType, String CIA) {
    initiatePayOutShop_sub(amount, PayOutType, CIA);
    DRIVER.findElement(ZP_cancel).click();

    Assert.assertEquals(
        DBReusables.getInstance().getStatusCIABCR(CIA),
        "ACTIVE",
        "CIA change request status did not match");
    TestLogger.logInfo("Cancelled Payout from Shop successfully");
    TestLogger.logInfo("CIA change request status is Active");
  }

  /*
   * This method sets prolongation type in Shop and validates in shop
   * @param TrancheIdentifier
   * @param ProlongationType
   * @param amount
   */
  public void shopProlongationSettings(
      String TrancheIdentifier, String ProlongationType, String Amount)
      throws InterruptedException, AWTException {
    String pType;

    if (DBReusables.getInstance()
        .getProlongation_status(TrancheIdentifier)
        .equalsIgnoreCase("false")) {
      DBReusables.getInstance().UpdateProlongation_status(TrancheIdentifier, "1");
      ShopLoginLogoutPO.getInstance().shopCache();
    }
    initiateProlongation();
    switch (ProlongationType) {
      case "FullProlongation":
      case "NoPayOut":
        DRIVER.findElement(FullProlongation).click();
        WebUIOperations.getInstance().waitForElementAndClick(DRIVER.findElement(FullProlongation));
        // drag n drop of dialog as its failing in some machines/git pipeline
        WebUIOperations.getInstance()
            .dragAndDrop(
                DRIVER.findElement(By.xpath("//body/section[1]")),
                DRIVER.findElement(zpProductDetails));
        WebUIOperations.getInstance()
            .waitForElementAndClick(DRIVER.findElement(ProlongationSubmit1));
        WebUIOperations.getInstance()
            .waitForElementAndClick(DRIVER.findElement(ProlongationSubmit2));
        waitTillBrowserLoads();
        pType = DRIVER.findElement(prolongationText).getText();
        Assert.assertEquals(
            pType.substring((pType.indexOf("%") + 1), pType.length()),
            "\n" + "Autom. Prolongation",
            "Selected prolongation setting is not dispalying correctly");
        break;
      case "PartialProlongation":
      case "PartialPayOut":
        WebUIOperations.getInstance()
            .waitForElementAndClick(DRIVER.findElement(PartialProlongation));
        WebUIOperations.getInstance().sendKeys(DRIVER.findElement(FG_PayOutAmount), Amount);
        // drag n drop of dialog as its failing in some machines/git pipeline
        WebUIOperations.getInstance()
            .dragAndDrop(
                DRIVER.findElement(By.xpath("//body/section[1]")),
                DRIVER.findElement(zpProductDetails));
        WebUIOperations.getInstance()
            .waitForElementAndClick(DRIVER.findElement(ProlongationSubmit1));
        WebUIOperations.getInstance()
            .waitForElementAndClick(DRIVER.findElement(ProlongationSubmit2));

        waitTillBrowserLoads();
        pType = DRIVER.findElement(prolongationText).getText();
        Assert.assertEquals(
            pType.substring((pType.indexOf("%") + 2), pType.length()),
            "Autom. Prolongation" + "\n" + "Auszahlung: " + Amount + " €",
            "Selected prolongation setting is not dispalying correctly");
        break;
      case "NoProlongation":
      case "FullPayOut":
        // drag n drop of dialog as its failing in some machines/git pipeline
        WebUIOperations.getInstance()
            .dragAndDrop(
                DRIVER.findElement(By.xpath("//body/section[1]")),
                DRIVER.findElement(zpProductDetails));
        WebUIOperations.getInstance().waitForElementAndClick(DRIVER.findElement(NoProlongation));
        WebUIOperations.getInstance()
            .waitForElementAndClick(DRIVER.findElement(ProlongationSubmit1));
        WebUIOperations.getInstance()
            .waitForElementAndClick(DRIVER.findElement(ProlongationSubmit2));
        waitTillBrowserLoads();
        pType = DRIVER.findElement(prolongationText).getText();
        Assert.assertEquals(
            pType.substring((pType.indexOf("%") + 1), pType.length()),
            "\n" + "Keine Prolongation",
            "Selected prolongation setting is not dispalying correctly");
        break;
    }
    TestLogger.logInfo(ProlongationType + " is successfully set in Shop");
    TestLogger.logInfo("validated Prolongation Type in Shop");
  }

  /*
   * This method validates pending or completed bookings in Shop
   * @param num
   * @param expected
   */
  public void validateShopBookings(int num, String expected) {
    List<WebElement> list =
        DRIVER.findElements(
            By.xpath("//div[@class='table-responsive'][" + num + "]/table/tbody/tr"));

    Assert.assertTrue(
        list.stream().filter(e -> e.getText().equalsIgnoreCase(expected)).count() >= 1,
        "missing shop entry: " + expected);
  }

  /*
   * This method validates pending or completed bookings in Shop
   * @param num
   * @param expected
   */
  public void validateNegativeShopBookings(int num, String expected) {
    List<WebElement> list =
        DRIVER.findElements(
            By.xpath("//div[@class='table-responsive'][" + num + "]/table/tbody/tr"));

    Assert.assertFalse(
        list.stream().filter(e -> e.getText().equalsIgnoreCase(expected)).count() >= 1,
        "missing shop entry: " + expected);
  }

  /*
   * This method validates hint for pending bookings in Shop
   * @param expectedText
   */
  public void validateShopHint(String expectedText) {
    DRIVER.findElement(By.xpath("//strong[contains(text(),'* Hinweis:')]")).isDisplayed();
    Assert.assertTrue(DRIVER.findElement(HintHeader).isDisplayed(), "Hint section is missing");
    Assert.assertEquals(
        DRIVER.findElement(HintText).getText(), expectedText, "Hint message is not correct");
    TestLogger.logInfo("Validated Shop pending Bookings Hint");
  }

  /*
   * This method checks for Tranche in Meine Anlagen and calls sub method-ArchiveAndDocuments
   * @param TrancheIdentifier
   * @param CIA
   */
  public void validateClosedTranche(String TrancheIdentifier, String CIA)
      throws InterruptedException {
    validateTranche(TrancheIdentifier, "absent");
    ArchiveAndDocumentsPO.getInstance().validateArchiveAndDocumentsTranche(TrancheIdentifier, CIA);
  }

  /*
   * This method checks for Tranche in Meine Anlagen
   * @param TrancheIdentifier
   * @param CIA
   */
  public void validateTranche(String TrancheIdentifier, String presence)
      throws InterruptedException {
    DRIVER.findElement(ZP_MeineAnlagen).click();
    ShopLoginLogoutPO.getInstance().shopCache();
    if (presence.equalsIgnoreCase("present")) {
      WebUIOperations.getInstance()
          .verifyElementPresence(
              DRIVER.findElements(By.id("details-" + TrancheIdentifier)), "present");
      TestLogger.logInfo(TrancheIdentifier + " is displayed in Meine Anlagen");
    } else {
      WebUIOperations.getInstance()
          .verifyElementPresence(
              DRIVER.findElements(By.id("details-" + TrancheIdentifier)), "absent");
      TestLogger.logInfo(TrancheIdentifier + " is not displayed in Meine Anlagen");
    }
  }

  /*
   * This method validates Pending Payout and Interest Tickets
   * @param customerNumber
   * @param PayOutType
   * @param SourceTrancheIdentifier
   * @param FormatedTotalBalanceAmount
   * @param FormatedInterestAmount
   * @param FormatedPayOutAmount
   * @param TargetTrancheIdentifier
   * @param FormatedProlongationAmount
   */
  public void payOutValidateInprogressTicketBookings(
      String CustomerEmail,
      String PayOutType,
      String SourceTrancheIdentifier,
      String FormatedTotalBalanceAmount,
      String FormatedInterestAmount,
      String FormatedPayOutAmount,
      String TargetTrancheIdentifier,
      String FormatedProlongationAmount)
      throws InterruptedException {
    getInvestmentDetails(SourceTrancheIdentifier, CustomerEmail);
    if (SourceTrancheIdentifier.contains("-FG")
        && (PayOutType.equalsIgnoreCase("PartialPayOut")
            || PayOutType.equalsIgnoreCase(("FullProlongation"))
                && !FormatedTotalBalanceAmount.equalsIgnoreCase(FormatedPayOutAmount))) {
      // Shop validation for old tranche
      TestLogger.logInfo("***shop validation for Source tranche***");

      validateShopBookings(
          2,
          DateTimeFormatter.ofPattern("dd.MM.yyyy")
                  .format(
                      LocalDate.parse(
                          (CharSequence)
                              DBReusables.getInstance().getTrancheEndDate(SourceTrancheIdentifier)))
              + " vorgemerkt Auszahlung -"
              + FormatedInterestAmount);
      validateShopBookings(
          1,
          DBReusables.getInstance().formatDate("dd.MM.yyyy")
              + " "
              + DateTimeFormatter.ofPattern("dd.MM.yyyy")
                  .format(
                      LocalDate.parse(
                          (CharSequence)
                              DBReusables.getInstance().getTrancheEndDate(SourceTrancheIdentifier)))
              + " Prolongation -"
              + FormatedProlongationAmount);
      validateShopBookings(
          1,
          DBReusables.getInstance().formatDate("dd.MM.yyyy")
              + " "
              + DateTimeFormatter.ofPattern("dd.MM.yyyy")
                  .format(
                      LocalDate.parse(
                          (CharSequence)
                              DBReusables.getInstance().getTrancheEndDate(SourceTrancheIdentifier)))
              + " Zinsbuchung "
              + FormatedInterestAmount);
      if (!PayOutType.equalsIgnoreCase("FullProlongation")) {
        validateShopBookings(
            2,
            DateTimeFormatter.ofPattern("dd.MM.yyyy")
                    .format(
                        LocalDate.parse(
                            (CharSequence)
                                DBReusables.getInstance()
                                    .getTrancheEndDate(SourceTrancheIdentifier)))
                + " vorgemerkt Auszahlung -"
                + FormatedPayOutAmount);
      }
      TestLogger.logInfo("Shop UI Validated post Interest Booking and Prolongation");
      // Shop validation for new tranche
      TestLogger.logInfo("***shop validation for Target tranche***");
      getInvestmentDetails(TargetTrancheIdentifier, CustomerEmail);
      validateShopBookings(
          1,
          DBReusables.getInstance().formatDate("dd.MM.yyyy")
              + " "
              + DateTimeFormatter.ofPattern("dd.MM.yyyy")
                  .format(
                      LocalDate.parse(
                          (CharSequence)
                              DBReusables.getInstance().getTrancheEndDate(SourceTrancheIdentifier)))
              + " Prolongation "
              + FormatedProlongationAmount);

    } else if (SourceTrancheIdentifier.contains("-FG")
        && (PayOutType.equalsIgnoreCase("FullPayOut")
            || FormatedTotalBalanceAmount.equalsIgnoreCase(FormatedPayOutAmount))) {
      validateShopBookings(
          2,
          DateTimeFormatter.ofPattern("dd.MM.yyyy")
                  .format(
                      LocalDate.parse(
                          (CharSequence)
                              DBReusables.getInstance().getTrancheEndDate(SourceTrancheIdentifier)))
              + " vorgemerkt Auszahlung -"
              + FormatedPayOutAmount);
      validateShopBookings(
          2,
          DateTimeFormatter.ofPattern("dd.MM.yyyy")
                  .format(
                      LocalDate.parse(
                          (CharSequence)
                              DBReusables.getInstance().getTrancheEndDate(SourceTrancheIdentifier)))
              + " vorgemerkt Auszahlung -"
              + FormatedInterestAmount);
      validateShopBookings(
          1,
          DBReusables.getInstance().formatDate("dd.MM.yyyy")
              + " "
              + DateTimeFormatter.ofPattern("dd.MM.yyyy")
                  .format(
                      LocalDate.parse(
                          (CharSequence)
                              DBReusables.getInstance().getTrancheEndDate(SourceTrancheIdentifier)))
              + " Zinsbuchung "
              + FormatedInterestAmount);
      TestLogger.logInfo("Shop UI Validated post Interest Booking and PayOut");
    } else {
      validateShopBookings(
          2,
          DateTimeFormatter.ofPattern("dd.MM.yyyy")
                  .format(
                      LocalDate.parse(
                          (CharSequence)
                              DBReusables.getInstance()
                                  .getTrancheStartDate(SourceTrancheIdentifier)))
              + " vorgemerkt Auszahlung -"
              + FormatedPayOutAmount);
      validateShopBookings(
          2,
          DateTimeFormatter.ofPattern("dd.MM.yyyy")
                  .format(
                      LocalDate.parse(
                          (CharSequence)
                              DBReusables.getInstance()
                                  .getTrancheStartDate(SourceTrancheIdentifier)))
              + " vorgemerkt Auszahlung -"
              + FormatedInterestAmount);
      validateShopBookings(
          1,
          DBReusables.getInstance().formatDate("dd.MM.yyyy")
              + " "
              + DateTimeFormatter.ofPattern("dd.MM.yyyy")
                  .format(
                      LocalDate.parse(
                          (CharSequence)
                              DBReusables.getInstance()
                                  .getTrancheStartDate(SourceTrancheIdentifier)))
              + " Zinsbuchung "
              + FormatedInterestAmount);
      TestLogger.logInfo("Shop UI Validated post Interest Booking and PayOut");
    }
  }

  /*
   * This method validates Pending Payout and Interest Tickets for Investment Change
   * @param methodName
   * @param customerNumber
   * @param IcType
   * @param SourceTrancheIdentifier
   * @param FormatedTotalBalanceAmount
   * @param FormatedInterestAmount
   * @param FormatedIcAmount
   * @param ProlongationTrancheIdentifier
   * @param FormatedProlongationAmount
   */
  public void icValidateInprogressTicketBookings(
      String methodName,
      String CustomerEmail,
      String IcType,
      String SourceTrancheIdentifier,
      String FormatedTotalBalanceAmount,
      String FormatedInterestAmount,
      String FormatedIcAmount,
      String ProlongationTrancheIdentifier,
      String FormatedProlongationAmount,
      String TargetTrancheIdentifier)
      throws InterruptedException {
    getInvestmentDetails(SourceTrancheIdentifier, CustomerEmail);
    if (TargetTrancheIdentifier.contains("TG")) {
      validateShopBookings(
          2,
          DateTimeFormatter.ofPattern("dd.MM.yyyy")
                  .format(
                      LocalDate.parse(
                          (CharSequence)
                              DBReusables.getInstance()
                                  .getTrancheStartDate(TargetTrancheIdentifier)))
              + " vorgemerkt Anlagewechsel zum "
              + getProductType(TargetTrancheIdentifier)
              + " "
              + DBReusables.getInstance().getBankName_FromTrancheIdentifier(TargetTrancheIdentifier)
              + " zu "
              + DBReusables.getInstance().getInterestPercentage(TargetTrancheIdentifier)
              + " p.a. -"
              + FormatedIcAmount);

    } else {
      validateShopBookings(
          2,
          DateTimeFormatter.ofPattern("dd.MM.yyyy")
                  .format(
                      LocalDate.parse(
                          (CharSequence)
                              DBReusables.getInstance()
                                  .getTrancheStartDate(TargetTrancheIdentifier)))
              + " vorgemerkt Anlagewechsel zum "
              + getProductType(TargetTrancheIdentifier)
              + " "
              + DBReusables.getInstance().getBankName_FromTrancheIdentifier(TargetTrancheIdentifier)
              + " "
              + getProductDuration(TargetTrancheIdentifier)
              + " zu "
              + DBReusables.getInstance().getInterestPercentage(TargetTrancheIdentifier)
              + " p.a. -"
              + FormatedIcAmount);
    }
    validateShopBookings(
        2,
        DateTimeFormatter.ofPattern("dd.MM.yyyy")
                .format(
                    LocalDate.parse(
                        (CharSequence)
                            DBReusables.getInstance().getTrancheStartDate(TargetTrancheIdentifier)))
            + " vorgemerkt Auszahlung -"
            + FormatedInterestAmount);
    validateShopBookings(
        1,
        DBReusables.getInstance().formatDate("dd.MM.yyyy")
            + " "
            + DateTimeFormatter.ofPattern("dd.MM.yyyy")
                .format(
                    LocalDate.parse(
                        (CharSequence)
                            DBReusables.getInstance().getTrancheStartDate(TargetTrancheIdentifier)))
            + " Zinsbuchung "
            + FormatedInterestAmount);

    if (SourceTrancheIdentifier.contains("-FG")
        && IcType.equalsIgnoreCase("PartialIc")
        && !FormatedTotalBalanceAmount.equalsIgnoreCase(FormatedIcAmount)) {
      // Shop validation for old tranche
      TestLogger.logInfo("***shop validation for Source tranche***");

      validateShopBookings(
          1,
          DBReusables.getInstance().formatDate("dd.MM.yyyy")
              + " "
              + DateTimeFormatter.ofPattern("dd.MM.yyyy")
                  .format(
                      LocalDate.parse(
                          (CharSequence)
                              DBReusables.getInstance().getTrancheEndDate(SourceTrancheIdentifier)))
              + " Prolongation -"
              + FormatedProlongationAmount);
      if (methodName.contains("DefaultPayOut")) {
        validateShopBookings(
            2,
            DateTimeFormatter.ofPattern("dd.MM.yyyy")
                    .format(
                        LocalDate.parse(
                            (CharSequence)
                                DBReusables.getInstance()
                                    .getTrancheEndDate(SourceTrancheIdentifier)))
                + " vorgemerkt Auszahlung -"
                + "FormatedPayOutAmount");
      }
      // Shop validation for new tranche
      TestLogger.logInfo("***shop validation for Prolongation tranche***");
      getInvestmentDetails(ProlongationTrancheIdentifier, CustomerEmail);
      validateShopBookings(
          1,
          DBReusables.getInstance().formatDate("dd.MM.yyyy")
              + " "
              + DateTimeFormatter.ofPattern("dd.MM.yyyy")
                  .format(
                      LocalDate.parse(
                          (CharSequence)
                              DBReusables.getInstance().getTrancheEndDate(SourceTrancheIdentifier)))
              + " Prolongation "
              + FormatedProlongationAmount);
    }
    TestLogger.logInfo("Validated Shop UI Inprogress Bookings post Interest Booking");
  }

  /*
   * This method validates Pending Payout and Interest Tickets
   * @param CIA
   * @param PayOutType
   * @param SourceTrancheIdentifier
   * @param FormatedTotalBalanceAmount
   * @param FormatedTotalAmount
   * @param FormatedPayOutAmount
   */
  public void payOutValidatePost_t2c(
      String CIA,
      String PayOutType,
      String SourceTrancheIdentifier,
      String FormatedTotalBalanceAmount,
      String FormatedTotalAmount,
      String FormatedPayOutAmount)
      throws InterruptedException {
    if ((SourceTrancheIdentifier.contains("-TG")
            && (PayOutType.equalsIgnoreCase("PartialPayOut")
                || PayOutType.equalsIgnoreCase("PartialIC")
                || !FormatedTotalBalanceAmount.equalsIgnoreCase(FormatedPayOutAmount)))
        || SourceTrancheIdentifier.equalsIgnoreCase("AGRLFR22XXX-TG")) {
      validatePendingPayOutMessage("absent", FormatedTotalAmount);
    } else if (SourceTrancheIdentifier.contains("-FG")) {
      // CIA closed validation
      DBReusables.getInstance().getCIA_status(CIA, "true");
      // Shop validation for old tranche
      validateClosedTranche(SourceTrancheIdentifier, CIA);
    }
  }

  /*
   * This method validates Pending Payout and Interest Tickets
   * @param CustomerEmail
   * @param CIA
   * @param PayOutType
   * @param SourceTrancheIdentifier
   * @param FormatedTotalBalanceAmount
   * @param FormatedTotalAmount
   * @param FormatedPayOutAmount
   * @param FormatedInterestAmount
   */
  public void payOutValidatePost_i2t(
      String CustomerEmail,
      String CIA,
      String PayOutType,
      String SourceTrancheIdentifier,
      String FormatedTotalBalanceAmount,
      String FormatedTotalAmount,
      String FormatedPayOutAmount,
      String FormatedInterestAmount)
      throws InterruptedException {

    if (SourceTrancheIdentifier.contains("-TG")) {
      // validate for closing investment ticket
      if ((FormatedTotalBalanceAmount.equalsIgnoreCase(FormatedPayOutAmount)
              || PayOutType.equalsIgnoreCase("FullPayOut"))
          && !SourceTrancheIdentifier.equalsIgnoreCase("AGRLFR22XXX-TG")) {
        DBReusables.getInstance().ValidateCIT(CIA, "EXECUTED");
        // CIA closed validation
        DBReusables.getInstance().getCIA_status(CIA, "true");
        validateClosedTranche(SourceTrancheIdentifier, CIA);
      } else {
        ShopLoginLogoutPO.getInstance().shopCache();
        validatePendingPayOutMessage("present", FormatedTotalAmount);
        validateShopBookings(
            1,
            DBReusables.getInstance().formatDate("dd.MM.yyyy")
                + " "
                + DBReusables.getInstance().formatDate("dd.MM.yyyy")
                + " Auszahlung -"
                + FormatedPayOutAmount);
        validateShopBookings(
            1,
            DBReusables.getInstance().formatDate("dd.MM.yyyy")
                + " "
                + DBReusables.getInstance().formatDate("dd.MM.yyyy")
                + " Auszahlung (Zins) ohne deutschen Steuerabzug -"
                + FormatedInterestAmount);
      }
    } else {
      // Shop validation for old tranche
      TestLogger.logInfo("***shop validation for Source tranche***");
      getInvestmentDetails(SourceTrancheIdentifier, CustomerEmail);
      validatePendingPayOutMessage("present", FormatedTotalAmount);
      validateShopBookings(
          1,
          DBReusables.getInstance().formatDate("dd.MM.yyyy")
              + " "
              + DBReusables.getInstance().formatDate("dd.MM.yyyy")
              + " Auszahlung (Zins) ohne deutschen Steuerabzug -"
              + FormatedInterestAmount);
      if (!PayOutType.equalsIgnoreCase("FullProlongation")) {
        validateShopBookings(
            1,
            DBReusables.getInstance().formatDate("dd.MM.yyyy")
                + " "
                + DBReusables.getInstance().formatDate("dd.MM.yyyy")
                + " Auszahlung -"
                + FormatedPayOutAmount);
      }
    }
    TestLogger.logInfo("Shop Completed Transactions validated successfully");
  }

  /*
   * This method validates Pending Payout and Interest Tickets for Investment Change
   * @param CustomerEmail
   * @param CIA
   * @param PayOutType
   * @param SourceTrancheIdentifier
   * @param FormatedTotalBalanceAmount
   * @param FormatedTotalAmount
   * @param FormatedPayOutAmount
   * @param FormatedInterestAmount
   */
  public void icValidatePost_i2t(
      String methodName,
      String CustomerEmail,
      String SourceTrancheIdentifier,
      String FormatedIcAmount,
      String FormatedInterestAmount)
      throws InterruptedException {
    getInvestmentDetails(SourceTrancheIdentifier, CustomerEmail);
    validatePendingPayOutMessage("present", FormatedInterestAmount);
    if (methodName.contains("External")) {
      validateShopBookings(
          1,
          DBReusables.getInstance().formatDate("dd.MM.yyyy")
              + " "
              + DBReusables.getInstance().formatDate("dd.MM.yyyy")
              + " Auszahlung -"
              + FormatedIcAmount);
    }
    validateShopBookings(
        1,
        DBReusables.getInstance().formatDate("dd.MM.yyyy")
            + " "
            + DBReusables.getInstance().formatDate("dd.MM.yyyy")
            + " Auszahlung (Zins) ohne deutschen Steuerabzug -"
            + FormatedInterestAmount);

    TestLogger.logInfo("Shop Completed Transactions validated successfully");
  }

  /*
  This method gets Product Type
  *param TrancheIdentifier
   */
  public String getProductType(String TrancheIdentifier) {
    String maturityCode =
        DBReusables.getInstance()
            .getMaturityCode(
                DBReusables.getInstance().getPayInCodeFromTrancheIdentifier(TrancheIdentifier));
    if (maturityCode.contains("CALL_ALIKE")) {
      return "Flexgeld24";
    } else {
      return "Festgeld";
    }
  }

  /*
  This method gets Product Durations in Months
  *param TrancheIdentifier
   */
  public String getProductDuration(String TrancheIdentifier) {
    String months =
        (DBReusables.getInstance().getPayInCodeFromTrancheIdentifier(TrancheIdentifier))
            .replaceAll("[^0-9]", "");
    if (months.equalsIgnoreCase("1")) {
      return months + " Monat";
    } else {
      return months + " Monate";
    }
  }

  /*
  This method verifies the payout button status
  *param TrancheIdentifier
   */
  public void verifyDisabledPayOutButton(String CustomerEmail, String TrancheIdentifier) {

    TestLogger.logMsg("Step-2: Click on Meine Analgen link");
    WebUIOperations.getInstance()
        .waitForElementAndClick(DRIVER.findElement(MeineAnlagenPO.getInstance().ZP_MeineAnlagen));

    TestLogger.logMsg("Step-3: Click on Tranche to see Bookings Page");
    MeineAnlagenPO.getInstance().verifyZPProductDetails(TrancheIdentifier);
    String isEnabled =
        DRIVER.findElement(MeineAnlagenPO.getInstance().ZP_PayOut).getAttribute("class");

    TestLogger.logInfo("Step-4: Validate if Payout button is disabled or not");
    Assert.assertTrue(
        isEnabled.contains("disabled"), "Payout button is Disabled, but found enabled");
  }
}
