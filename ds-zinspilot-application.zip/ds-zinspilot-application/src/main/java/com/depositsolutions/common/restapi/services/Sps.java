package com.depositsolutions.common.restapi.services;

import static io.restassured.RestAssured.given;

import com.depositsolutions.common.restapi.helpers.Endpoints;
import com.depositsolutions.common.utils.ConfigManager;
import com.depositsolutions.common.utils.TestLogger;
import io.restassured.RestAssured;

public class Sps {
  public static Sps singleInstance = null;
  private String spsUrl = ConfigManager.getInstance().getString("spsUrl");

  public static Sps getInstance() {
    if (singleInstance == null) {
      singleInstance = new Sps();
    }
    return singleInstance;
  }

  /*
   * This method imports bankStatement from sutor into sps
   */
  public void importBankstatements() {

    RestAssured.baseURI = spsUrl;
    given()
        .header("Content-Type", "application/json")
        .when()
        .post(Endpoints.importBankstatements_sps)
        .then()
        .log()
        .ifError()
        .assertThat()
        .statusCode(200);
    TestLogger.logInfo("API: SPS Bank Statement Import is successful");
  }

  /*
   * This method imports PayOut into sps
   */
  public void importPayout() {
    RestAssured.baseURI = spsUrl;

    given()
        .header("Content-Type", "application/json")
        .when()
        .post(Endpoints.importPayout)
        .then()
        .log()
        .ifError()
        .assertThat()
        .statusCode(200);
    TestLogger.logInfo("API: Payout import is successful");
  }
}
