USE `comonea_b2c`;

-- For `b2c_customer`
LOCK TABLES `b2c_customer` WRITE;
/*!40000 ALTER TABLE `b2c_customer` DISABLE KEYS */;
INSERT INTO `b2c_customer` VALUES (470,'2015-01-16 09:20:38','2015-11-01 08:07:35','11158126','FULLY_REGISTERED','11158126@comoneto.com','fffHannes','fffRyjikh','NONE','MALE','$2a$12$sQKljQ4OLwf2YvB3QXy90Ok5eedQptcp6Sc6zlppsiMz.tL.hMNLu','UNRESTRICTED','eab38837-d71e-4f9f-9e69-6c207a5dc2f1',0,1,0);
/*!40000 ALTER TABLE `b2c_customer` ENABLE KEYS */;
UNLOCK TABLES;

-- For `b2c_customer_service_bank_affiliation`
LOCK TABLES `b2c_customer_service_bank_affiliation` WRITE;
/*!40000 ALTER TABLE `b2c_customer_service_bank_affiliation` DISABLE KEYS */;
INSERT INTO `b2c_customer_service_bank_affiliation` VALUES (379,'2015-04-30 17:58:56','2015-05-06 08:27:03',NULL,'2015-04-30','OWNERSHIP_VALIDATED','0c5b791d-b4f7-4032-b37a-88af994f35bf',470,5,'2015-05-06 08:27:03',0);
/*!40000 ALTER TABLE `b2c_customer_service_bank_affiliation` ENABLE KEYS */;
UNLOCK TABLES;

-- For `b2c_depot_bank_account`
LOCK TABLES `b2c_depot_bank_account` WRITE;
/*!40000 ALTER TABLE `b2c_depot_bank_account` DISABLE KEYS */;
INSERT INTO `b2c_depot_bank_account` VALUES (384,'2015-04-30 17:58:56','2016-05-25 15:57:47','fffAlessandro von Pinnock','DE81202308006564946146','5e6959c6-5ce3-4871-ad4b-1f519a67ff6d',5,'EUR');
/*!40000 ALTER TABLE `b2c_depot_bank_account` ENABLE KEYS */;
UNLOCK TABLES;

-- For `b2c_customer_depot`
LOCK TABLES `b2c_customer_depot` WRITE;
/*!40000 ALTER TABLE `b2c_customer_depot` DISABLE KEYS */;
INSERT INTO `b2c_customer_depot` VALUES (371,'2015-04-30 17:58:56','2015-04-30 17:58:56',1,'43cc1797-bced-441e-b0a2-351ac662d95d',384,379);
/*!40000 ALTER TABLE `b2c_customer_depot` ENABLE KEYS */;
UNLOCK TABLES;


-- For `b2c_customer_transit_account`
LOCK TABLES `b2c_customer_transit_account` WRITE;
/*!40000 ALTER TABLE `b2c_customer_transit_account` DISABLE KEYS */;
INSERT INTO `b2c_customer_transit_account` VALUES (219,'2015-05-06 08:27:02',NULL,'f602b680-b42f-4086-a33f-8c070fe1d9d4',371,3,'EUR');
/*!40000 ALTER TABLE `b2c_customer_transit_account` ENABLE KEYS */;
UNLOCK TABLES;

-- For `b2c_unique_trustor`
LOCK TABLES `b2c_unique_trustor` WRITE;
/*!40000 ALTER TABLE `b2c_unique_trustor` DISABLE KEYS */;
INSERT INTO `b2c_unique_trustor` VALUES ('3','2015-01-16 09:20:38',NULL,'11158126',NULL);
/*!40000 ALTER TABLE `b2c_unique_trustor` ENABLE KEYS */;

-- For `b2c_trustor`
LOCK TABLES `b2c_trustor` WRITE;
/*!40000 ALTER TABLE `b2c_trustor` DISABLE KEYS */;
INSERT INTO `b2c_trustor` VALUES ('365','379','2015-04-30 17:58:56','2020-08-12 11:34:49','11158126',1,'3','1');
/*!40000 ALTER TABLE `b2c_trustor` ENABLE KEYS */;

-- For `b2c_trustor_service_bank_data`
LOCK TABLES `b2c_trustor_service_bank_data` WRITE;
/*!40000 ALTER TABLE `b2c_trustor_service_bank_data` DISABLE KEYS */;
INSERT INTO `b2c_trustor_service_bank_data` VALUES ('365','2015-04-30 17:58:56','2021-01-26 11:37:03','365',NULL,NULL,'Allensteiner Str.','30a','55151','Filipowskiburg','DE','fffJolie','fffStoutjesdijk','Zoe','NONE','MALE','DE','+41-143-6343974','false','1971-12-08','Dennydorf','2782708303','DE-RP','fffHausfrau','Wirtschaftlich unselbständige Privatpersonen','90208061342','97A','DE','222',1,'SINGLE','NONE','VJ4S21ATI','Klein Melanie, TH',NULL,NULL,NULL,'1561200','Holzer Weg','736','65328','Groß Pascalberg','Nigeria','0',NULL,'','A',NULL,NULL,'','','A - A   - Aktiv');
/*!40000 ALTER TABLE `b2c_trustor_service_bank_data` ENABLE KEYS */;

-- For `b2c_trustor_country_of_birth_override`
LOCK TABLES `b2c_trustor_country_of_birth_override` WRITE;
/*!40000 ALTER TABLE `b2c_trustor_country_of_birth_override` DISABLE KEYS */;
INSERT INTO `b2c_trustor_country_of_birth_override` VALUES ('404','2016-03-04 02:31:34',NULL,'365','DE');
/*!40000 ALTER TABLE `b2c_trustor_country_of_birth_override` ENABLE KEYS */;

-- For `b2c_trustor_country_of_birth_override_audit_record`
LOCK TABLES `b2c_trustor_country_of_birth_override_audit_record` WRITE;
/*!40000 ALTER TABLE `b2c_trustor_country_of_birth_override_audit_record` DISABLE KEYS */;
INSERT INTO `b2c_trustor_country_of_birth_override_audit_record` VALUES ('365','2016-03-04 02:31:34','2016-03-04 02:31:35','INITIAL_CREATON_EMPTY_RECORD',NULL,'404',NULL,NULL);
/*!40000 ALTER TABLE `b2c_trustor_country_of_birth_override_audit_record` ENABLE KEYS */;

-- For `b2c_trustor_phone_number_override`
LOCK TABLES `b2c_trustor_phone_number_override` WRITE;
/*!40000 ALTER TABLE `b2c_trustor_phone_number_override` DISABLE KEYS */;
INSERT INTO `b2c_trustor_phone_number_override` VALUES ('651','2016-03-04 02:28:53',NULL,'365',NULL);
/*!40000 ALTER TABLE `b2c_trustor_phone_number_override` ENABLE KEYS */;

-- For `b2c_trustor_phone_number_override_audit_record`
LOCK TABLES `b2c_trustor_phone_number_override_audit_record` WRITE;
/*!40000 ALTER TABLE `b2c_trustor_phone_number_override_audit_record` DISABLE KEYS */;
INSERT INTO `b2c_trustor_phone_number_override_audit_record` VALUES ('365','2021-06-03 17:16:12',NULL,'INITIAL_CREATON_EMPTY_RECORD',NULL,'651',NULL,NULL);
/*!40000 ALTER TABLE `b2c_trustor_phone_number_override_audit_record` ENABLE KEYS */;

-- For `b2c_customer_state_history`
LOCK TABLES `b2c_customer_state_history` WRITE;
/*!40000 ALTER TABLE `b2c_customer_state_history` DISABLE KEYS */;
INSERT INTO `b2c_customer_state_history` VALUES ('1','2021-06-03 17:15:20',NULL,'REGISTERED','470');
INSERT INTO `b2c_customer_state_history` VALUES ('2','2021-06-03 17:15:40',NULL,'ACTIVATED','470');
INSERT INTO `b2c_customer_state_history` VALUES ('3','2021-06-03 17:16:13',NULL,'FULLY_REGISTERED','470');
/*!40000 ALTER TABLE `b2c_customer_state_history` ENABLE KEYS */;

-- For `b2c_customer_activation_code`
LOCK TABLES `b2c_customer_activation_code` WRITE;
/*!40000 ALTER TABLE `b2c_customer_activation_code` DISABLE KEYS */;
INSERT INTO `b2c_customer_activation_code` VALUES ('1','2021-06-03 17:15:20',NULL,'327946','470');
/*!40000 ALTER TABLE `b2c_customer_activation_code` ENABLE KEYS */;

-- For `b2c_customer_accountstatus_history`
LOCK TABLES `b2c_customer_accountstatus_history` WRITE;
/*!40000 ALTER TABLE `b2c_customer_accountstatus_history` DISABLE KEYS */;
INSERT INTO `b2c_customer_accountstatus_history` VALUES ('707452','2021-05-17 05:44:58',NULL,'470','ACTIVE','System-Login','Der Account wurde aktiviert');
/*!40000 ALTER TABLE `b2c_customer_accountstatus_history` ENABLE KEYS */;

-- For `b2c_customer_interest_account`
LOCK TABLES `b2c_customer_interest_account` WRITE;
/*!40000 ALTER TABLE `b2c_customer_interest_account` DISABLE KEYS */;
INSERT INTO `b2c_customer_interest_account` VALUES (1,'2021-05-20 09:18:03',NULL,'3a9f0aec-9603-45f1-9a35-cd897e7a48d8',219,371,7544,0,0,NULL,NULL,NULL,'EUR',NULL,NULL);
/*!40000 ALTER TABLE `b2c_customer_interest_account` ENABLE KEYS */;
UNLOCK TABLES;

-- For `b2c_customer_interest_account_booking`
LOCK TABLES `b2c_customer_interest_account_booking` WRITE;
/*!40000 ALTER TABLE `b2c_customer_interest_account_booking` DISABLE KEYS */;
INSERT INTO `b2c_customer_interest_account_booking` VALUES (1,'2021-08-16 05:09:37',NULL,NULL,'Einzahlung fuer Produkt CreditPlusTG','TRANSIT_TO_INTEREST','5d140842-f81e-461d-b7ad-e77eac80dc91','EUR','10000.00','2021-10-15',1,NULL);
/*!40000 ALTER TABLE `b2c_customer_interest_account_booking` ENABLE KEYS */;
UNLOCK TABLES;

-- For `b2c_customer_transit_account_booking`
LOCK TABLES `b2c_customer_transit_account_booking` WRITE;
/*!40000 ALTER TABLE `b2c_customer_transit_account_booking` DISABLE KEYS */;
INSERT INTO `b2c_customer_transit_account_booking` VALUES (1,'2021-10-10 04:50:53',NULL,NULL,'CreditPlusTG','PAY_IN','b7047fe5-d915-4398-8035-54e255afab63','EUR','10000.00','2021-08-16',219,NULL);
INSERT INTO `b2c_customer_transit_account_booking` VALUES (2,'2021-10-15 04:51:08',NULL,NULL,'Einzahlung fuer Produkt CreditPlusTG','TRANSIT_TO_INTEREST','79917703-7862-41c6-b8ee-23ac764cbb96','EUR','-10000.00','2021-10-15',219,NULL);
/*!40000 ALTER TABLE `b2c_customer_transit_account_booking` ENABLE KEYS */;
UNLOCK TABLES;

-- For `b2c_service_bank_transit_account_booking`
LOCK TABLES `b2c_service_bank_transit_account_booking` WRITE;
/*!40000 ALTER TABLE `b2c_service_bank_transit_account_booking` DISABLE KEYS */;
INSERT INTO `b2c_service_bank_transit_account_booking` VALUES (1,'2021-10-10 04:50:53',NULL,NULL,'CreditPlusTG','PAY_IN','b7047fe5-d915-4398-8035-54e255afab63','EUR','10000.00','2021-08-16',NULL,NULL,3);
INSERT INTO `b2c_service_bank_transit_account_booking` VALUES (2,'2021-10-15 04:51:08',NULL,NULL,'Einzahlung fuer Produkt CreditPlusTG','TRANSIT_TO_INTEREST','79917703-7862-41c6-b8ee-23ac764cbb96','EUR','-10000.00','2021-10-15',NULL,NULL,3);
/*!40000 ALTER TABLE `b2c_service_bank_transit_account_booking` ENABLE KEYS */;
UNLOCK TABLES;

-- For `b2c_product_bank_interest_account_booking`
LOCK TABLES `b2c_product_bank_interest_account_booking` WRITE;
/*!40000 ALTER TABLE `b2c_product_bank_interest_account_booking` DISABLE KEYS */;
INSERT INTO `b2c_product_bank_interest_account_booking` VALUES (1,'2021-10-15 04:51:08',NULL,NULL,'Einzahlung fuer Produkt CreditPlusTG','TRANSIT_TO_INTEREST','a3ca5bb6-85dc-4ca3-b69e-b2d2bd489bd1','EUR','10000.00','2021-10-15',7544,NULL);
/*!40000 ALTER TABLE `b2c_product_bank_interest_account_booking` ENABLE KEYS */;
UNLOCK TABLES;
