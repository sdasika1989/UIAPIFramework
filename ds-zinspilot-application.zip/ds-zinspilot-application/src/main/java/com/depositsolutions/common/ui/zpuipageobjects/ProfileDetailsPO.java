package com.depositsolutions.common.ui.zpuipageobjects;

import com.depositsolutions.common.ui.helpers.BaseTestClassUI;
import com.depositsolutions.common.ui.helpers.WebUIOperations;
import com.depositsolutions.common.utils.TestLogger;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import org.openqa.selenium.By;
import org.testng.Assert;

public class ProfileDetailsPO extends BaseTestClassUI {
  public static ProfileDetailsPO singleInstance = null;

  public By myRegistrationHeaderText = By.tagName("h2");
  public By ausweisdaten = By.id("ausweisdaten");
  public By Hinzufügen = By.xpath("//button[contains(text(),'Hinzufügen')]");
  public By idCardDataBean = By.id("idCardDataBean");
  public By idCardType = By.id("idCardType");
  public By idCardNumber = By.id("idCardNumber");
  public By idCardExpiryDate = By.id("idCardExpiryDate");
  public By idCardIssueDate = By.id("idCardIssueDate");
  public By authority = By.id("authority");
  public By saveButton = By.id("change-customer-details-submit-btn");
  public By successMessage = By.xpath("//div[contains(@class,'msg msg-success')]");
  public By savedData =
      By.xpath("//div/label[text()='Ausweisnummer']/following-sibling::div/input");
  public By errorMessageExpiryDate = By.id("idCardExpiryDate.errors");
  public By errorMessageIssueDate = By.id("idCardIssueDate.errors");
  public By passwordForm = By.id("passwordChange");
  public By oldPassword = By.id("oldPassword");
  public By newPassword = By.id("newPassword.password");
  public By savePassword =
      By.xpath("//form[@id='passwordChange']//button[contains(text(),'Speichern')]");
  public By passwordSaveMessage = By.id("password-changed-successful");
  public By anredeLabel = By.xpath("//label[contains(text(),'Anrede *')]");
  public By titelLabel = By.xpath("//label[contains(text(),'Titel')]");
  public By vornameLabel = By.xpath("//label[contains(text(),'Vorname')]");
  public By NachnameLabel = By.xpath("//label[contains(text(),'Nachname')]");
  public By pflichtfelderLabel = By.xpath("//div[contains(text(),'* Pflichtfelder')]");
  public By emailLabel = By.xpath("//label[contains(text(),'E-Mail')]");
  public By KundennummerLabel = By.xpath("//label[contains(text(),'Kundennummer')]");
  public By titel = By.id("name.title");
  public By saveCustomerDetails = By.id("change-customer-details-submit-btn");
  public static By SUCCESS_MESSAGE_FOR_CUSTOMER_DETAIL_CHANGE =
      By.id("message-data-changed-successful");
  public By phoneNumberLabel = By.xpath("//div/label[text()='Rufnummer']");
  public By phoneNumber = By.xpath("//div/label[text()='Rufnummer']/following-sibling::div/input");
  public By ZPPartnerBankLabel = By.xpath("//div/label[text()='ZINSPILOT Partnerbank']");
  public By ZPPartnerBank =
      By.xpath("//div/label[text()='ZINSPILOT Partnerbank']/following-sibling::div/input");
  public By KontoinhaberLabel = By.xpath("//div/label[text()='Kontoinhaber']");
  public By Kontoinhaber =
      By.xpath("//div/label[text()='Kontoinhaber']/following-sibling::div/input");
  public By IBANZINSPILOT_KontoLabel = By.xpath("//div/label[text()='IBAN ZINSPILOT-Konto']");
  public By IBANZINSPILOT_Konto =
      By.xpath("//div/label[text()='IBAN ZINSPILOT-Konto']/following-sibling::div/input");
  public By StraßeLabel = By.xpath("//div/label[text()='Straße, Hausnummer']");
  public By Straße =
      By.xpath("//div/label[text()='Straße, Hausnummer']/following-sibling::div/input");
  public By postalCodeLabel = By.xpath("//div/label[text()='Postleitzahl, Ort']");
  public By postalCode =
      By.xpath("//div/label[text()='Postleitzahl, Ort']/following-sibling::div/input");
  public By LandLabel = By.xpath("//div/label[text()='Land']");
  public By Land = By.xpath("//div/label[text()='Land']/following-sibling::div/input");
  public By IBANLabel = By.xpath("//div/label[text()='IBAN']");
  public By IBANNumber = By.xpath("//div/label[text()='IBAN']/following-sibling::div/input");
  public By BICLabel = By.xpath("//div/label[text()='BIC']");
  public By BIC = By.xpath("//div/label[text()='BIC']/following-sibling::div/input");
  public By ZumPostidentButton = By.xpath("//button[contains(text(),'Zum Postident Portal')]");

  public By referralCodeInput = By.xpath("//div[contains(@class,'form-group')]/input");
  public By referralCodeLink =
      By.xpath("//div[contains(@class,'form-group')]/input[contains(@value,'werbepraemie')]");
  public By actionPageLink = By.linkText("Aktionsseite");
  public By copyReferralLink =
      By.xpath(
          "//div[contains(@class,'referral-code-copy-button-wrapper')]/button[contains(@data-referral-link,'werbepraemie')]");
  public By saveTitelButton =
      By.xpath("//form[@id='customer']//button[contains(text(),'Speichern')]");

  public By resetPasswordLink = By.linkText("Sie haben Ihr Passwort vergessen?");
  public By emailAddress = By.id("emailAddress");
  public By submitEmail = By.xpath("//button[contains(text(),'Absenden')]");

  public By newPasswordInput =
      By.xpath(
          "//fieldset/form[@id='passwordForgottenPassword']//input[@id='newPassword.password']");
  public By passwordChangeButton = By.xpath("//button[contains(text(),'Speichern')]");

  public static By EDIT_TIN_SECTION = By.xpath("//button[contains(text(),'Bearbeiten')]");
  public static By RADIO_BUTTON_TIN_NONGERMAN = By.id("taxableGermanyOnly1");

  public static ProfileDetailsPO getInstance() {
    if (singleInstance == null) {
      singleInstance = new ProfileDetailsPO();
    }
    return singleInstance;
  }

  public void updateIDData(
      String idType, String idCardNum, String expiryDate, String issueDate, String authorityCity) {
    TestLogger.logInfo("Click on Profile Link and Navigate to Profile Details Page");
    WebUIOperations.getInstance()
        .waitForElementAndClick(getWebElement(ShopLoginLogoutPO.getInstance().customerName));
    String headerText = DRIVER.findElement(myRegistrationHeaderText).getText();
    Assert.assertEquals(
        headerText,
        "Meine Registrierungsdaten",
        "Expected Header text: Meine Registrierungsdaten but observed is: " + headerText);

    TestLogger.logInfo("Scroll Down and click on AddID button");
    WebUIOperations.getInstance().scrollDownThePage();
    WebUIOperations.getInstance()
        .verifyElementIsPresent(DRIVER.findElement(ausweisdaten), "My ID Data");
    WebUIOperations.getInstance().waitForElementAndClick(DRIVER.findElement(Hinzufügen));

    TestLogger.logInfo(
        "Enter the ID Details , select Passport-fill IssueDate, expiryDate and Authorization Details");
    WebUIOperations.getInstance().selectDropdownByValue(DRIVER.findElement(idCardType), idType);
    WebUIOperations.getInstance().sendKeys(DRIVER.findElement(idCardNumber), idCardNum);
    WebUIOperations.getInstance().sendKeys(DRIVER.findElement(idCardExpiryDate), expiryDate);
    WebUIOperations.getInstance().sendKeys(DRIVER.findElement(idCardIssueDate), issueDate);
    WebUIOperations.getInstance().sendKeys(DRIVER.findElement(authority), authorityCity);

    TestLogger.logInfo("Click Save");
    WebUIOperations.getInstance().waitForElementAndClick(DRIVER.findElement(saveButton));
  }

  public String updateInvalidData(
      String idType, String idCardNum, String expiryDate, String issueDate, String authorityCity) {
    String errorMessage = "";
    TestLogger.logInfo("Click on Profile Link and Navigate to Profile Details Page");
    WebUIOperations.getInstance()
        .waitForElementAndClick(getWebElement(ShopLoginLogoutPO.getInstance().customerName));
    String headerText = DRIVER.findElement(myRegistrationHeaderText).getText();
    Assert.assertEquals(
        headerText,
        "Meine Registrierungsdaten",
        "Expected Header text: Meine Registrierungsdaten but observed is: " + headerText);
    TestLogger.logInfo("Scroll Down and click on AddID button");
    WebUIOperations.getInstance().scrollDownThePage();

    WebUIOperations.getInstance()
        .verifyElementIsPresent(DRIVER.findElement(ausweisdaten), "My ID Data");
    WebUIOperations.getInstance().waitForElementAndClick(DRIVER.findElement(Hinzufügen));

    TestLogger.logInfo(
        "Enter the ID Details , select Passport-fill IssueDate, expiryDate and Authorization Details");
    WebUIOperations.getInstance().selectDropdownByValue(DRIVER.findElement(idCardType), idType);
    WebUIOperations.getInstance().sendKeys(DRIVER.findElement(idCardNumber), idCardNum);
    WebUIOperations.getInstance().sendKeys(DRIVER.findElement(idCardExpiryDate), expiryDate);

    WebUIOperations.getInstance().sendKeys(DRIVER.findElement(idCardIssueDate), issueDate);
    WebUIOperations.getInstance().sendKeys(DRIVER.findElement(authority), authorityCity);
    TestLogger.logInfo("Click Save");
    WebUIOperations.getInstance().waitForElementAndClick(DRIVER.findElement(saveButton));
    if (doesWebElementExist(errorMessageExpiryDate)) {
      errorMessage = DRIVER.findElement(errorMessageExpiryDate).getText();
    } else if (doesWebElementExist(errorMessageIssueDate)) {
      errorMessage = DRIVER.findElement(errorMessageIssueDate).getText();
    }
    return errorMessage;
  }

  public void updatePassword(String OldPassword, String NewPassword) {
    TestLogger.logInfo("Click on Profile Link and Navigate to Profile Details Page");
    WebUIOperations.getInstance()
        .waitForElementAndClick(getWebElement(ShopLoginLogoutPO.getInstance().customerName));
    String headerText = DRIVER.findElement(myRegistrationHeaderText).getText();
    Assert.assertEquals(
        headerText,
        "Meine Registrierungsdaten",
        "Expected Header text: Meine Registrierungsdaten but observed is: " + headerText);
    TestLogger.logInfo("Scroll Down and click on AddID button");
    WebUIOperations.getInstance().scrollDownThePage();
    WebUIOperations.getInstance().scrollDownThePage();
    WebUIOperations.getInstance().scrollDownThePage();
    WebUIOperations.getInstance()
        .verifyElementIsPresent(DRIVER.findElement(passwordForm), "Password Form");
    WebUIOperations.getInstance().sendKeys(DRIVER.findElement(oldPassword), OldPassword);
    WebUIOperations.getInstance().sendKeys(DRIVER.findElement(newPassword), NewPassword);
    WebUIOperations.getInstance().waitForElementAndClick(DRIVER.findElement(savePassword));
  }

  public String getDate(int year, int day) {

    Calendar calendar = Calendar.getInstance();

    calendar.add(Calendar.DAY_OF_YEAR, day);
    calendar.add(Calendar.YEAR, year);
    Date date = calendar.getTime();
    DateFormat dateFormat = new SimpleDateFormat("dd.MM.yyyy");

    return dateFormat.format(date);
  }

  public void selectTIN(String country, String TIN, int i) {

    //    String taxIdByCountry = "";
    //    String TINNumber = "";
    //
    //    taxIdByCountry = "taxIdsByCountry" + i + ".country";
    //    TINNumber = "taxIdsByCountry" + i + ".taxId";
    By selectCountry = By.id("taxIdsByCountry" + i + ".country");
    By setTIN = By.id("taxIdsByCountry" + i + ".taxId");
    WebUIOperations.getInstance().selectDropdownByValue(getWebElement(selectCountry), country);
    WebUIOperations.getInstance().sendKeys(getWebElement(setTIN), TIN);
  }

  public String verifyMaskedTinValues(int i) {

    String maskValues =
        "/html/body/div[4]/div/section/div[3]/div/div/div/div[4]/div[" + i + "]/div[3]";

    return getWebElement(By.xpath(maskValues)).getText();
  }
}
