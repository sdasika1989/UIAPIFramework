-- Dumping data for table `b2c_product_bank`,`b2c_product_tranche`,`b2c_product_tranche_call_alike_transfer`,`b2c_product_bank_interest_account` and
--
-- WHERE:  bic='CPLUDES1XXX-FG'

USE `comonea_b2c`;


-- For `b2c_product_tranche`
LOCK TABLES `b2c_product_tranche` WRITE;
/*!40000 ALTER TABLE `b2c_product_tranche` DISABLE KEYS */;
INSERT INTO `b2c_product_tranche` VALUES (25594, '2020-11-23 17:35:21', '2021-12-14 01:00:01', 'EUR', 1000000.00, 'FIXED_TERM', '2024-03-31', 'EUR', 1000000.00, '2022-03-30 00:00:00', '2022-03-31 16:00:00', 'CPLUDES1XXX-FG2Y-2022-03-31', '', NULL, 'CREATED', '2022-03-31', '1438d713-6901-48aa-a0b8-48e1fda67f4f', 'PUBLISHED', 'Das Festgeld der CreditPlus Bank AG ist eine Termineinlage, bei der ein vorab vereinbarter Anlagebetrag zwischen {minPayInAmount} EUR und {maxPayInAmount} mit einer festen Laufzeit von {duration} und einem festen Zinssatz von {interestRate}% p.a. angelegt wird.', 'EUR', 1000.00, 51, 8, 0, 'SERVICE_BANK', 1, 0, NULL);
/*!40000 ALTER TABLE `b2c_product_tranche` ENABLE KEYS */;
UNLOCK TABLES;

-- For `b2c_interest_rate`
LOCK TABLES `b2c_interest_rate` WRITE;
/*!40000 ALTER TABLE `b2c_interest_rate` DISABLE KEYS */;
INSERT INTO `b2c_interest_rate` VALUES (25931, '2020-11-23 17:35:21', '2021-10-04 14:16:04', 0.00070, '2020-11-23', 25594);

/*!40000 ALTER TABLE `b2c_interest_rate` ENABLE KEYS */;
UNLOCK TABLES;

-- For `b2c_fixed_term_interest_approval`
LOCK TABLES `b2c_fixed_term_interest_approval` WRITE;
/*!40000 ALTER TABLE `b2c_fixed_term_interest_approval` DISABLE KEYS */;
INSERT INTO `b2c_fixed_term_interest_approval` VALUES (19680, '2021-12-09 16:35:03', NULL, 'fffa692229tjuhjo.fiete.gröss@gmx.de', '2021-12-09 16:35:03', 25594);

/*!40000 ALTER TABLE `b2c_fixed_term_interest_approval` ENABLE KEYS */;
UNLOCK TABLES;

-- For `b2c_product_bank_interest_account`
LOCK TABLES `b2c_product_bank_interest_account` WRITE;
/*!40000 ALTER TABLE `b2c_product_bank_interest_account` DISABLE KEYS */;
INSERT INTO `b2c_product_bank_interest_account` VALUES (33839, '2020-11-23 17:35:21', NULL, 'fffTyler Burmeister', 'DE93600306006910104560', 'fd89f4e5-47ca-4ece-9045-0e11f119f781', 25594, 4, 3, 'CPLUDES1XXX', 'CPLUDES1XXX', 'DE93600306006910104560', 0, 'EUR', NULL);
/*!40000 ALTER TABLE `b2c_product_bank_interest_account` ENABLE KEYS */;
UNLOCK TABLES;

-- For `b2c_service_bank_product_mapping`
LOCK TABLES `b2c_service_bank_product_mapping` WRITE;
/*!40000 ALTER TABLE `b2c_service_bank_product_mapping` DISABLE KEYS */;
INSERT INTO `b2c_service_bank_product_mapping` VALUES (33832, '2020-11-23 17:35:21', NULL, 33839, 25594, 5, 3);
/*!40000 ALTER TABLE `b2c_service_bank_product_mapping` ENABLE KEYS */;
UNLOCK TABLES;

-- For `b2c_document_product_information`
LOCK TABLES `b2c_document_product_information` WRITE;
/*!40000 ALTER TABLE `b2c_document_product_information` DISABLE KEYS */;
INSERT INTO `b2c_document_product_information` (`id`, `creationDate`, `lastModifiedDate`, `active`, `content`,`name`,`productTranche_id`,`template_id`,`validFrom`,`version`,`substitutionParamsJson`,`content_id`) VALUES ('111', '2021-04-15 08:10:38', NULL, 1,'', 'ZP_Produktsinformationsblatt_CreditPlus_FG.pdf', 25594, '1073', '2021-04-15', '6', '{\"interestRate\":\"0,01%\",\"documentCreationDate\":\"15.04.2021\",\"minAmount\":\"1\",\"textInterestRate\":\"Zinssatz ab 15.04.2021: 0,01% p.a.\",\"minAmountWithCUAndDot\":\"1 EUR.\",\"relationshipModel\":\"Treuhandanlage\",\"interestRateWithPa\":\"0,01% p.a.\",\"currentTextInterestRate\":\"Aktueller Zinsatz: 0,01% p.a. (seit: 15.04.2021)\",\"textNewInterestRate\":\"\",\"maxProductAmount\":\"1.000.000 EUR\",\"minProductAmount\":\"1 EUR\",\"noticePeriodInDays\":\"0\",\"minAmountWithCU\":\"1 EUR\",\"withholdingTaxRate\":\"0,00%\",\"investmentProtectionTresholdValidFrom\":\"01.01.2020\",\"maxAmountWithCU\":\"1.000.000 EUR\",\"cutOffAmountWithCurrency\":\"\",\"maxAmount\":\"1.000.000\",\"nextTextInterestRate\":\"\",\"investmentProtectionTresholdVolume\":\"44,88\"}',NULL);
/*!40000 ALTER TABLE `b2c_document_product_information` ENABLE KEYS */;
UNLOCK TABLES;


-- Table Dump completed
