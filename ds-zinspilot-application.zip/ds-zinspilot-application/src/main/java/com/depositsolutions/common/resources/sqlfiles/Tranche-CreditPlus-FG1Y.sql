-- Dumping data for table `b2c_product_bank`,`b2c_product_tranche`,`b2c_product_tranche_call_alike_transfer`,`b2c_product_bank_interest_account` and
--
-- WHERE:  bic='CPLUDES1XXX-FG'

USE `comonea_b2c`;


-- For `b2c_product_tranche`
LOCK TABLES `b2c_product_tranche` WRITE;
/*!40000 ALTER TABLE `b2c_product_tranche` DISABLE KEYS */;
INSERT INTO `b2c_product_tranche` VALUES (16592, '2020-11-23 17:35:15', NULL, 'EUR', 1000000.00, 'FIXED_TERM', '2023-03-31', 'EUR', 1000000.00, '2022-03-30 00:00:00', '2022-03-31 16:00:00', 'CPLUDES1XXX-FG1Y-2022-03-31', '', NULL, 'CREATED', '2022-03-31', 'a7c36d6d-0c3d-4901-9e60-efdf9831dedf', 'PUBLISHED', 'Das Festgeld der CreditPlus Bank AG ist eine Termineinlage, bei der ein vorab vereinbarter Anlagebetrag zwischen {minPayInAmount} EUR und {maxPayInAmount} mit einer festen Laufzeit von {duration} und einem festen Zinssatz von {interestRate}% p.a. angelegt wird.', 'EUR', 1000.00, 91, 5, 0, 'SERVICE_BANK',1,0, NULL);
INSERT INTO `b2c_product_tranche` VALUES (16591, '2020-01-28 12:58:05', '2020-08-17 07:45:35', 'EUR', 1000000.00, 'FIXED_TERM', '2022-03-31', 'EUR', 1000000.00, '2021-03-30 00:00:00', '2021-03-31 07:45:35', 'CPLUDES1XXX-FG12M-2021-03-31', '', NULL, 'CREATED', '2021-03-31', '7851dad6-7ae7-4fc8-9a52-5f894a10852e', 'HIDDEN', 'Das Festgeld der CreditPlus Bank AG ist eine Termineinlage, bei der ein vorab vereinbarter Anlagebetrag zwischen {minPayInAmount} EUR und {maxPayInAmount} mit einer festen Laufzeit von {duration} und einem festen Zinssatz von {interestRate}% p.a. angelegt wird.', 'EUR', 1000.00, 91, 5, 0, 'SERVICE_BANK',1,0, NULL);
/*!40000 ALTER TABLE `b2c_product_tranche` ENABLE KEYS */;
UNLOCK TABLES;

-- For `b2c_interest_rate`
LOCK TABLES `b2c_interest_rate` WRITE;
/*!40000 ALTER TABLE `b2c_interest_rate` DISABLE KEYS */;
INSERT INTO `b2c_interest_rate` VALUES (2,'2020-02-26 15:15:27',NULL,'0.00020','2020-05-03',16591);
INSERT INTO `b2c_interest_rate` VALUES (3,'2020-02-26 15:15:27',NULL,'0.00030','2021-05-03',16592);
/*!40000 ALTER TABLE `b2c_interest_rate` ENABLE KEYS */;
UNLOCK TABLES;

-- For `b2c_fixed_term_interest_approval`
LOCK TABLES `b2c_fixed_term_interest_approval` WRITE;
/*!40000 ALTER TABLE `b2c_fixed_term_interest_approval` DISABLE KEYS */;
INSERT INTO `b2c_fixed_term_interest_approval` VALUES (1,'2020-12-02 15:15:27',NULL,'marco','2020-12-02 15:15:27',16591);
INSERT INTO `b2c_fixed_term_interest_approval` VALUES (2,'2020-12-26 15:15:27',NULL,'marco','2020-12-26 15:15:27',16592);
/*!40000 ALTER TABLE `b2c_fixed_term_interest_approval` ENABLE KEYS */;
UNLOCK TABLES;

-- For `b2c_product_bank_interest_account`
LOCK TABLES `b2c_product_bank_interest_account` WRITE;
/*!40000 ALTER TABLE `b2c_product_bank_interest_account` DISABLE KEYS */;
INSERT INTO `b2c_product_bank_interest_account` VALUES (24375,'2020-01-28 12:58:05',NULL,'fffLily Beele','DE29600306006565060610','d5fb5fe5-d324-465a-9030-55bf78633954',16591,4,3,'CPLUDES1XXX','CPLUDES1XXX','DE29600306006565060610',0,'EUR',null);
INSERT INTO `b2c_product_bank_interest_account` VALUES (24376,'2020-01-28 12:58:05',NULL,'fffLily Beele','DE29600306006565060610','d5fb8fe5-d324-465a-9030-55bf78633954',16592,4,3,'CPLUDES1XXX','CPLUDES1XXX','DE29600306006565060610',0,'EUR',null);
/*!40000 ALTER TABLE `b2c_product_bank_interest_account` ENABLE KEYS */;
UNLOCK TABLES;

-- For `b2c_service_bank_product_mapping`
LOCK TABLES `b2c_service_bank_product_mapping` WRITE;
/*!40000 ALTER TABLE `b2c_service_bank_product_mapping` DISABLE KEYS */;
INSERT INTO `b2c_service_bank_product_mapping` VALUES (24368,'2020-01-28 12:58:05',NULL,24375,16591,5,3);
INSERT INTO `b2c_service_bank_product_mapping` VALUES (24369,'2020-01-28 12:58:05',NULL,24376,16592,5,3);
/*!40000 ALTER TABLE `b2c_service_bank_product_mapping` ENABLE KEYS */;
UNLOCK TABLES;

-- For `b2c_document_product_information_content`)
LOCK TABLES `b2c_document_product_information_content` WRITE;
/*!40000 ALTER TABLE `b2c_document_product_information_content` DISABLE KEYS */;
INSERT INTO `b2c_document_product_information_content` VALUES ('5', '2021-04-15 08:10:38', NULL, '{\"interestRate\":\"0,01%\",\"documentCreationDate\":\"15.04.2021\",\"minAmount\":\"1\",\"textInterestRate\":\"Zinssatz ab 15.04.2021: 0,01% p.a.\",\"minAmountWithCUAndDot\":\"1 EUR.\",\"relationshipModel\":\"Treuhandanlage\",\"interestRateWithPa\":\"0,01% p.a.\",\"currentTextInterestRate\":\"Aktueller Zinsatz: 0,01% p.a. (seit: 15.04.2021)\",\"textNewInterestRate\":\"\",\"maxProductAmount\":\"1.000.000 EUR\",\"minProductAmount\":\"1 EUR\",\"noticePeriodInDays\":\"0\",\"minAmountWithCU\":\"1 EUR\",\"withholdingTaxRate\":\"0,00%\",\"investmentProtectionTresholdValidFrom\":\"01.01.2020\",\"maxAmountWithCU\":\"1.000.000 EUR\",\"cutOffAmountWithCurrency\":\"\",\"maxAmount\":\"1.000.000\",\"nextTextInterestRate\":\"\",\"investmentProtectionTresholdVolume\":\"44,88\"}');
/*!40000 ALTER TABLE `b2c_document_product_information_content` ENABLE KEYS */;
UNLOCK TABLES;

-- For `b2c_document_product_information`
LOCK TABLES `b2c_document_product_information` WRITE;
/*!40000 ALTER TABLE `b2c_document_product_information` DISABLE KEYS */;
INSERT INTO `b2c_document_product_information` (`id`, `creationDate`, `lastModifiedDate`, `active`, `content`,`name`,`productTranche_id`,`template_id`,`validFrom`,`version`,`substitutionParamsJson`,`content_id`) VALUES ('11291', '2021-04-15 08:10:38', NULL, 1,'', 'ZP_Produktsinformationsblatt_CreditPlus_FG.pdf', '16591', '1073', '2021-04-15', '6', '{\"interestRate\":\"0,01%\",\"documentCreationDate\":\"15.04.2021\",\"minAmount\":\"1\",\"textInterestRate\":\"Zinssatz ab 15.04.2021: 0,01% p.a.\",\"minAmountWithCUAndDot\":\"1 EUR.\",\"relationshipModel\":\"Treuhandanlage\",\"interestRateWithPa\":\"0,01% p.a.\",\"currentTextInterestRate\":\"Aktueller Zinsatz: 0,01% p.a. (seit: 15.04.2021)\",\"textNewInterestRate\":\"\",\"maxProductAmount\":\"1.000.000 EUR\",\"minProductAmount\":\"1 EUR\",\"noticePeriodInDays\":\"0\",\"minAmountWithCU\":\"1 EUR\",\"withholdingTaxRate\":\"0,00%\",\"investmentProtectionTresholdValidFrom\":\"01.01.2020\",\"maxAmountWithCU\":\"1.000.000 EUR\",\"cutOffAmountWithCurrency\":\"\",\"maxAmount\":\"1.000.000\",\"nextTextInterestRate\":\"\",\"investmentProtectionTresholdVolume\":\"44,88\"}',5);
INSERT INTO `b2c_document_product_information` (`id`, `creationDate`, `lastModifiedDate`, `active`, `content`,`name`,`productTranche_id`,`template_id`,`validFrom`,`version`,`substitutionParamsJson`,`content_id`) VALUES ('1121', '2021-04-15 08:10:38', NULL, 1,'', 'ZP_Produktsinformationsblatt_CreditPlus_FG.pdf', '16592', '1073', '2021-04-15', '6', '{\"interestRate\":\"0,01%\",\"documentCreationDate\":\"15.04.2021\",\"minAmount\":\"1\",\"textInterestRate\":\"Zinssatz ab 15.04.2021: 0,01% p.a.\",\"minAmountWithCUAndDot\":\"1 EUR.\",\"relationshipModel\":\"Treuhandanlage\",\"interestRateWithPa\":\"0,01% p.a.\",\"currentTextInterestRate\":\"Aktueller Zinsatz: 0,01% p.a. (seit: 15.04.2021)\",\"textNewInterestRate\":\"\",\"maxProductAmount\":\"1.000.000 EUR\",\"minProductAmount\":\"1 EUR\",\"noticePeriodInDays\":\"0\",\"minAmountWithCU\":\"1 EUR\",\"withholdingTaxRate\":\"0,00%\",\"investmentProtectionTresholdValidFrom\":\"01.01.2020\",\"maxAmountWithCU\":\"1.000.000 EUR\",\"cutOffAmountWithCurrency\":\"\",\"maxAmount\":\"1.000.000\",\"nextTextInterestRate\":\"\",\"investmentProtectionTresholdVolume\":\"44,88\"}',5);
/*!40000 ALTER TABLE `b2c_document_product_information` ENABLE KEYS */;
UNLOCK TABLES;

-- Table Dump completed
