-- Dumping data for table `b2c_product_bank`,`b2c_product_tranche`,`b2c_product_tranche_call_alike_transfer`,`b2c_product_bank_interest_account` and 
--
-- WHERE:  bic='CPLUDES1XXX-FG'

USE `comonea_b2c`;


-- For `b2c_product_tranche`
LOCK TABLES `b2c_product_tranche` WRITE;
/*!40000 ALTER TABLE `b2c_product_tranche` DISABLE KEYS */;
INSERT INTO `b2c_product_tranche` VALUES ('23811', '2020-11-04 11:24:16', '2021-10-13 01:00:02', 'EUR', '1000000.00', 'FIXED_TERM', '2023-03-31', 'EUR', '100000.00', '2022-03-30 00:00:00', '2022-03-31 10:00:00', 'MOEYFRPPXXX-FG1Y-2022-03-31', '', NULL, 'CREATED', '2022-03-31', '1087cc51-9c20-4339-93b8-c740ffcbf336', 'PUBLISHED', 'Das Festgeld der My Money Bank S.A. ist eine Termineinlage, bei der ein vorab vereinbarter Anlagebetrag zwischen {minPayInAmount} EUR und {maxPayInAmount} mit einer festen Laufzeit von {duration} und einem festen Zinssatz von {interestRate}% p.a. angelegt wird.', 'EUR', '1.00', '83', '287', '0', 'SERVICE_BANK', 1, 0, NULL);
INSERT INTO `b2c_product_tranche` VALUES ('15269', '2019-11-22 12:34:19', '2020-10-30 09:09:22', NULL, NULL, 'FIXED_TERM', '2022-03-31', 'EUR', '100000.00', '2021-03-30 00:00:00', '2021-03-31 00:00:00', 'MOEYFRPPXXX-FG12M-2021-03-31', '', NULL, 'CREATED', '2021-03-31', 'c9d864b2-a5e9-480e-9f8f-4746c107df8d', 'HIDDEN', 'Das Festgeld der My Money Bank S.A. ist eine Termineinlage, bei der ein vorab vereinbarter Anlagebetrag zwischen {minPayInAmount} EUR und {maxPayInAmount} mit einer festen Laufzeit von {duration} und einem festen Zinssatz von {interestRate}% p.a. angelegt wird.', 'EUR', '1.00', '95', '287', '0', 'SERVICE_BANK', 1, 0, NULL);
/*!40000 ALTER TABLE `b2c_product_tranche` ENABLE KEYS */;
UNLOCK TABLES;

-- For `b2c_interest_rate`
LOCK TABLES `b2c_interest_rate` WRITE;
/*!40000 ALTER TABLE `b2c_interest_rate` DISABLE KEYS */;
INSERT INTO `b2c_interest_rate` VALUES (6,'2020-02-26 15:15:27',NULL,'0.00020','2020-05-03',23811);
INSERT INTO `b2c_interest_rate` VALUES (8,'2020-02-26 15:15:27',NULL,'0.00030','2021-05-03',15269);
/*!40000 ALTER TABLE `b2c_interest_rate` ENABLE KEYS */;
UNLOCK TABLES;

-- For `b2c_fixed_term_interest_approval`
LOCK TABLES `b2c_fixed_term_interest_approval` WRITE;
/*!40000 ALTER TABLE `b2c_fixed_term_interest_approval` DISABLE KEYS */;
INSERT INTO `b2c_fixed_term_interest_approval` VALUES (3,'2020-12-02 15:15:27',NULL,'marco','2020-12-02 15:15:27',23811);
INSERT INTO `b2c_fixed_term_interest_approval` VALUES (4,'2020-12-26 15:15:27',NULL,'marco','2020-12-26 15:15:27',15269);
/*!40000 ALTER TABLE `b2c_fixed_term_interest_approval` ENABLE KEYS */;
UNLOCK TABLES;

-- For `b2c_product_bank_interest_account`
LOCK TABLES `b2c_product_bank_interest_account` WRITE;
/*!40000 ALTER TABLE `b2c_product_bank_interest_account` DISABLE KEYS */;
INSERT INTO `b2c_product_bank_interest_account` VALUES ('31721', '2020-11-04 11:24:16', NULL, 'fffJulien vom Reuber', 'FR5830003031752788782090494', '0c486ab3-98f0-48d8-93ee-9f88fa07eb42', '23811', '44', '3', 'MOEYFRPPXXX', 'MOEYFRPPXXX', 'FR1742799000092788782090158', 0, 'EUR', NULL);
INSERT INTO `b2c_product_bank_interest_account` VALUES ('22903', '2019-11-22 12:34:19', NULL, 'fffJulien vom Reuber', 'FR5830003031752788782090494', 'ea9f3e3f-1975-454d-b732-388599ea3ae6', '15269', '44', '3', 'MOEYFRPPXXX', 'MOEYFRPPXXX', 'FR1742799000092788782090158', 0, 'EUR', NULL);
/*!40000 ALTER TABLE `b2c_product_bank_interest_account` ENABLE KEYS */;
UNLOCK TABLES;

-- For `b2c_service_bank_product_mapping`
LOCK TABLES `b2c_service_bank_product_mapping` WRITE;
/*!40000 ALTER TABLE `b2c_service_bank_product_mapping` DISABLE KEYS */;
INSERT INTO `b2c_service_bank_product_mapping` VALUES (24668,'2020-01-28 12:58:05',NULL,31721,23811,5,3);
INSERT INTO `b2c_service_bank_product_mapping` VALUES (24069,'2020-01-28 12:58:05',NULL,22903,15269,5,3);
/*!40000 ALTER TABLE `b2c_service_bank_product_mapping` ENABLE KEYS */;
UNLOCK TABLES;

-- For `b2c_document_product_information`
LOCK TABLES `b2c_document_product_information` WRITE;
/*!40000 ALTER TABLE `b2c_document_product_information` DISABLE KEYS */;
INSERT INTO `b2c_document_product_information` (`id`, `creationDate`, `lastModifiedDate`, `active`, `content`,`name`,`productTranche_id`,`template_id`,`validFrom`,`version`,`substitutionParamsJson`,`content_id`) VALUES ('1129', '2021-04-15 08:10:38', NULL, 1,'', 'ZP_Produktsinformationsblatt_MyMoney_FG.pdf', '23811', '105', '2021-04-15', '6', '{\"interestRate\":\"0,01%\",\"documentCreationDate\":\"15.04.2021\",\"minAmount\":\"1\",\"textInterestRate\":\"Zinssatz ab 15.04.2021: 0,01% p.a.\",\"minAmountWithCUAndDot\":\"1 EUR.\",\"relationshipModel\":\"Treuhandanlage\",\"interestRateWithPa\":\"0,01% p.a.\",\"currentTextInterestRate\":\"Aktueller Zinsatz: 0,01% p.a. (seit: 15.04.2021)\",\"textNewInterestRate\":\"\",\"maxProductAmount\":\"1.000.000 EUR\",\"minProductAmount\":\"1 EUR\",\"noticePeriodInDays\":\"0\",\"minAmountWithCU\":\"1 EUR\",\"withholdingTaxRate\":\"0,00%\",\"investmentProtectionTresholdValidFrom\":\"01.01.2020\",\"maxAmountWithCU\":\"1.000.000 EUR\",\"cutOffAmountWithCurrency\":\"\",\"maxAmount\":\"1.000.000\",\"nextTextInterestRate\":\"\",\"investmentProtectionTresholdVolume\":\"44,88\"}',NULL);
INSERT INTO `b2c_document_product_information` (`id`, `creationDate`, `lastModifiedDate`, `active`, `content`,`name`,`productTranche_id`,`template_id`,`validFrom`,`version`,`substitutionParamsJson`,`content_id`) VALUES ('121', '2021-04-15 08:10:38', NULL, 1,'', 'ZP_Produktsinformationsblatt_MyMoney_FG.pdf', '15269', '105', '2021-04-15', '6', '{\"interestRate\":\"0,01%\",\"documentCreationDate\":\"15.04.2021\",\"minAmount\":\"1\",\"textInterestRate\":\"Zinssatz ab 15.04.2021: 0,01% p.a.\",\"minAmountWithCUAndDot\":\"1 EUR.\",\"relationshipModel\":\"Treuhandanlage\",\"interestRateWithPa\":\"0,01% p.a.\",\"currentTextInterestRate\":\"Aktueller Zinsatz: 0,01% p.a. (seit: 15.04.2021)\",\"textNewInterestRate\":\"\",\"maxProductAmount\":\"1.000.000 EUR\",\"minProductAmount\":\"1 EUR\",\"noticePeriodInDays\":\"0\",\"minAmountWithCU\":\"1 EUR\",\"withholdingTaxRate\":\"0,00%\",\"investmentProtectionTresholdValidFrom\":\"01.01.2020\",\"maxAmountWithCU\":\"1.000.000 EUR\",\"cutOffAmountWithCurrency\":\"\",\"maxAmount\":\"1.000.000\",\"nextTextInterestRate\":\"\",\"investmentProtectionTresholdVolume\":\"44,88\"}',NULL);
/*!40000 ALTER TABLE `b2c_document_product_information` ENABLE KEYS */;
UNLOCK TABLES;


-- Table Dump completed
