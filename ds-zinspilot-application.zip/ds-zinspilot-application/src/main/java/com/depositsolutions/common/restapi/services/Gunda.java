package com.depositsolutions.common.restapi.services;

import static io.restassured.RestAssured.given;

import com.depositsolutions.common.restapi.helpers.Endpoints;
import com.depositsolutions.common.utils.ConfigManager;
import com.depositsolutions.common.utils.TestLogger;
import io.restassured.RestAssured;

public class Gunda {
  public static Gunda singleInstance = null;
  private String CoreBLUrl = ConfigManager.getInstance().getString("CoreBLUrl");

  public static Gunda getInstance() {
    if (singleInstance == null) {
      singleInstance = new Gunda();
    }
    return singleInstance;
  }

  /*
   * This method gets Customer details
   * @param customerNumber
   * @return
   */
  public String Gunda_GetCustomer(String customerNumber) throws InterruptedException {
    RestAssured.baseURI = CoreBLUrl;

    String response =
        given()
            .header("Content-Type", "application/json")
            .header("Accept", "application/json")
            .when()
            .get("/gunda/customer/" + customerNumber)
            .then()
            .log()
            .ifError()
            .assertThat()
            .statusCode(200)
            .extract()
            .response()
            .asString();
    return response;
  }

  /*
   * This method runs validation endpoint
   */
  public void Gunda_validate() throws InterruptedException {
    RestAssured.baseURI = CoreBLUrl;
    given()
        .header("Content-Type", "application/json")
        .header("Accept", "application/json")
        .when()
        .put(Endpoints.gundaValidate)
        .then()
        .log()
        .ifError()
        .assertThat()
        .statusCode(200);
    TestLogger.logInfo("API: Gunda Validation Endpoint is successful");
  }
}
