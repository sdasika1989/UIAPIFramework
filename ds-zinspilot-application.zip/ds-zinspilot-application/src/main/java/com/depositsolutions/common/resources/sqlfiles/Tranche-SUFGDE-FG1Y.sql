-- Dumping data for table `b2c_product_bank`,`b2c_product_tranche`,`b2c_product_tranche_call_alike_transfer`,`b2c_product_bank_interest_account` and
--
-- WHERE:  bic='CPLUDES1XXX-FG'

USE `comonea_b2c`;


-- For `b2c_product_tranche`
LOCK TABLES `b2c_product_tranche` WRITE;
/*!40000 ALTER TABLE `b2c_product_tranche` DISABLE KEYS */;

INSERT INTO `b2c_product_tranche` VALUES ('27013', '2020-11-04 11:24:16', '2021-10-13 01:00:02', 'EUR', '1000000.00', 'FIXED_TERM', '2023-03-31', 'EUR', '100000.00', '2022-03-30 00:00:00', '2022-03-31 10:00:00', 'SUFGDE51XXX-FG1Y-2022-03-31', '', NULL, 'CREATED', '2022-03-31', '1087cc51-9c20-4339-93b8-c740ffcbf336', 'PUBLISHED', 'Das Festgeld der My Money Bank S.A. ist eine Termineinlage, bei der ein vorab vereinbarter Anlagebetrag zwischen {minPayInAmount} EUR und {maxPayInAmount} mit einer festen Laufzeit von {duration} und einem festen Zinssatz von {interestRate}% p.a. angelegt wird.', 'EUR', '1.00', '83', '287', '0', 'SERVICE_BANK', 1, 0, NULL);
INSERT INTO `b2c_product_tranche` VALUES ('27014', '2019-11-22 12:34:19', '2020-10-30 09:09:22', NULL, NULL, 'FIXED_TERM', '2022-03-31', 'EUR', '100000.00', '2021-03-30 00:00:00', '2021-03-31 00:00:00', 'SUFGDE51XXX-FG12M-2021-03-31', '', NULL, 'CREATED', '2021-03-31', 'c9d864b2-a5e9-480e-9f8f-4746c107df8d', 'HIDDEN', 'Das Festgeld der My Money Bank S.A. ist eine Termineinlage, bei der ein vorab vereinbarter Anlagebetrag zwischen {minPayInAmount} EUR und {maxPayInAmount} mit einer festen Laufzeit von {duration} und einem festen Zinssatz von {interestRate}% p.a. angelegt wird.', 'EUR', '1.00', '95', '287', '0', 'SERVICE_BANK', 1, 0, NULL);

/*!40000 ALTER TABLE `b2c_product_tranche` ENABLE KEYS */;
UNLOCK TABLES;

-- For `b2c_interest_rate`
LOCK TABLES `b2c_interest_rate` WRITE;
/*!40000 ALTER TABLE `b2c_interest_rate` DISABLE KEYS */;
INSERT INTO `b2c_interest_rate` VALUES (1,'2020-02-26 15:15:27',NULL,'0.00020','2020-05-03',27013);
INSERT INTO `b2c_interest_rate` VALUES (4,'2020-01-08 15:15:27',NULL,'0.00030','2021-05-03',27014);
/*!40000 ALTER TABLE `b2c_interest_rate` ENABLE KEYS */;
UNLOCK TABLES;


-- For `b2c_fixed_term_interest_approval`
LOCK TABLES `b2c_fixed_term_interest_approval` WRITE;
/*!40000 ALTER TABLE `b2c_fixed_term_interest_approval` DISABLE KEYS */;
INSERT INTO `b2c_fixed_term_interest_approval` VALUES (6,'2020-12-02 15:15:27',NULL,'marco','2020-12-02 15:15:27',27013);
INSERT INTO `b2c_fixed_term_interest_approval` VALUES (82,'2020-12-26 15:15:27',NULL,'marco','2020-12-26 15:15:27',27014);
/*!40000 ALTER TABLE `b2c_fixed_term_interest_approval` ENABLE KEYS */;
UNLOCK TABLES;


-- For `b2c_product_bank_interest_account`
LOCK TABLES `b2c_product_bank_interest_account` WRITE;
/*!40000 ALTER TABLE `b2c_product_bank_interest_account` DISABLE KEYS */;
INSERT INTO `b2c_product_bank_interest_account` VALUES ('31147','2020-11-03 18:04:12',NULL,'fffFreiherrin Michelle Knies','DE09550207005004433909','15fecb4d-b9f5-4f38-a921-64fd62136901','27013','58','3','SUFGDE51XXX','SUFGDE51XXX','DE09550207005004433909',0,'EUR',NULL);
INSERT INTO `b2c_product_bank_interest_account` VALUES ('23896','2020-01-09 09:25:30',NULL,'fffBaronin Thalia von Fuhlbrügge','DE09550207005004433909','cc4c771b-69de-4f59-b7f8-ab0da42a320d','27014','58','3','SUFGDE51XXX','SUFGDE51XXX','DE09550207005004433909',0,'EUR',NULL);
/*!40000 ALTER TABLE `b2c_product_bank_interest_account` ENABLE KEYS */;
UNLOCK TABLES;

-- For `b2c_service_bank_product_mapping`
LOCK TABLES `b2c_service_bank_product_mapping` WRITE;
/*!40000 ALTER TABLE `b2c_service_bank_product_mapping` DISABLE KEYS */;
INSERT INTO `b2c_service_bank_product_mapping` VALUES ('31140','2020-11-03 18:04:12',NULL,'31147','27013','5','3');
INSERT INTO `b2c_service_bank_product_mapping` VALUES ('23889','2020-01-09 09:25:30',NULL,'23896','27014','5','3');
/*!40000 ALTER TABLE `b2c_service_bank_product_mapping` ENABLE KEYS */;
UNLOCK TABLES;

-- For `b2c_document_depositors_information`
LOCK TABLES `b2c_document_depositors_information` WRITE;
/*!40000 ALTER TABLE `b2c_document_depositors_information` DISABLE KEYS */;
INSERT INTO `b2c_document_depositors_information` VALUES ( '185', '2021-06-17 14:08:35', NULL, 1, 'PRODUCT_BANK', 'SUFGDE51XXX','', 'ZP_IFE_SWK.pdf', '2021-06-17', '1');
/*!40000 ALTER TABLE `b2c_document_depositors_information` ENABLE KEYS */;
UNLOCK TABLES;

-- For `b2c_document_product_information`
LOCK TABLES `b2c_document_product_information` WRITE;
/*!40000 ALTER TABLE `b2c_document_product_information` DISABLE KEYS */;
INSERT INTO `b2c_document_product_information` (`id`, `creationDate`, `lastModifiedDate`, `active`, `content`,`name`,`productTranche_id`,`template_id`,`validFrom`,`version`,`substitutionParamsJson`,`content_id`) VALUES ('11201', '2021-04-15 08:10:38', NULL, 1,'', 'ZP_Produktsinformationsblatt_CreditPlus_FG1.pdf', '27013', '1975', '2021-04-15', '6', '{\"interestRate\":\"0,01%\",\"documentCreationDate\":\"15.04.2021\",\"minAmount\":\"1\",\"textInterestRate\":\"Zinssatz ab 15.04.2021: 0,01% p.a.\",\"minAmountWithCUAndDot\":\"1 EUR.\",\"relationshipModel\":\"Treuhandanlage\",\"interestRateWithPa\":\"0,01% p.a.\",\"currentTextInterestRate\":\"Aktueller Zinsatz: 0,01% p.a. (seit: 15.04.2021)\",\"textNewInterestRate\":\"\",\"maxProductAmount\":\"1.000.000 EUR\",\"minProductAmount\":\"1 EUR\",\"noticePeriodInDays\":\"0\",\"minAmountWithCU\":\"1 EUR\",\"withholdingTaxRate\":\"0,00%\",\"investmentProtectionTresholdValidFrom\":\"01.01.2020\",\"maxAmountWithCU\":\"1.000.000 EUR\",\"cutOffAmountWithCurrency\":\"\",\"maxAmount\":\"1.000.000\",\"nextTextInterestRate\":\"\",\"investmentProtectionTresholdVolume\":\"44,88\"}',NULL);
INSERT INTO `b2c_document_product_information` (`id`, `creationDate`, `lastModifiedDate`, `active`, `content`,`name`,`productTranche_id`,`template_id`,`validFrom`,`version`,`substitutionParamsJson`,`content_id`) VALUES ('11211', '2021-04-15 08:10:38', NULL, 1,'', 'ZP_Produktsinformationsblatt_CreditPlus_FG.pdf', '27014', '1976', '2021-04-15', '6', '{\"interestRate\":\"0,01%\",\"documentCreationDate\":\"15.04.2021\",\"minAmount\":\"1\",\"textInterestRate\":\"Zinssatz ab 15.04.2021: 0,01% p.a.\",\"minAmountWithCUAndDot\":\"1 EUR.\",\"relationshipModel\":\"Treuhandanlage\",\"interestRateWithPa\":\"0,01% p.a.\",\"currentTextInterestRate\":\"Aktueller Zinsatz: 0,01% p.a. (seit: 15.04.2021)\",\"textNewInterestRate\":\"\",\"maxProductAmount\":\"1.000.000 EUR\",\"minProductAmount\":\"1 EUR\",\"noticePeriodInDays\":\"0\",\"minAmountWithCU\":\"1 EUR\",\"withholdingTaxRate\":\"0,00%\",\"investmentProtectionTresholdValidFrom\":\"01.01.2020\",\"maxAmountWithCU\":\"1.000.000 EUR\",\"cutOffAmountWithCurrency\":\"\",\"maxAmount\":\"1.000.000\",\"nextTextInterestRate\":\"\",\"investmentProtectionTresholdVolume\":\"44,88\"}',NULL);
/*!40000 ALTER TABLE `b2c_document_product_information` ENABLE KEYS */;
UNLOCK TABLES;

-- Table Dump completed
