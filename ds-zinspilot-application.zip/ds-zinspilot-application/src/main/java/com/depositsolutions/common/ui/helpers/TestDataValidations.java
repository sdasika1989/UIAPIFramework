package com.depositsolutions.common.ui.helpers;

public class TestDataValidations {
  public static String INCORRECT_ACTIVATIONCODE_MESSAGE =
      "Sie haben leider einen falschen Registrierungscode eingegeben. Bitte nutzen Sie den Link in der E-Mail oder prüfen Sie, ob Sie mit einem anderen Nutzerkonto bei ZINSPILOT eingeloggt sind.";
  public static String expectedErrorMessageExpiryDate =
      "Das Gültigkeitsdatum darf nicht mehr als 10 Jahre in der Zukunft liegen.";
  public static String expectedErrorMessageIssueDate =
      "Das Ausstellungsdatum darf nicht mehr als 10 Jahre in der Vergangenheit liegen.";
  public static String expectedErrorMessageForIssueDate1 =
      "Das Ausstellungsdatum muss in der Vergangenheit liegen.";
  public static String expectedDateFormatErrorMessage = "Das Format wurde nicht erkannt.";

  public static String idDataSuccessMessage = "Ihre Ausweisdaten wurden erfolgreich gespeichert.";
  public static String passwordchngMessage = "Ihr neues Passwort wurde erfolgreich gespeichert.";
  public static String phoneNumberMasked = "***********3974";
  public static String profileDataSuccessMessage =
      "Ihre Kundendaten wurden erfolgreich gespeichert.";
  public static String getPasswordchngMessage = "Ihr Passwort wurde erfolgreich geändert";
}
