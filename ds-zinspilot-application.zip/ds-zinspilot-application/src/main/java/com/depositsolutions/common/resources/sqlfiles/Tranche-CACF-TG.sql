-- Dumping data for table `b2c_product_bank`,`b2c_product_tranche`,`b2c_product_tranche_call_alike_transfer`,`b2c_product_bank_interest_account` and 
--
-- WHERE:  bic='CPLUDES1XXX-TG'

USE `comonea_b2c`;
-- For `b2c_product_tranche`
LOCK TABLES `b2c_product_tranche` WRITE;
/*!40000 ALTER TABLE `b2c_product_tranche` DISABLE KEYS */;
INSERT INTO `b2c_product_tranche` (`id`, `creationDate`, `lastModifiedDate`, `cut_off_amount_currency`, `cut_off_amount`, `depositType`, `endDate`, `max_amount_currency`, `max_amount`, `payInDeadline`, `transactionDate`, `productIdentifier`, `productName`, `infoProduct`, `productState`, `startDate`, `uuid`, `viewState`, `description`, `min_amount_currency`, `min_amount`, `marketing_rank`, `interestProduct_id`, `investmentChangeOnly`, `interestTaxation`, `canBeProlongated`, `noticePeriodInDays`, `targetGroup`)
VALUES
	(29506, '2021-07-28 08:35:47', '2021-09-29 13:49:27', 'EUR', 1000000.00, 'DIRECT_ACCESS', NULL, 'EUR', 100000.00, NULL, NULL, 'AGRLFR22XXX-TG', '', NULL, 'CONNECTED', NULL, '0d1b9d3c-b124-4492-9e46-939f37f92bfc', 'PUBLISHED', 'Das GenoFlexgeld der CA Consumer Finance S.A. ist eine Termineinlage, bei der ein vorab vereinbarter Anlagebetrag zwischen {minPayInAmount} EUR und {maxPayInAmount} EUR mit einer festen Laufzeit von 1 Monat und einem festen Zinssatz von {interestRate}% p.a. angelegt wird. Erteilt der Kunde bis zu 5 Bankarbeitstage vor dem Fälligkeitstermin keine anderslautende Weisung wird die Einlage verlängert', 'EUR', 1.00, 7500, 500, 0, 'SERVICE_BANK', 1, 0, NULL);
/*!40000 ALTER TABLE `b2c_product_tranche` ENABLE KEYS */;
UNLOCK TABLES;

-- For `b2c_interest_rate`
LOCK TABLES `b2c_interest_rate` WRITE;
/*!40000 ALTER TABLE `b2c_interest_rate` DISABLE KEYS */;
INSERT INTO `b2c_interest_rate` VALUES (1,'2020-02-26 15:15:27',NULL,'0.00050','2020-03-16',29506);
/*!40000 ALTER TABLE `b2c_interest_rate` ENABLE KEYS */;
UNLOCK TABLES;

-- For `b2c_product_tranche_call_alike_transfer`
LOCK TABLES `b2c_product_tranche_call_alike_transfer` WRITE;
/*!40000 ALTER TABLE `b2c_product_tranche_call_alike_transfer` DISABLE KEYS */;
INSERT INTO `b2c_product_tranche_call_alike_transfer` VALUES (1997,'2020-11-23 17:09:16',NULL,'2022-03-15',NULL,29506,'CLOSED','CLOSED');
INSERT INTO `b2c_product_tranche_call_alike_transfer` VALUES (1998,'2020-11-23 17:09:16',NULL,'2022-03-31',NULL,29506,'OPEN','OPEN');
/*!40000 ALTER TABLE `b2c_product_tranche_call_alike_transfer` ENABLE KEYS */;
UNLOCK TABLES;

-- For `b2c_product_bank_interest_account`
LOCK TABLES `b2c_product_bank_interest_account` WRITE;
/*!40000 ALTER TABLE `b2c_product_bank_interest_account` DISABLE KEYS */;
INSERT INTO `b2c_product_bank_interest_account` (`id`, `creationDate`, `lastModifiedDate`, `accountHolder`, `iban`, `uuid`, `product_id`, `productBank_id`, `serviceBankTransitAccount_id`, `bic`, `payInBic`, `payInIban`, `closed`, `currency`, `ultimateCreditorIban`)
VALUES
	(37800, '2021-07-28 08:35:47', NULL, 'fffTyler Burmeister', 'FR1930006000019688554743422', 'e759a6f0-c98a-4fa1-a34f-24801c01a60f', 29506, 83, 3, 'AGRIFRPPXXX', 'AGRIFRPPXXX', 'FR1930006000019688554743422', 0, 'EUR', NULL);
/*!40000 ALTER TABLE `b2c_product_bank_interest_account` ENABLE KEYS */;
UNLOCK TABLES;

-- For `b2c_service_bank_product_mapping`
LOCK TABLES `b2c_service_bank_product_mapping` WRITE;
/*!40000 ALTER TABLE `b2c_service_bank_product_mapping` DISABLE KEYS */;
INSERT INTO `b2c_service_bank_product_mapping` VALUES (7551,'2017-09-06 16:01:27',NULL,37800,29506,5,3);
/*!40000 ALTER TABLE `b2c_service_bank_product_mapping` ENABLE KEYS */;
UNLOCK TABLES;

-- For `b2c_document_depositors_information`
LOCK TABLES `b2c_document_depositors_information` WRITE;
/*!40000 ALTER TABLE `b2c_document_depositors_information` DISABLE KEYS */;
INSERT INTO `b2c_document_depositors_information` VALUES ( '185', '2021-06-17 14:08:35', NULL, 1, 'PRODUCT_BANK', 'AGRLFR22XXX','', 'ZP_IFE_AGRLFR22XXX_N.V..pdf', '2021-06-17', '1');
/*!40000 ALTER TABLE `b2c_document_depositors_information` ENABLE KEYS */;
UNLOCK TABLES;

-- For `b2c_document_product_information_content`)
LOCK TABLES `b2c_document_product_information_content` WRITE;
/*!40000 ALTER TABLE `b2c_document_product_information_content` DISABLE KEYS */;
INSERT INTO `b2c_document_product_information_content` VALUES ('1', '2021-04-15 08:10:38', NULL, '{\"interestRate\":\"0,01%\",\"documentCreationDate\":\"15.04.2021\",\"minAmount\":\"1\",\"textInterestRate\":\"Zinssatz ab 15.04.2021: 0,01% p.a.\",\"minAmountWithCUAndDot\":\"1 EUR.\",\"relationshipModel\":\"Treuhandanlage\",\"interestRateWithPa\":\"0,01% p.a.\",\"currentTextInterestRate\":\"Aktueller Zinsatz: 0,01% p.a. (seit: 15.04.2021)\",\"textNewInterestRate\":\"\",\"maxProductAmount\":\"1.000.000 EUR\",\"minProductAmount\":\"1 EUR\",\"noticePeriodInDays\":\"0\",\"minAmountWithCU\":\"1 EUR\",\"withholdingTaxRate\":\"0,00%\",\"investmentProtectionTresholdValidFrom\":\"01.01.2020\",\"maxAmountWithCU\":\"1.000.000 EUR\",\"cutOffAmountWithCurrency\":\"\",\"maxAmount\":\"1.000.000\",\"nextTextInterestRate\":\"\",\"investmentProtectionTresholdVolume\":\"44,88\"}');
/*!40000 ALTER TABLE `b2c_document_product_information_content` ENABLE KEYS */;
UNLOCK TABLES;

-- For `b2c_document_product_information`
LOCK TABLES `b2c_document_product_information` WRITE;
/*!40000 ALTER TABLE `b2c_document_product_information` DISABLE KEYS */;
INSERT INTO `b2c_document_product_information` (`id`, `creationDate`, `lastModifiedDate`, `active`, `content`,`name`,`productTranche_id`,`template_id`,`validFrom`,`version`,`substitutionParamsJson`,`content_id`) VALUES ('112291', '2021-04-15 08:10:38', NULL, 1,'', 'ZP_Produktinformatinsblatt_Cacf_TG.pdf', '29506', '1976', '2021-04-15', '6', '{\"interestRate\":\"0,01%\",\"documentCreationDate\":\"15.04.2021\",\"minAmount\":\"1\",\"textInterestRate\":\"Zinssatz ab 15.04.2021: 0,01% p.a.\",\"minAmountWithCUAndDot\":\"1 EUR.\",\"relationshipModel\":\"Treuhandanlage\",\"interestRateWithPa\":\"0,01% p.a.\",\"currentTextInterestRate\":\"Aktueller Zinsatz: 0,01% p.a. (seit: 15.04.2021)\",\"textNewInterestRate\":\"\",\"maxProductAmount\":\"1.000.000 EUR\",\"minProductAmount\":\"1 EUR\",\"noticePeriodInDays\":\"0\",\"minAmountWithCU\":\"1 EUR\",\"withholdingTaxRate\":\"0,00%\",\"investmentProtectionTresholdValidFrom\":\"01.01.2020\",\"maxAmountWithCU\":\"1.000.000 EUR\",\"cutOffAmountWithCurrency\":\"\",\"maxAmount\":\"1.000.000\",\"nextTextInterestRate\":\"\",\"investmentProtectionTresholdVolume\":\"44,88\"}',1);
/*!40000 ALTER TABLE `b2c_document_product_information` ENABLE KEYS */;
UNLOCK TABLES;

-- PB Dump completed
