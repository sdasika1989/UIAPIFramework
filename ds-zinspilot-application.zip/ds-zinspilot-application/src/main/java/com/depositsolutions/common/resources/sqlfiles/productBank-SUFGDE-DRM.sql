-- Dumping data for table `b2c_product_bank`,`b2c_product_tranche`,`b2c_product_tranche_call_alike_transfer`,`b2c_product_bank_interest_account` and
--
-- WHERE:  bic='CKV-FG'

USE `comonea_b2c`;

-- For `b2c_product_bank`
LOCK TABLES `b2c_product_bank` WRITE;
/*!40000 ALTER TABLE `b2c_product_bank` DISABLE KEYS */;
INSERT INTO `b2c_product_bank` VALUES ('58','2020-12-18 09:56:07','2021-04-12 12:58:24','SUFGDE51XXX',NULL,'Süd-West-Kreditbank Finanzierung GmbH','DE',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'HRB Mainz 21815','DE 811127781','3f800518-4117-11eb-b187-26e0a622eaa4',NULL,'EUR','100000.00',NULL,NULL,NULL,NULL,'0.00000','CUSTOMER_INTEREST_ACCOUNT_BASED','DIRECT_RELATIONSHIP_MODEL',NULL,NULL,'SWK Bank','24','1','-2','00:00:00','-2','12:00:00','0');
/*!40000 ALTER TABLE `b2c_product_bank` ENABLE KEYS */;
UNLOCK TABLES;

-- For `b2c_product_bank_contact_details`
LOCK TABLES `b2c_product_bank_contact_details` WRITE;
/*!40000 ALTER TABLE `b2c_product_bank_contact_details` DISABLE KEYS */;INSERT INTO `b2c_product_bank_contact_details` (`id`, `creationDate`, `lastModifiedDate`, `productBank_id`, `emailAddress`, `addressLine1`, `postalCode`, `townName`, `countryCode`)
VALUES(4, '2020-12-18 09:56:07', NULL, 58, 'widerruf-swkbank@zinspilot.de', 'Am Ockenheimer Graben 52', '55411', 'Bingen am Rhein', 'DE');
/*!40000 ALTER TABLE `b2c_product_bank_contact_details` ENABLE KEYS */;
UNLOCK TABLES;

-- For `b2c_product_bank_validation_requirement`
LOCK TABLES `b2c_product_bank_validation_requirement` WRITE;
/*!40000 ALTER TABLE `b2c_product_bank_validation_requirement` DISABLE KEYS */;

INSERT INTO `b2c_product_bank_validation_requirement` VALUES ('5','2020-01-22 10:07:38',NULL,'VALID_LEGITIMISATION_DATA','58','NONE',NULL,'1');
INSERT INTO `b2c_product_bank_validation_requirement` VALUES ('23','2020-01-22 10:07:38',NULL,'VALID_DRM_CONTRACT','58','NONE',NULL,'1');
/*!40000 ALTER TABLE `b2c_product_bank_validation_requirement` ENABLE KEYS */;
UNLOCK TABLES;



-- For `b2c_product_bank_logo`
LOCK TABLES `b2c_product_bank_logo` WRITE;
/*!40000 ALTER TABLE `b2c_product_bank_logo` DISABLE KEYS */;
INSERT INTO `b2c_product_bank_logo` VALUES ('11', '2021-01-26 10:37:46.000000', NULL,'', 'SUFGDE51XXX.svg', 'SUFGDE51XXX');
/*!40000 ALTER TABLE `b2c_product_bank_logo` ENABLE KEYS */;
UNLOCK TABLES;

-- For `b2c_interest_product`
LOCK TABLES `b2c_interest_product` WRITE;
/*!40000 ALTER TABLE `b2c_interest_product` DISABLE KEYS */;
INSERT INTO `b2c_interest_product` VALUES ('287','2019-12-20 16:41:33','2020-02-04 10:09:54','SUFGDE51XXX-FIXED_1Y','AFTER_TERM_END','GERMAN_30_360','FIXED_1Y',NULL,'SWKBANKFG12M','58','EUR','PROLONGATION','PAYOUT','2020-02-04 00:00:00','2');
/*!40000 ALTER TABLE `b2c_interest_product` ENABLE KEYS */;
UNLOCK TABLES;



-- For `b2c_document_product_information_template`
LOCK TABLES `b2c_document_product_information_template` WRITE;
/*!40000 ALTER TABLE `b2c_document_product_information_template` DISABLE KEYS */;
INSERT INTO `b2c_document_product_information_template` VALUES ('1975', '2021-03-17 13:32:21', '2021-02-05 10:26:58', 1, '', 'ZP_PIB_SWK_FG.pdf.pdf', 'FIXED_TERM', '58', '2020-12-11', '1', NULL, '5', NULL);
INSERT INTO `b2c_document_product_information_template` VALUES ('1976', '2021-03-17 13:32:21', NULL, 1, '', 'ZP_Produktinformationsblatt_SWK_Bank_FG.pdf', 'FIXED_TERM', '58', '2020-12-18', '4', NULL, '5', NULL);
/*!40000 ALTER TABLE `b2c_document_product_information_template` ENABLE KEYS */;
UNLOCK TABLES;

-- For `zp_messages`
LOCK TABLES `zp_messages` WRITE;
/*!40000 ALTER TABLE `zp_messages` DISABLE KEYS */;
INSERT INTO `zp_messages` (`id`, `creationDate`, `lastModifiedDate`, `message_key`, `message`)
VALUES(545, '2021-01-26 10:33:04.000000', NULL, 'high_yield.category.SUFGDE51XXX', '1');
/*!40000 ALTER TABLE `zp_messages` ENABLE KEYS */;
UNLOCK TABLES;


--drm
USE `cm`;
LOCK TABLES `dc_cancellation_timeout` WRITE;
/*!40000 ALTER TABLE `dc_cancellation_timeout` DISABLE KEYS */;
INSERT INTO `dc_cancellation_timeout` (`distributionChannel`, `days`)
VALUES('ZP', 45);
/*!40000 ALTER TABLE `dc_cancellation_timeout` ENABLE KEYS */;
UNLOCK TABLES;

LOCK TABLES `product_bank` WRITE;
/*!40000 ALTER TABLE `product_bank` DISABLE KEYS */;
INSERT INTO `product_bank` (`id`, `creationDate`, `lastModifiedDate`, `uuid`)
VALUES(58, '2020-01-07 08:25:13.101171', NULL, '3f800518-4117-11eb-b187-26e0a622eaa4');
/*!40000 ALTER TABLE `product_bank` ENABLE KEYS */;
UNLOCK TABLES;

LOCK TABLES `terms` WRITE;
/*!40000 ALTER TABLE `terms` DISABLE KEYS */;
INSERT INTO `terms` (`id`, `creationDate`, `lastModifiedDate`, `uuid`, `productBank_id`, `validFrom`)
VALUES(516, '2021-06-17 14:17:46.418502', NULL, 'be8fe1ec-e1ca-4696-aa8d-ed19c2030f29', 58, '2021-06-17');
/*!40000 ALTER TABLE `terms` ENABLE KEYS */;
UNLOCK TABLES;



-- Table Dump completed
