--BNIF_MT

--Dumping data for 'b2c_product_tranche' table

USE `comonea_b2c`;
LOCK TABLES `b2c_product_tranche` WRITE;
/*!40000 ALTER TABLE `b2c_product_tranche` DISABLE KEYS */;
INSERT INTO `comonea_b2c`.`b2c_product_tranche` (`id`, `creationDate`, `lastModifiedDate`, `cut_off_amount_currency`, `cut_off_amount`, `depositType`, `endDate`, `max_amount_currency`, `max_amount`, `payInDeadline`, `transactionDate`, `productIdentifier`, `productName`, `productState`, `startDate`, `uuid`, `viewState`, `description`, `min_amount_currency`, `min_amount`, `marketing_rank`, `interestProduct_id`, `investmentChangeOnly`, `interestTaxation`, `canBeProlongated`, `noticePeriodInDays`) VALUES ('24101', '2020-11-04 13:40:27', '2021-06-11 01:00:07', 'EUR', '1000000.00', 'FIXED_TERM', '2026-07-01', 'EUR', '100000.00', '2021-06-28 00:00:00', '2021-06-30 10:00:00', 'BNIFMTMTXXX-FG5Y-2021-07-01', '', 'CREATED', '2021-07-01', 'a6450c11-01f9-46c4-9e2d-911df518785c', 'PUBLISHED', 'Das Festgeld der BNF Bank p.l.c. ist eine Termineinlage, bei der ein vorab vereinbarter Anlagebetrag zwischen {minPayInAmount} EUR und {maxPayInAmount} mit einer festen Laufzeit von {duration} und einem festen Zinssatz von {interestRate}% p.a. angelegt wird.', 'EUR', '1.00', '20', '296', '0', 'SERVICE_BANK', b'1', b'0');
INSERT INTO `comonea_b2c`.`b2c_product_tranche` (`id`, `creationDate`, `depositType`, `max_amount_currency`, `max_amount`, `productIdentifier`, `productName`, `productState`, `uuid`, `viewState`, `description`, `min_amount_currency`, `min_amount`, `marketing_rank`, `interestProduct_id`, `investmentChangeOnly`, `interestTaxation`, `canBeProlongated`, `noticePeriodInDays`) VALUES ('13241', '2018-11-21 11:35:40', 'DIRECT_ACCESS', 'EUR', '100000.00', 'BNIFMTMTXXX-TG', '', 'CONNECTED', '92e8d938-ed81-11e8-bddf-26e0a622eaa4', 'PUBLISHED', 'Das Flexgeld24 der BNF ist eine Spareinlage, bei der ein frei definierbarer Anlagebetrag von bis zu {maxPayInAmount} EUR mit einem variablen Zinssatz von zurzeit {interestRate}% p.a. angelegt werden kann. Die Zinszahlung für das Produkt Flexgeld24 erfolgt zweimal monatlich. Anlagen können zu den Zinszahlungsterminen gestartet und beendet werden, d.h.: Der Kunde hat mit dem Flexgeld24 die Flexibilität, sein Geld jeweils zum 1. und zum 15. eines Monats bzw. dem darauffolgenden Bankarbeitstag ein- oder auszuzahlen. Bitte beachten Sie die Angaben im Produktinformationsblatt zur Hinterlegung von Ausweisdaten.', 'EUR', '1.00', '171', '292', '0', 'SERVICE_BANK', b'1', b'0');
/*!40000 ALTER TABLE `b2c_product_tranche` ENABLE KEYS */;
UNLOCK TABLES;

--Dumping data for table 'b2c_interest_approval'

Use `comonea_b2c`;
LOCK TABLES `b2c_fixed_term_interest_approval` WRITE;
/*!40000 ALTER TABLE `b2c_fixed_term_interest_approval` DISABLE KEYS */;
INSERT INTO `comonea_b2c`.`b2c_fixed_term_interest_approval` (`id`, `creationDate`, `username`, `approvedOn`, `productTranche_id`) VALUES ('16770', '2021-06-09 14:51:46', 'fffa360037seyyua.baran.zeyhle@web.de', '2021-06-09 14:51:46', '24101');/*!40000 ALTER TABLE `b2c_fixed_term_interest_approval` ENABLE KEYS */;
/*!40000 ALTER TABLE `b2c_fixed_term_interest_approval` ENABLE KEYS */;
UNLOCK TABLES;

--Dumping data for table 'b2c_interest_rate'

USE `comonea_b2c`;
LOCK TABLES `b2c_interest_rate` WRITE;
/*!40000 ALTER TABLE `b2c_interest_rate` DISABLE KEYS */;
INSERT INTO `comonea_b2c`.`b2c_interest_rate` (`id`, `creationDate`, `rate`, `validFrom`, `product_id`) VALUES ('28225', '2021-04-09 14:45:37', '0.00150', '2021-05-03', '13241');
INSERT INTO `comonea_b2c`.`b2c_interest_rate` (`id`, `creationDate`, `rate`, `validFrom`, `product_id`) VALUES ('24434', '2020-11-04 13:40:27', '0.00500', '2020-11-04', '24101');
/*!40000 ALTER TABLE `b2c_interest_rate` ENABLE KEYS */;
UNLOCK TABLES;

