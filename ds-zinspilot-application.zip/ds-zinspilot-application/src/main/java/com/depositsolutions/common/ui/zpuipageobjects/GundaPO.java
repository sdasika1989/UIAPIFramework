package com.depositsolutions.common.ui.zpuipageobjects;

import com.depositsolutions.common.restapi.helpers.WebServiceOperations;
import com.depositsolutions.common.restapi.services.Gunda;
import com.depositsolutions.common.reusables.DBReusables;
import com.depositsolutions.common.reusables.GundaServices;
import com.depositsolutions.common.ui.helpers.BaseTestClassUI;
import com.depositsolutions.common.ui.helpers.WebUIOperations;
import com.depositsolutions.common.utils.ConfigManager;
import com.depositsolutions.common.utils.TestLogger;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.testng.Assert;

public class GundaPO extends BaseTestClassUI {
  public static GundaPO singleInstance = null;
  public By Gunda_username = By.xpath("//input[@name='username']");
  public By Gunda_password = By.xpath("//input[@name='password']");
  public By Gunda_Login = By.id("login");
  public By Gunda_Logout = By.xpath("//button[@id='logout']/i");
  public By Gunda_searchCustomer = By.xpath("//input[@name='searchString']");
  public By Gunda_searchInvestment = By.xpath("//div[@id='tranchesOverview_filter']/label/input");
  public By Gunda_payout = By.xpath("//button[text()='Auszahlung']");
  public By Gunda_IC = By.xpath("//button[text()='Anlagewechsel']");
  public By Gunda_prolongation = By.xpath("//button[text()='Prolongation anpassen']");
  public By Gunda_TGamount = By.id("amount");
  public By Gunda_FGamount = By.id("payoutAmount");
  public By Gunda_submit = By.xpath("//button[text()=' Auszahlen']");
  //  public By Gunda_submit1 = By.xpath("//button[@type='submit' and span=' Speichern']");
  public By Gunda_submit1 = By.xpath("//button[text()=' Speichern']");
  public By Gunda_submit3 = By.xpath("//button[text()='Speichern']");
  public By Gunda_tranchesOverview = By.xpath("//table[@id='tranchesOverview']/tbody/tr/td[2]");
  public By Gunda_prolongationType = By.id("prolongationType");
  public By Gunda_ic_target = By.id("payInCode");
  public By Gunda_submit2 = By.xpath("//button[text()=' Wechseln']");
  public By fehlerhafteTicketsButton = By.xpath("//button[@id='logout']");
  public By showCustomer = By.xpath("//button[text()='Kunde anzeigen']");
  public By toEdit = By.xpath("//button[text()='Bearbeiten']");

  public By selectProductCode = By.id("tickets0.product"); // CKVFG12M , PAY_OUT
  public By enterAmount = By.id("tickets0.amount");
  public By selectProductCode1 = By.id("tickets1.product"); // CKVFG12M , PAY_OUT
  public By enterAmount1 = By.id("tickets1.amount");
  public By save = By.xpath("//button[text()=' Ändern']");
  public By selectIDType = By.id("idCardType");
  public By idCardNumber = By.id("idCardNumber");
  public By idCardIssueDate = By.id("idCardIssueDate");
  public By idCardExpiryDate = By.id("idCardExpiryDate");
  public By issuingAuthority = By.id("authority");
  public By issuingCountry = By.id("issuingCountry");
  public By statusCheck = By.xpath("//*[@id='openTicketsTable']/tbody/tr/td[3]");
  public By payoutCheck = By.xpath("//*[@id='openTicketsTable']/tbody/tr[1]/td[2]");
  public By payinCheck = By.xpath("//*[@id='openTicketsTable']/tbody/tr[2]/td[2]");
  public By ticketTable = By.xpath("//*[@id='openTicketsTable']/tbody/tr");
  public By validateTicket = By.xpath("//button[text()='Validieren']");
  public By addTo = By.xpath("//button[text()=' Hinzufügen']");
  public By idcardCopy =
      By.xpath(
          ".//*[@id='page-wrapper']/div[2]/div[2]/div/div[2]/div[2]/div[2]/div/div[2]/div[1]/div/div[2]/p/button");
  public By idcardAuthority =
      By.xpath(
          ".//*[@id='page-wrapper']/div[2]/div[2]/div/div[2]/div[2]/div[2]/div/div[2]/div[2]/div[2]/button");
  public By searchString = By.name("searchString");

  public By Gunda_Ptype = By.xpath("//div[@class='col-xs-10 col-xs-offset-1']");
  public By Gunda_alertText = By.xpath("//p[@class='alert alert-info']");

  public String gundaUrl = ConfigManager.getInstance().getString("gundaUrl");
  public String userName = ConfigManager.getInstance().getString("gundaUsername");
  public String password = ConfigManager.getInstance().getString("gundaPassword");

  public By extinguishIdCardCopy =
      By.xpath(
          "//*[@id=\"page-wrapper\"]/div[2]/div[2]/div/div[2]/div[2]/div[2]/div/div[2]/div[1]/div/div[2]/form/button");
  public By statusCheckKOP = By.xpath("//*[@id='transitToInterestTickets']/tbody/tr/td[2]");

  public static GundaPO getInstance() {
    if (singleInstance == null) {
      singleInstance = new GundaPO();
    }
    return singleInstance;
  }

  /*
   * This method log into Gunda
   */
  public void gundaLogin() {
    ((JavascriptExecutor) DRIVER).executeScript("window.open()");
    WebUIOperations.getInstance().switchTab(1);
    DRIVER.get(gundaUrl);
    waitTillBrowserLoads();
    WebUIOperations.getInstance().sendKeys(DRIVER.findElement(Gunda_username), userName);
    WebUIOperations.getInstance().sendKeys(DRIVER.findElement(Gunda_password), password);
    DRIVER.findElement(Gunda_Login).click();
    waitTillBrowserLoads();
    TestLogger.logInfo("Logged into Gunda successfully");
  }

  /*
   * This method log out of Gunda
   */
  public void gundaLogOut() {
    WebUIOperations.getInstance().waitForElementAndClick(DRIVER.findElement(Gunda_Logout));
    DRIVER.close();
    TestLogger.logInfo("Logged out of Gunda successfully");
  }

  /*
   * This method search with searchString
   * @param searchString
   */
  public void gunda_searchCustomer(String searchString) {
    TestLogger.logInfo("Searching for " + searchString + " in Gunda");
    // Thread.sleep(300);
    DRIVER.findElement(Gunda_searchCustomer).sendKeys(searchString + Keys.ENTER);
    waitTillBrowserLoads();
  }

  /*
   * This method search for Tranche with deposit
   * @param tranche
   */
  public void gunda_searchInvestment(String tranche) {
    TestLogger.logInfo("Searching for deposit: " + tranche);
    WebUIOperations.getInstance()
        .verifyElementIsPresent(DRIVER.findElement(Gunda_tranchesOverview), tranche);
    DRIVER.findElement(Gunda_searchInvestment).click();
    WebUIOperations.getInstance().sendKeys(DRIVER.findElement(Gunda_searchInvestment), tranche);
    WebUIOperations.getInstance()
        .verifyElementIsPresent(DRIVER.findElement(Gunda_tranchesOverview), tranche);
    Assert.assertTrue(
        DRIVER.findElement(Gunda_tranchesOverview).getText().contains(tranche),
        "Investment is not visible in Gunda");
  }

  /*
   * This method clears and enters amount for TG
   * @param amount
   */
  public void gunda_TGamount(String amount) {
    DRIVER.findElement(Gunda_TGamount).clear();
    WebUIOperations.getInstance().sendKeys(DRIVER.findElement(Gunda_TGamount), amount);
  }

  /*
   * This method clears and enters amount for FG
   * @param amount
   */
  public void gunda_FGamount(String amount) {
    DRIVER.findElement(Gunda_FGamount).clear();
    WebUIOperations.getInstance().sendKeys(DRIVER.findElement(Gunda_FGamount), amount);
  }

  /*
   * This method creates payout from gunda for call/TG
   * @param TrancheIdentifier
   * @param amount
   * @param CustomerNumber
   */
  public void gundaPayOut(String TrancheIdentifier, String amount, String CustomerNumber) {
    gundaLogin();
    gunda_searchCustomer(CustomerNumber);
    gunda_searchInvestment(TrancheIdentifier);
    DRIVER.findElement(Gunda_payout).click();
    waitTillBrowserLoads();
    gunda_TGamount(amount + " EUR");
    DRIVER.findElement(Gunda_submit).click();
    TestLogger.logInfo("successfully created Payout from Gunda ");
    gundaLogOut();
    WebUIOperations.getInstance().switchTab(0);
  }

  /*
   * This method sets prolongation type in gunda and validates in shop & gunda
   * @param TrancheIdentifier
   * @param ProlongationType
   * @param amount
   * @param CustomerNumber
   * @param CIA
   */
  public void gundaProlongationSettings(
      String TrancheIdentifier,
      String ProlongationType,
      String amount,
      String CustomerNumber,
      String CIA)
      throws InterruptedException {
    gundaLogin();
    gunda_searchCustomer(CustomerNumber);
    gunda_searchInvestment(TrancheIdentifier);
    DRIVER.findElement(Gunda_prolongation).click();
    String Ptype;
    switch (ProlongationType) {
      case "FullProlongation":
      case "NoPayOut":
        WebUIOperations.getInstance()
            .selectDropdownByText(
                DRIVER.findElement(Gunda_prolongationType), "Prolongation Gesamtbetrag");
        DRIVER.findElement(Gunda_submit1).click();
        waitTillBrowserLoads();
        Assert.assertEquals(
            (WebServiceOperations.getInstance()
                .convertStringToJson(Gunda.getInstance().Gunda_GetCustomer(CustomerNumber))
                .getString(
                    "affiliations[0].customerInterestAccountsDetails["
                        + GundaServices.getInstance().getCIA_Array(CustomerNumber, CIA)
                        + "].prolongationType")),
            "ALL",
            "Gunda status is not correct");
        Assert.assertNull(
            (WebServiceOperations.getInstance()
                .convertStringToJson(Gunda.getInstance().Gunda_GetCustomer(CustomerNumber))
                .getString(
                    "affiliations[0].customerInterestAccountsDetails["
                        + GundaServices.getInstance().getCIA_Array(CustomerNumber, CIA)
                        + "].prolongationPayOutAmount")),
            "Gunda prolongation amount is not correct");
        WebUIOperations.getInstance().switchTab(0);
        ShopLoginLogoutPO.getInstance().shopCache();
        Ptype = DRIVER.findElement(Gunda_Ptype).getText();
        Assert.assertEquals(
            Ptype.substring((Ptype.indexOf("%") + 1), Ptype.length()),
            "\n" + "Autom. Prolongation",
            "Selected prolongation setting is not dispalying correctly");
        break;
      case "PartialProlongation":
      case "PartialPayOut":
        WebUIOperations.getInstance()
            .selectDropdownByText(DRIVER.findElement(Gunda_prolongationType), "Teilprolongation");
        gunda_FGamount(amount + " EUR");
        WebUIOperations.getInstance()
            .waitForElementAndClick(DRIVER.findElement(Gunda_searchCustomer));
        DRIVER.findElement(Gunda_submit1).click();
        waitTillBrowserLoads();
        Assert.assertEquals(
            (WebServiceOperations.getInstance()
                .convertStringToJson(Gunda.getInstance().Gunda_GetCustomer(CustomerNumber))
                .getString(
                    "affiliations[0].customerInterestAccountsDetails["
                        + GundaServices.getInstance().getCIA_Array(CustomerNumber, CIA)
                        + "].prolongationType")),
            "PARTIAL",
            "Gunda status is not correct");
        Assert.assertEquals(
            (WebServiceOperations.getInstance()
                .convertStringToJson(Gunda.getInstance().Gunda_GetCustomer(CustomerNumber))
                .getString(
                    "affiliations[0].customerInterestAccountsDetails["
                        + GundaServices.getInstance().getCIA_Array(CustomerNumber, CIA)
                        + "].prolongationPayOutAmount")),
            DBReusables.getInstance()
                    .formatCurrency1(amount)
                    .substring(1, DBReusables.getInstance().formatCurrency1(amount).length())
                + " EUR",
            "Gunda prolongation amount is not correct");
        WebUIOperations.getInstance().switchTab(0);
        ShopLoginLogoutPO.getInstance().shopCache();
        Ptype = DRIVER.findElement(Gunda_Ptype).getText();
        Assert.assertEquals(
            Ptype.substring((Ptype.indexOf("%") + 2), Ptype.length()),
            "Autom. Prolongation" + "\n" + "Auszahlung: " + amount + " €",
            "Selected prolongation setting is not dispalying correctly");
        break;
      case "NoProlongation":
      case "FullPayOut":
        WebUIOperations.getInstance()
            .selectDropdownByText(DRIVER.findElement(Gunda_prolongationType), "Keine Prolongation");
        DRIVER.findElement(Gunda_submit1).click();
        waitTillBrowserLoads();
        Assert.assertEquals(
            (WebServiceOperations.getInstance()
                .convertStringToJson(Gunda.getInstance().Gunda_GetCustomer(CustomerNumber))
                .getString(
                    "affiliations[0].customerInterestAccountsDetails["
                        + GundaServices.getInstance().getCIA_Array(CustomerNumber, CIA)
                        + "].prolongationType")),
            "NONE",
            "Gunda status is not correct");
        Assert.assertNull(
            (WebServiceOperations.getInstance()
                .convertStringToJson(Gunda.getInstance().Gunda_GetCustomer(CustomerNumber))
                .getString(
                    "affiliations[0].customerInterestAccountsDetails["
                        + GundaServices.getInstance().getCIA_Array(CustomerNumber, CIA)
                        + "].prolongationPayOutAmount")),
            "Gunda prolongation amount is not correct");
        WebUIOperations.getInstance().switchTab(0);
        ShopLoginLogoutPO.getInstance().shopCache();
        Ptype = DRIVER.findElement(Gunda_Ptype).getText();
        Assert.assertEquals(
            Ptype.substring((Ptype.indexOf("%") + 1), Ptype.length()),
            "\n" + "Keine Prolongation",
            "Selected prolongation setting is not dispalying correctly");
        break;
    }
    WebUIOperations.getInstance().switchTab(1);
    gundaLogOut();
    WebUIOperations.getInstance().switchTab(0);
    TestLogger.logInfo(ProlongationType + " is successfully set in Gunda");
    TestLogger.logInfo("validated Prolongation Type in Gunda");
    TestLogger.logInfo("validated Prolongation Type in Shop");
  }

  /*
   * This method creates payout from gunda for call/TG
   * @param TrancheIdentifier
   * @param amount
   * @param CustomerNumber
   */
  public void gundaIc(
      String SourceTrancheIdentifier,
      String TargetTrancheIdentifier,
      String amount,
      String CustomerNumber) {
    gundaLogin();
    gunda_searchCustomer(CustomerNumber);
    gunda_searchInvestment(SourceTrancheIdentifier);
    DRIVER.findElement(Gunda_IC).click();
    waitTillBrowserLoads();
    WebUIOperations.getInstance()
        .selectDropdownByValue(
            DRIVER.findElement(Gunda_ic_target),
            DBReusables.getInstance().getPayInCodeFromTrancheIdentifier(TargetTrancheIdentifier));
    gunda_TGamount(amount + " EUR");
    DRIVER.findElement(Gunda_submit2).click();
    TestLogger.logInfo("successfully created IC from Gunda ");
    gundaLogOut();
    WebUIOperations.getInstance().switchTab(0);
  }

  /*
   * This method creates cancle payin from gunda for call/TG
   * @param TrancheIdentifier
   * @param amount
   * @param CustomerNumber
   */
  public void gundaCancel(String ticketNo, String ticketType, String table, String CustomerNumber) {
    gundaLogin();
    gunda_searchCustomer(CustomerNumber);
    DRIVER
        .findElement(
            By.xpath(
                "//form[@action='/ticket/"
                    + ticketType
                    + "/"
                    + DBReusables.getInstance().getTicket_uuid(ticketNo, table)
                    + "/cancellation/"
                    + CustomerNumber
                    + "']/button"))
        .click();
    WebUIOperations.getInstance().handleWindowPopup("OK");
    if (ticketType.equalsIgnoreCase("TRANSIT_TO_INTEREST")) {
      Assert.assertEquals(
          DRIVER.findElement(Gunda_alertText).getText(),
          "Stornierung erfolgreich durchgeführt.",
          "alert message is incorrect");
    } else {
      WebUIOperations.getInstance()
          .verifyElementPresence(
              DRIVER.findElements(
                  By.xpath(
                      "//form[@action='/ticket/"
                          + ticketType
                          + "/"
                          + DBReusables.getInstance().getTicket_uuid(ticketNo, table)
                          + "/cancellation/"
                          + CustomerNumber
                          + "']/button")),
              "absent");
    }
    TestLogger.logInfo("successfully cancelled from Gunda ");
    gundaLogOut();
    WebUIOperations.getInstance().switchTab(0);
  }
}
