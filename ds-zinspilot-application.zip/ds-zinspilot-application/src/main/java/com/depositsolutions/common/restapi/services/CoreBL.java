package com.depositsolutions.common.restapi.services;

import static io.restassured.RestAssured.given;

import com.depositsolutions.common.restapi.helpers.Endpoints;
import com.depositsolutions.common.utils.ConfigManager;
import com.depositsolutions.common.utils.TestLogger;
import io.restassured.RestAssured;
import java.time.LocalDate;

public class CoreBL {

  public static CoreBL singleInstance = null;
  private String CoreBLUrl = ConfigManager.getInstance().getString("CoreBLUrl");

  public static CoreBL getInstance() {
    if (singleInstance == null) {
      singleInstance = new CoreBL();
    }
    return singleInstance;
  }

  /*
   * This method generates Interest Tickets
   * @param TrancheIdentifier
   * @param ValueDate
   */
  public void createInterestPayoutTickets(String TrancheIdentifier, LocalDate transferDate) {
    RestAssured.baseURI = CoreBLUrl;

    given()
        .header("Content-Type", "application/json")
        .body(
            "{\"productIdentifier\" : \""
                + TrancheIdentifier
                + "\",\"valueDate\" : \""
                + transferDate
                + "\"}")
        .when()
        .post(Endpoints.interestPayoutTickets)
        .then()
        .log()
        .ifError()
        .assertThat()
        .statusCode(200);

    TestLogger.logInfo("API: Create Interest Payout Tickets is successful");
  }

  /*
   * This method imports bankStatement from sps into b2c
   */
  public void importBankstatements() throws InterruptedException {
    RestAssured.baseURI = CoreBLUrl;

    given()
        .header("Content-Type", "application/json")
        .when()
        .post(Endpoints.importBankstatements_b2c)
        .then()
        .log()
        .ifError()
        .assertThat()
        .statusCode(200);
    TestLogger.logInfo("API: CoreBL Bank Statement Import is successful");
  }
  /*
   * This method executes camunda process-closing investment tickets
   */
  public void camundaClosingInvestmentTicket(String RVD) {
    RestAssured.baseURI = CoreBLUrl;

    given()
        .queryParam("requestedValueDate", RVD)
        .header("Content-Type", "application/json")
        .when()
        .put(Endpoints.camunda_CIT)
        .then()
        .log()
        .ifError()
        .assertThat()
        .statusCode(200);
    TestLogger.logInfo("API: Camunda closing investment ticket processing is successful");
  }
}
