package com.depositsolutions.common.ui.zpuipageobjects;

import static com.depositsolutions.common.reusables.TestConstants.CURRENT_WORKING_DIRECTORY;
import static com.depositsolutions.common.reusables.TestConstants.SUTOR_SFTP_DOWNLOAD;

import com.depositsolutions.common.restapi.services.Sbaff;
import com.depositsolutions.common.restapi.services.Sutor;
import com.depositsolutions.common.restapi.services.ZpBL;
import com.depositsolutions.common.reusables.DBReusables;
import com.depositsolutions.common.reusables.DynamicDataReusables;
import com.depositsolutions.common.reusables.SutorServices;
import com.depositsolutions.common.ui.helpers.BaseTestClassUI;
import com.depositsolutions.common.ui.helpers.WebUIOperations;
import com.depositsolutions.common.utils.ConfigManager;
import com.depositsolutions.common.utils.TestLogger;
import java.awt.*;
import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.concurrent.ThreadLocalRandom;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;
import org.testng.Reporter;

public class CustomerRegistrationPO extends BaseTestClassUI {

  public String ACTIVATION_CODE;
  private String filepath =
      CURRENT_WORKING_DIRECTORY + "/src/main/java/com/depositsolutions/common/resources/csvfiles/";
  private static final String SFTP_PATH =
      CURRENT_WORKING_DIRECTORY + ConfigManager.getInstance().getString(SUTOR_SFTP_DOWNLOAD);

  public static By CR_RegistrationButton =
      By.xpath("//*[@class='logged-out-nav-action btn-success logged-out-nav-action']");
  public static By CR_SalutationDropdown = By.id("name.gender"); // name
  public static By CR_TitleDropdown = By.id("name.title"); // name
  public static By CR_FirstnameTextbox = By.id("name.firstName");
  public static By CR_SurnameTextbox = By.id("name.lastName");
  public static By CR_EmailAddressTextbox = By.id("email");
  public static By CR_PasswordTextbox = By.id("password.password");
  public static By CR_ReferralCodeTextbox = By.id("referralCode");
  public static By CR_AcceptCheckbox = By.id("newsletter");
  public static By CR_SignupButton = By.name("_eventId_proceed");
  public static By CR_ActivationCodeTextbox = By.id("code");
  public static By CR_OpeningAccButton = By.id("submitActivationCode");
  public static By CR_PageBody = By.xpath("//*[@class='icn-ssl-large']");
  public static By CR_MaritalStatus = By.id("familySituation");
  public static By CR_DOB = By.id("dayOfBirth");
  public static By CR_PlaceofBirth = By.id("cityOfBirth"); // id
  public static By CR_CountryofBirth = By.id("countryOfBirth");
  public static By CR_StreetNameTextbox = By.id("street");
  public static By CR_StreetNumberTextbox = By.id("streetNumber");
  public static By CR_EmailAddressText = By.id("emailAddress");
  public static By CR_PostCodeTextbox = By.id("postcode");
  public static By CR_TownTextbox = By.id("city");
  public static By CR_LandDropdown = By.id("land");
  public static By CR_PhoneTextbox = By.id("phoneNumber");
  public static By CR_Nationality = By.id("nationality");
  public static By CR_Job = By.id("profession");
  public static By CR_Branch = By.id("professionAdditionalInfo");
  public static By CR_BirthName = By.id("birthName");
  public static By CR_BusinessPurpose = By.id("purposeBusinessRelation");
  public static By CR_IBANtextbox = By.id("iban");
  public static By CR_ContinueButton = By.id("btn-to-opening-account");
  //    public static By CR_ContinueButton = By.xpath("//span[text()='Weiter']");
  public static By CR_BankName = By.id("accountHolder");

  public static By CR_Compliance = By.id("usCompliance");
  public static By CR_Compliance1 = By.id("usCompliance1");
  public static By CR_PrivacyAceept = By.id("privacyAccepted");
  public static By CR_TermsAccept = By.id("termsAndConditionsBankAccepted");
  public static By CR_DepositInfoAccept = By.id("depositorsInformationAccepted");
  public static By CR_DigitalAccAccept = By.id("digitalAccountOpeningAccepted");
  public static By CR_AccOpeningButton = By.id("btn-to-opening-account");
  public static By CR_DownloadCopyButton =
      By.xpath("//span[contains(text(), 'Kopie herunterladen')]");
  public static By CR_ToPostidentPortalButton =
      By.xpath("//span[contains(text(), 'Zum Postident Portal')]");
  public static By CR_PostidentSite = By.xpath("//img[@alt='POSTIDENT']");
  public static By CR_AGB_Link =
      By.xpath(
          "//button[@name='_eventId_proceed']/ancestor::div[2]/preceding-sibling::div/div[2]/div/a[1]");
  public static By CR_Data_Regulation_Link =
      By.xpath(
          "//button[@name='_eventId_proceed']/ancestor::div[2]/preceding-sibling::div/div[2]/div/a[2]");
  public static By TermsAndConditions_Page =
      By.xpath("//h1[contains(text(), 'Allgemeine Geschäftsbedingungen')]");
  public static By DataRegulation_Page = By.xpath("//h1[contains(text(), 'Datenschutz')]");
  public static By LoginHere_Link =
      By.xpath(
          "//button[@name='_eventId_proceed']/ancestor::div[2]/following-sibling::div[1]/div/span/a");
  public static By CR_MrLabel = By.xpath("//label[@for='name.gender']");
  public static By CR_Firstname_ErrMsg =
      By.xpath("//label[@for='name.firstName']/following-sibling::span/span");
  public static By CR_Surname_ErrMsg =
      By.xpath("//label[@for='name.lastName']/following-sibling::span/span");
  public static By CR_EmailAddress_ErrMsg =
      By.xpath("//label[@for='email']/following-sibling::span/span");
  public static By CR_AlreadyRegistered_EmailAddress_ErrMsg =
      By.xpath("//label[@for='email']/following-sibling::span");
  public static By CR_Password_ErrMsg =
      By.xpath("//label[@for='password.password']/following-sibling::span/span");
  public static By CR_AccOpening_Sutorbank_link =
      By.xpath("//a[@href='http://www.sutorbank.de/agb']");
  public static By CR_AccOpening_ContractDoc_link =
      By.xpath("//input[@id='termsAndConditionsBankAccepted']/following-sibling::a");
  public static By CR_AccOpening_DepositInfo_link =
      By.xpath("//input[@id='depositorsInformationAccepted']/following-sibling::a");
  public static By CR_IncorrectActivationCode_ErrorMsg = By.xpath("//span[@id='code.errors']");
  public static CustomerRegistrationPO singleInstance = null;

  public static CustomerRegistrationPO getInstance() {
    if (singleInstance == null) {
      singleInstance = new CustomerRegistrationPO();
    }
    return singleInstance;
  }

  public void launchCustomerRegistrationPortal() {
    DRIVER.findElement(CR_RegistrationButton).click();
    waitTillBrowserLoads();
  }

  public void customerRegistration(
      String fname, String surnme, String email, String pass, String salutation, String title)
      throws InterruptedException {

    TestLogger.logInfo("Click Registration Button");
    launchCustomerRegistrationPortal();
    WebUIOperations.getInstance()
        .selectDropdownByText(DRIVER.findElement(CR_SalutationDropdown), salutation);

    TestLogger.logInfo("Saluation entered is : " + salutation);
    WebUIOperations.getInstance().selectDropdownByText(DRIVER.findElement(CR_TitleDropdown), title);
    TestLogger.logInfo("Title entered is : " + title);

    WebUIOperations.getInstance().sendKeys(DRIVER.findElement(CR_FirstnameTextbox), fname);
    TestLogger.logInfo("Firstname entered is : " + fname);
    DRIVER.findElement(CR_SurnameTextbox).sendKeys(surnme);
    TestLogger.logInfo("Surname entered is : " + surnme);

    DRIVER.findElement(CR_EmailAddressTextbox).sendKeys(email);
    TestLogger.logInfo("Email entered is : " + email);
    enterPassword(pass);
    clickAcceptChekbox();
    WebElement element = DRIVER.findElement(CR_SignupButton);
    JavascriptExecutor executor = (JavascriptExecutor) DRIVER;
    executor.executeScript("arguments[0].click();", element);
    TestLogger.logInfo("Signup button clicked successfully");
  }

  public void accountOpening(
      String sal,
      String tit,
      String fname,
      String surnme,
      String email,
      String phone,
      String dob,
      String Marital,
      String countryOfBirth,
      String street,
      String streetNum,
      String postal,
      String job,
      String birthName,
      String iban,
      String branch)
      throws InterruptedException, AWTException {
    // clickOpeningAccount();

    TestLogger.logInfo("Account Opening");
    verifySaluation(sal);
    verifyTitle(tit);
    verifyFirstname(fname);
    verifyLastname(surnme);
    WebUIOperations.getInstance().scrollDownThePage();
    verifyMaritalStatus(Marital);
    DRIVER.findElement(CR_DOB).sendKeys(dob);
    TestLogger.logInfo("Date of birth etered is : " + dob);

    verifyCountryofBirth(countryOfBirth);
    DRIVER.findElement(CR_StreetNameTextbox).sendKeys(street);
    TestLogger.logInfo("Street name entered is : " + street);
    DRIVER.findElement(CR_StreetNumberTextbox).sendKeys(streetNum);
    TestLogger.logInfo("Street number entered is : " + streetNum);
    verifyEmailAddress(email);
    DRIVER.findElement(CR_PostCodeTextbox).sendKeys(postal);
    TestLogger.logInfo("Postal code entered is : " + postal);
    DRIVER.findElement(CR_TownTextbox).sendKeys(countryOfBirth);
    TestLogger.logInfo("Place entered is : " + countryOfBirth);

    verifyCountry(countryOfBirth);
    WebElement ph = DRIVER.findElement(CR_PhoneTextbox);
    ph.sendKeys(phone);
    ph.sendKeys(Keys.TAB);
    TestLogger.logInfo("Phone number entered is : " + phone);
    verifyNationality(countryOfBirth);
    verifyJob(job);
    DRIVER.findElement(CR_Branch).sendKeys(branch);
    TestLogger.logInfo("Branch entered is : " + branch);
    DRIVER.findElement(CR_BirthName).sendKeys(birthName);
    TestLogger.logInfo("Birth name entered is : " + birthName);

    WebElement element = DRIVER.findElement(CR_Compliance);
    JavascriptExecutor executor = (JavascriptExecutor) DRIVER;
    executor.executeScript("arguments[0].click();", element);
    WebElement element1 = DRIVER.findElement(CR_Compliance1);
    JavascriptExecutor executor1 = (JavascriptExecutor) DRIVER;
    executor1.executeScript("arguments[0].click();", element1);
    DRIVER.findElement(CR_BusinessPurpose);
    verifyBankname();

    WebElement ib = DRIVER.findElement(CR_IBANtextbox);
    ib.sendKeys(iban);
    TestLogger.logInfo("IBAN entered is : " + iban);

    WebUIOperations.getInstance().scrollDownThePage();
    WebElement element2 = DRIVER.findElement(CR_ContinueButton);
    JavascriptExecutor executor2 = (JavascriptExecutor) DRIVER;
    executor2.executeScript("arguments[0].click();", element2);
    Thread.sleep(3000);
    TestLogger.logInfo("Continue button clicked");
  }

  public void accountConfirmation() throws InterruptedException {
    TestLogger.logInfo("Account Confirmation");
    WebUIOperations.getInstance().scrollDownThePage();
    clickAccountCheckbox();
    clickAccountOpeningButton();
  }

  public void VerifyOKEDocument() throws InterruptedException {
    clickDownloadButton();
    // need to uncomment below lines once postident site is reachable
    // clickPortalButton();
    // verifyPostidentSite();
  }

  public void zpIntPopUp(String env) throws InterruptedException {
    Thread.sleep(1000);
    if (env.equalsIgnoreCase("zp_int")) {
      DRIVER.findElement(ShopLoginLogoutPO.getInstance().zpIntPopUp).click();
      TestLogger.logInfo("Pop-up button clicked successfully");
    }
  }

  public void verifyRegisterLink() {
    DRIVER.findElement(ShopLoginLogoutPO.getInstance().zpShopRegisterLink).click();
    TestLogger.logInfo("Register link clicked");
    DRIVER.findElement(CR_MrLabel).isDisplayed();
    TestLogger.logInfo("Register link navigated to home page successfully");
    DRIVER.navigate().back();
  }

  public void verifyForgotPasswordLink() {
    DRIVER.findElement(ShopLoginLogoutPO.getInstance().zpForgotPasswordLink).click();
    TestLogger.logInfo("Forgot password link clicked");
    DRIVER.findElement(ShopLoginLogoutPO.getInstance().forgotPassword).isDisplayed();
    TestLogger.logInfo("Forgot password link navigated to home page successfully");
    DRIVER.navigate().back();
  }

  public void verifyLoginPageLinks() {
    verifyRegisterLink();
    verifyForgotPasswordLink();
  }

  public void signupWithoutEmail() throws InterruptedException {
    TestLogger.logInfo("Registration form validation");
    WebUIOperations.getInstance().waitForElementAndClick(DRIVER.findElement(CR_RegistrationButton));

    WebElement element = DRIVER.findElement(CR_SignupButton);
    JavascriptExecutor executor = (JavascriptExecutor) DRIVER;
    executor.executeScript("arguments[0].click();", element);
    TestLogger.logInfo("Signup button clicked successfully");
  }

  // Verify the AGB link redirected to AGB homepage
  public void verifyTermsConditionsLink() throws InterruptedException {
    WebUIOperations.getInstance().waitForElementAndClick(DRIVER.findElement(CR_RegistrationButton));
    DRIVER.findElement(CR_AGB_Link).click();
    TestLogger.logInfo("Terms and conditions link clicked successfully");
    switchTab(1);
    if (ENV.equalsIgnoreCase("int")) {
      DRIVER.findElement(TermsAndConditions_Page).isDisplayed();
    }
    DRIVER.close();
    TestLogger.logInfo("Terms and conditions redirected to AGB home page successfully");
    switchTab(0);
  }

  // Verify the Data link redirected to Data Regulations homepage
  public void verifyDataRegulationsLink() {
    DRIVER.findElement(CR_Data_Regulation_Link).click();
    switchTab(1);
    TestLogger.logInfo("Data link clicked successfully");
    if (ENV.equalsIgnoreCase("int")) {
      DRIVER.findElement(DataRegulation_Page).isDisplayed();
    }
    DRIVER.close();
    TestLogger.logInfo("Data link redirected to data regulations page successfully");
    switchTab(0);
  }

  // Verify the Data link redirected to Data Regulations homepage
  public void verifyLoginHereLink() {
    DRIVER.findElement(LoginHere_Link).click();
    switchTab(1);
    TestLogger.logInfo("Login here link clicked successfully");
    DRIVER.findElement(ShopLoginLogoutPO.getInstance().zpLogin).isDisplayed();
    DRIVER.close();
    TestLogger.logInfo("Login here link redirected to login page successfully");
    switchTab(0);
  }

  public void verifyRegistrationFormErrMsg() {
    verifyFirstNameErrMsg();
    verifySurnameErrMsg();
    verifyEmailAddressErrMsg();
    verifyPasswordErrMsg();
  }

  public void verifyRegistrationFormLink(String shopUrl) throws InterruptedException {
    verifyTermsConditionsLink();
    verifyDataRegulationsLink();
    verifyLoginHereLink();
    launchUrl(shopUrl);
  }

  public void verifyAccConfirmationLinks() {
    TestLogger.logInfo("Account confirmation page link verification started...");
    verifyAccOpeningSutorBankLink();
    verifyAccOpeningContractDocLink();
    switchTab(3);
    DRIVER.close();
    switchTab(2);
    verifyAccOpeningDepositInfoLink();
    switchTab(3);
    DRIVER.close();
    switchTab(2);
  }

  public void verifyAccOpeningSutorBankLink() {
    DRIVER.findElement(CR_AccOpening_Sutorbank_link).click();
    TestLogger.logInfo("Account confirmation sutor bank link verified successfully");
  }

  public void verifyAccOpeningContractDocLink() {
    DRIVER.findElement(CR_AccOpening_ContractDoc_link).click();
    TestLogger.logInfo("Account confirmation contract document link verified successfully");
  }

  public void verifyAccOpeningDepositInfoLink() {
    DRIVER.findElement(CR_AccOpening_DepositInfo_link).click();
    TestLogger.logInfo("Account confirmation deposit information link verified successfully");
  }

  // Verify firstname error message
  public void verifyFirstNameErrMsg() {
    WebElement errmsgText = DRIVER.findElement(CR_Firstname_ErrMsg);
    errmsgText.isDisplayed();
    String errmsg = errmsgText.getText();
    TestLogger.logInfo("FirstName error message displayed is : " + errmsg);
  }

  // Verify surname error message
  public void verifySurnameErrMsg() {
    WebElement errmsgText = DRIVER.findElement(CR_Surname_ErrMsg);
    errmsgText.isDisplayed();
    String errmsg = errmsgText.getText();
    TestLogger.logInfo("Surname error message displayed is : " + errmsg);
  }

  // Verify email error message
  public void verifyEmailAddressErrMsg() {
    WebElement errmsgText = DRIVER.findElement(CR_EmailAddress_ErrMsg);
    errmsgText.isDisplayed();
    String errmsg = errmsgText.getText();
    TestLogger.logInfo("Email address error message displayed is : " + errmsg);
  }

  // Verify email already registered error message
  public void verifyEmailAddressAlreadyRegistered() {
    WebElement errmsgText = DRIVER.findElement(CR_AlreadyRegistered_EmailAddress_ErrMsg);
    errmsgText.isDisplayed();
    String errmsg = errmsgText.getText();
    TestLogger.logInfo("Already Registered Email address error message displayed : " + errmsg);
  }

  // Verify password error message
  public void verifyPasswordErrMsg() {
    WebElement errmsgText = DRIVER.findElement(CR_Password_ErrMsg);
    errmsgText.isDisplayed();
    String errmsg = errmsgText.getText();
    TestLogger.logInfo("Password error message displayed is : " + errmsg);
  }

  public void closeTabsErrMsg() {
    switchTab(1);
    DRIVER.close();
    switchTab(0);
    DRIVER.close();
    switchTab(0);
  }

  // Enter password in the textbox
  public void enterPassword(String password) {
    DRIVER.findElement(CR_PasswordTextbox).sendKeys(password);
    TestLogger.logInfo("Password entered is : " + password);
  }

  // Click accept button
  public void clickAcceptChekbox() {
    DRIVER.findElement(CR_AcceptCheckbox).click();
    TestLogger.logInfo("Checkbox clicked successfully");
  }

  //    //Enter activation code
  //    public void enterActivationCode(String code) {
  //        driver.findElement(By.id(CR_ActivationCodeTextbox)).sendKeys(code);
  //    }

  public void clickOpeningAccount() throws InterruptedException {
    DRIVER.findElement(CR_OpeningAccButton).click();
    Thread.sleep(2000);
  }

  public void verifySaluation(String saluation) {
    String sal =
        WebUIOperations.getInstance()
            .waitToGetFirstSelectedOption(DRIVER.findElement(CR_SalutationDropdown));
    TestLogger.logInfo("Saluation displayed is : " + sal);
    Assert.assertEquals(sal, saluation);
    TestLogger.logInfo("Correct saluation is displayed");
  }

  public void verifyTitle(String title) {
    Select select = new Select(DRIVER.findElement(CR_TitleDropdown));
    String tit = select.getFirstSelectedOption().getText();
    TestLogger.logInfo("Title displayed is : " + tit);
    Assert.assertEquals(tit, title);
    TestLogger.logInfo("Correct Title is displayed");
  }

  public void verifyFirstname(String firstname) {
    WebElement we = DRIVER.findElement(CR_FirstnameTextbox);
    String text = we.getAttribute("Value");
    TestLogger.logInfo("Firstname displayed is : " + text);
    Assert.assertEquals(text, firstname);
    TestLogger.logInfo("Correct firstname is displayed");
  }

  public void verifyLastname(String surname) {
    String text = DRIVER.findElement(CR_SurnameTextbox).getAttribute("Value");
    TestLogger.logInfo("Lastname displayed is : " + text);
    Assert.assertEquals(text, surname);
    TestLogger.logInfo("Correct lastname is displayed");
  }

  public void verifyMaritalStatus(String marital) {
    Select select = new Select(DRIVER.findElement(CR_MaritalStatus));
    String mar = select.getFirstSelectedOption().getText();
    TestLogger.logInfo("Marital status displayed is : " + mar);
    Assert.assertEquals(mar, marital);
    TestLogger.logInfo("Correct marital status is displayed");
  }

  public void verifyCountryofBirth(String cob) {
    Select select = new Select(DRIVER.findElement(CR_CountryofBirth));
    String country = select.getFirstSelectedOption().getText();
    Assert.assertEquals(country, cob);
    TestLogger.logInfo("Country od borth entered is : " + cob);
  }

  public void verifyEmailAddress(String email) {
    String em = DRIVER.findElement(CR_EmailAddressText).getAttribute("Value");
    Assert.assertEquals(em, email);
    TestLogger.logInfo("Email address displayed is : " + em);
  }

  public void verifyCountry(String country) {
    DRIVER.findElement(CR_PlaceofBirth).sendKeys(country);
    TestLogger.logInfo("Country entered is : " + country);
  }

  public void enterPhone(String phone) {}

  public void verifyNationality(String nationality) {
    Select select = new Select(DRIVER.findElement(CR_Nationality));
    String mar = select.getFirstSelectedOption().getText();
    Assert.assertEquals(mar, nationality);
    TestLogger.logInfo("Nationality displayed is : " + mar);
  }

  public void verifyJob(String job) {
    Select select = new Select(DRIVER.findElement(CR_Job));
    String mar = select.getFirstSelectedOption().getText();
    Assert.assertEquals(mar, job);
    TestLogger.logInfo("Job displayed is : " + job);
  }

  public void switchTab(int tabIndex) {
    ArrayList<String> tabs = new ArrayList<String>(DRIVER.getWindowHandles());
    DRIVER.switchTo().window(tabs.get(tabIndex));
  }

  public void verifyRegistrationButton() {
    WebElement registerButton = DRIVER.findElement(CR_RegistrationButton);
    Assert.assertEquals(true, registerButton.isDisplayed());
    Reporter.log("To Register button is displayed in the login page");
    DRIVER.close();
  }

  public void switchtoIframeMailhog() {
    DRIVER.switchTo().frame("preview-html");
  }

  public void ActivatingCustomer_ActivationCode(String emailAddress, String subject)
      throws SQLException, ClassNotFoundException, InterruptedException {
    String ActivationCode =
        MailHogPO.getInstance().customerRegistration_GetActivationCode(emailAddress, subject);
    switchTab(0);
    DRIVER.findElement(CR_ActivationCodeTextbox).sendKeys(ActivationCode);
    DRIVER.findElement(CR_OpeningAccButton).click();
    waitTillBrowserLoads();
  }

  public void ActivatingCustomer_ActivationLink(String emailAddress, String subject)
      throws SQLException, ClassNotFoundException, InterruptedException {
    String ActivationCode =
        MailHogPO.getInstance().customerRegistration_GetActivationCode(emailAddress, subject);
    switchTab(2);
    DRIVER.findElement(CR_ActivationCodeTextbox).sendKeys(ActivationCode);
    DRIVER.findElement(CR_OpeningAccButton).click();
    waitTillBrowserLoads();
  }

  public void verifyCustomerStatus(String emailAddress, String status) throws SQLException {
    Assert.assertEquals(DBReusables.getInstance().getCustomerState(emailAddress), status);
    TestLogger.logInfo("Correct customer status : " + status);
  }

  public void verifyBankname() {
    WebElement name = DRIVER.findElement(CR_BankName);
    String bankname = name.getText();
    TestLogger.logInfo("Bank name displayed is : " + bankname);
  }

  public void clickAccountCheckbox() {
    WebElement element = DRIVER.findElement(CR_PrivacyAceept);
    JavascriptExecutor executor = (JavascriptExecutor) DRIVER;
    executor.executeScript("arguments[0].click();", element);
    TestLogger.logInfo("Privacy checkbox clicked");

    WebElement element1 = DRIVER.findElement(CR_TermsAccept);
    JavascriptExecutor executor1 = (JavascriptExecutor) DRIVER;
    executor1.executeScript("arguments[0].click();", element1);
    TestLogger.logInfo("Terms accept checkbox clicked");

    WebElement element2 = DRIVER.findElement(CR_DigitalAccAccept);
    JavascriptExecutor executor2 = (JavascriptExecutor) DRIVER;
    executor2.executeScript("arguments[0].click();", element2);
    TestLogger.logInfo("Digital accept checkbox clicked");

    WebElement element3 = DRIVER.findElement(CR_DepositInfoAccept);
    JavascriptExecutor executor3 = (JavascriptExecutor) DRIVER;
    executor3.executeScript("arguments[0].click();", element3);
    TestLogger.logInfo("Deposit info accept checkbox clicked");
  }

  public void clickAccountOpeningButton() throws InterruptedException {
    WebElement element = DRIVER.findElement(CR_AccOpeningButton);
    JavascriptExecutor executor = (JavascriptExecutor) DRIVER;
    executor.executeScript("arguments[0].click();", element);
    Thread.sleep(2000);
    TestLogger.logInfo("Account opening button clicked");
  }

  public void clickDownloadButton() throws InterruptedException {
    Thread.sleep(2000);
    WebElement element = DRIVER.findElement(CR_DownloadCopyButton);
    JavascriptExecutor executor = (JavascriptExecutor) DRIVER;
    executor.executeScript("arguments[0].click();", element);
    Thread.sleep(2000);
    TestLogger.logInfo("Download button clicked");
    /*if (browser.equals("Safari")) {
      ArrayList<String> tabs = new ArrayList<String>(DRIVER.getWindowHandles());
      DRIVER.switchTo().window(tabs.get(1));
      DRIVER.close();
      Thread.sleep(2000);
      DRIVER.switchTo().window(tabs.get(0));
      Thread.sleep(2000);
    }

     */
  }

  public void clickPortalButton() throws InterruptedException {
    WebElement element = DRIVER.findElement(CR_ToPostidentPortalButton);
    JavascriptExecutor executor = (JavascriptExecutor) DRIVER;
    executor.executeScript("arguments[0].click();", element);
    Thread.sleep(2000);
    TestLogger.logInfo("Postident portal button clicked");
  }

  public void verifyPostidentSite() throws InterruptedException {
    Thread.sleep(2000);
    DRIVER.findElement(CR_PostidentSite).isDisplayed();
    TestLogger.logInfo("Postident site verified scuccessfully");
  }

  public void importCustomerListCSV(
      String CustNum,
      String title,
      String gender,
      String lastname,
      String firstname,
      String dob,
      String pob,
      String telnum,
      String name,
      String addStreet,
      String addPlace,
      String FamilyStatus,
      String CustomerIban) {
    // Building csv content
    TestLogger.logInfo("Building csv content...");
    String csvContent =
        generateCustomerListCSVContent(
            CustNum,
            title,
            gender,
            lastname,
            firstname,
            dob,
            pob,
            telnum,
            name,
            addStreet,
            addPlace,
            FamilyStatus,
            CustomerIban);
    TestLogger.logInfo("Csv content builded successfully");
    // Placing csv in sutor path
    TestLogger.logInfo("Placing csv in sutor path...");
    SutorServices.getInstance().putCustomerListCSVFile(csvContent);
    try {
      Thread.sleep(1000);
    } catch (InterruptedException e) {
      e.printStackTrace();
    }
    // import to sbaff&zp_bl
    TestLogger.logInfo("Import to Sbaff...");
    Sbaff.getInstance().importCustomerToSbaffCD();
    TestLogger.logInfo("Sbaff import completed successfully");
    TestLogger.logInfo("Import to zp_bl...");
    ZpBL.getInstance().importCustomerToZP_BL();
    TestLogger.logInfo("zp_bl import completed successfully");
  }

  public void exportSbaffandVerifyState(String CustNo) throws SQLException {
    TestLogger.logInfo("Export customer sbaff started...");
    Sbaff.getInstance().exportCustomerSbaff(CustNo);
    TestLogger.logInfo("Export customer sbaff comleted successfully");
  }

  public void sutorSplitterSFTP(String customerNum) throws IOException {
    TestLogger.logInfo("Outgoing sutor splitter sftp started...");
    Sutor.getInstance().outgoingSutorSplitterSFTP();
    TestLogger.logInfo("Outgoing sutor splitter sftp completed");
    moveXMLfile(customerNum, SFTP_PATH);
    TestLogger.logInfo("Received sutor splitter sftp started...");
    Sutor.getInstance().receivedSutorSplitterSFTP();
    TestLogger.logInfo("Received sutor splitter sftp completed");
    TestLogger.logInfo("Digital account opening sbaff started...");
    Sbaff.getInstance().digitalAccountOpeningSbaff();
    TestLogger.logInfo("Digital account opening sbaff completed");
  }

  public void verifyProcessState(String state, String CustNo) throws SQLException {
    Assert.assertEquals(DBReusables.getInstance().getProcessState(CustNo), state);
    Reporter.log("Process state is : " + state);
  }

  public String generateCustomerListCSVContent(
      String customernumber,
      String title,
      String gender,
      String lastname,
      String firstname,
      String dob,
      String pob,
      String telnum,
      String name,
      String addStreet,
      String addPlace,
      String familyStatus,
      String CustomerIban) {
    String CustomerCsvContent;

    TestLogger.logInfo("Generate customer list csv content started...");
    String sutor = "2782707402";
    String CustomerSutorIban = DynamicDataReusables.getInstance().CTAIban(customernumber);

    try {
      File CustomerListTemplateFile = new File(filepath + "CustomerList_csv");

      CustomerCsvContent = new String(Files.readAllBytes(CustomerListTemplateFile.toPath()));
      CustomerCsvContent =
          CustomerCsvContent.replace(
              "{ID_ACCOPENING}", Integer.toString(ThreadLocalRandom.current().nextInt(1, 999999)));
      CustomerCsvContent = CustomerCsvContent.replace("{KDNR_COMONEA}", customernumber);
      CustomerCsvContent = CustomerCsvContent.replace("{KDNR_SUTOR}", sutor);
      CustomerCsvContent = CustomerCsvContent.replace("{TITEL}", title);
      CustomerCsvContent = CustomerCsvContent.replace("{GENDER}", gender);
      CustomerCsvContent = CustomerCsvContent.replace("{LASTNAME}", lastname);
      CustomerCsvContent = CustomerCsvContent.replace("{FIRSTNAME}", firstname);
      CustomerCsvContent = CustomerCsvContent.replace("{DATE_OF_BIRTH}", dob);
      CustomerCsvContent = CustomerCsvContent.replace("{PLACE_OF_BIRTH}", pob);
      CustomerCsvContent = CustomerCsvContent.replace("{NATIONALIY}", "DE");
      CustomerCsvContent = CustomerCsvContent.replace("{TELEPHONE_NUMBER}", telnum);
      CustomerCsvContent = CustomerCsvContent.replace("{PEP}", "0");
      CustomerCsvContent = CustomerCsvContent.replace("{IBAN_SUTOR}", CustomerSutorIban);
      CustomerCsvContent = CustomerCsvContent.replace("{NAME_BVINHABER}", name);
      CustomerCsvContent = CustomerCsvContent.replace("{IBAN}", CustomerIban);
      CustomerCsvContent = CustomerCsvContent.replace("{TAX_IDENTIFICATION_NUMBER}", "83479651721");
      CustomerCsvContent = CustomerCsvContent.replace("{W_ADDRESS_STREET}", addStreet);
      CustomerCsvContent = CustomerCsvContent.replace("{W_ADDRESS_PLZ}", addPlace);
      CustomerCsvContent = CustomerCsvContent.replace("{W_ADDRESS_CITY}", "Hamburg");
      CustomerCsvContent = CustomerCsvContent.replace("{W_ADDRESS_COUNTRY}", "D");
      CustomerCsvContent = CustomerCsvContent.replace("{COUNTRY_OF_BIRTH}", "DE");
      CustomerCsvContent = CustomerCsvContent.replace("{FAMILY_STATUS}", familyStatus);

    } catch (IOException e) {
      throw new RuntimeException("Could not generate content of customer list file", e);
    }
    TestLogger.logInfo("Generate customer list csv content completed successfully");
    return CustomerCsvContent;
  }

  public void moveXMLfile(String cust, String SFTP_Path) throws IOException {
    String fileName = DBReusables.getInstance().getReferenceID(cust);
    String fpath = SFTP_Path + "/from-DS-Prod/digital_account_opening/";
    File ffolder = new File(fpath);
    if (!ffolder.exists()) {
      ffolder.mkdir();
    }
    String tpath = SFTP_Path + "/to-DS-Prod/digital_account_opening/";
    File tfolder = new File(tpath);
    if (!tfolder.exists()) {
      tfolder.mkdir();
    }
    File dirFrom = new File(fpath + fileName + "_request.ctl");
    File repCtl = new File(tpath + fileName + "_reply.ctl");
    File repXml = new File(tpath + fileName + "_reply.xml");
    File recCtl = new File(tpath + fileName + "_received.ctl");
    File recXml = new File(tpath + fileName + "_received.xml");
    Files.copy(dirFrom.toPath(), repCtl.toPath());
    Files.copy(dirFrom.toPath(), repXml.toPath());
    Files.copy(dirFrom.toPath(), recCtl.toPath());
    Files.copy(dirFrom.toPath(), recXml.toPath());
  }
}
