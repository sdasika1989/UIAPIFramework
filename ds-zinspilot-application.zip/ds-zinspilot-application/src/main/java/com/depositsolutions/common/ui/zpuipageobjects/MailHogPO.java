package com.depositsolutions.common.ui.zpuipageobjects;

import com.depositsolutions.common.ui.helpers.BaseTestClassUI;
import com.depositsolutions.common.ui.helpers.WebUIOperations;
import com.depositsolutions.common.utils.ConfigManager;
import com.depositsolutions.common.utils.TestLogger;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.testng.Assert;

public class MailHogPO extends BaseTestClassUI {
  public static MailHogPO singleInstance = null;
  public By CR_Mailhog_Email_Subject =
      By.xpath("//div[@class='messages container-fluid ng-scope']/div[1]/div[2]/span");
  public By CR_Mailhog_Email_Button = By.xpath("//u[contains(text(), 'E-Mail')]");
  public By CR_Mailhog_Email_Link =
      By.xpath("//u[contains(text(), 'E-Mail')]/ancestor::tr[2]/following-sibling::tr[1]/td/p/a");
  public By CR_Mailhog_Email_Activation_Code =
      By.xpath("//a[contains(text(), 'activateEmail')]/preceding-sibling::span/b");
  public By CR_Mailhog_Email_RefreshButton = By.xpath("//button[@title='Refresh']");
  public By CR_Mailhog_Email_BackButton = By.xpath("//button[@title='Back to Inbox']");
  public By Mailhog_search = By.id("search");
  public String mailHogUrl = ConfigManager.getInstance().getString("mailHogUrl");

  public By passwordResetLink = By.xpath("//*[@role='presentation']/tbody/tr[2]/td/p/a");

  public static MailHogPO getInstance() {
    if (singleInstance == null) {
      singleInstance = new MailHogPO();
    }
    return singleInstance;
  }

  /*
   * This method search in mailhog using searchString
   * @param searchString
   */
  public void performSearchOnMailHog(String searchString) {
    TestLogger.logInfo("Performing Search Operation on MailHog");
    DRIVER.findElement(Mailhog_search).sendKeys(searchString + Keys.ENTER);
  }

  /*
   * This method opens mailhog in new tab
   */
  public void openMailhog() {
    ((JavascriptExecutor) DRIVER).executeScript("window.open()");
    WebUIOperations.getInstance().switchTab(1);
    DRIVER.get(mailHogUrl);
    waitTillBrowserLoads();
    TestLogger.logInfo("MailHog is launched Successfully");
  }
  /*
   * This method closes mailhog
   */
  public void closeMailhog() {
    DRIVER.close();
    TestLogger.logInfo("MailHog is closed Successfully");
  }

  /*
   * This method search for email using email as search string
   * @param CustomerEmail
   * @param subject
   */
  public void verifyEmail(String CustomerEmail, String subject) throws InterruptedException {
    WebUIOperations.getInstance()
        .waitForElementAndClick(DRIVER.findElement(CR_Mailhog_Email_RefreshButton));

    Thread.sleep(2000);
    waitTillBrowserLoads();
    Thread.sleep(2000);
    performSearchOnMailHog(CustomerEmail);
    Thread.sleep(2000);
    Assert.assertEquals(
        DRIVER.findElement(CR_Mailhog_Email_Subject).getText(),
        subject,
        "Expected email is missing in mailhog");
    TestLogger.logInfo("Customer Received Email: " + subject);
    DRIVER.findElement(CR_Mailhog_Email_BackButton).click();
  }
  /*
   * This method search for email and clicks on activation email button
   * @param CustomerEmail
   * @param subject
   */
  public void customerRegistration_ActivationButton(String CustomerEmail, String subject)
      throws InterruptedException {
    openMailhog();
    verifyEmail(CustomerEmail, subject);
    DRIVER.findElement(CR_Mailhog_Email_Subject).click();
    DRIVER.switchTo().frame("preview-html");
    WebUIOperations.getInstance()
        .verifyElementIsPresent(DRIVER.findElement(CR_Mailhog_Email_Link), "CR Email Link");
    Assert.assertEquals(true, DRIVER.findElement(CR_Mailhog_Email_Link).isDisplayed());
    WebUIOperations.getInstance()
        .waitForElementAndClick(DRIVER.findElement(CR_Mailhog_Email_Button));
    TestLogger.logInfo("Clicked activation email button");
    WebUIOperations.getInstance().switchTab(2);
    waitTillBrowserLoads();
  }
  /*
   * This method search for email and fetches Activation code
   * @param CustomerEmail
   * @param subject
   */
  public String customerRegistration_GetActivationCode(String CustomerEmail, String subject)
      throws InterruptedException {
    openMailhog();
    verifyEmail(CustomerEmail, subject);
    DRIVER.findElement(CR_Mailhog_Email_Subject).click();
    DRIVER.switchTo().frame("preview-html");

    WebUIOperations.getInstance()
        .verifyElementIsPresent(DRIVER.findElement(CR_Mailhog_Email_Link), "CR EmailLink");
    WebUIOperations.getInstance()
        .verifyElementIsPresent(
            DRIVER.findElement(CR_Mailhog_Email_Button), "Email Confirmation Button");

    TestLogger.logInfo("Activation email button is displayed");
    String ACTIVATION_CODE = DRIVER.findElement(CR_Mailhog_Email_Activation_Code).getText();

    TestLogger.logInfo("Activation Code : " + ACTIVATION_CODE);
    WebUIOperations.getInstance()
        .verifyElementIsPresent(DRIVER.findElement(CR_Mailhog_Email_Link), "CR EmailLink");
    TestLogger.logInfo("Activation email link is displayed");
    DRIVER.findElement(CR_Mailhog_Email_Link).click();
    TestLogger.logInfo(
        "By clicking on Email confirmation button it redirected to OKE form successfully");
    return ACTIVATION_CODE;
  }

  /*
   * This method search for email and fetches Activation code
   * @param CustomerEmail
   * @param subject
   */
  public void clickPasswordResetLink(String CustomerEmail, String subject)
      throws InterruptedException {

    verifyEmail(CustomerEmail, subject);
    DRIVER.findElement(CR_Mailhog_Email_Subject).click();
    DRIVER.switchTo().frame("preview-html");

    WebUIOperations.getInstance().waitForElementAndClick(DRIVER.findElement(passwordResetLink));

    waitTillBrowserLoads();
  }
}
