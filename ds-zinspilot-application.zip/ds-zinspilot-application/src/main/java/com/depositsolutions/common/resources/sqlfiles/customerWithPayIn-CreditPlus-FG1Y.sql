USE `comonea_b2c`;

-- For `b2c_customer`
LOCK TABLES `b2c_customer` WRITE;
/*!40000 ALTER TABLE `b2c_customer` DISABLE KEYS */;
INSERT INTO `b2c_customer` VALUES (470,'2015-01-16 09:20:38','2015-11-01 08:07:35','11158126','FULLY_REGISTERED','11158126@comoneto.com','fffHannes','fffRyjikh','NONE','MALE','$2a$12$sQKljQ4OLwf2YvB3QXy90Ok5eedQptcp6Sc6zlppsiMz.tL.hMNLu','UNRESTRICTED','eab38837-d71e-4f9f-9e69-6c207a5dc2f1',0,1,0);
/*!40000 ALTER TABLE `b2c_customer` ENABLE KEYS */;
UNLOCK TABLES;

-- For `b2c_customer_service_bank_affiliation`
LOCK TABLES `b2c_customer_service_bank_affiliation` WRITE;
/*!40000 ALTER TABLE `b2c_customer_service_bank_affiliation` DISABLE KEYS */;
INSERT INTO `b2c_customer_service_bank_affiliation` VALUES (379,'2015-04-30 17:58:56','2015-05-06 08:27:03',NULL,'2015-04-30','OWNERSHIP_VALIDATED','0c5b791d-b4f7-4032-b37a-88af994f35bf',470,5,'2015-05-06 08:27:03',0);
/*!40000 ALTER TABLE `b2c_customer_service_bank_affiliation` ENABLE KEYS */;
UNLOCK TABLES;

-- For `b2c_depot_bank_account`
LOCK TABLES `b2c_depot_bank_account` WRITE;
/*!40000 ALTER TABLE `b2c_depot_bank_account` DISABLE KEYS */;
INSERT INTO `b2c_depot_bank_account` VALUES (384,'2015-04-30 17:58:56','2016-05-25 15:57:47','fffAlessandro von Pinnock','DE81202308006564946146','5e6959c6-5ce3-4871-ad4b-1f519a67ff6d',5,'EUR');
/*!40000 ALTER TABLE `b2c_depot_bank_account` ENABLE KEYS */;
UNLOCK TABLES;

-- For `b2c_customer_depot`
LOCK TABLES `b2c_customer_depot` WRITE;
/*!40000 ALTER TABLE `b2c_customer_depot` DISABLE KEYS */;
INSERT INTO `b2c_customer_depot` VALUES (371,'2015-04-30 17:58:56','2015-04-30 17:58:56',1,'43cc1797-bced-441e-b0a2-351ac662d95d',384,379);
/*!40000 ALTER TABLE `b2c_customer_depot` ENABLE KEYS */;
UNLOCK TABLES;


-- For `b2c_customer_transit_account`
LOCK TABLES `b2c_customer_transit_account` WRITE;
/*!40000 ALTER TABLE `b2c_customer_transit_account` DISABLE KEYS */;
INSERT INTO `b2c_customer_transit_account` VALUES (219,'2015-05-06 08:27:02',NULL,'f602b680-b42f-4086-a33f-8c070fe1d9d4',371,3,'EUR');
/*!40000 ALTER TABLE `b2c_customer_transit_account` ENABLE KEYS */;
UNLOCK TABLES;

-- For `b2c_unique_trustor`
LOCK TABLES `b2c_unique_trustor` WRITE;
/*!40000 ALTER TABLE `b2c_unique_trustor` DISABLE KEYS */;
INSERT INTO `b2c_unique_trustor` VALUES ('3','2015-01-16 09:20:38',NULL,'11158126',NULL);
/*!40000 ALTER TABLE `b2c_unique_trustor` ENABLE KEYS */;

-- For `b2c_trustor`
LOCK TABLES `b2c_trustor` WRITE;
/*!40000 ALTER TABLE `b2c_trustor` DISABLE KEYS */;
INSERT INTO `b2c_trustor` VALUES ('365','379','2015-04-30 17:58:56','2020-08-12 11:34:49','11158126',1,'3','1');
/*!40000 ALTER TABLE `b2c_trustor` ENABLE KEYS */;

-- For `b2c_trustor_service_bank_data`
LOCK TABLES `b2c_trustor_service_bank_data` WRITE;
/*!40000 ALTER TABLE `b2c_trustor_service_bank_data` DISABLE KEYS */;
INSERT INTO `b2c_trustor_service_bank_data` VALUES ('365','2015-04-30 17:58:56','2021-01-26 11:37:03','365',NULL,NULL,'Allensteiner Str.','30a','55151','Filipowskiburg','DE','fffJolie','fffStoutjesdijk','Zoe','NONE','MALE','DE','+41-143-6343974','false','1971-12-08','Dennydorf','2782708303','DE-RP','fffHausfrau','Wirtschaftlich unselbständige Privatpersonen','90208061342','97A','DE','222',1,'SINGLE','NONE','VJ4S21ATI','Klein Melanie, TH',NULL,NULL,NULL,'1561200','Holzer Weg','736','65328','Groß Pascalberg','Nigeria','0',NULL,'','A',NULL,NULL,'','','A - A   - Aktiv');
/*!40000 ALTER TABLE `b2c_trustor_service_bank_data` ENABLE KEYS */;

-- For `b2c_trustor_country_of_birth_override`
LOCK TABLES `b2c_trustor_country_of_birth_override` WRITE;
/*!40000 ALTER TABLE `b2c_trustor_country_of_birth_override` DISABLE KEYS */;
INSERT INTO `b2c_trustor_country_of_birth_override` VALUES ('404','2016-03-04 02:31:34',NULL,'365','DE');
/*!40000 ALTER TABLE `b2c_trustor_country_of_birth_override` ENABLE KEYS */;

-- For `b2c_trustor_country_of_birth_override_audit_record`
LOCK TABLES `b2c_trustor_country_of_birth_override_audit_record` WRITE;
/*!40000 ALTER TABLE `b2c_trustor_country_of_birth_override_audit_record` DISABLE KEYS */;
INSERT INTO `b2c_trustor_country_of_birth_override_audit_record` VALUES ('365','2016-03-04 02:31:34','2016-03-04 02:31:35','INITIAL_CREATON_EMPTY_RECORD',NULL,'404',NULL,NULL);
/*!40000 ALTER TABLE `b2c_trustor_country_of_birth_override_audit_record` ENABLE KEYS */;

-- For `b2c_trustor_phone_number_override`
LOCK TABLES `b2c_trustor_phone_number_override` WRITE;
/*!40000 ALTER TABLE `b2c_trustor_phone_number_override` DISABLE KEYS */;
INSERT INTO `b2c_trustor_phone_number_override` VALUES ('651','2016-03-04 02:28:53',NULL,'365',NULL);
/*!40000 ALTER TABLE `b2c_trustor_phone_number_override` ENABLE KEYS */;

-- For `b2c_trustor_phone_number_override_audit_record`
LOCK TABLES `b2c_trustor_phone_number_override_audit_record` WRITE;
/*!40000 ALTER TABLE `b2c_trustor_phone_number_override_audit_record` DISABLE KEYS */;
INSERT INTO `b2c_trustor_phone_number_override_audit_record` VALUES ('365','2021-06-03 17:16:12',NULL,'INITIAL_CREATON_EMPTY_RECORD',NULL,'651',NULL,NULL);
/*!40000 ALTER TABLE `b2c_trustor_phone_number_override_audit_record` ENABLE KEYS */;

-- For `b2c_customer_state_history`
LOCK TABLES `b2c_customer_state_history` WRITE;
/*!40000 ALTER TABLE `b2c_customer_state_history` DISABLE KEYS */;
INSERT INTO `b2c_customer_state_history` VALUES ('1','2021-06-03 17:15:20',NULL,'REGISTERED','470');
INSERT INTO `b2c_customer_state_history` VALUES ('2','2021-06-03 17:15:40',NULL,'ACTIVATED','470');
INSERT INTO `b2c_customer_state_history` VALUES ('3','2021-06-03 17:16:13',NULL,'FULLY_REGISTERED','470');
/*!40000 ALTER TABLE `b2c_customer_state_history` ENABLE KEYS */;

-- For `b2c_customer_activation_code`
LOCK TABLES `b2c_customer_activation_code` WRITE;
/*!40000 ALTER TABLE `b2c_customer_activation_code` DISABLE KEYS */;
INSERT INTO `b2c_customer_activation_code` VALUES ('1','2021-06-03 17:15:20',NULL,'327946','470');
/*!40000 ALTER TABLE `b2c_customer_activation_code` ENABLE KEYS */;

-- For `b2c_customer_accountstatus_history`
LOCK TABLES `b2c_customer_accountstatus_history` WRITE;
/*!40000 ALTER TABLE `b2c_customer_accountstatus_history` DISABLE KEYS */;
INSERT INTO `b2c_customer_accountstatus_history` VALUES ('707452','2021-05-17 05:44:58',NULL,'470','ACTIVE','System-Login','Der Account wurde aktiviert');
/*!40000 ALTER TABLE `b2c_customer_accountstatus_history` ENABLE KEYS */;

-- For `b2c_customer_interest_account`
LOCK TABLES `b2c_customer_interest_account` WRITE;
/*!40000 ALTER TABLE `b2c_customer_interest_account` DISABLE KEYS */;
INSERT INTO `b2c_customer_interest_account` VALUES ('1','2020-05-20 07:47:13',NULL,'4855127b-0991-486b-8c77-d4abbff49095','219','371','24375','0','0',NULL,NULL,NULL,'EUR',NULL,NULL);
/*!40000 ALTER TABLE `b2c_customer_interest_account` ENABLE KEYS */;
UNLOCK TABLES;

-- For `b2c_customer_interest_account_booking`
LOCK TABLES `b2c_customer_interest_account_booking` WRITE;
/*!40000 ALTER TABLE `b2c_customer_interest_account_booking` DISABLE KEYS */;
INSERT INTO `b2c_customer_interest_account_booking` VALUES ('1','2021-02-15 07:18:06',NULL,NULL,'Einzahlung fuer Produkt CreditPlusFG12M','TRANSIT_TO_INTEREST','8fcc974b-65f6-46f0-b6f0-66576ac298ea','EUR','9922.00','2021-02-15','1',NULL);
/*!40000 ALTER TABLE `b2c_customer_interest_account_booking` ENABLE KEYS */;
UNLOCK TABLES;

-- For `b2c_customer_transit_account_booking`
LOCK TABLES `b2c_customer_transit_account_booking` WRITE;
/*!40000 ALTER TABLE `b2c_customer_transit_account_booking` DISABLE KEYS */;
INSERT INTO `b2c_customer_transit_account_booking` VALUES ('1','2021-01-18 07:17:17',NULL,NULL,'CreditPlusFG12M','PAY_IN','28216565-e744-4b52-8561-3bc2bb68fc68','EUR','239922.00','2021-02-01','219',NULL);
INSERT INTO `b2c_customer_transit_account_booking` VALUES (2,'2021-02-01 05:02:10',NULL,NULL,'Einzahlung fuer Produkt CreditPlusTG','TRANSIT_TO_INTEREST','c2613831-c477-45bb-9182-51f7a27e980e','EUR','-9922.00','2021-02-01',219,NULL);
/*!40000 ALTER TABLE `b2c_customer_transit_account_booking` ENABLE KEYS */;
UNLOCK TABLES;

-- For `b2c_service_bank_transit_account_booking`
LOCK TABLES `b2c_service_bank_transit_account_booking` WRITE;
/*!40000 ALTER TABLE `b2c_service_bank_transit_account_booking` DISABLE KEYS */;
INSERT INTO `b2c_service_bank_transit_account_booking` VALUES (1,'2021-01-18 07:17:17',NULL,NULL,'CreditPlusFG12M','PAY_IN','28216565-e744-4b52-8561-3bc2bb68fc68','EUR','239922.00','2021-02-01',NULL,NULL,3);
INSERT INTO `b2c_service_bank_transit_account_booking` VALUES (2,'2021-02-01 05:02:10',NULL,NULL,'Einzahlung fuer Produkt CreditPlusTG','TRANSIT_TO_INTEREST','c2613831-c477-45bb-9182-51f7a27e980e','EUR','-9922.00','2021-02-01',NULL,NULL,3);
/*!40000 ALTER TABLE ` b2c_service_bank_transit_account_booking` ENABLE KEYS */;
UNLOCK TABLES;

-- For `b2c_product_bank_interest_account_booking`
LOCK TABLES `b2c_product_bank_interest_account_booking` WRITE;
/*!40000 ALTER TABLE `b2c_product_bank_interest_account_booking` DISABLE KEYS */;
INSERT INTO `b2c_product_bank_interest_account_booking` VALUES ('1','2021-02-01 07:18:06',NULL,NULL,'Einzahlung fuer Produkt CreditPlusFG12M','TRANSIT_TO_INTEREST','b3f2bdd0-ef87-436b-ba68-0077798c1932','EUR','9922.00','2021-02-01','24375',NULL);
/*!40000 ALTER TABLE `b2c_product_bank_interest_account_booking` ENABLE KEYS */;
UNLOCK TABLES;
