package com.depositsolutions.common.reusables;

import com.depositsolutions.common.restapi.helpers.WebServiceOperations;
import com.depositsolutions.common.restapi.services.Gunda;
import com.depositsolutions.common.utils.TestLogger;
import io.restassured.path.json.JsonPath;
import org.testng.Assert;

public class GundaServices {
  public static GundaServices singleInstance = null;

  public static GundaServices getInstance() {
    if (singleInstance == null) {
      singleInstance = new GundaServices();
    }
    return singleInstance;
  }

  /*
   * This method gets array number of CIA
   * @param customerNumber
   * @param CIA
   * @return
   */
  public int getCIA_Array(String customerNumber, String CIA) throws InterruptedException {
    JsonPath js = new JsonPath(Gunda.getInstance().Gunda_GetCustomer(customerNumber));
    int count = js.getInt("affiliations[0].customerInterestAccountsDetails.size()");
    int num = 0;
    for (int i = 0; i < count; i++) {
      String uuid =
          js.getString(
              "affiliations[0].customerInterestAccountsDetails[" + i + "].interestAccount.uuid");
      if (uuid.equalsIgnoreCase(DBReusables.getInstance().getCIA_UUID(CIA))) {
        num = i;
        break;
      }
    }
    return num;
  }

  /*
   * This method gets array number of Pending Ticket
   * @param customerNumber
   * @param uuid_exp
   * @return
   */
  public int getInprogressTicket_Array(String customerNumber, String uuid_exp)
      throws InterruptedException {
    JsonPath js = new JsonPath(Gunda.getInstance().Gunda_GetCustomer(customerNumber));
    int count = js.getInt("notExecutedTickets.size()");
    int num = 0;
    for (int i = 0; i < count; i++) {
      String uuid = js.getString("notExecutedTickets[" + i + "].uuid");
      if (uuid.equalsIgnoreCase(uuid_exp)) {
        num = i;
        break;
      }
    }
    return num;
  }

  /*
   * This method validates Pending Payout and Interest Tickets
   * @param customerNumber
   * @param i2tPTicket_id
   * @param SourceTrancheIdentifier
   * @param PayOutAmount
   * @param i2tITicket_id
   * @param InterestAmount
   * @param TargetTrancheIdentifier
   * @param PayOutType
   */
  public void payOutValidateInprogressTicket(
      String CustomerNumber,
      String i2tPTicket_id,
      String SourceTrancheIdentifier,
      String PayOutAmount,
      String i2tITicket_id,
      String InterestAmount,
      String TargetTrancheIdentifier,
      String PayOutType)
      throws InterruptedException {
    if (!PayOutType.equalsIgnoreCase("FullProlongation")) {
      int num =
          getInprogressTicket_Array(
              CustomerNumber,
              DBReusables.getInstance()
                  .getTicket_uuid(i2tPTicket_id, DBReusables.getInstance().ci2tTable));
      Assert.assertEquals(
          (WebServiceOperations.getInstance()
              .convertStringToJson(Gunda.getInstance().Gunda_GetCustomer(CustomerNumber))
              .getString("notExecutedTickets[" + num + "].productIdentifier")),
          SourceTrancheIdentifier,
          "Gunda TrancheIdentifier is not correct");
      Assert.assertEquals(
          (WebServiceOperations.getInstance()
              .convertStringToJson(Gunda.getInstance().Gunda_GetCustomer(CustomerNumber))
              .getString("notExecutedTickets[" + num + "].ticketType")),
          "INTEREST_TO_TRANSIT",
          "Gunda ticketType is not correct");
      Assert.assertEquals(
          (WebServiceOperations.getInstance()
              .convertStringToJson(Gunda.getInstance().Gunda_GetCustomer(CustomerNumber))
              .getString("notExecutedTickets[" + num + "].ticketState")),
          "CREATED",
          "Gunda ticketState is not correct");
      Assert.assertEquals(
          (WebServiceOperations.getInstance()
              .convertStringToJson(Gunda.getInstance().Gunda_GetCustomer(CustomerNumber))
              .getString("notExecutedTickets[" + num + "].gundaTicketCategory")),
          "PRINCIPAL",
          "Gunda gundaTicketCategory is not correct");
      Assert.assertEquals(
          (WebServiceOperations.getInstance()
              .convertStringToJson(Gunda.getInstance().Gunda_GetCustomer(CustomerNumber))
              .getString("notExecutedTickets[" + num + "].amount")),
          DBReusables.getInstance()
                  .formatCurrency1(PayOutAmount)
                  .substring(1, DBReusables.getInstance().formatCurrency1(PayOutAmount).length())
              + " EUR",
          "Gunda amount is not correct");

      int num1 =
          getInprogressTicket_Array(
              CustomerNumber,
              DBReusables.getInstance()
                  .getTicket_uuid(i2tPTicket_id, DBReusables.getInstance().ct2cTable));
      Assert.assertEquals(
          (WebServiceOperations.getInstance()
              .convertStringToJson(Gunda.getInstance().Gunda_GetCustomer(CustomerNumber))
              .getString("notExecutedTickets[" + num1 + "].productIdentifier")),
          SourceTrancheIdentifier,
          "Gunda TrancheIdentifier is not correct");
      Assert.assertEquals(
          (WebServiceOperations.getInstance()
              .convertStringToJson(Gunda.getInstance().Gunda_GetCustomer(CustomerNumber))
              .getString("notExecutedTickets[" + num1 + "].ticketType")),
          "TRANSIT_TO_CUSTOMER",
          "Gunda ticketType is not correct");
      Assert.assertEquals(
          (WebServiceOperations.getInstance()
              .convertStringToJson(Gunda.getInstance().Gunda_GetCustomer(CustomerNumber))
              .getString("notExecutedTickets[" + num1 + "].ticketState")),
          "CREATED",
          "Gunda ticketState is not correct");
      Assert.assertEquals(
          (WebServiceOperations.getInstance()
              .convertStringToJson(Gunda.getInstance().Gunda_GetCustomer(CustomerNumber))
              .getString("notExecutedTickets[" + num1 + "].gundaTicketCategory")),
          "PRINCIPAL",
          "Gunda gundaTicketCategory is not correct");
      Assert.assertEquals(
          (WebServiceOperations.getInstance()
              .convertStringToJson(Gunda.getInstance().Gunda_GetCustomer(CustomerNumber))
              .getString("notExecutedTickets[" + num1 + "].amount")),
          DBReusables.getInstance()
                  .formatCurrency1(PayOutAmount)
                  .substring(1, DBReusables.getInstance().formatCurrency1(PayOutAmount).length())
              + " EUR",
          "Gunda amount is not correct");
      if (SourceTrancheIdentifier.contains("-TG")) {
        Assert.assertEquals(
            (WebServiceOperations.getInstance()
                .convertStringToJson(Gunda.getInstance().Gunda_GetCustomer(CustomerNumber))
                .getString("notExecutedTickets[" + num + "].expectedValueDate")),
            DBReusables.getInstance().getTrancheStartDate(SourceTrancheIdentifier),
            "Gunda expectedValueDate is not correct");
        Assert.assertEquals(
            (WebServiceOperations.getInstance()
                .convertStringToJson(Gunda.getInstance().Gunda_GetCustomer(CustomerNumber))
                .getString("notExecutedTickets[" + num1 + "].expectedValueDate")),
            DBReusables.getInstance().getTrancheStartDate(SourceTrancheIdentifier),
            "Gunda expectedValueDate is not correct");
      } else {
        Assert.assertEquals(
            (WebServiceOperations.getInstance()
                .convertStringToJson(Gunda.getInstance().Gunda_GetCustomer(CustomerNumber))
                .getString("notExecutedTickets[" + num + "].expectedValueDate")),
            DBReusables.getInstance().getTrancheStartDate(TargetTrancheIdentifier),
            "Gunda expectedValueDate is not correct");
        Assert.assertEquals(
            (WebServiceOperations.getInstance()
                .convertStringToJson(Gunda.getInstance().Gunda_GetCustomer(CustomerNumber))
                .getString("notExecutedTickets[" + num1 + "].expectedValueDate")),
            DBReusables.getInstance().getTrancheStartDate(TargetTrancheIdentifier),
            "Gunda expectedValueDate is not correct");
      }
    }
    int num2 =
        getInprogressTicket_Array(
            CustomerNumber,
            DBReusables.getInstance()
                .getTicket_uuid(i2tITicket_id, DBReusables.getInstance().ci2tTable));
    Assert.assertEquals(
        (WebServiceOperations.getInstance()
            .convertStringToJson(Gunda.getInstance().Gunda_GetCustomer(CustomerNumber))
            .getString("notExecutedTickets[" + num2 + "].productIdentifier")),
        SourceTrancheIdentifier,
        "Gunda TrancheIdentifier is not correct");
    Assert.assertEquals(
        (WebServiceOperations.getInstance()
            .convertStringToJson(Gunda.getInstance().Gunda_GetCustomer(CustomerNumber))
            .getString("notExecutedTickets[" + num2 + "].ticketType")),
        "INTEREST_TO_TRANSIT",
        "Gunda ticketType is not correct");
    Assert.assertEquals(
        (WebServiceOperations.getInstance()
            .convertStringToJson(Gunda.getInstance().Gunda_GetCustomer(CustomerNumber))
            .getString("notExecutedTickets[" + num2 + "].ticketState")),
        "CREATED",
        "Gunda ticketState is not correct");
    Assert.assertEquals(
        (WebServiceOperations.getInstance()
            .convertStringToJson(Gunda.getInstance().Gunda_GetCustomer(CustomerNumber))
            .getString("notExecutedTickets[" + num2 + "].gundaTicketCategory")),
        "GROSS_INTEREST",
        "Gunda gundaTicketCategory is not correct");
    Assert.assertEquals(
        (WebServiceOperations.getInstance()
            .convertStringToJson(Gunda.getInstance().Gunda_GetCustomer(CustomerNumber))
            .getString("notExecutedTickets[" + num2 + "].amount")),
        DBReusables.getInstance()
                .formatCurrency1(InterestAmount)
                .substring(1, DBReusables.getInstance().formatCurrency1(InterestAmount).length())
            + " EUR",
        "Gunda amount is not correct");

    int num3 =
        getInprogressTicket_Array(
            CustomerNumber,
            DBReusables.getInstance()
                .getTicket_uuid(i2tITicket_id, DBReusables.getInstance().ct2cTable));
    Assert.assertEquals(
        (WebServiceOperations.getInstance()
            .convertStringToJson(Gunda.getInstance().Gunda_GetCustomer(CustomerNumber))
            .getString("notExecutedTickets[" + num3 + "].productIdentifier")),
        SourceTrancheIdentifier,
        "Gunda TrancheIdentifier is not correct");
    Assert.assertEquals(
        (WebServiceOperations.getInstance()
            .convertStringToJson(Gunda.getInstance().Gunda_GetCustomer(CustomerNumber))
            .getString("notExecutedTickets[" + num3 + "].ticketType")),
        "TRANSIT_TO_CUSTOMER",
        "Gunda ticketType is not correct");
    Assert.assertEquals(
        (WebServiceOperations.getInstance()
            .convertStringToJson(Gunda.getInstance().Gunda_GetCustomer(CustomerNumber))
            .getString("notExecutedTickets[" + num3 + "].ticketState")),
        "CREATED",
        "Gunda ticketState is not correct");
    Assert.assertEquals(
        (WebServiceOperations.getInstance()
            .convertStringToJson(Gunda.getInstance().Gunda_GetCustomer(CustomerNumber))
            .getString("notExecutedTickets[" + num3 + "].gundaTicketCategory")),
        "GROSS_INTEREST",
        "Gunda gundaTicketCategory is not correct");
    Assert.assertEquals(
        (WebServiceOperations.getInstance()
            .convertStringToJson(Gunda.getInstance().Gunda_GetCustomer(CustomerNumber))
            .getString("notExecutedTickets[" + num3 + "].amount")),
        DBReusables.getInstance()
                .formatCurrency1(InterestAmount)
                .substring(1, DBReusables.getInstance().formatCurrency1(InterestAmount).length())
            + " EUR",
        "Gunda amount is not correct");
    if (SourceTrancheIdentifier.contains("-TG")) {
      Assert.assertEquals(
          (WebServiceOperations.getInstance()
              .convertStringToJson(Gunda.getInstance().Gunda_GetCustomer(CustomerNumber))
              .getString("notExecutedTickets[" + num3 + "].expectedValueDate")),
          DBReusables.getInstance().getTrancheStartDate(SourceTrancheIdentifier),
          "Gunda expectedValueDate is not correct");
      Assert.assertEquals(
          (WebServiceOperations.getInstance()
              .convertStringToJson(Gunda.getInstance().Gunda_GetCustomer(CustomerNumber))
              .getString("notExecutedTickets[" + num2 + "].expectedValueDate")),
          DBReusables.getInstance().getTrancheStartDate(SourceTrancheIdentifier),
          "Gunda expectedValueDate is not correct");
    } else {
      Assert.assertEquals(
          (WebServiceOperations.getInstance()
              .convertStringToJson(Gunda.getInstance().Gunda_GetCustomer(CustomerNumber))
              .getString("notExecutedTickets[" + num3 + "].expectedValueDate")),
          DBReusables.getInstance().getTrancheStartDate(TargetTrancheIdentifier),
          "Gunda expectedValueDate is not correct");
      Assert.assertEquals(
          (WebServiceOperations.getInstance()
              .convertStringToJson(Gunda.getInstance().Gunda_GetCustomer(CustomerNumber))
              .getString("notExecutedTickets[" + num2 + "].expectedValueDate")),
          DBReusables.getInstance().getTrancheStartDate(TargetTrancheIdentifier),
          "Gunda expectedValueDate is not correct");
    }

    TestLogger.logInfo(
        "Successfully validated Inprogress Principal & Interest ticket validations in Gunda");
  }

  /*
   * This method validates Pending Payout and Interest Tickets
   * @param customerNumber
   * @param SourceTrancheIdentifier
   * @param i2tITicket_id
   * @param InterestAmount
   * @param TargetTrancheIdentifier
   * @param t2cITicket_id
   */
  public void icValidateInprogressTicket(
      String CustomerNumber,
      String SourceTrancheIdentifier,
      String i2tITicket_id,
      String InterestAmount,
      String TargetTrancheIdentifier,
      String t2cITicket_id)
      throws InterruptedException {
    int num2 =
        getInprogressTicket_Array(
            CustomerNumber,
            DBReusables.getInstance()
                .getTicket_uuid(i2tITicket_id, DBReusables.getInstance().ci2tTable));
    Assert.assertEquals(
        (WebServiceOperations.getInstance()
            .convertStringToJson(Gunda.getInstance().Gunda_GetCustomer(CustomerNumber))
            .getString("notExecutedTickets[" + num2 + "].productIdentifier")),
        SourceTrancheIdentifier,
        "Gunda TrancheIdentifier is not correct");
    Assert.assertEquals(
        (WebServiceOperations.getInstance()
            .convertStringToJson(Gunda.getInstance().Gunda_GetCustomer(CustomerNumber))
            .getString("notExecutedTickets[" + num2 + "].ticketType")),
        "INTEREST_TO_TRANSIT",
        "Gunda ticketType is not correct");
    Assert.assertEquals(
        (WebServiceOperations.getInstance()
            .convertStringToJson(Gunda.getInstance().Gunda_GetCustomer(CustomerNumber))
            .getString("notExecutedTickets[" + num2 + "].ticketState")),
        "CREATED",
        "Gunda ticketState is not correct");
    Assert.assertEquals(
        (WebServiceOperations.getInstance()
            .convertStringToJson(Gunda.getInstance().Gunda_GetCustomer(CustomerNumber))
            .getString("notExecutedTickets[" + num2 + "].gundaTicketCategory")),
        "GROSS_INTEREST",
        "Gunda gundaTicketCategory is not correct");
    Assert.assertEquals(
        (WebServiceOperations.getInstance()
            .convertStringToJson(Gunda.getInstance().Gunda_GetCustomer(CustomerNumber))
            .getString("notExecutedTickets[" + num2 + "].amount")),
        DBReusables.getInstance()
                .formatCurrency1(InterestAmount)
                .substring(1, DBReusables.getInstance().formatCurrency1(InterestAmount).length())
            + " EUR",
        "Gunda amount is not correct");
    Assert.assertEquals(
        (WebServiceOperations.getInstance()
            .convertStringToJson(Gunda.getInstance().Gunda_GetCustomer(CustomerNumber))
            .getString("notExecutedTickets[" + num2 + "].expectedValueDate")),
        DBReusables.getInstance().getTrancheStartDate(TargetTrancheIdentifier),
        "Gunda expectedValueDate is not correct");

    int num3 =
        getInprogressTicket_Array(
            CustomerNumber,
            DBReusables.getInstance()
                .getTicket_uuid(t2cITicket_id, DBReusables.getInstance().ct2cTable));
    Assert.assertEquals(
        (WebServiceOperations.getInstance()
            .convertStringToJson(Gunda.getInstance().Gunda_GetCustomer(CustomerNumber))
            .getString("notExecutedTickets[" + num3 + "].productIdentifier")),
        SourceTrancheIdentifier,
        "Gunda TrancheIdentifier is not correct");
    Assert.assertEquals(
        (WebServiceOperations.getInstance()
            .convertStringToJson(Gunda.getInstance().Gunda_GetCustomer(CustomerNumber))
            .getString("notExecutedTickets[" + num3 + "].ticketType")),
        "TRANSIT_TO_CUSTOMER",
        "Gunda ticketType is not correct");
    Assert.assertEquals(
        (WebServiceOperations.getInstance()
            .convertStringToJson(Gunda.getInstance().Gunda_GetCustomer(CustomerNumber))
            .getString("notExecutedTickets[" + num3 + "].ticketState")),
        "CREATED",
        "Gunda ticketState is not correct");
    Assert.assertEquals(
        (WebServiceOperations.getInstance()
            .convertStringToJson(Gunda.getInstance().Gunda_GetCustomer(CustomerNumber))
            .getString("notExecutedTickets[" + num3 + "].gundaTicketCategory")),
        "GROSS_INTEREST",
        "Gunda gundaTicketCategory is not correct");
    Assert.assertEquals(
        (WebServiceOperations.getInstance()
            .convertStringToJson(Gunda.getInstance().Gunda_GetCustomer(CustomerNumber))
            .getString("notExecutedTickets[" + num3 + "].amount")),
        DBReusables.getInstance()
                .formatCurrency1(InterestAmount)
                .substring(1, DBReusables.getInstance().formatCurrency1(InterestAmount).length())
            + " EUR",
        "Gunda amount is not correct");
    Assert.assertEquals(
        (WebServiceOperations.getInstance()
            .convertStringToJson(Gunda.getInstance().Gunda_GetCustomer(CustomerNumber))
            .getString("notExecutedTickets[" + num3 + "].expectedValueDate")),
        DBReusables.getInstance().getTrancheStartDate(TargetTrancheIdentifier),
        "Gunda expectedValueDate is not correct");
    TestLogger.logInfo(
        "Successfully validated Inprogress Principal & Interest ticket validations in Gunda");
  }

  /*
   * This method validates Pending Payout and Interest Tickets
   * @param customerNumber
   * @param CIA
   * @param SourceTrancheIdentifier
   */
  public void payOutValidatePost_i2tort2c(
      String CustomerNumber, String CIA, String SourceTrancheIdentifier)
      throws InterruptedException {
    Assert.assertEquals(
        (WebServiceOperations.getInstance()
            .convertStringToJson(Gunda.getInstance().Gunda_GetCustomer(CustomerNumber))
            .getString(
                "affiliations[0].customerInterestAccountsDetails["
                    + getCIA_Array(CustomerNumber, CIA)
                    + "].interestAccount.productIdentifier")),
        SourceTrancheIdentifier,
        "Gunda TrancheIdentifier is not correct");
    String FinalTotalBalanceAmount =
        DBReusables.getInstance()
            .getCIAB_Balance(
                SourceTrancheIdentifier,
                DBReusables.getInstance().getCustomerEmail(CustomerNumber));
    if (FinalTotalBalanceAmount == null) {
      Assert.assertEquals(
          (WebServiceOperations.getInstance()
              .convertStringToJson(Gunda.getInstance().Gunda_GetCustomer(CustomerNumber))
              .getString(
                  "affiliations[0].customerInterestAccountsDetails["
                      + getCIA_Array(CustomerNumber, CIA)
                      + "].interestAccount.balance")),
          "0.00 EUR",
          "Gunda amount is not correct");
    } else {
      Assert.assertEquals(
          (WebServiceOperations.getInstance()
              .convertStringToJson(Gunda.getInstance().Gunda_GetCustomer(CustomerNumber))
              .getString(
                  "affiliations[0].customerInterestAccountsDetails["
                      + getCIA_Array(CustomerNumber, CIA)
                      + "].interestAccount.balance")),
          DBReusables.getInstance()
                  .formatCurrency1(FinalTotalBalanceAmount)
                  .substring(
                      1,
                      DBReusables.getInstance().formatCurrency1(FinalTotalBalanceAmount).length())
              + " EUR",
          "Gunda amount is not correct");
    }
    TestLogger.logInfo("Successfully validated Completed ticket validations in Gunda");
  }
}
