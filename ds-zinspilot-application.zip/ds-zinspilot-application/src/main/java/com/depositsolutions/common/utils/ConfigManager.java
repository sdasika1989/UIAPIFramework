package com.depositsolutions.common.utils;

import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

public class ConfigManager {

  private static ConfigManager manager;
  private static final Properties prop = new Properties();

  private ConfigManager() throws IOException {
    InputStream fis = ConfigManager.class.getResourceAsStream("/global.properties");
    prop.load(fis);
    final String env = getString("env");
    fis = ConfigManager.class.getResourceAsStream("/config-" + env + ".properties");
    prop.load(fis);
  }

  public static ConfigManager getInstance() {
    if (manager == null) {
      synchronized (ConfigManager.class) {
        try {
          manager = new ConfigManager();
        } catch (IOException e) {
          e.printStackTrace();
        }
      }
    }
    return manager;
  }

  public String getString(String key) {
    if (System.getenv(key) != null) {
      return System.getenv(key);
    }
    return System.getProperty(key, prop.getProperty(key));
  }
}
