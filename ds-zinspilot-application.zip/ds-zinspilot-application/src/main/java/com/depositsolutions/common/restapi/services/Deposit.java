package com.depositsolutions.common.restapi.services;

import static io.restassured.RestAssured.given;

import com.depositsolutions.common.restapi.helpers.Endpoints;
import com.depositsolutions.common.reusables.DBReusables;
import com.depositsolutions.common.utils.ConfigManager;
import com.depositsolutions.common.utils.TestLogger;
import io.restassured.RestAssured;

public class Deposit {
  public static Deposit singleInstance = null;
  private String depositUrl = ConfigManager.getInstance().getString("depositUrl");

  public static Deposit getInstance() {
    if (singleInstance == null) {
      singleInstance = new Deposit();
    }
    return singleInstance;
  }

  public void investmentChangeMapping(
      String SourceTrancheIdentifier, String TargetTrancheIdentifier) {
    RestAssured.baseURI = depositUrl;
    String sourceProductIdentifier =
        DBReusables.getInstance().getProductIdentifierFromInterestProduct(SourceTrancheIdentifier);
    String targetProductIdentifier =
        DBReusables.getInstance().getProductIdentifierFromInterestProduct(TargetTrancheIdentifier);

    given()
        .header("Content-Type", "application/json")
        .header("Accept", "application/json")
        .body(
            "{\"investmentChangePossibilityRequests\":[{\"type\":\"PRODUCT_VIEW\",\"sourceProductIdentifier\":\""
                + sourceProductIdentifier
                + "\",\"targetProductIdentifier\":\""
                + targetProductIdentifier
                + "\",\"serviceBankBic\":\"MHSBDEHBXXX\"}]}")
        .when()
        .post(Endpoints.investmentChangeMapping)
        .then()
        .log()
        .ifError()
        .assertThat()
        .statusCode(200);
    TestLogger.logInfo("API: Investment change mapping is successful");
  }
}
