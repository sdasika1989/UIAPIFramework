package com.depositsolutions.common.reusables;

import static com.depositsolutions.common.reusables.TestConstants.CURRENT_WORKING_DIRECTORY;
import static com.depositsolutions.common.reusables.TestConstants.SUTOR_SFTP_DOWNLOAD;

import com.depositsolutions.common.utils.ConfigManager;
import com.depositsolutions.common.utils.TestLogger;
import com.github.javafaker.Faker;
import java.io.File;
import java.io.IOException;
import java.util.UUID;
import java.util.concurrent.ThreadLocalRandom;
import org.apache.commons.io.FileUtils;

public class SutorServices {
  public static SutorServices singleInstance = null;
  private final String CSV_SUTOR_FILE_NAME_FORMATTER =
      "accounttransactions_%s_2016-12-20_17%d%d_%d.csv";
  private static final String SFTP_DOWNLOAD_PATH =
      CURRENT_WORKING_DIRECTORY
          + ConfigManager.getInstance().getString(SUTOR_SFTP_DOWNLOAD)
          + "/to-DS-Prod/ZINSPILOT/";

  public static SutorServices getInstance() {
    if (singleInstance == null) {
      singleInstance = new SutorServices();
    }
    return singleInstance;
  }

  /*
   * This method puts csv and ctrl files in sutor path
   * @param fileName
   * @param fileContent
   */
  public void putFilesCSVnControl(String fileName, String fileContent) {
    try {
      File fileLocation = new File(SFTP_DOWNLOAD_PATH + fileName);
      FileUtils.writeStringToFile(fileLocation, fileContent, "UTF-8");
    } catch (IOException e) {
      throw new RuntimeException("Could not generate csv file" + fileName, e);
    }
    try {
      File CtrlFile = new File(SFTP_DOWNLOAD_PATH + fileName + ".ctrl");
      CtrlFile.createNewFile();
    } catch (IOException e) {
      throw new RuntimeException("Could not generate control file", e);
    }
    TestLogger.logInfo("Placed csv and csv.ctrl files successfully");
  }

  /*
   * This method generates file name's and calls method putFilesCSVnControl
   * @param csvContent
   * @param accountNumber
   * @return
   */
  public String putBookingCSVFile(String csvContent, String accountNumber) {
    String fileName = getUniqueFileName(accountNumber);
    putFilesCSVnControl(fileName, csvContent);
    return fileName;
  }

  /*
   * This method generates payoutExecuted file name and calls method putFilesCSVnControl
   * @param payoutExecutedFileContent
   * @param accountNumber
   * @return
   */
  public String putPayoutExecuted(String payoutExecutedFileContent, UUID payoutExecutedUuid) {
    String fileName = "payout_customer_executed-" + payoutExecutedUuid.toString() + ".csv";
    putFilesCSVnControl(fileName, payoutExecutedFileContent);
    return fileName;
  }

  /*
   * This method generates unique file name
   * @param accountNumber
   * @return
   */
  private String getUniqueFileName(String accountNumber) {

    int expectedThreeDigitsRandomMillis = ThreadLocalRandom.current().nextInt(100, 999);
    int expectedTwoDigitsRandomSeconds = ThreadLocalRandom.current().nextInt(10, 59);
    int expectedTwoDigitsRandomMinutes = ThreadLocalRandom.current().nextInt(10, 59);
    return String.format(
        CSV_SUTOR_FILE_NAME_FORMATTER,
        accountNumber,
        expectedTwoDigitsRandomMinutes,
        expectedTwoDigitsRandomSeconds,
        expectedThreeDigitsRandomMillis);
  }

  public String putCustomerListCSVFile(String bookingsCsv) {
    Faker faker = new Faker();
    String CustomerListCsvfileName = "customer-list" + faker.number().digits(4);
    putFilesCSVnControl(CustomerListCsvfileName, bookingsCsv);
    return CustomerListCsvfileName;
  }
}
