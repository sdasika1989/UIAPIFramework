-- Dumping data for table `b2c_product_bank`,`b2c_product_tranche`,`b2c_product_tranche_call_alike_transfer`,`b2c_product_bank_interest_account` and
--
-- WHERE:  bic='CPLUDES1XXX-FG'

USE `comonea_b2c`;


-- For `b2c_product_tranche`
LOCK TABLES `b2c_product_tranche` WRITE;
/*!40000 ALTER TABLE `b2c_product_tranche` DISABLE KEYS */;
INSERT INTO `b2c_product_tranche` VALUES ('23236','2020-11-03 18:04:12',NULL,'EUR','1000000.00','FIXED_TERM','2023-03-31','EUR','100000.00','2022-03-30 00:00:00','2022-03-31 16:00:00','CEKVBE81XXX-FG1Y-2022-03-31','',NULL,'CREATED','2022-03-31','4e393ed9-a559-4279-aa9c-cf6c1dd682ac','PUBLISHED','Das Festgeld der Centrale Kredietverlening N.V. ist eine Termineinlage, bei der ein vorab vereinbarter Anlagebetrag zwischen {minPayInAmount} EUR und {maxPayInAmount} mit einer festen Laufzeit von {duration} und einem festen Zinssatz von {interestRate}% p.a. angelegt wird.','EUR','100.00','0','343','0','SERVICE_BANK',1,'0',NULL);
INSERT INTO `b2c_product_tranche` VALUES ('16262','2020-01-09 09:25:30','2020-08-27 14:34:52',NULL,NULL,'FIXED_TERM','2022-03-31','EUR','100000.00','2021-03-30 00:00:00','2021-03-31 14:34:52','CEKVBE81XXX-FG12M-2021-03-31','',NULL,'CREATED','2021-03-31','fa885f54-32c1-11ea-b8e4-26e0a622eaa4','HIDDEN','Das Festgeld der CKV ist eine Termineinlage, bei der ein vorab vereinbarter Anlagebetrag zwischen {minPayInAmount} EUR und {maxPayInAmount} mit einer festen Laufzeit von {duration} und einem festen Zinssatz von {interestRate}% p.a. angelegt wird. ','EUR','100.00','115','343','0','SERVICE_BANK',1,'0',NULL);
/*!40000 ALTER TABLE `b2c_product_tranche` ENABLE KEYS */;
UNLOCK TABLES;

-- For `b2c_interest_rate`
LOCK TABLES `b2c_interest_rate` WRITE;
/*!40000 ALTER TABLE `b2c_interest_rate` DISABLE KEYS */;
INSERT INTO `b2c_interest_rate` VALUES (1,'2020-02-26 15:15:27',NULL,'0.00020','2020-05-03',23236);
INSERT INTO `b2c_interest_rate` VALUES (2,'2020-01-08 15:15:27',NULL,'0.00030','2021-05-03',16262);
/*!40000 ALTER TABLE `b2c_interest_rate` ENABLE KEYS */;
UNLOCK TABLES;


-- For `b2c_fixed_term_interest_approval`
LOCK TABLES `b2c_fixed_term_interest_approval` WRITE;
/*!40000 ALTER TABLE `b2c_fixed_term_interest_approval` DISABLE KEYS */;
INSERT INTO `b2c_fixed_term_interest_approval` VALUES (6,'2020-12-02 15:15:27',NULL,'marco','2020-12-02 15:15:27',23236);
INSERT INTO `b2c_fixed_term_interest_approval` VALUES (82,'2020-12-26 15:15:27',NULL,'marco','2020-12-26 15:15:27',16262);
/*!40000 ALTER TABLE `b2c_fixed_term_interest_approval` ENABLE KEYS */;
UNLOCK TABLES;


-- For `b2c_product_bank_interest_account`
LOCK TABLES `b2c_product_bank_interest_account` WRITE;
/*!40000 ALTER TABLE `b2c_product_bank_interest_account` DISABLE KEYS */;
INSERT INTO `b2c_product_bank_interest_account` VALUES ('31147','2020-11-03 18:04:12',NULL,'fffFreiherrin Michelle Knies','BE32285836521907','93381794-a2c4-4501-b566-9132d4c76284','23236','58','3','GEBABEBBXXX','BBRUBEBBXXX','BE95385836521835',0,'EUR',NULL);
INSERT INTO `b2c_product_bank_interest_account` VALUES ('23896','2020-01-09 09:25:30',NULL,'fffBaronin Thalia von Fuhlbrügge','BE32285836521907','fa88c64a-32c1-11ea-b8e4-26e0a622eaa4','16262','58','3','GEBABEBBXXX','BBRUBEBBXXX','BE95385836521835',0,'EUR',NULL);
/*!40000 ALTER TABLE `b2c_product_bank_interest_account` ENABLE KEYS */;
UNLOCK TABLES;

-- For `b2c_service_bank_product_mapping`
LOCK TABLES `b2c_service_bank_product_mapping` WRITE;
/*!40000 ALTER TABLE `b2c_service_bank_product_mapping` DISABLE KEYS */;
INSERT INTO `b2c_service_bank_product_mapping` VALUES ('31140','2020-11-03 18:04:12',NULL,'31147','23236','5','3');
INSERT INTO `b2c_service_bank_product_mapping` VALUES ('23889','2020-01-09 09:25:30',NULL,'23896','16262','5','3');
/*!40000 ALTER TABLE `b2c_service_bank_product_mapping` ENABLE KEYS */;
UNLOCK TABLES;

-- For `b2c_document_depositors_information`
LOCK TABLES `b2c_document_depositors_information` WRITE;
/*!40000 ALTER TABLE `b2c_document_depositors_information` DISABLE KEYS */;
INSERT INTO `b2c_document_depositors_information` VALUES ( '185', '2021-06-17 14:08:35', NULL, 1, 'PRODUCT_BANK', 'CEKVBE81XXX','', 'ZP_IFE_Centrale_Kredietverlening_N.V..pdf', '2021-06-17', '1');
/*!40000 ALTER TABLE `b2c_document_depositors_information` ENABLE KEYS */;
UNLOCK TABLES;

-- For `b2c_document_product_information`
LOCK TABLES `b2c_document_product_information` WRITE;
/*!40000 ALTER TABLE `b2c_document_product_information` DISABLE KEYS */;
INSERT INTO `b2c_document_product_information` (`id`, `creationDate`, `lastModifiedDate`, `active`, `content`,`name`,`productTranche_id`,`template_id`,`validFrom`,`version`,`substitutionParamsJson`,`content_id`) VALUES ('11291', '2021-04-15 08:10:38', NULL, 1,'', 'ZP_Produktsinformationsblatt_CreditPlus_FG1.pdf', '23236', '1975', '2021-04-15', '6', '{\"interestRate\":\"0,01%\",\"documentCreationDate\":\"15.04.2021\",\"minAmount\":\"1\",\"textInterestRate\":\"Zinssatz ab 15.04.2021: 0,01% p.a.\",\"minAmountWithCUAndDot\":\"1 EUR.\",\"relationshipModel\":\"Treuhandanlage\",\"interestRateWithPa\":\"0,01% p.a.\",\"currentTextInterestRate\":\"Aktueller Zinsatz: 0,01% p.a. (seit: 15.04.2021)\",\"textNewInterestRate\":\"\",\"maxProductAmount\":\"1.000.000 EUR\",\"minProductAmount\":\"1 EUR\",\"noticePeriodInDays\":\"0\",\"minAmountWithCU\":\"1 EUR\",\"withholdingTaxRate\":\"0,00%\",\"investmentProtectionTresholdValidFrom\":\"01.01.2020\",\"maxAmountWithCU\":\"1.000.000 EUR\",\"cutOffAmountWithCurrency\":\"\",\"maxAmount\":\"1.000.000\",\"nextTextInterestRate\":\"\",\"investmentProtectionTresholdVolume\":\"44,88\"}',NULL);
INSERT INTO `b2c_document_product_information` (`id`, `creationDate`, `lastModifiedDate`, `active`, `content`,`name`,`productTranche_id`,`template_id`,`validFrom`,`version`,`substitutionParamsJson`,`content_id`) VALUES ('1121', '2021-04-15 08:10:38', NULL, 1,'', 'ZP_Produktsinformationsblatt_CreditPlus_FG.pdf', '16262', '1976', '2021-04-15', '6', '{\"interestRate\":\"0,01%\",\"documentCreationDate\":\"15.04.2021\",\"minAmount\":\"1\",\"textInterestRate\":\"Zinssatz ab 15.04.2021: 0,01% p.a.\",\"minAmountWithCUAndDot\":\"1 EUR.\",\"relationshipModel\":\"Treuhandanlage\",\"interestRateWithPa\":\"0,01% p.a.\",\"currentTextInterestRate\":\"Aktueller Zinsatz: 0,01% p.a. (seit: 15.04.2021)\",\"textNewInterestRate\":\"\",\"maxProductAmount\":\"1.000.000 EUR\",\"minProductAmount\":\"1 EUR\",\"noticePeriodInDays\":\"0\",\"minAmountWithCU\":\"1 EUR\",\"withholdingTaxRate\":\"0,00%\",\"investmentProtectionTresholdValidFrom\":\"01.01.2020\",\"maxAmountWithCU\":\"1.000.000 EUR\",\"cutOffAmountWithCurrency\":\"\",\"maxAmount\":\"1.000.000\",\"nextTextInterestRate\":\"\",\"investmentProtectionTresholdVolume\":\"44,88\"}',NULL);
/*!40000 ALTER TABLE `b2c_document_product_information` ENABLE KEYS */;
UNLOCK TABLES;

-- Table Dump completed
