package com.depositsolutions.common.ui.zpuipageobjects;

import com.depositsolutions.common.reusables.DBReusables;
import com.depositsolutions.common.ui.helpers.BaseTestClassUI;
import com.depositsolutions.common.ui.helpers.WebUIOperations;
import com.depositsolutions.common.utils.TestLogger;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;

public class ProductDetailsPO extends BaseTestClassUI {

  public static ProductDetailsPO singleInstance = null;
  public By sof = By.id("availableSourceOfFundsOptionsSelect");
  public By DRM_hint = By.xpath("//button[contains(text(),'Warum')]");
  public By ife = By.xpath("//a[contains(text(),'Informationsbogen')]");
  public By que_MaritalStatus = By.id("id_select_MARITAL_STATUS");
  public By que_EmploymentType = By.id("id_select_TYPE_EMPLOYMENT");
  public By que_EmploymentSector = By.id("id_select_SECTOR_EMPLOYMENT");
  public By drm_agreement = By.id("isDrmAgreementSignedWithoutActiveInvestment");
  public By drm_accept = By.id("proceedFromAcceptedDrmButton");
  public By Anlageangebote = By.linkText("Anlageangebote");
  public By changeSOF = By.linkText("hier");
  public By sofPreselectedText = By.xpath("//div[@class='col-md-12 control-label']");
  public By drmErrorText = By.xpath("//span[@id='notAgreedToDrmAgreementErrorLabel']");
  public By drm_successmsg = By.xpath("//div[@class='msg-warning']");
  public By pib1 = By.linkText("Produktinformationsblatt");
  public By pib2 = By.linkText("Hier herunterladen");
  public By button_payin = By.id("proceed_with_product_selected");
  public static By Duration1to11Monate =
      By.xpath("//li[not(contains(@style, 'display: none'))]//div[1]/div/div[3]/div/p");
  public static By InterestRates3MonateDuration =
      By.xpath("//*[@data-maturityduration='3']//strong");
  public static By BankNames1to11Monate =
      By.xpath(
          "/strong[contains(text(),'0,06%')]/following::div[4]//p[normalize-space()='6 Monate']");
  public By zpShopHomePageTerms = By.id("product_select_maturity");
  public By zpShopHomePageAllCountries = By.id("product_select_country");
  public By zpShopHomePageSort = By.id("product_select_sort");
  public By badgeStatusDuration = By.xpath("//p[contains(@class,'badge-status-duration')]");
  public By badgeTitleBD = By.xpath("//div[contains(@class,'badge-title-bd')]");
  public By badgeTitleImage = By.xpath("//img[contains(@src,'/images/banks/CPLU.svg')]");
  public By badgeStatusInterestRate =
      By.xpath("//strong[contains(@class,'badge-status-interest-rate')]");
  public By que_COB = By.id("id_select_COUNTRY_OF_BIRTH");
  public By que_Citizenship = By.id("id_select_EU_CITIZENSHIP");
  public By que_AN = By.id("id_select_ADDITIONAL_NATIONALITY_1");
  public By que_OA = By.id("id_select_OCCUPATION_ACTIVITY");
  public By que_Income = By.id("id_select_INCOME");

  public static By CREATE_NOW_PRODUCTDETAILS =
      By.xpath("*//button[contains(text(),' Jetzt anlegen')]");
  public static By PRINT_TRANSFER_DETAILS = By.xpath("//*[@id='downloadTransferFormButton']/span");
  public static final By LEGITIMISATION_LINK_PDP =
      By.linkText("Bitte klicken Sie hier, um eine erneute Legitimation zu starten");

  public static ProductDetailsPO getInstance() {
    if (singleInstance == null) {
      singleInstance = new ProductDetailsPO();
    }
    return singleInstance;
  }

  /*
   * This method selects tranche from ProductDetails/product list page
   * @param TrancheIdentifier
   */
  public void selectingProductFromProductListPage(String TrancheIdentifier)
      throws InterruptedException {
    ShopLoginLogoutPO.getInstance().shopCache();
    DRIVER.findElement(Anlageangebote).click();
    DRIVER
        .findElement(
            By.id(
                "proceed_with_product_"
                    + DBReusables.getInstance()
                        .getPayInCodeFromTrancheIdentifier(TrancheIdentifier)))
        .click();
    TestLogger.logInfo("Selected product " + TrancheIdentifier + " from product list page");
  }

  public void selectingSourceOfFunds1(String sofValue) {
    TestLogger.logInfo("Select SOF from UI ");
    WebUIOperations.getInstance().selectDropdownByValue(DRIVER.findElement(sof), sofValue);
  }

  public void selectingSourceOfFunds2(String sofValue) {
    DRIVER.findElement(changeSOF).click();
    TestLogger.logInfo("Select new SOF Value from UI ");
    WebUIOperations.getInstance().selectDropdownByValue(DRIVER.findElement(sof), sofValue);
  }

  public void selectingQuestionary_CKV() {
    WebUIOperations.getInstance().selectDropdownByValue(DRIVER.findElement(que_MaritalStatus), "2");
    WebUIOperations.getInstance()
        .selectDropdownByValue(DRIVER.findElement(que_EmploymentType), "11");
    WebUIOperations.getInstance()
        .selectDropdownByValue(DRIVER.findElement(que_EmploymentSector), "36");
    TestLogger.logInfo("Selected Questionnaire from UI ");
    WebUIOperations.getInstance().scrollDownThePage();
    DRIVER.findElement(button_payin).click();
    // check QUE in DB
    TestLogger.logInfo("validated selected QUE in DB ");
    DBReusables.getInstance().checkQUE("MARITAL_STATUS", "2");
    DBReusables.getInstance().checkQUE("TYPE_EMPLOYMENT", "11");
    DBReusables.getInstance().checkQUE("SECTOR_EMPLOYMENT", "36");
  }

  public void selectingQuestionary_QLIRO() {
    WebUIOperations.getInstance().selectDropdownByValue(DRIVER.findElement(que_MaritalStatus), "2");
    WebUIOperations.getInstance()
        .selectDropdownByValue(DRIVER.findElement(que_EmploymentType), "11");
    TestLogger.logInfo("Selected Questionnaire from UI ");
    WebUIOperations.getInstance().scrollDownThePage();
    DRIVER.findElement(button_payin).click();
    // check QUE in DB
    TestLogger.logInfo("validated selected QUE in DB ");
    DBReusables.getInstance().checkQUE("MARITAL_STATUS", "2");
    DBReusables.getInstance().checkQUE("TYPE_EMPLOYMENT", "11");
  }

  public void selectingDRM_Contract(String TrancheIdentifier) {
    DRIVER.findElement(drm_agreement).click();
    // check for ennable of DRM button
    Assert.assertEquals(
        DRIVER.findElement(ProductDetailsPO.getInstance().drm_accept).getAttribute("class"),
        "btn btn-info",
        "DRM button is not enabled");
    // accept DRM Contract
    DRIVER.findElement(drm_accept).click();
    // check for DRM success message
    Assert.assertEquals(
        DRIVER.findElement(ProductDetailsPO.getInstance().drm_successmsg).getText(),
        "Der Kundenrahmenvertrag der "
            + DBReusables.getInstance().getBankName_FromTrancheIdentifier(TrancheIdentifier)
            + " wurde Ihnen in \"Archiv & Dokumente\" bereitgestellt.",
        "DRM button is not enabled");
    TestLogger.logInfo("DRM Contract accepted successfully");
    // Check in Archive and Documents
    ArchiveAndDocumentsPO.getInstance()
        .validatePersonalDocument(
            DBReusables.getInstance().formatDate("dd.MM.yyyy")
                + " Kundenrahmenvertrag - "
                + DBReusables.getInstance().getBankName_FromTrancheIdentifier(TrancheIdentifier)
                + "\n"
                + "Zum Vertragsabschluss wird Ihre Einzahlung benötigt"
                + " Download Kundenrahmenvertrag",
            "present");
    // check for DRM Status
    Assert.assertEquals(
        DBReusables.getInstance().checkDRM(), "INITIATED", "DRM state is not INITIATED");
    TestLogger.logInfo("validated DRM Status is INITIATED");
  }

  public void VerifyPreSelectedSOF(String sofValue) {
    Assert.assertTrue(
        DRIVER.findElement(sofPreselectedText).getText().contains(sofValue),
        "Pre-Selected SOF is not saved on UI");
    TestLogger.logInfo("Previous selected SOF is pre-selected");
  }

  public void verifyShopHomePageIsDisplayed() {

    WebUIOperations.getInstance()
        .verifyElementIsPresent(getWebElement(zpShopHomePageTerms), "Terms DropDown");
    WebUIOperations.getInstance()
        .verifyElementIsPresent(
            getWebElement(zpShopHomePageAllCountries), "All Countries DropDown");
    WebUIOperations.getInstance()
        .verifyElementIsPresent(getWebElement(zpShopHomePageSort), "Sort DropDown");
  }

  /**
   * This method is used to validate the filter or Sort options present in the dropdown in the Shop
   * HomePage
   *
   * @param expectedValue
   * @param element
   */
  public void validateFilterValues(String expectedValue, WebElement element) {
    Select select = new Select(element);
    int i = 0;
    List<WebElement> list = select.getOptions();
    String observedValues[] = new String[list.size()];

    for (WebElement we : list) {

      String listValuesFromDropDown = we.getText();
      observedValues[i] = listValuesFromDropDown;
      String[] expectedValues = expectedValue.split(",");
      Assert.assertEquals(
          expectedValues[i],
          observedValues[i],
          "Expected Values: "
              + expectedValues[i]
              + " are not same as observed Values: "
              + observedValues[i]);
      i++;
    }
  }

  public void validateResults(String expectedText, List<WebElement> element) {
    List<WebElement> products = element;
    int productsDisplayed = products.size();

    String productText = "";
    boolean isImagePresent = false;
    for (WebElement productImages : products) {
      isImagePresent = productImages.isDisplayed();
      productText = productImages.getText();

      if (!productText.equals("")) {
        break;
      }
    }
    Assert.assertTrue(
        productsDisplayed >= 1 && isImagePresent && productText.contains(expectedText),
        "Expected text: " + expectedText + " Observed Text: " + productText);
  }

  public void validateProductSelectMaturityFilter() {
    Select s1 = new Select(DRIVER.findElement(zpShopHomePageTerms));
    //    s1.selectByVisibleText(selectValue"");
    s1.selectByVisibleText("1-11 Monate");
    // Validate Less Duration on top
    List<Integer> Duration = new ArrayList<>();
    //    List<WebElement> monate = element;
    List<WebElement> monate = DRIVER.findElements(Duration1to11Monate);
    for (WebElement text : monate) {
      String Durations = text.getText();
      int numberOnly =
          Integer.parseInt(
              Durations.replaceAll("[^0-9]", "")); // Displays only Numeric values of Monate
      Duration.add(numberOnly);
    }
    for (int i = 0; i < Duration.size() - 1; i++) {
      if (Duration.get(i) <= Duration.get(i + 1)) {
        TestLogger.logInfo("Less duration are displayed on top");

      } else {
        TestLogger.logInfo("Failed: Duration sorting filter ");
      }
    }

    // if duration is same, products are sorted by interest rate. Product with high interest rate is
    // shown first
    List<Integer> InterestRate = new ArrayList<Integer>();
    List<WebElement> interest = DRIVER.findElements(InterestRates3MonateDuration);
    for (WebElement text : interest) {
      String InterestRates = text.getText();
      int numberOnly = Integer.parseInt(InterestRates.replaceAll("[^0-9]", ""));
      InterestRate.add(numberOnly);
    }
    for (int i = 0; i < InterestRate.size() - 1; i++) {
      if (InterestRate.get(i) >= InterestRate.get(i + 1)) {
        TestLogger.logInfo("When duration is same product with high interest rate is shown first");

      } else {
        TestLogger.logInfo(
            "Failed:When duration is same product with high interest rate is NOT shown first");
      }
    }

    // if duration and interest rate is same, products are sorted Alphabetically by bank name (A
    // first)
    List<WebElement> srcs = DRIVER.findElements(BankNames1to11Monate);
    List<String> BankNamesfromUI = new ArrayList<String>();
    List<String> BankNamesAfterSorting = new ArrayList<String>();
    for (WebElement srcvalues : srcs) {
      String str = srcvalues.getAttribute("src");
      String str1 = str.substring(str.lastIndexOf("/"), str.lastIndexOf(".")).replaceAll("/", " ");
      String str1final = str1.trim();
      String str2 = DBReusables.getInstance().getBankName(str1final);
      BankNamesfromUI.add(str2);
    }
    Collections.sort(BankNamesfromUI);
    BankNamesAfterSorting = BankNamesfromUI;
    if (BankNamesfromUI.equals(BankNamesAfterSorting)) {
      TestLogger.logInfo(
          "if duration and interest rate is same, products are sorted Alphabetically by bank name (A first)");

    } else {
      TestLogger.logInfo("Failed: Bank Name sorting failed");
    }
    //    lineBreak();
  }

  public void selectingQuestionary_CACF() {
    WebUIOperations.getInstance().selectDropdownByValue(DRIVER.findElement(que_COB), "DE");
    WebUIOperations.getInstance().selectDropdownByValue(DRIVER.findElement(que_Citizenship), "DE");
    WebUIOperations.getInstance().selectDropdownByValue(DRIVER.findElement(que_AN), "DE");
    WebUIOperations.getInstance()
        .selectDropdownByValue(DRIVER.findElement(que_OA), "Angestellte/r");
    WebUIOperations.getInstance().selectDropdownByValue(DRIVER.findElement(que_Income), "25000");
    TestLogger.logInfo("Selected Questionnaire from UI ");
    WebUIOperations.getInstance().scrollDownThePage();
  }
}
