package com.depositsolutions.common.reusables.payout;

import java.math.BigDecimal;
import org.apache.commons.lang3.builder.ToStringBuilder;

public class PayoutExecuted {
  private String fileUuid;

  public BigDecimal getMoneyAmount() {
    return moneyAmount;
  }

  @Override
  public String toString() {
    return new ToStringBuilder(this)
        .append("fileUuid", fileUuid)
        .append("moneyAmount", moneyAmount)
        .append("category", category)
        .toString();
  }

  public void setMoneyAmount(BigDecimal moneyAmount) {
    this.moneyAmount = moneyAmount;
  }

  private BigDecimal moneyAmount;

  public String getFileUuid() {
    return fileUuid;
  }

  public void setFileUuid(String fileUuid) {
    this.fileUuid = fileUuid;
  }

  public String getCategory() {
    return category;
  }

  private String category;
}
