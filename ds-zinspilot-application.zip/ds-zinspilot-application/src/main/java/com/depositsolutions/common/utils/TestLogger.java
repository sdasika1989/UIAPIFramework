package com.depositsolutions.common.utils;

import org.testng.Reporter;

public class TestLogger {
  public static void logMsg(String msg) {
    System.out.println(msg);
    Reporter.log(msg);
  }

  public static void logInfo(String msg) {
    System.out.println("INFO: " + msg);
    Reporter.log("INFO: " + msg);
  }
}
