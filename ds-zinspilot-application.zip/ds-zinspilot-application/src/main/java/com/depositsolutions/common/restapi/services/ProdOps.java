package com.depositsolutions.common.restapi.services;

import static io.restassured.RestAssured.given;

import com.depositsolutions.common.restapi.helpers.Endpoints;
import com.depositsolutions.common.reusables.DBReusables;
import com.depositsolutions.common.utils.ConfigManager;
import com.depositsolutions.common.utils.TestLogger;
import io.restassured.RestAssured;
import java.time.LocalDate;

public class ProdOps {

  public static ProdOps singleInstance = null;
  private String CoreBLUrl = ConfigManager.getInstance().getString("CoreBLUrl");

  public static ProdOps getInstance() {
    if (singleInstance == null) {
      singleInstance = new ProdOps();
    }
    return singleInstance;
  }

  /*
   * This method books Interest
   * @param TrancheIdentifier
   * @param ValueDate
   */
  public void bookInterest(String TrancheIdentifier, LocalDate transferDate) {
    RestAssured.baseURI = CoreBLUrl;

    given()
        .header("Content-Type", "application/json")
        .body(
            "{\"productIdentifier\" : \""
                + TrancheIdentifier
                + "\",\"valueDate\" : \""
                + transferDate
                + "\"}")
        .when()
        .post(Endpoints.bookInterest)
        .then()
        .log()
        .ifError()
        .assertThat()
        .statusCode(200);
    TestLogger.logInfo("API: Book Interest is successful");
  }

  /*
   * This method distributes Interest
   * @param TrancheIdentifier
   * @param ValueDate
   */
  public void distributeInterest(String TrancheIdentifier, LocalDate transferDate) {
    RestAssured.baseURI = CoreBLUrl;

    given()
        .header("Content-Type", "application/json")
        .body(
            "{\"productIdentifier\" : \""
                + TrancheIdentifier
                + "\",\"valueDate\" : \""
                + transferDate
                + "\"}")
        .when()
        .post(Endpoints.distributeInterest)
        .then()
        .log()
        .ifError()
        .assertThat()
        .statusCode(200);

    TestLogger.logInfo("API: Distribute Interest is successful");
  }

  /*
   * This method initiate prolongation
   * @param TrancheIdentifier
   * @param ValueDate
   */
  public void initiateProlongation(String TrancheIdentifier) {
    RestAssured.baseURI = CoreBLUrl;

    given()
        .header("Content-Type", "application/json")
        .when()
        .post(
            "/product/product/"
                + TrancheIdentifier
                + "/bankInterestAccounts/prolongation/preparation")
        .then()
        .log()
        .ifError()
        .assertThat()
        .statusCode(200);
    TestLogger.logInfo("API: Prepare Prolongation is successful");
  }

  /*
   * This method executes and creates prolongation Tickets
   * @param TrancheIdentifier
   * @param ValueDate
   * Note-Issue with api.Raised Issue with CCA Team.Looping till 200 as worked around
   */
  public void performProlongation(String TrancheIdentifier) {
    RestAssured.baseURI = CoreBLUrl;
    given()
        .header("Content-Type", "application/json")
        .when()
        .post(
            "/product/product/"
                + TrancheIdentifier
                + "/bankInterestAccounts/prolongation/execution")
        .then()
        .log()
        .ifError()
        .assertThat()
        .statusCode(200);
    TestLogger.logInfo("API: Execute Prolongation is successful");
  }

  /*
   * This method prepare customer tickets individually
   * @param TicketType
   * @param sourceAccountId
   * @param targetAccountId
   */
  public void prepareTickets(String TicketType, String sourceAccountId, String targetAccountId) {
    RestAssured.baseURI = CoreBLUrl;
    given()
        .header("Content-Type", "application/json")
        .body(
            "{\"type\" : \""
                + TicketType
                + "\",\"sourceAccountId\" : \""
                + sourceAccountId
                + "\",\"targetAccountId\" : \""
                + targetAccountId
                + "\"}")
        .when()
        .post(Endpoints.prepareTickets)
        .then()
        .log()
        .ifError()
        .assertThat()
        .statusCode(200);
    TestLogger.logInfo("API: Prepare Tickets is successful");
  }

  /*
   * This method aggregates individual and generates Bank Transfer Ticket
   * @param TicketType
   * @param sourceAccountId
   * @param targetAccountId
   * @param PB_BIC
   */
  public void createTickets(
      String TicketType, String sourceAccountId, String targetAccountId, String PB_BIC) {
    RestAssured.baseURI = CoreBLUrl;

    switch (TicketType) {
      case "TRANSIT_TO_CUSTOMER":
        {
          given()
              .header("Content-Type", "application/json")
              .header("Accept", "application/json")
              .body(
                  "{\"type\" : \""
                      + TicketType
                      + "\",\"sourceAccountId\" : \""
                      + sourceAccountId
                      + "\",\"targetAccountId\" : \""
                      + targetAccountId
                      + "\",\"productBankBic\":\""
                      + PB_BIC
                      + "\"}")
              .when()
              .post(Endpoints.createTickets)
              .then()
              .log()
              .ifError()
              .assertThat()
              .statusCode(200);
          break;
        }
      default:
        {
          given()
              .header("Content-Type", "application/json")
              .header("Accept", "application/json")
              .body(
                  "{\"type\" : \""
                      + TicketType
                      + "\",\"sourceAccountId\" : \""
                      + sourceAccountId
                      + "\",\"targetAccountId\" : \""
                      + targetAccountId
                      + "\",\"productBankBic\":\""
                      + PB_BIC
                      + "\"}")
              .when()
              .post(Endpoints.createTickets)
              .then()
              .log()
              .ifError()
              .assertThat()
              .statusCode(201);
          break;
        }
    }
    TestLogger.logInfo("API: Create Tickets is successful");
  }

  /*
   * This method sends Bank Transfer Ticket to Product Bank
   * @param TicketType
   * @param sourceAccountId
   * @param targetAccountId
   */
  public void ProcessTickets(
      String TicketType, String ServiceBank_BIC, String sourceAccountId, String targetAccountId) {
    RestAssured.baseURI = CoreBLUrl;

    given()
        .queryParam(
            "serviceBankTransitAccountId",
            DBReusables.getInstance().getSutorTransitAccountUUID(ServiceBank_BIC))
        .queryParam("serviceBankBic", ServiceBank_BIC)
        .header("Content-Type", "application/json")
        .body(
            "{\"type\" : \""
                + TicketType
                + "\",\"sourceAccountId\" : \""
                + sourceAccountId
                + "\",\"targetAccountId\" : \""
                + targetAccountId
                + "\"}")
        .when()
        .post(Endpoints.ProcessTickets)
        .then()
        .log()
        .ifError()
        .assertThat()
        .statusCode(200);
    TestLogger.logInfo("API: Process Tickets is successful");
  }

  /*
   * This method changes default ProductBank prolongation settings
   * @param action
   * @param TrancheIdentifier
   */
  public void Prodops_PB_Prolongation_setting(String action, String TrancheIdentifier)
      throws InterruptedException {
    RestAssured.baseURI = CoreBLUrl;

    given()
        .header("Content-Type", "application/json")
        .header("Accept", "application/json")
        .body("{\"productTrancheCanBeProlongated\" : \"" + action + "\"}")
        .when()
        .post(
            "/product/product/"
                + TrancheIdentifier
                + "/bankInterestAccounts/prolongation/canBeProlongated")
        .then()
        .log()
        .ifError()
        .assertThat()
        .statusCode(200);
    TestLogger.logInfo("API: Product Bank Prolongation Settings is successful");
  }
}
