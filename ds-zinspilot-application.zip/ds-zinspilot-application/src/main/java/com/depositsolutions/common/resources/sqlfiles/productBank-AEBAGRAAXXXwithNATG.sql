-- Dumping data for table `b2c_product_bank`,`b2c_product_tranche`,`b2c_product_tranche_call_alike_transfer`,`b2c_product_bank_interest_account` and 
--
-- WHERE:  bic='BUCUROBU-TG'

USE `comonea_b2c`;

-- For `b2c_product_bank`
LOCK TABLES `b2c_product_bank` WRITE;
/*!40000 ALTER TABLE `b2c_product_bank` DISABLE KEYS */;
INSERT INTO `b2c_product_bank` (`id`, `creationDate`, `lastModifiedDate`, `bic`, `bankSortCode`, `bankName`, `investmentProtectionCountry`, `investmentProtectionOrganisation`, `investmentProtectionThresholdCurrency`, `investmentProtectionThresholdVolume`, `ratingDbrs`, `ratingFitch`, `ratingGbb`, `ratingMoodys`, `ratingStandardAndPoors`, `registrationNumber`, `taxNumber`, `uuid`, `description`, `maxInvestmentAmountCurrency`, `maxInvestmentAmountVolume`, `proprietorStructure`, `investmentProtectionThresholdValidFrom`, `taxResidenceCertificateHandlingType`, `depositorInformationDocumentUrl`, `creditableWithholdingTaxRate`, `payoutAmountCalculationMethod`, `relationshipModel`, `drmTranchesStartDate`, `drmConversionPeriodEndDate`, `brandName`, `legitimisationValidityPeriod`, `publicOffer`, `payInDeadLineOffset`, `payInDeadLineTime`, `trnDateOffset`, `trnDateTime`, `customizedCallAlikeProductSupported`)
VALUES
	(54, '2019-09-05 13:09:22', '2021-02-24 08:59:23', 'AEBAGRAAXXX', NULL, 'Aegean Baltic Bank S.A.', 'GR', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Athens, Greece - General Electronic Commercial Registry (G.E.MI) registration no 4918201000', 'EL099937684', '61035815-cfde-11e9-b8e4-26e0a622eaa4', NULL, 'EUR', 100000.00, NULL, NULL, NULL, NULL, 0.10000, 'CUSTOMER_INTEREST_ACCOUNT_BASED', 'FIDUCIARY_ACCOUNT_MODEL', NULL, NULL, 'ABBank', NULL, 1, -2, '00:00:00', -1, '10:00:00', 0);
/*!40000 ALTER TABLE `b2c_product_bank` ENABLE KEYS */;
UNLOCK TABLES;

-- For `b2c_product_bank_validation_requirement`
LOCK TABLES `b2c_product_bank_validation_requirement` WRITE;
/*!40000 ALTER TABLE `b2c_product_bank_validation_requirement` DISABLE KEYS */;
INSERT INTO `b2c_product_bank_validation_requirement` (`id`, `creationDate`, `lastModifiedDate`, `validationRequirement`, `productBank_id`, `validationRequirementValueType`, `specifier`, `performValidation`)
VALUES
	(108, '2019-09-05 13:09:22', NULL, 'GERMAN_TAX_ID', 54, 'NONE', NULL, 1),
	(109, '2019-09-05 13:09:22', NULL, 'IDENTITY_CARD_DATA_AUTHORITY', 54, 'NONE', NULL, 1),
	(110, '2019-09-05 13:09:22', NULL, 'IDENTITY_CARD_DATA', 54, 'NONE', NULL, 1),
	(212, '2020-07-31 09:38:01', NULL, 'PRODUCTBANK_QUESTIONS_ANSWERED', 54, 'NONE', NULL, 1);
/*!40000 ALTER TABLE `b2c_product_bank_validation_requirement` ENABLE KEYS */;
UNLOCK TABLES;

-- For `b2c_product_bank_logo`
LOCK TABLES `b2c_product_bank_logo` WRITE;
/*!40000 ALTER TABLE `b2c_product_bank_logo` DISABLE KEYS */;
INSERT INTO `b2c_product_bank_logo` VALUES (14,'2021-01-26 10:29:53.000000',NULL,'','AEBAGRAAXXX.svg','AEBAGRAAXXX');
/*!40000 ALTER TABLE `b2c_product_bank_logo` ENABLE KEYS */;
UNLOCK TABLES;
	
-- For `b2c_interest_product`
LOCK TABLES `b2c_interest_product` WRITE;
/*!40000 ALTER TABLE `b2c_interest_product` DISABLE KEYS */;
INSERT INTO `b2c_interest_product` (`id`, `creationDate`, `lastModifiedDate`, `productIdentifier`, `bookingInterval`, `interestCalculationMethod`, `maturityCode`, `specifier`, `payInCode`, `productBank_id`, `currencyUnit`, `prolongationStrategy`, `interestReinvestStrategy`, `startDate`, `anticipateTrancheCloseByDays`)
VALUES
	(515, '2021-06-25 11:10:59', NULL, 'AEBAGRAAXXX-CALL-33', 'QUARTERLY', 'EUROPEAN_ACT_360', 'CALL', NULL, 'AegeanKG33', 54, 'EUR', 'PROLONGATION', 'PAYOUT', NULL, 0);
/*!40000 ALTER TABLE `b2c_interest_product` ENABLE KEYS */;
UNLOCK TABLES;

-- For `b2c_product_tranche`
LOCK TABLES `b2c_product_tranche` WRITE;
/*!40000 ALTER TABLE `b2c_product_tranche` DISABLE KEYS */;
INSERT INTO `b2c_product_tranche` (`id`, `creationDate`, `lastModifiedDate`, `cut_off_amount_currency`, `cut_off_amount`, `depositType`, `endDate`, `max_amount_currency`, `max_amount`, `payInDeadline`, `transactionDate`, `productIdentifier`, `productName`, `infoProduct`, `productState`, `startDate`, `uuid`, `viewState`, `description`, `min_amount_currency`, `min_amount`, `marketing_rank`, `interestProduct_id`, `investmentChangeOnly`, `interestTaxation`, `canBeProlongated`, `noticePeriodInDays`, `targetGroup`)
VALUES
	(29102, '2021-06-25 11:11:00', '2021-06-25 12:09:14', NULL, NULL, 'DIRECT_ACCESS', NULL, 'EUR', 100000.00, NULL, NULL, 'AEBAGRAAXXX-NA-33', '', NULL, 'CONNECTED', NULL, '05dcbb77-d5a6-11eb-b8f8-26e0a622eaa4', 'PUBLISHED', 'Das Flexgeld24 der Aegean_Baltic_Bank ist eine Spareinlage, bei der ein frei definierbarer Anlagebetrag von bis zu {maxPayInAmount} EUR mit einem variablen Zinssatz von zurzeit {interestRate}% p.a. angelegt werden kann. Die Zinszahlung für das Produkt Flexgeld24 erfolgt zweimal monatlich. Anlagen können zu den Zinszahlungsterminen gestartet und beendet werden, d.h.: Der Kunde hat mit dem Flexgeld24 die Flexibilität, sein Geld jeweils zum 1. und zum 15. eines Monats bzw. dem darauffolgenden Bankarbeitstag ein- oder auszuzahlen. Bitte beachten Sie die Angaben im Produktinformationsblatt zur Hinterlegung von Ausweisdaten.', 'EUR', 1.00, 0, 515, 0, 'SERVICE_BANK', 1, 33, NULL);
/*!40000 ALTER TABLE `b2c_product_tranche` ENABLE KEYS */;
UNLOCK TABLES;

-- For `b2c_interest_rate`
LOCK TABLES `b2c_interest_rate` WRITE;
/*!40000 ALTER TABLE `b2c_interest_rate` DISABLE KEYS */;
INSERT INTO `b2c_interest_rate` VALUES (1,'2020-02-26 15:15:27',NULL,'0.00030','2020-03-16',29102);
/*!40000 ALTER TABLE `b2c_interest_rate` ENABLE KEYS */;
UNLOCK TABLES;

-- For `b2c_product_bank_interest_account`
LOCK TABLES `b2c_product_bank_interest_account` WRITE;
/*!40000 ALTER TABLE `b2c_product_bank_interest_account` DISABLE KEYS */;
INSERT INTO `b2c_product_bank_interest_account` (`id`, `creationDate`, `lastModifiedDate`, `accountHolder`, `iban`, `uuid`, `product_id`, `productBank_id`, `serviceBankTransitAccount_id`, `bic`, `payInBic`, `payInIban`, `closed`, `currency`, `ultimateCreditorIban`)
VALUES
	(37396, '2021-06-25 11:11:00', '2021-07-05 16:12:19', 'fffTyler Burmeister', 'GR5105610014047596882806993', '05df2a91-d5a6-11eb-b8f8-26e0a622eaa4', 29102, 54, 3, 'AEBAGRAAXXX', 'AEBAGRAAXXX', 'GR5105610014047596882806993', 0, 'EUR', NULL);
/*!40000 ALTER TABLE `b2c_product_bank_interest_account` ENABLE KEYS */;
UNLOCK TABLES;

-- For `b2c_service_bank_product_mapping`
LOCK TABLES `b2c_service_bank_product_mapping` WRITE;
/*!40000 ALTER TABLE `b2c_service_bank_product_mapping` DISABLE KEYS */;
INSERT INTO `b2c_service_bank_product_mapping` VALUES (2400,'2017-01-19 09:37:49',NULL,37396,29102,5,3);
/*!40000 ALTER TABLE `b2c_service_bank_product_mapping` ENABLE KEYS */;
UNLOCK TABLES;

--questionary
USE `cq`;
LOCK TABLES `cq_product_bank` WRITE;
/*!40000 ALTER TABLE `cq_product_bank` DISABLE KEYS */;
INSERT INTO `cq_product_bank` (`id`, `creation_date`, `last_modified_date`, `bic`, `tenant`)
VALUES(8, '2020-01-09 09:26:44.000000', NULL, 'AEBAGRAAXXX', 'ZINSPILOT');
/*!40000 ALTER TABLE `cq_product_bank` ENABLE KEYS */;
UNLOCK TABLES;


LOCK TABLES `cq_question_groups` WRITE;
/*!40000 ALTER TABLE `cq_question_groups` DISABLE KEYS */;
INSERT INTO `cq_question_groups` (`id`, `name`, `creation_date`, `last_modified_date`)
VALUES(1, 'DEFAULT', '2019-12-06 08:47:56.462756', NULL);
/*!40000 ALTER TABLE `cq_question_groups` ENABLE KEYS */;
UNLOCK TABLES;

LOCK TABLES `cq_question_types` WRITE;
/*!40000 ALTER TABLE `cq_question_types` DISABLE KEYS */;
INSERT INTO `cq_question_types` (`id`, `name`, `creation_date`, `last_modified_date`)
VALUES
	(10, 'OPTIONS', '2019-12-06 08:47:56.606533', NULL),
	(20, 'TEXT', '2019-12-06 08:47:56.606533', NULL),
	(40, 'NUMBER', '2019-12-06 08:47:56.606533', NULL),
	(50, 'MONEY', '2019-12-06 08:47:56.606533', NULL),
	(60, 'DATE', '2019-12-06 08:47:56.606533', NULL),
	(70, 'AUTOCOMPLETE', '2019-12-06 08:47:56.606533', NULL),
	(80, 'MULTIPLE_CHOICE', '2019-12-06 08:47:56.606533', NULL);

/*!40000 ALTER TABLE `cq_question_types` ENABLE KEYS */;
UNLOCK TABLES;

LOCK TABLES `cq_questions` WRITE;
/*!40000 ALTER TABLE `cq_questions` DISABLE KEYS */;
INSERT INTO `cq_questions` (`product_bank_id`, `question_text`, `code`, `description`, `group_id`, `type_id`, `max_length`, `order_value`, `creation_date`, `last_modified_date`, `is_active`, `is_mandatory`)
VALUES
	(8, 'Bitte geben Sie den Vornamen Ihres Vaters an. Sollten Sie diesen nicht kennen schreiben Sie bitte \"unbekannt\".', 'FATHER_NAME', 'Diese Angabe ist für die Anlegeridentifikation in Griechenland erforderlich.', 1, 20, NULL, 10, '2020-07-31 09:39:37.623989', NULL, 1, 1);
/*!40000 ALTER TABLE `cq_questions` ENABLE KEYS */;
UNLOCK TABLES;

-- PB Dump completed
