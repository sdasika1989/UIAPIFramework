# Mocking it up!
One of the main problems with ZP is the many dependencies we have and trying to test each of them.

This module uses [mock-server](https://www.mock-server.com/) to mock/proxy all dependent zp services so
the shop can be tested in isolation.

# Before you start
You need to do [this](https://confluence.deposit-solutions.com/display/DSM/Step-by-step+workspace+setup+guide)

You should also read [what is mockserver](https://www.mock-server.com/#what-is-mockserver)

Check out the video [here](https://web.microsoftstream.com/video/8d07c119-c32b-415f-aed7-a6f2b9682a1d)

# How do I use it?
1) If this [MR](https://git.prod.infra.deposit/comonea/ds-zinspilot-shop/-/merge_requests/613) hasn't been merged, you will
   need to either
   1) Change the shop version in the .env file to
        ```bash
       DS_SHOP_VERSION=feature-kepler-14311-add-mockserver-SNAPSHOT
       ```
   1) Build a local docker image for the shop with the changes from feature-kepler-14311-add-mockserver-SNAPSHOT 
      (enable the local-docker-build in maven and run mvn package)
      and change the shop image used for docker-compose.yml
       ```bash
       shop:
          image: registry.prod.infra.deposit/comonea/ds-zinspilot-shop:${DS_SHOP_VERSION}
       
       shop:
          image: localregistry/comonea/ds-zinspilot-shop:0-SNAPSHOT
        ```      
1) Start the environment up 
   ```bash
   cd $WORKSPACE_DIR/ds-zinspilot-whole-environment
   PROFILE=mockproxy ./dc.sh up -d shop
   ```
1) Login to the shop [http://localhost:8096](http://localhost:8096)
1) Open up a separate browser [http://localhost:1080/mockserver/dashboard](http://localhost:1080/mockserver/dashboard)
 and take a look at all the data the shop loads on login.
1) Go to the high yield page and my profile page and then log out.
1) Run the follow command to "save" all the data.
   ```bash
   ./mockserver/save.sh
   ```
1) You should see a new file saved in the **$WORKSPACE_DIR/ds-zinspilot-whole-environment/mockserver** directory. 
   e.g. **2021-05-12T104212_mock_expectations.json**
1) Stop the environment
   ```bash
   docker-compose stop
   ```
1) Now we have saved our data, let's run the shop with our mockserver.
1) Let's assume the file you created above is called **2021-05-12T104212_mock_expectations.json**
1) Open up the ds-zinspilot-shop project from the branch feature-kepler-14311-refactor-zp-auth-for-okta
1) Open src/main/java/CleanExpectations.java file in ds-mockserver
1) Change the variable at the top of the CleanExpectations to your filename e.g
   ```java 
   final String sourceFilename = "2021-05-05T160805_mock_expecations.json";
   ```
1) Change the name of the initializationJson property in the pom
   ```maven 
      <initializationJson>2021-05-05T160805_mock_expecations.json</initializationJson>
     ``` 
1) Enable the "shop-with-embedded-db" and "with-mockserver" profiles in Maven
1) Run the "Start MockServer" IntelliJ run configuration
1) Run the "Run-ZinspilotShopApplication-With-MockServer-embeddeddb" IntelliJ run configuration
1) Navigate to http://localhost:8197/login/ and login with the save username/password you used when you saved the data

# What next?

Use the saved data to create automated unit/integration testing.

Combine with the test automation work that is already being worked on.



See https://git.prod.infra.deposit/comonea/ds-zinspilot-whole-environment/-/blob/master/mockserver/README.md
