#!/bin/bash

SCRIPT_DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" &> /dev/null && pwd )"
DATETIME=$(date +"%Y-%m-%dT%H%M%S")

curl -v -X PUT "http://localhost:1080/mockserver/retrieve?type=RECORDED_EXPECTATIONS" > ${SCRIPT_DIR}/${DATETIME}_mock_expectations.json
