#!/bin/bash

TMP_DIR_PATH=`mktemp -d`
LOCKFILE="/tmp/`basename $0`.lock"

unlock() { 
  rm -f "${LOCKFILE}" 
  rm -rf "${TMP_DIR_PATH}" 
  exit $? 
}

lock()  { 
  if ( set -o noclobber; echo "locked" > ${LOCKFILE} ) 2> /dev/null; then
     trap unlock INT TERM EXIT
     echo "Lock succeeded" >&2
  else
     echo "Lock failed - exit" >&2
     exit 1
  fi
}

echo_with_date() {
  builtin echo -n `date +"%Y-%m-%d %H:%M:%S"` ": " 
  builtin echo -e $1
}

print_script_vars() {
  echo -e "Script variables:\n `( set -o posix ; set ) | awk '{ if(match($1, \"^ZP_APP_*\") || match($1, \"^DS_*\") || match($1, \"^USE_NOHUB*\")) print; }'`"
}

wait_for_mysql() {
   echo "Checking mysql on host $1"
   
   maxcounter=120
   counter=1 
   while ! mysqladmin ping -h"$1" --silent; do
     echo >&2 "Waiting for mysql to start up ..."
     sleep 1
     counter=`expr $counter + 1`
     if [ $counter -gt $maxcounter ]; then
        >&2 echo "Waiting for MySQL too long already; failing."
        exit 1
     fi;
   done
}

