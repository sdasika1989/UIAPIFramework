#!/bin/bash
set -e

SCRIPT_DIR=$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )
source "${SCRIPT_DIR}/support_functions.sh"

if [ "$1" == "--help" ]; then
  echo "Usage: $(basename $0) [OPTIONS]
  Options:
  --ZP_APP_DIR <value>         -  ZP application directory
  --ZP_APP_MYSQL_HOST <value>  -  ZP app MySql host name
  --ZP_APP_MYSQL_USER <value>  -  ZP app MySql user name
  --ZP_APP_MYSQL_PASS <value>  -  ZP app MySql password
  --ZP_APP_MYSQL_DUMP <value>  -  ZP app MySql dump
  --ZP_APP_MYSQL_DB <value>    -  ZP app MySql dump"
  exit 0
fi
  
ZP_APP_DIR=${ZP_APP_DIR:-"zp_app"}
ZP_APP_MYSQL_HOST=${ZP_APP_MYSQL_HOST:-"127.0.0.1"}
ZP_APP_MYSQL_USER=${ZP_APP_MYSQL_USER:-"root"}
ZP_APP_MYSQL_PASS=${ZP_APP_MYSQL_PASS:-"mysqlroot"}
ZP_APP_MYSQL_DUMP=${ZP_APP_MYSQL_DUMP:-"zp_app.dump.gz"}
ZP_APP_MYSQL_DB=${ZP_APP_MYSQL_DB:-"comonea_b2c"}


echo_with_date "Parsing input parameters ..."
while [ $# -gt 0 ]; do
  if [[ $1 == *"--"* ]]; then
    param="${1/--/}"
    declare $param="$2"
    #echo $param $2 // Optional to see the parameter:value result
  fi
  shift
done
print_script_vars

echo_with_date "Locking script ..."
lock

echo_with_date "Stopping zp application ..."
cd ${ZP_APP_DIR}
docker-compose stop
docker-compose up -d percona_db
cd ..

maxcounter=120
counter=1 
while ! mysqladmin ping -h"${ZP_APP_MYSQL_HOST}" --silent; do
    echo >&2 "Waiting for mysql to start up ..."
    sleep 1
    counter=`expr $counter + 1`
    if [ $counter -gt $maxcounter ]; then
        >&2 echo "Waiting for MySQL too long already; failing."
        exit 1
    fi;
done

echo_with_date "Importing new dump ..."
MYSQL_PWD=${ZP_APP_MYSQL_PASS} mysql --host=${ZP_APP_MYSQL_HOST} --user=${ZP_APP_MYSQL_USER} --database=${ZP_APP_MYSQL_DB} --execute="SET GLOBAL AUTOCOMMIT=0; SET GLOBAL FOREIGN_KEY_CHECKS=0; SET GLOBAL UNIQUE_CHECKS=0;"
gunzip < ${ZP_APP_MYSQL_DUMP} | MYSQL_PWD=${ZP_APP_MYSQL_PASS} mysql --host=${ZP_APP_MYSQL_HOST} --user=${ZP_APP_MYSQL_USER} --database=${ZP_APP_MYSQL_DB}
MYSQL_PWD=${ZP_APP_MYSQL_PASS} mysql --host=${ZP_APP_MYSQL_HOST} --user=${ZP_APP_MYSQL_USER} --database=${ZP_APP_MYSQL_DB} --execute="SET GLOBAL AUTOCOMMIT=1; SET GLOBAL FOREIGN_KEY_CHECKS=1; SET GLOBAL UNIQUE_CHECKS=1;" 

echo_with_date "Restarting zp application ..."
cd ${ZP_APP_DIR}
docker-compose stop
docker-compose up -d shop
 
echo_with_date "Cleaning data ..."
cd ..
rm -rf ${ZP_APP_MYSQL_DUMP}

echo_with_date "Done."