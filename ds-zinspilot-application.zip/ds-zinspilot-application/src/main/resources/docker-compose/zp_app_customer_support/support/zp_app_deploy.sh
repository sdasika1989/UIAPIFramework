#!/bin/bash
set -e

SCRIPT_DIR=$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )
source "${SCRIPT_DIR}/support_functions.sh"

if [ "$1" == "--help" ]; then
  echo "Usage: $(basename $0) [OPTIONS]
  Options:
  --ZP_APP_DIR <value>             -  ZP app directory
  --ZP_APP_SRC_ARCHIVE <value>     -  ZP app src archive name
  --ZP_APP_IMAGES_ARCHIVE <value>  -  ZP app docker images archive name"
  exit 0
fi

ZP_APP_DIR=${ZP_APP_DIR:-"zp_app"}
ZP_APP_SRC_ARCHIVE=${ZP_APP_SRC_ARCHIVE:-"zp_app_src.tar.gz"}
ZP_APP_IMAGES_ARCHIVE=${ZP_APP_IMAGES_ARCHIVE:-"zp_app_images.tar.gz"}


echo_with_date "Parsing input parameters ..."
while [ $# -gt 0 ]; do
  if [[ $1 == *"--"* ]]; then
    param="${1/--/}"
    declare $param="$2"
    #echo $param $2 // Optional to see the parameter:value result
  fi
  shift
done
print_script_vars

echo_with_date "Locking script ..."
lock

if [ -d "${ZP_APP_DIR}" ]; then
   if [ -f "${ZP_APP_DIR}/docker-compose.yml" ]; then
     echo_with_date "Stopping docker and removing all containers & images ..."
     cd ${ZP_APP_DIR}
     docker-compose stop
     docker-compose rm -f -v
     docker-compose down --rmi all --volumes	
     cd ..
   fi
   echo_with_date "Removing old src data ..."
   sudo rm -rf ${ZP_APP_DIR}
fi

echo_with_date "Unpacking new src data ..."
mkdir -p ${ZP_APP_DIR}
tar -xzf ${ZP_APP_SRC_ARCHIVE} -C ${ZP_APP_DIR} 
rm ${ZP_APP_SRC_ARCHIVE}

echo_with_date "Loading new images ..."
docker load --input ${ZP_APP_IMAGES_ARCHIVE}
rm ${ZP_APP_IMAGES_ARCHIVE}

echo_with_date "Starting up application ..."
cd ${ZP_APP_DIR}
docker-compose up -d shop

echo_with_date "Done."