#!/bin/bash
set -e

SCRIPT_DIR=$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )
source "${SCRIPT_DIR}/support/support_functions.sh"

if [ "$1" == "--help" ]; then
  echo "Usage: $(basename $0) [OPTIONS]
  Options:
  --ZP_APP_HOST <value>           -  ZP app target host name
  --ZP_APP_USER <value>           -  ZP app host user name
  --ZP_APP_IDENTITY_FILE <value>  -  ZP app host identity file
  --DS_NEXUS_USER <value>         -  Deposit Solutions Nexus user name
  --DS_NEXUS_PASS <value>         -  Deposit Solutions Nexus password
  --ZP_APP_SRC_DIR_PATH <value>   -  Path to ZP application source folder"
  exit 0
fi
  
ZP_APP_HOST=${ZP_APP_HOST:-"23.101.79.48"}
ZP_APP_USER=${ZP_APP_USER:-"ds_user"}
ZP_APP_IDENTITY_FILE=${ZP_APP_IDENTITY_FILE:-"${SCRIPT_DIR}/ssh/id_rsa_azure_ds_zp_vm"}
DS_NEXUS_USER=${DS_NEXUS_USER:-"install"}
DS_NEXUS_PASS=${DS_NEXUS_PASS:-"IWantNewStuff"}
ZP_APP_SRC_DIR_PATH=${ZP_APP_SRC_DIR_PATH:-"$(dirname ${SCRIPT_DIR})"} 

ZP_APP_NAME=zp_app
ZP_APP_DIR=${ZP_APP_NAME}
ZP_APP_SRC_ARCHIVE=${ZP_APP_NAME}_src.tar.gz
ZP_APP_IMAGES_ARCHIVE=${ZP_APP_NAME}_images.tar.gz

ZP_APP_SSH_KEYS="-o StrictHostKeyChecking=no -i ${ZP_APP_IDENTITY_FILE}"

ZP_APP_IMAGES_NAMES=()
ZP_APP_IMAGES_NAMES[0]="rabbitmq"
ZP_APP_IMAGES_NAMES[1]="minio/minio"
ZP_APP_IMAGES_NAMES[2]="docker-registry.deposit-solutions.com/mailhog/mailhog"
ZP_APP_IMAGES_NAMES[3]="docker-registry.deposit-solutions.com/base/percona"
ZP_APP_IMAGES_NAMES[4]="registry.prod.infra.deposit/core/ds-comonea-contract-management"
ZP_APP_IMAGES_NAMES[5]="registry.prod.infra.deposit/comonea/ds-customer-questionnaire"
ZP_APP_IMAGES_NAMES[6]="registry.prod.infra.deposit/core/ds-comonea-deposit"
ZP_APP_IMAGES_NAMES[7]="registry.prod.infra.deposit/product-banks/management/ds-comonea-product"
ZP_APP_IMAGES_NAMES[8]="registry.prod.infra.deposit/comonea/ds-sbaff"
ZP_APP_IMAGES_NAMES[9]="registry.prod.infra.deposit/core/ds-comonea-sbaff-trustor"
ZP_APP_IMAGES_NAMES[10]="docker-registry.deposit-solutions.com/comonea/service-bank-affiliation-documents"
ZP_APP_IMAGES_NAMES[11]="registry.prod.infra.deposit/comonea/ds-zinspilot-shop"
ZP_APP_IMAGES_NAMES[12]="registry.prod.infra.deposit/comonea/ds-comonea-b2c"
ZP_APP_IMAGES_NAMES[13]="registry.prod.infra.deposit/comonea/ds-comonea-b2c-database-schema"
ZP_APP_IMAGES_NAMES[14]="local/comonea_session_db_migration"
ZP_APP_IMAGES_NAMES[15]="local/sbaff_doc_db_migration"
ZP_APP_IMAGES_NAMES[16]="local/sbaff_db_migration"
ZP_APP_IMAGES_NAMES[17]="local/sbaff_db_import"
ZP_APP_IMAGES_IDS=()

echo_with_date "Parsing input parameters ..."
while [ $# -gt 0 ]; do
  if [[ $1 == *"--"* ]]; then
    param="${1/--/}"
    declare $param="$2"
    #echo $param $2 // Optional to see the parameter:value result
  fi
  shift
done
print_script_vars

echo_with_date "Locking script ..."
lock

echo_with_date "Pulling images ..."
cd ${ZP_APP_SRC_DIR_PATH}

for IMAGE in $(docker-compose config | awk '{if ($1 == "image:") print $2;}'); do  
   for IMAGE_NAME in "${ZP_APP_IMAGES_NAMES[@]}"; do
      if [[ ${IMAGE} == ${IMAGE_NAME}:* || ${IMAGE} == ${IMAGE_NAME} ]]
      then
         if [[ ${IMAGE} == local/* ]] 
         then
            echo docker-compose build --build-arg NEXUS_USER=${DS_NEXUS_USER} --build-arg NEXUS_PASS=${DS_NEXUS_PASS} $(echo ${IMAGE} | sed -e "s/^local\///" -e "s/:.*$//")
         else 
            echo docker pull ${IMAGE}
         fi
         ZP_APP_IMAGES_IDS+=(${IMAGE})
      fi
   done
done

echo_with_date "Saving & packing images ..."
#docker save $(echo ${ZP_APP_IMAGES_IDS[*]}) | gzip > ${TMP_DIR_PATH}/${ZP_APP_IMAGES_ARCHIVE}

echo_with_date "Packing src ..."
echo "Modifying Shop application.properties - setting cookie.domain && typo3BaseUri for remote host ip ..."
mv ${ZP_APP_SRC_DIR_PATH}/shop/application.properties ${ZP_APP_SRC_DIR_PATH}/shop/application.properties.default
awk -F'=' -v app_domain="${ZP_APP_HOST}" '
  BEGIN {OFS = FS} { 
     if (match($1, "cookie.domain")) {
       $0="cookie.domain="app_domain; 
     } 
     else if( match($1, "typo3BaseUri")) {
        $0="typo3BaseUri=http://"app_domain":8096"; 
     }
     print; 
   }' ${ZP_APP_SRC_DIR_PATH}/shop/application.properties.default > ${ZP_APP_SRC_DIR_PATH}/shop/application.properties

exit;
echo "Packing ..."
tar -zcvf ${TMP_DIR_PATH}/${ZP_APP_SRC_ARCHIVE} --exclude='.git' -C ${ZP_APP_SRC_DIR_PATH} .

echo "Cleaning ..."
mv ${ZP_APP_SRC_DIR_PATH}/shop/application.properties.default ${ZP_APP_SRC_DIR_PATH}/shop/application.properties

echo_with_date "Copying data to remote host ... "
scp ${ZP_APP_SSH_KEYS} ${TMP_DIR_PATH}/${ZP_APP_SRC_ARCHIVE} ${TMP_DIR_PATH}/${ZP_APP_IMAGES_ARCHIVE} ${ZP_APP_USER}@${ZP_APP_HOST}:~

echo_with_date "Executing commands on remote host ... "
REMOTE_TMP_DIR="support-$(uuidgen)"
ssh ${ZP_APP_SSH_KEYS} ${ZP_APP_USER}@${ZP_APP_HOST} "mkdir -p ${REMOTE_TMP_DIR}"
scp ${ZP_APP_SSH_KEYS} -r ${SCRIPT_DIR}/support/* ${ZP_APP_USER}@${ZP_APP_HOST}:~/${REMOTE_TMP_DIR}
ssh ${ZP_APP_SSH_KEYS} ${ZP_APP_USER}@${ZP_APP_HOST} "./${REMOTE_TMP_DIR}/zp_app_deploy.sh --ZP_APP_DIR ${ZP_APP_DIR} --ZP_APP_SRC_ARCHIVE ${ZP_APP_SRC_ARCHIVE} --ZP_APP_IMAGES_ARCHIVE ${ZP_APP_IMAGES_ARCHIVE}"
ssh ${ZP_APP_SSH_KEYS} ${ZP_APP_USER}@${ZP_APP_HOST} "rm -rf ${REMOTE_TMP_DIR}"

echo_with_date "Done."

