#!/bin/bash
set -e

SCRIPT_DIR=$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )
source "${SCRIPT_DIR}/support/support_functions.sh"

if [ "$1" == "--help" ]; then
  echo "Usage: $(basename $0) [OPTIONS]
  Options:
  --ZP_APP_MYSQL_HOST <value>  -  ZP app mysql host
  --ZP_APP_MYSQL_USER <value>  -  ZP app mysql user
  --ZP_APP_MYSQL_PASS <value>  -  ZP app mysql user pass
  --ZP_APP_MYSQL_DUMP <value>  -  ZP app db dump
  --DS_NEXUS_USER <value>      -  Deposit Solutions Nexus user name
  --DS_NEXUS_PASS <value>      -  Deposit Solutions Nexus password"
  exit 0
fi

DS_NEXUS_USER=${DS_NEXUS_USER:-"install"}
DS_NEXUS_PASS=${DS_NEXUS_PASS:-"IWantNewStuff"}
ZP_APP_MYSQL_HOST=${ZP_APP_MYSQL_HOST:-"127.0.0.1"}
ZP_APP_MYSQL_USER=${ZP_APP_MYSQL_USER:-"root"}
ZP_APP_MYSQL_PASS=${ZP_APP_MYSQL_PASS:-"mysqlroot"}
ZP_APP_MYSQL_DUMP=${ZP_APP_MYSQL_DUMP:-"zp_app.dump.gz"}
ZP_APP_MYSQL_DB=comonea_b2c

echo_with_date "Parsing input parameters ..."
while [ $# -gt 0 ]; do
  if [[ $1 == *"--"* ]]; then
    param="${1/--/}"
    declare $param="$2"
    #echo $param $2 // Optional to see the parameter:value result
  fi
  shift
done
print_script_vars

echo_with_date "Locking script ..."
lock

echo_with_date "Downloading latest dump ..."
DS_NEXUS_REPO=releases
DS_NEXUS_GROUP_ID=de.comonea.cb2c.dumps
#DS_NEXUS_ARTIFACT_ID=tenant_zp_prd_comonea
DS_NEXUS_ARTIFACT_ID=tenant_mhb_prd_b2c
DS_NEXUS_ARTIFACT_EXT=gz
DS_NEXUS_ARTIFACT_VERSION=LATEST
curl -k -u ${DS_NEXUS_USER}:${DS_NEXUS_PASS} "https://nexus.deposit-solutions.com/service/local/artifact/maven/redirect?r=${DS_NEXUS_REPO}&g=${DS_NEXUS_GROUP_ID}&a=${DS_NEXUS_ARTIFACT_ID}&v=${DS_NEXUS_ARTIFACT_VERSION}&e=${DS_NEXUS_ARTIFACT_EXT}" -L -o ${TMP_DIR_PATH}/${ZP_APP_MYSQL_DUMP}

echo_with_date "Importing new dump ..."
wait_for_mysql ${ZP_APP_MYSQL_HOST}
MYSQL_PWD=${ZP_APP_MYSQL_PASS} mysql --host=${ZP_APP_MYSQL_HOST} --user=${ZP_APP_MYSQL_USER} --database=${ZP_APP_MYSQL_DB} --execute="SET GLOBAL AUTOCOMMIT=0; SET GLOBAL FOREIGN_KEY_CHECKS=0; SET GLOBAL UNIQUE_CHECKS=0;"
gunzip < ${ZP_APP_MYSQL_DUMP} | MYSQL_PWD=${ZP_APP_MYSQL_PASS} mysql --host=${ZP_APP_MYSQL_HOST} --user=${ZP_APP_MYSQL_USER} --database=${ZP_APP_MYSQL_DB}
MYSQL_PWD=${ZP_APP_MYSQL_PASS} mysql --host=${ZP_APP_MYSQL_HOST} --user=${ZP_APP_MYSQL_USER} --database=${ZP_APP_MYSQL_DB} --execute="SET GLOBAL AUTOCOMMIT=1; SET GLOBAL FOREIGN_KEY_CHECKS=1; SET GLOBAL UNIQUE_CHECKS=1;" 

echo_with_date "Done."

