# Description
Scripts are used to roll out ZP Shop to server with pre-installed docker, docker-compose and mysql client. 


# Prerequisites

* SSH keys for server access;
* Server with pre-installed:

  * docker >= 1.19;
  * docker-compose >= 1.24;
  * mysql-client;
  * SSH public key;

* docker >= 1.19;
* docker-compose >= 1.24;
* access to Docker Registry: registry.prod.infra.deposit;
* access to Nexus: nexus.deposit-solutions.com;


# Script structure 
* `zp_remote_env_deploy.sh` - deployment/re-deployment of ZP Shop on remote machine (based on building and exporting docker images and uploading and importing them on server);
* `zp_remote_env_db_update.sh` - ZP Shop database update  on remote machine (based on fetching latest anonymized dump of comonea_b2c schema, uploading to the server and importing with mysql-client);
* `zp_local_env_db_update.sh` - ZP Shop database update on local machine (based on fetching latest anonymized dump of comonea_b2c schema and importing with mysql-client);
* `support/zp_app_deploy.sh` - script for ZP application deployment on remote machine;
* `support/zp_db_update.sh` - script for ZP application database update on remote machine;
* `support/support_functions.sh` - misc. support functions;
 


# Usage
1. Deploying / Redeploying ZP Shop on remote machine: `./zp_remote_env_deploy.sh [OPTIONS]`

Options:

*   `--ZP_APP_HOST <value>` : ZP app target host name
*   `--ZP_APP_USER <value>` : ZP app host user name
*   `--ZP_APP_IDENTITY_FILE <value>` : ZP app host identity file
*   `--DS_NEXUS_USER <value>` : Deposit Solutions Nexus user name
*   `--DS_NEXUS_PASS <value>` : Deposit Solutions Nexus password
*   `--ZP_APP_SRC_DIR_PATH <value>` : Path to ZP application source folder


2. Updating ZP Shop database on remote machine: `./zp_remote_env_db_update.sh [OPTIONS]`

Options:

*   `--ZP_APP_HOST <value>` : ZP app target host name
*   `--ZP_APP_USER <value>` : ZP app host user name
*   `--ZP_APP_IDENTITY_FILE <value>` : ZP app host identity file
*   `--DS_NEXUS_USER <value>` : Deposit Solutions Nexus user name
*   `--DS_NEXUS_PASS <value>` : Deposit Solutions Nexus password

3. Updating ZP Shop database: `./zp_local_env_db_update.sh [OPTIONS]`

Options:

*   `--ZP_APP_MYSQL_HOST <value>` : ZP app mysql host
*   `--ZP_APP_MYSQL_USER <value>` : ZP app mysql user
*   `--ZP_APP_MYSQL_PASS <value>` : ZP app mysql user pass
*   `--ZP_APP_MYSQL_DUMP <value>` : ZP app db dump
*   `--DS_NEXUS_USER` : Deposit Solutions Nexus user name
*   `--DS_NEXUS_PASS` : Deposit Solutions Nexus password
  
