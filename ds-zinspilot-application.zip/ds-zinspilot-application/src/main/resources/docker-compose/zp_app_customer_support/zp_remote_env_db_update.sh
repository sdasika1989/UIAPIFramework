#!/bin/bash
set -e

SCRIPT_DIR=$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )
source "${SCRIPT_DIR}/support/support_functions.sh"

if [ "$1" == "--help" ]; then
  echo "Usage: $(basename $0) [OPTIONS]
  Options:
  --ZP_APP_HOST <value>           -  ZP app target host name
  --ZP_APP_USER <value>           -  ZP app host user name
  --ZP_APP_IDENTITY_FILE <value>  -  ZP app host identity file
  --DS_NEXUS_USER <value>         -  Deposit Solutions Nexus user name
  --DS_NEXUS_PASS <value>         -  Deposit Solutions Nexus password"
  exit 0
fi

ZP_APP_HOST=${ZP_APP_HOST:-"23.101.79.48"}
ZP_APP_USER=${ZP_APP_USER:-"ds_user"}
ZP_APP_IDENTITY_FILE=${ZP_APP_IDENTITY_FILE:-"${SCRIPT_DIR}/ssh/id_rsa_azure_ds_zp_vm"}
DS_NEXUS_USER=${DS_NEXUS_USER:-"install"}
DS_NEXUS_PASS=${DS_NEXUS_PASS:-"IWantNewStuff"}

# USE NOHUP FOR MYSQL IMPORT
USE_NOHUP_ON_REMOTE=1

ZP_APP_SSH_KEYS="-o StrictHostKeyChecking=no -i ${ZP_APP_IDENTITY_FILE}"

ZP_APP_NAME=zp_app
ZP_APP_DIR=${ZP_APP_NAME}
ZP_APP_MYSQL_HOST=127.0.0.1
ZP_APP_MYSQL_USER=root
ZP_APP_MYSQL_PASS=mysqlroot
ZP_APP_MYSQL_DUMP=${ZP_APP_NAME}.dump.gz
ZP_APP_MYSQL_DB=comonea_b2c

echo_with_date "Parsing input parameters ..."
while [ $# -gt 0 ]; do
  if [[ $1 == *"--"* ]]; then
    param="${1/--/}"
    declare $param="$2"
    #echo $param $2 // Optional to see the parameter:value result
  fi
  shift
done
print_script_vars

echo_with_date "Locking script ..."
lock

echo_with_date "Downloading latest dump ..."
DS_NEXUS_REPO=releases
DS_NEXUS_GROUP_ID=de.comonea.cb2c.dumps
DS_NEXUS_ARTIFACT_ID=tenant_zp_prd_comonea
#DS_NEXUS_ARTIFACT_ID=tenant_mhb_prd_b2c
DS_NEXUS_ARTIFACT_EXT=gz
DS_NEXUS_ARTIFACT_VERSION=LATEST
curl -k -u ${DS_NEXUS_USER}:${DS_NEXUS_PASS} "https://nexus.deposit-solutions.com/service/local/artifact/maven/redirect?r=${DS_NEXUS_REPO}&g=${DS_NEXUS_GROUP_ID}&a=${DS_NEXUS_ARTIFACT_ID}&v=${DS_NEXUS_ARTIFACT_VERSION}&e=${DS_NEXUS_ARTIFACT_EXT}" -L -o ${TMP_DIR_PATH}/${ZP_APP_MYSQL_DUMP}

echo_with_date "Copying data to remote host ... "
scp ${ZP_APP_SSH_KEYS} ${TMP_DIR_PATH}/${ZP_APP_MYSQL_DUMP} ${ZP_APP_USER}@${ZP_APP_HOST}:~

echo_with_date "Executing commands on remote host ... " 
REMOTE_TMP_DIR="support-$(uuidgen)"
ssh ${ZP_APP_SSH_KEYS} ${ZP_APP_USER}@${ZP_APP_HOST} "mkdir -p ${REMOTE_TMP_DIR}"
scp ${ZP_APP_SSH_KEYS} -r ${SCRIPT_DIR}/support/* ${ZP_APP_USER}@${ZP_APP_HOST}:~/${REMOTE_TMP_DIR}

SCRIPT_CODE="./${REMOTE_TMP_DIR}/zp_db_update.sh --ZP_APP_DIR ${ZP_APP_DIR} --ZP_APP_MYSQL_HOST ${ZP_APP_MYSQL_HOST} --ZP_APP_MYSQL_USER ${ZP_APP_MYSQL_USER} --ZP_APP_MYSQL_PASS ${ZP_APP_MYSQL_PASS} --ZP_APP_MYSQL_DB ${ZP_APP_MYSQL_DB} --ZP_APP_MYSQL_DUMP ${ZP_APP_MYSQL_DUMP}"
if [ ${USE_NOHUP_ON_REMOTE} -eq 1 ]; then 
  SCRIPT_CODE="nohup ${SCRIPT_CODE} &> nohup.results.out &"; 
fi;
echo "Command to execute - ${SCRIPT_CODE}"
ssh ${ZP_APP_SSH_KEYS} ${ZP_APP_USER}@${ZP_APP_HOST} ${SCRIPT_CODE}

ssh ${ZP_APP_SSH_KEYS} ${ZP_APP_USER}@${ZP_APP_HOST} "rm -rf ${REMOTE_TMP_DIR}"

echo_with_date "Done."

