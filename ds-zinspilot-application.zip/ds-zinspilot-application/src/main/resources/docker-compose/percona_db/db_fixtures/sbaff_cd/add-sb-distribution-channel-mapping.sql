INSERT IGNORE INTO sbaff_cd_service_bank_distribution_channel_mapping(creation_date, service_bank_identifier, distribution_channel_identifier, identified_by_service_bank_as)
VALUES
  (now(), 'MHSBDEHBXXX', 'ZINSPILOT', '19'),
  (now(), 'MHSBDEHBXXX', 'GENO', '19_0006'),
  (now(), 'MHSBDEHBXXX', 'CHECK24', '19_0005'),
  (now(), 'MHSBDEHBXXX', 'JDC', '19_0004');
