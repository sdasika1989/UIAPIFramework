CREATE USER 'cq_u'@'%' identified by 'cq_p';
GRANT ALL ON cq.* TO 'cq_u'@'%';
