CREATE USER 'cm_u'@'%' identified by 'cm_p';
GRANT ALL ON cm.* TO 'cm_u'@'%';
