CREATE USER 'sps_o'@'%' identified by 'sps_p';
GRANT ALL ON sps.* TO 'sps_o'@'%';
CREATE USER 'sps_u'@'%' identified by 'sps_p';
GRANT ALL ON sps.* TO 'sps_u'@'%';
