CREATE USER 'processing_o' IDENTIFIED BY 'processing_p';
GRANT ALL ON processing.* TO 'processing_o'@'%';
CREATE USER 'processing_u'@'%' identified by 'processing_p';
GRANT ALL ON processing.* TO 'processing_u'@'%';
