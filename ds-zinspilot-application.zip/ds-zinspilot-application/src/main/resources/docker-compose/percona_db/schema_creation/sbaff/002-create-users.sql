CREATE USER 'sbaff_o'@'%' identified by 'sbaff_p';
GRANT ALL ON sbaff.* TO 'sbaff_o'@'%';
CREATE USER 'sbaff_u'@'%' identified by 'sbaff_p';
GRANT ALL ON sbaff.* TO 'sbaff_u'@'%';
