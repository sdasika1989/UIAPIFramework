CREATE USER 'comonea_session_o' IDENTIFIED BY 'comonea_session_p';
GRANT ALL ON comonea_session.* TO 'comonea_session_o'@'%';
CREATE USER 'comonea_session_u'@'%' identified by 'comonea_session_p';
GRANT ALL ON comonea_session.* TO 'comonea_session_u'@'%';
