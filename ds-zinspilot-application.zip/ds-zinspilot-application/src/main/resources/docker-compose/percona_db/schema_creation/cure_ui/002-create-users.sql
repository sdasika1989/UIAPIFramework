CREATE USER 'cure_ui_o'@'%' identified by 'cure_ui_p';
GRANT ALL ON cure_ui.* TO 'cure_ui_o'@'%';
CREATE USER 'cure_ui_u'@'%' identified by 'cure_ui_p';
GRANT ALL ON cure_ui.* TO 'cure_ui_u'@'%';
