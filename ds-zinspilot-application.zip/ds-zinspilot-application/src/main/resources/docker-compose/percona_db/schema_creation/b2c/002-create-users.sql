CREATE USER 'comonea_b2c_o' IDENTIFIED BY 'comonea_b2c_p';
GRANT ALL ON comonea_b2c.* TO 'comonea_b2c_o'@'%';
CREATE USER 'comonea_b2c_u'@'%' identified by 'comonea_b2c_p';
GRANT ALL ON comonea_b2c.* TO 'comonea_b2c_u'@'%';
