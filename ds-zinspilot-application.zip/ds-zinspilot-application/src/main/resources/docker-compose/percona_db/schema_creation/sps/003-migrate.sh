#!/bin/bash

echo "MySQL command: ${mysql[@]}"
echo "Database: ${MYSQL_DATABASE}"
echo "Root password: ${MYSQL_ROOT_PASSWORD}"

DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
MIGRATION_JAR=$(basename $(ls -tr ${DIR}/*-jar-with-dependencies.jar | head -1))
echo "Executing migration jar [${MIGRATION_JAR}] on database [${MYSQL_DATABASE}]"
java -Ddb.port=13306 -Ddb.database=$MYSQL_DATABASE -Ddb.username=root -Ddb.password=$MYSQL_ROOT_PASSWORD -jar $DIR/$MIGRATION_JAR
