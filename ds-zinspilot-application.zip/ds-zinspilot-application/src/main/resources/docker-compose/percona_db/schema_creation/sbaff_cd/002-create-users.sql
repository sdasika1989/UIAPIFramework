CREATE USER 'sbcd_o'@'%' identified by 'sbcd_p';
GRANT ALL ON sbaff_cd.* TO 'sbcd_o'@'%';
CREATE USER 'sbcd_u'@'%' identified by 'sbcd_p';
GRANT ALL ON sbaff_cd.* TO 'sbcd_u'@'%';
