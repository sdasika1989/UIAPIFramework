CREATE USER 'sbaff_doc_o'@'%' identified by 'sbaff_doc_p';
GRANT ALL ON sbaff_doc.* TO 'sbaff_doc_o'@'%';
CREATE USER 'sbaff_doc_u'@'%' identified by 'sbaff_doc_p';
GRANT ALL ON sbaff_doc.* TO 'sbaff_doc_u'@'%';
