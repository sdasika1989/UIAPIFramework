#!/bin/sh

cat /b2c_testdata/*.sql | MYSQL_PWD=$MYSQL_ROOT_PASSWORD mysql -h 127.0.0.1 -u root "$DB_SCHEMA"
