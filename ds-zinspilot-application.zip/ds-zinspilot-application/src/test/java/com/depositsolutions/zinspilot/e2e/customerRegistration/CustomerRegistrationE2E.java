package com.depositsolutions.zinspilot.e2e.customerRegistration;

import static com.depositsolutions.common.reusables.TestConstants.SHOP_URL_CONFIG_KEY;

import com.depositsolutions.common.reusables.DBReusables;
import com.depositsolutions.common.reusables.DynamicDataReusables;
import com.depositsolutions.common.ui.helpers.BaseTestClassUI;
import com.depositsolutions.common.ui.helpers.TestDataValidations;
import com.depositsolutions.common.ui.zpuipageobjects.ArchiveAndDocumentsPO;
import com.depositsolutions.common.ui.zpuipageobjects.CustomerRegistrationPO;
import com.depositsolutions.common.ui.zpuipageobjects.MailHogPO;
import com.depositsolutions.common.ui.zpuipageobjects.ShopLoginLogoutPO;
import com.depositsolutions.common.utils.ConfigManager;
import com.depositsolutions.common.utils.TestLogger;
import java.awt.AWTException;
import java.io.IOException;
import java.lang.reflect.Method;
import java.sql.SQLException;
import org.testng.Assert;
import org.testng.ITestResult;
import org.testng.annotations.*;

public class CustomerRegistrationE2E extends BaseTestClassUI {

  private String testDataInjection = ConfigManager.getInstance().getString("testDataInjection");
  public DynamicDataReusables LOAD_INPUTS;
  String dob = "09.09.1990",
      marital = "verheiratet",
      pob = "12/12/2000",
      cob = "Deutschland",
      street = "West Street",
      streetNum = "19-A",
      postal = "14109",
      job = "Hausmann",
      birthName = "Dietrich",
      branch = "Test";

  @BeforeTest(alwaysRun = true)
  public void setupDB() {
    DBReusables.getInstance().dbConnect();
  }

  @BeforeClass(alwaysRun = true)
  public void preLoadSQLTestData() {
    if (testDataInjection.equalsIgnoreCase("Yes")) {
      // Truncate All Tables
      DBReusables.getInstance().executeSqlScript("TruncateAllTables.sql");
      // Test Data Injection for Service Bank
      DBReusables.getInstance().executeSqlScript("serviceBank-sutor.sql");
    } else {
      // Test data till sbaff abd sbaff_cd bug is resolved
      DBReusables.getInstance().executeSqlScript("sbaff_sbaff_cd.sql");
    }
  }

  @BeforeMethod(alwaysRun = true)
  public void setup() {
    setUpForTest(ConfigManager.getInstance().getString(SHOP_URL_CONFIG_KEY));
  }

  @Test(
      enabled = true,
      groups = {"CustomerRegistration", "Regression"})
  public void CustomerRegistration_ActivationLink(Method methodName)
      throws InterruptedException, SQLException, AWTException, IOException, ClassNotFoundException {
    String testName = methodName.getName();
    TestLogger.logMsg("==========" + testName + " Started=========");

    Registration(
        "Button", dob, marital, pob, cob, street, streetNum, postal, job, birthName, branch);

    TestLogger.logMsg("==========" + testName + " Completed=========");
  }

  @Test(
      enabled = true,
      groups = {"CustomerRegistration", "Regression"})
  public void CustomerRegistration_ActivationCode(Method methodName)
      throws InterruptedException, SQLException, AWTException, IOException, ClassNotFoundException {
    String testName = methodName.getName();
    TestLogger.logMsg("==========" + testName + " Started=========");
    Registration("Code", dob, marital, pob, cob, street, streetNum, postal, job, birthName, branch);

    TestLogger.logMsg("==========" + testName + " Completed=========");
  }

  @Test(
      enabled = true,
      groups = {"CustomerRegistration", "Regression", "e2e"})
  public void CustomerRegistration_ActivationButton(Method methodName)
      throws InterruptedException, SQLException, AWTException, IOException, ClassNotFoundException {
    String testName = methodName.getName();
    TestLogger.logMsg("==========" + testName + " Started=========");
    Registration(
        "Button", dob, marital, pob, cob, street, streetNum, postal, job, birthName, branch);

    TestLogger.logMsg("==========" + testName + " Completed=========");
  }

  @Test(
      enabled = true,
      groups = {"CustomerRegistration", "Regression"})
  public void ErrorMessageValidations(Method methodName)
      throws InterruptedException, SQLException, AWTException, IOException, ClassNotFoundException {
    String testName = methodName.getName();
    TestLogger.logMsg("==========" + testName + " Started=========");
    CustomerRegistrationPO.getInstance().signupWithoutEmail();

    CustomerRegistrationPO.getInstance().verifyRegistrationFormErrMsg();

    launchUrl(ConfigManager.getInstance().getString(SHOP_URL_CONFIG_KEY));

    LOAD_INPUTS = DynamicDataReusables.getInstance();
    DynamicDataReusables.getInstance().generateInputs();

    CustomerRegistrationPO.getInstance()
        .customerRegistration(
            LOAD_INPUTS.firstName,
            LOAD_INPUTS.surName,
            LOAD_INPUTS.emailAddress,
            LOAD_INPUTS.password,
            LOAD_INPUTS.saluation,
            LOAD_INPUTS.title);

    MailHogPO.getInstance()
        .customerRegistration_ActivationButton(
            LOAD_INPUTS.emailAddress, "Ihre Anmeldung bei Zinspilot");

    ShopLoginLogoutPO.getInstance().shopLogOut();

    CustomerRegistrationPO.getInstance().closeTabsErrMsg();

    TestLogger.logMsg("Register with existing customer details");
    CustomerRegistrationPO.getInstance()
        .customerRegistration(
            LOAD_INPUTS.firstName,
            LOAD_INPUTS.surName,
            LOAD_INPUTS.emailAddress,
            LOAD_INPUTS.password,
            LOAD_INPUTS.saluation,
            LOAD_INPUTS.title);

    CustomerRegistrationPO.getInstance().verifyEmailAddressAlreadyRegistered();
    setUpForTest(ConfigManager.getInstance().getString(SHOP_URL_CONFIG_KEY));

    TestLogger.logMsg("==========" + testName + " Completed=========");
  }

  @Test(
      enabled = true,
      groups = {"CustomerRegistration", "Regression"})
  public void LinkValidations(Method methodName)
      throws InterruptedException, SQLException, AWTException, IOException, ClassNotFoundException {
    String testName = methodName.getName();
    TestLogger.logMsg("==========" + testName + " Started=========");
    CustomerRegistrationPO.getInstance().verifyLoginPageLinks();

    CustomerRegistrationPO.getInstance()
        .verifyRegistrationFormLink(ConfigManager.getInstance().getString(SHOP_URL_CONFIG_KEY));

    LOAD_INPUTS = DynamicDataReusables.getInstance();
    LOAD_INPUTS.generateInputs();

    TestLogger.logInfo("Register with existing customer details");
    CustomerRegistrationPO.getInstance()
        .customerRegistration(
            LOAD_INPUTS.firstName,
            LOAD_INPUTS.surName,
            LOAD_INPUTS.emailAddress,
            LOAD_INPUTS.password,
            LOAD_INPUTS.saluation,
            LOAD_INPUTS.title);

    MailHogPO.getInstance()
        .customerRegistration_ActivationButton(
            LOAD_INPUTS.emailAddress, "Ihre Anmeldung bei Zinspilot");

    String CustNo = DBReusables.getInstance().getCustomerNumber(LOAD_INPUTS.emailAddress);
    TestLogger.logInfo("Customer Number : " + CustNo);

    String CustomerIban = LOAD_INPUTS.CustomerIban(CustNo);

    CustomerRegistrationPO.getInstance()
        .accountOpening(
            LOAD_INPUTS.saluation,
            LOAD_INPUTS.title,
            LOAD_INPUTS.firstName,
            LOAD_INPUTS.surName,
            LOAD_INPUTS.emailAddress,
            LOAD_INPUTS.phone,
            dob,
            marital,
            cob,
            street,
            streetNum,
            postal,
            job,
            birthName,
            CustomerIban,
            branch);

    CustomerRegistrationPO.getInstance().verifyAccConfirmationLinks();

    CustomerRegistrationPO.getInstance().accountConfirmation();

    TestLogger.logMsg("==========" + testName + " Completed=========");
  }

  /**
   * author: Shalini Sudam This test-case validates if user gets appropriate error message when
   * trying to enter incorrect activation code during customer registration
   *
   * @throws InterruptedException
   * @throws SQLException
   */
  @Test(
      enabled = true,
      groups = {"CustomerRegistration", "Regression"})
  public void testValidateIncorrectActivationCode() throws InterruptedException, SQLException {
    sTestCaseID = "C3220";
    TestLogger.logInfo("TestCase ID: " + sTestCaseID);

    TestLogger.logMsg("Step-1: Perform Customer Registration");
    LOAD_INPUTS = new DynamicDataReusables();
    LOAD_INPUTS.generateInputs();
    CustomerRegistrationPO.getInstance()
        .customerRegistration(
            LOAD_INPUTS.firstName,
            LOAD_INPUTS.surName,
            LOAD_INPUTS.emailAddress,
            LOAD_INPUTS.password,
            LOAD_INPUTS.saluation,
            LOAD_INPUTS.title);
    TestLogger.logMsg("Step-2: Validate if the customer status is updated to Registered");
    CustomerRegistrationPO.getInstance()
        .verifyCustomerStatus(LOAD_INPUTS.emailAddress, "REGISTERED");

    TestLogger.logInfo(
        "Step-3: Enter the Incorrect activation code in the Activation text box and Open Account Button");
    DRIVER
        .findElement(CustomerRegistrationPO.getInstance().CR_ActivationCodeTextbox)
        .sendKeys("INCORRECT ACTIVATION");
    DRIVER.findElement(CustomerRegistrationPO.getInstance().CR_OpeningAccButton).click();

    String errorMessage =
        DRIVER
            .findElement(CustomerRegistrationPO.getInstance().CR_IncorrectActivationCode_ErrorMsg)
            .getText();
    TestLogger.logMsg(
        "Step-4: Validate if an error message with incorrect registration code is displayed to the customer");
    Assert.assertEquals(
        errorMessage,
        TestDataValidations.INCORRECT_ACTIVATIONCODE_MESSAGE,
        "Expected Message: "
            + errorMessage
            + "But found: "
            + TestDataValidations.INCORRECT_ACTIVATIONCODE_MESSAGE);
  }

  public void Registration(
      String methodName,
      String dob,
      String marital,
      String pob,
      String cob,
      String street,
      String streetNum,
      String postal,
      String job,
      String birthName,
      String branch)
      throws InterruptedException, SQLException, AWTException, IOException, ClassNotFoundException {
    LOAD_INPUTS = new DynamicDataReusables();

    LOAD_INPUTS.generateInputs();

    CustomerRegistrationPO.getInstance()
        .customerRegistration(
            LOAD_INPUTS.firstName,
            LOAD_INPUTS.surName,
            LOAD_INPUTS.emailAddress,
            LOAD_INPUTS.password,
            LOAD_INPUTS.saluation,
            LOAD_INPUTS.title);

    CustomerRegistrationPO.getInstance()
        .verifyCustomerStatus(LOAD_INPUTS.emailAddress, "REGISTERED");

    if (methodName.contains("Button")) {
      MailHogPO.getInstance()
          .customerRegistration_ActivationButton(
              LOAD_INPUTS.emailAddress, "Ihre Anmeldung bei Zinspilot");
    } else if (methodName.contains("Code")) {

      CustomerRegistrationPO.getInstance()
          .ActivatingCustomer_ActivationCode(
              LOAD_INPUTS.emailAddress, "Ihre Anmeldung bei Zinspilot");
    } else {
      CustomerRegistrationPO.getInstance()
          .ActivatingCustomer_ActivationLink(
              LOAD_INPUTS.emailAddress, "Ihre Anmeldung bei Zinspilot");
    }

    String CustNo = DBReusables.getInstance().getCustomerNumber(LOAD_INPUTS.emailAddress);
    TestLogger.logMsg("Customer Number : " + CustNo);

    String CustomerIban = LOAD_INPUTS.CustomerIban(CustNo);

    CustomerRegistrationPO.getInstance()
        .accountOpening(
            LOAD_INPUTS.saluation,
            LOAD_INPUTS.title,
            LOAD_INPUTS.firstName,
            LOAD_INPUTS.surName,
            LOAD_INPUTS.emailAddress,
            LOAD_INPUTS.phone,
            dob,
            marital,
            cob,
            street,
            streetNum,
            postal,
            job,
            birthName,
            CustomerIban,
            branch);

    CustomerRegistrationPO.getInstance().accountConfirmation();
    CustomerRegistrationPO.getInstance()
        .verifyCustomerStatus(LOAD_INPUTS.emailAddress, "ACTIVATED");

    CustomerRegistrationPO.getInstance().VerifyOKEDocument();

    CustomerRegistrationPO.getInstance().verifyProcessState("accepted", CustNo);

    CustomerRegistrationPO.getInstance().exportSbaffandVerifyState(CustNo);

    CustomerRegistrationPO.getInstance().verifyProcessState("exported", CustNo);

    CustomerRegistrationPO.getInstance().sutorSplitterSFTP(CustNo);

    CustomerRegistrationPO.getInstance().verifyProcessState("acknowledged", CustNo);

    CustomerRegistrationPO.getInstance()
        .importCustomerListCSV(
            CustNo,
            LOAD_INPUTS.title,
            LOAD_INPUTS.saluation,
            LOAD_INPUTS.surName,
            LOAD_INPUTS.firstName,
            dob,
            pob,
            LOAD_INPUTS.phone,
            LOAD_INPUTS.surName + ", " + LOAD_INPUTS.firstName,
            street + " " + streetNum,
            postal,
            marital,
            CustomerIban);

    CustomerRegistrationPO.getInstance()
        .verifyCustomerStatus(LOAD_INPUTS.emailAddress, "FULLY_REGISTERED");
    // Check in Archive and Documents
    ArchiveAndDocumentsPO.getInstance()
        .validatePersonalDocument(
            DBReusables.getInstance().formatDate("dd.MM.yyyy")
                + " Antrag auf Kontoeröffnung"
                + " Download Kontoeröffnungsantrag",
            "present");
    ArchiveAndDocumentsPO.getInstance()
        .validatePersonalDocument(
            "01.01.2022 Anpassung Nutzungs-/Treuhandvereinbarung (Kontoführungs- und Geschäftsbesorgungsvereinbarung) per 01.07.2019 Download Kontoführungs- und Geschäftsbesorgungsvereinbarung",
            "present");
    ArchiveAndDocumentsPO.getInstance()
        .validatePersonalDocument(
            "13.06.2018 Datenschutzhinweise Sutor Bank (EU-DSGVO) Download Datenschutzhinweise",
            "present");

    CustomerRegistrationPO.getInstance().closeTabsErrMsg();
  }

  @AfterMethod(alwaysRun = true)
  public void teardown(ITestResult result) {
    TestLogger.logInfo("Executing Browser tearDown method");
    if (ITestResult.FAILURE == result.getStatus()) {
      takeScreenshot(result.getName());
    }
    ShopLoginLogoutPO.getInstance().closeAllBrowsers();
  }

  @AfterTest(alwaysRun = true)
  // Closing All connections
  public void cleanup() throws SQLException {

    DBReusables.getInstance().closeDBCon();
  }
}
