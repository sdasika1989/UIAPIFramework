package com.depositsolutions.zinspilot.e2e.shopui;

import static com.depositsolutions.common.reusables.TestConstants.SHOP_URL_CONFIG_KEY;

import com.depositsolutions.common.reusables.DBReusables;
import com.depositsolutions.common.ui.helpers.*;
import com.depositsolutions.common.ui.zpuipageobjects.ProductDetailsPO;
import com.depositsolutions.common.ui.zpuipageobjects.ShopLoginLogoutPO;
import com.depositsolutions.common.utils.ConfigManager;
import com.depositsolutions.common.utils.TestLogger;
import java.sql.SQLException;
import org.testng.Assert;
import org.testng.ITestResult;
import org.testng.annotations.*;

/** Feature: ShopLoginLogout test-scripts TestRail Link: author: Shalini.Sudam */
public class ShopLoginLogout extends BaseTestClassUI {

  public ShopLoginLogout() {}

  @BeforeMethod(alwaysRun = true)
  @Parameters({"customerEmail"})
  public void setup(String customerEmail) {
    setUpForTest(ConfigManager.getInstance().getString(SHOP_URL_CONFIG_KEY));
  }

  @Test(
      enabled = true,
      groups = {"Sanity", "Standalone", "Regression"})
  @Parameters({"customerEmail"})
  public void testloginShop(String customerEmail) {
    sTestCaseID = "C5148";
    TestLogger.logMsg("TestCaseID: " + sTestCaseID);
    TestLogger.logMsg("Step-1: Log into Shop ");
    ShopLoginLogoutPO.getInstance().shopLogin(ENV, customerEmail);

    TestLogger.logMsg("Step-2: Verify if Product Page is displayed");
    ProductDetailsPO.getInstance().verifyShopHomePageIsDisplayed();

    TestLogger.logMsg("Step-3: Logout from Shop");
    ShopLoginLogoutPO.getInstance().shopLogOut();
  }

  @Test(
      enabled = true,
      groups = {"Sanity", "Standalone", "Regression"})
  @Parameters({"customerEmail"})
  public void testProductListPage(String customerEmail) {
    sTestCaseID = "C5149";
    TestLogger.logMsg("TestCaseID: " + sTestCaseID);
    TestLogger.logMsg("Step-1: Log into Shop ");
    WebUIOperations.getInstance()
        .verifyElementIsPresent(
            getWebElement(ShopLoginLogoutPO.getInstance().zpUserName), "ZP Login");
    ShopLoginLogoutPO.getInstance().shopLogin(ENV, customerEmail);

    TestLogger.logMsg("Step-2: Verify if Product List is displayed");
    WebUIOperations.getInstance()
        .verifyElementIsPresent(
            getWebElement(ProductDetailsPO.getInstance().zpShopHomePageTerms), "Terms DropDown");
    WebUIOperations.getInstance()
        .verifyElementIsPresent(
            getWebElement(ProductDetailsPO.getInstance().zpShopHomePageAllCountries),
            "All Countries DropDown");
    WebUIOperations.getInstance()
        .verifyElementIsPresent(
            getWebElement(ProductDetailsPO.getInstance().zpShopHomePageSort), "Sort DropDown");
    TestLogger.logMsg("Step-3: Logout from Shop");
    ShopLoginLogoutPO.getInstance().shopLogOut();
  }

  @Test(
      enabled = false,
      groups = {"Sanity", "Standalone", "Regression"})
  @Parameters({"customerEmail", "profileName"})
  public void testShopLoginAndTypo3Page(String customerEmail, String profileName) {
    sTestCaseID = "C5150";
    String actualProfileName;
    TestLogger.logMsg("TestCaseID:  " + sTestCaseID);
    TestLogger.logMsg("Step-1: Log into Shop ");
    ShopLoginLogoutPO.getInstance().shopLogin(ENV, customerEmail);

    TestLogger.logMsg("Step-2: Verify if Customer Name is displayed");
    actualProfileName = ShopLoginLogoutPO.getInstance().getCustomerInfo();
    Assert.assertEquals(actualProfileName, profileName);

    TestLogger.logMsg(
        "Step-3: Click on Typo3 Page ex: Banken and verify if the customer is still loggedin and customer name is shown on the right");
    getWebElement(ShopLoginLogoutPO.getInstance().bankenLink).click();
    Assert.assertEquals(actualProfileName, profileName);

    TestLogger.logMsg("Step-4: Logout from Shop");
    ShopLoginLogoutPO.getInstance().shopLogOut();
  }

  @Test(
      enabled = true,
      groups = {"Sanity", "Standalone", "Regression"})
  @Parameters({"customerEmail", "profileName"})
  public void testShopLogout(String customerEmail, String profileName) {
    sTestCaseID = "C5928";
    String actualProfileName = "";
    TestLogger.logMsg("TestCaseID: " + sTestCaseID);
    TestLogger.logMsg("Step-1: Login is Shop ");

    ShopLoginLogoutPO.getInstance().shopLogin(ENV, customerEmail);

    TestLogger.logMsg("Step-2: Verify if the CustomerInfo is displayed on the right top corner");
    actualProfileName = ShopLoginLogoutPO.getInstance().getCustomerInfo();
    Assert.assertEquals(actualProfileName, profileName);

    TestLogger.logMsg("Step-3: Logout of the application and verify if it navigates to LoginPage");
    ShopLoginLogoutPO.getInstance().shopLogOut();
    WebUIOperations.getInstance()
        .verifyElementIsPresent(
            getWebElement(ShopLoginLogoutPO.getInstance().zpUserName), "UserName Field");

    TestLogger.logMsg(
        "Step-4: Click on Typo3 Page ex: Banken and verify if the customer is still logged-in and customer name is shown on the right");
    getWebElement(ShopLoginLogoutPO.getInstance().bankenLink).click();
    Assert.assertEquals(actualProfileName, profileName);
  }

  @AfterMethod(alwaysRun = true)
  public void teardown(ITestResult result) {
    if (ITestResult.FAILURE == result.getStatus()) {
      takeScreenshot(result.getName());
    }
    TestLogger.logInfo("Executing Browser tearDown method");
    ShopLoginLogoutPO.getInstance().closeAllBrowsers();
  }

  @AfterTest(alwaysRun = true)
  public void cleanup() throws SQLException {
    DBReusables.getInstance().closeDBCon();
  }
}
