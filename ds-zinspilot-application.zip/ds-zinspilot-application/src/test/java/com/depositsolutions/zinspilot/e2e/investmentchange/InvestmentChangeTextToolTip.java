package com.depositsolutions.zinspilot.e2e.investmentchange;

import static com.depositsolutions.common.reusables.TestConstants.SHOP_URL_CONFIG_KEY;

import com.depositsolutions.common.restapi.services.Deposit;
import com.depositsolutions.common.reusables.DBReusables;
import com.depositsolutions.common.ui.helpers.BaseTestClassUI;
import com.depositsolutions.common.ui.zpuipageobjects.MeineAnlagenPO;
import com.depositsolutions.common.ui.zpuipageobjects.ShopLoginLogoutPO;
import com.depositsolutions.common.utils.ConfigManager;
import com.depositsolutions.common.utils.TestLogger;
import java.awt.*;
import java.lang.reflect.Method;
import java.sql.SQLException;
import org.testng.ITestResult;
import org.testng.annotations.*;

public class InvestmentChangeTextToolTip extends BaseTestClassUI {
  private String testDataInjection = ConfigManager.getInstance().getString("testDataInjection");
  String CustomerEmail, TargetTrancheIdentifier, SourceTrancheIdentifier;

  @BeforeTest(alwaysRun = true)
  public void setupDB() {

    DBReusables.getInstance().dbConnect();
  }

  @BeforeMethod(alwaysRun = true)
  public void preLoadSQLTestData() {
    if (testDataInjection.equalsIgnoreCase("Yes")) {
      DBReusables.getInstance().executeSqlScript("TruncateAllTables.sql");
      DBReusables.getInstance().executeSqlScript("serviceBank-sutor.sql");
    } else {
      // Truncate sps Tables
      DBReusables.getInstance().executeSqlScript("TruncateSPSTables.sql");
    }
    setUpForTest(ConfigManager.getInstance().getString(SHOP_URL_CONFIG_KEY));
  }

  /*
   * Feature: Validating Investment Change UI text and Tool Tip Text on Shop
   * Product Type: FG to TG
   * ProductBank Model: FAM
   * TestRail Link:https://depositsolutions.testrail.io/index.php?/cases/view/11876
   * Author: deepthi.gorre
   */
  @Test(
      enabled = true,
      groups = {"InvestmentChange", "Regression"})
  @Parameters({"sourceTrancheIdentifier", "customerEmail", "targetTrancheIdentifier"})
  public void C11876_Shop_ICText_ToolTip_Internal_FAM_FG2TG(
      Method methodName,
      String sSourceTrancheIdentifier,
      String sCustomerEmail,
      String sTargetTrancheIdentifier)
      throws SQLException, ClassNotFoundException, InterruptedException, AWTException {
    if (testDataInjection.equalsIgnoreCase("Yes")) {
      // Test Data Injection for Product Bank
      DBReusables.getInstance().executeSqlScript("productBank_CreditPlus.sql");
      DBReusables.getInstance().executeSqlScript("Tranche-CreditPlus-TG.sql");
      DBReusables.getInstance().executeSqlScript("Tranche-CreditPlus-FG1Y.sql");
      // Test Data Injection for Customer with Deposit
      DBReusables.getInstance().executeSqlScript("customerWithPayIn-CreditPlus-FG1Y.sql");
      // Getting customer details
      CustomerEmail = DBReusables.getInstance().getCustomerEmail();
      // Getting Product Details
      SourceTrancheIdentifier = DBReusables.getInstance().getPreviousTrancheIdentifier("FG");
      TargetTrancheIdentifier = DBReusables.getInstance().getTrancheIdentifier("TG");

    } else {
      CustomerEmail = sCustomerEmail;
      SourceTrancheIdentifier = sSourceTrancheIdentifier;
      TargetTrancheIdentifier = sTargetTrancheIdentifier;
    }
    String testName = methodName.getName();

    TestLogger.logMsg("==========" + testName + " Started==========");

    ShopLoginLogoutPO.getInstance().shopLogin(ENV, CustomerEmail);
    MeineAnlagenPO.getInstance().getInvestmentDetails(SourceTrancheIdentifier, CustomerEmail);
    TestLogger.logMsg("Step-1: Investment Change Mapping and Create IC from UI");
    // Investment Change Mapping
    Deposit.getInstance().investmentChangeMapping(SourceTrancheIdentifier, TargetTrancheIdentifier);
    // Initiating IC from shop UI
    TestLogger.logMsg("Step-2: Validate Investment Change UI Text");
    MeineAnlagenPO.getInstance().validateIcText(TargetTrancheIdentifier);

    TestLogger.logMsg("==========" + testName + " Completed==========");
  }

  @AfterMethod(alwaysRun = true)
  public void teardown(ITestResult result) {
    if (ITestResult.FAILURE == result.getStatus()) {
      takeScreenshot(result.getName());
    }
    TestLogger.logInfo("Executing Browser tearDown method");
    ShopLoginLogoutPO.getInstance().closeAllBrowsers();
  }

  @AfterTest(alwaysRun = true)
  // Closing All connections
  public void cleanup() throws SQLException {
    // closeDBCon();
    TestLogger.logInfo("Executing DB Cleanup");

    DBReusables.getInstance().closeDBCon();
  }
}
