package com.depositsolutions.zinspilot.e2e.prolongation;

import static com.depositsolutions.common.reusables.TestConstants.SHOP_URL_CONFIG_KEY;

import com.depositsolutions.common.restapi.helpers.WebServiceOperations;
import com.depositsolutions.common.restapi.services.Gunda;
import com.depositsolutions.common.restapi.services.ProdOps;
import com.depositsolutions.common.reusables.DBReusables;
import com.depositsolutions.common.reusables.GundaServices;
import com.depositsolutions.common.ui.helpers.BaseTestClassUI;
import com.depositsolutions.common.ui.zpuipageobjects.MeineAnlagenPO;
import com.depositsolutions.common.ui.zpuipageobjects.ShopLoginLogoutPO;
import com.depositsolutions.common.utils.ConfigManager;
import com.depositsolutions.common.utils.TestLogger;
import java.lang.reflect.Method;
import java.sql.SQLException;
import org.openqa.selenium.By;
import org.testng.Assert;
import org.testng.ITestResult;
import org.testng.annotations.*;

public class C1693_ProductBankProlongationSettings extends BaseTestClassUI {
  public String ServiceBank_BIC = "MHSBDEHBXXX";
  String Ptype;
  private String testDataInjection = ConfigManager.getInstance().getString("testDataInjection");
  String CustomerEmail, SourceTrancheIdentifier, PayOutAmount;

  @BeforeTest(alwaysRun = true)
  public void setupDB() {
    DBReusables.getInstance().dbConnect();
  }

  @BeforeMethod(alwaysRun = true)
  public void preLoadSQLTestData() {
    if (testDataInjection.equalsIgnoreCase("Yes")) {
      // Truncate All Tables
      DBReusables.getInstance().executeSqlScript("TruncateAllTables.sql");
      // Test Data Injection for Customer and Service Bank
      DBReusables.getInstance().executeSqlScript("serviceBank-sutor.sql");
      // Test Data Injection for Product Bank
      DBReusables.getInstance().executeSqlScript("productBank_CreditPlus.sql");
      DBReusables.getInstance().executeSqlScript("Tranche-CreditPlus-FG1Y.sql");
      // Test Data Injection for Customer with Deposit
      DBReusables.getInstance().executeSqlScript("customerWithPayIn-CreditPlus-FG1Y.sql");
      // Getting customer details
      CustomerEmail = DBReusables.getInstance().getCustomerEmail();
      // Getting Product Details
      SourceTrancheIdentifier = DBReusables.getInstance().getPreviousTrancheIdentifier("FG");
      PayOutAmount = "513.00";
    }
    setUpForTest(ConfigManager.getInstance().getString(SHOP_URL_CONFIG_KEY));
  }

  /*
   * Feature: Product Bank Prolongation Settings
   * Product Type:Fixed Term
   * Product Bank Model:FIDUCIARY_ACCOUNT_MODEL(FAM)
   * TestRail Link: https://depositsolutions.testrail.io/index.php?/cases/view/1693
   *                https://depositsolutions.testrail.io/index.php?/cases/view/1904
   * Author: deepthi.gorre
   */
  @Test(
      enabled = true,
      groups = {"Prolongation", "Regression"})
  @Parameters({"sourceTrancheIdentifier", "payOutAmount", "customerEmail"})
  public void C1904_C1693_ProductBankProlongationSettings(
      Method methodName,
      String sSourceTrancheIdentifier,
      String sPayOutAmount,
      String sCustomerEmail)
      throws InterruptedException {
    if (testDataInjection.equalsIgnoreCase("No")) {
      CustomerEmail = sCustomerEmail;
      SourceTrancheIdentifier = sSourceTrancheIdentifier;
      PayOutAmount = sPayOutAmount;
    }
    String testName = methodName.getName();
    TestLogger.logMsg("==========" + testName + " Started==========");
    String CustomerNumber = DBReusables.getInstance().getCustomerNumber(CustomerEmail);
    String CIA =
        DBReusables.getInstance().getCIA(CustomerNumber, SourceTrancheIdentifier, ServiceBank_BIC);
    String shopCacheUrl = ConfigManager.getInstance().getString("shopCacheUrl");

    // shop login
    ShopLoginLogoutPO.getInstance().shopLogin(ENV, CustomerEmail);
    DRIVER.findElement(MeineAnlagenPO.getInstance().ZP_MeineAnlagen).click();
    MeineAnlagenPO.getInstance().verifyZPProductDetails(SourceTrancheIdentifier);
    TestLogger.logMsg("*** ProductBankProlongationSettings for CanBeProlongated ***");
    // setting prolongation active in prodops
    TestLogger.logMsg("Step-1: Setting Product Bank Prolongation Settings to CanBeProlongated");
    ProdOps.getInstance().Prodops_PB_Prolongation_setting("true", SourceTrancheIdentifier);
    // DB validation
    Assert.assertEquals(
        DBReusables.getInstance().getProlongation_status(SourceTrancheIdentifier),
        "true",
        "DB status is not correct");
    TestLogger.logInfo("validated CanBeProlongated value in DB");
    Assert.assertNull(DBReusables.getInstance().getCustomerProlongationEntry(CIA));
    TestLogger.logInfo("validated customerProlongationSettings in DB");
    // Gunda validation
    Assert.assertTrue(
        (WebServiceOperations.getInstance()
            .convertStringToJson(Gunda.getInstance().Gunda_GetCustomer(CustomerNumber))
            .getBoolean(
                "affiliations[0].customerInterestAccountsDetails["
                    + GundaServices.getInstance().getCIA_Array(CustomerNumber, CIA)
                    + "].trancheCanBeProlongated")),
        "Gunda status is not correct");
    TestLogger.logInfo("validated Prolongation Button in Gunda");
    Assert.assertNull(
        (WebServiceOperations.getInstance()
            .convertStringToJson(Gunda.getInstance().Gunda_GetCustomer(CustomerNumber))
            .getString(
                "affiliations[0].customerInterestAccountsDetails["
                    + GundaServices.getInstance().getCIA_Array(CustomerNumber, CIA)
                    + "].prolongationType")),
        "Gunda status is not correct");
    TestLogger.logInfo("validated customerProlongationSettings in Gunda");
    // Shop validation
    ShopLoginLogoutPO.getInstance().shopCache();
    Assert.assertEquals(
        DRIVER.findElement(MeineAnlagenPO.getInstance().Prolongation).getAttribute("class"),
        "btn btn-info js-modal-action",
        "Prolongation button is not in correct status in Shop");
    TestLogger.logInfo("validated Prolongation Button in Shop");
    Ptype = DRIVER.findElement(By.xpath("//div[@class='col-xs-10 col-xs-offset-1']")).getText();
    Assert.assertEquals(
        Ptype.substring((Ptype.indexOf("%") + 1), Ptype.length()),
        "\n" + "Autom. Prolongation",
        "Selected prolongation setting is not dispalying correctly");
    TestLogger.logInfo("validated Prolongation Type in Shop");
    MeineAnlagenPO.getInstance().initiateProlongation();
    Assert.assertNull(
        DRIVER.findElement(MeineAnlagenPO.getInstance().FullProlongation).getAttribute("checked"));
    Assert.assertNull(
        DRIVER
            .findElement(MeineAnlagenPO.getInstance().PartialProlongation)
            .getAttribute("checked"));
    Assert.assertNull(
        DRIVER.findElement(MeineAnlagenPO.getInstance().NoProlongation).getAttribute("checked"));
    TestLogger.logInfo("validated customerProlongationSettings in Shop");

    TestLogger.logMsg("*** ProductBankProlongationSettings for Can'tBeProlongated ***");
    TestLogger.logMsg("Step-2: Setting Product Bank Prolongation Settings to Can'tBeProlongated");
    // setting prolongation inactive in prodops
    ProdOps.getInstance().Prodops_PB_Prolongation_setting("false", SourceTrancheIdentifier);
    // DB validation
    Assert.assertEquals(
        DBReusables.getInstance().getProlongation_status(SourceTrancheIdentifier),
        "false",
        "DB status is not correct");
    TestLogger.logInfo("Validated CanBeProlongated value in DB");

    Assert.assertNull(DBReusables.getInstance().getCustomerProlongationEntry(CIA));
    TestLogger.logInfo("Validated customerProlongationSettings in DB");

    // Gunda validation
    Assert.assertFalse(
        (WebServiceOperations.getInstance()
            .convertStringToJson(Gunda.getInstance().Gunda_GetCustomer(CustomerNumber))
            .getBoolean(
                "affiliations[0].customerInterestAccountsDetails["
                    + GundaServices.getInstance().getCIA_Array(CustomerNumber, CIA)
                    + "].trancheCanBeProlongated")),
        "Gunda status is not correct");
    TestLogger.logInfo("Validated Prolongation Button in Gunda");

    Assert.assertNull(
        (WebServiceOperations.getInstance()
            .convertStringToJson(Gunda.getInstance().Gunda_GetCustomer(CustomerNumber))
            .getString(
                "affiliations[0].customerInterestAccountsDetails["
                    + GundaServices.getInstance().getCIA_Array(CustomerNumber, CIA)
                    + "].prolongationType")),
        "Gunda status is not correct");
    TestLogger.logInfo("validated customerProlongationSettings in Gunda");

    // Shop validation
    ShopLoginLogoutPO.getInstance().shopCache();
    Assert.assertEquals(
        DRIVER.findElement(MeineAnlagenPO.getInstance().Prolongation).getAttribute("class"),
        "btn btn-info disabled ",
        "Prolongation button is not in correct status in Shop");
    TestLogger.logInfo("Validated Prolongation Button in Shop");
    Ptype = DRIVER.findElement(By.xpath("//div[@class='col-xs-10 col-xs-offset-1']")).getText();
    Assert.assertEquals(
        Ptype.substring((Ptype.indexOf("%") + 1), Ptype.length()),
        "\n" + "Keine Prolongation möglich" + "\n" + "Autom. Auszahlung",
        "Selected prolongation setting is not dispalying correctly");
    TestLogger.logInfo("validated Prolongation Type in Shop");

    TestLogger.logMsg("==========" + testName + " Completed==========");
  }

  @AfterMethod(alwaysRun = true)
  public void teardown(ITestResult result) {
    if (ITestResult.FAILURE == result.getStatus()) {
      takeScreenshot(result.getName());
    }
    TestLogger.logInfo("Executing Browser tearDown method");
    ShopLoginLogoutPO.getInstance().closeAllBrowsers();
  }

  @AfterTest(alwaysRun = true)
  // Closing All connections
  public void cleanup() throws SQLException {
    DBReusables.getInstance().closeDBCon();
  }
}
