package com.depositsolutions.zinspilot.e2e.shopui;

import static com.depositsolutions.common.reusables.TestConstants.SHOP_URL_CONFIG_KEY;

import com.depositsolutions.common.reusables.DBReusables;
import com.depositsolutions.common.ui.helpers.BaseTestClassUI;
import com.depositsolutions.common.ui.helpers.WebUIOperations;
import com.depositsolutions.common.ui.zpuipageobjects.ProductDetailsPO;
import com.depositsolutions.common.ui.zpuipageobjects.ProfileDetailsPO;
import com.depositsolutions.common.ui.zpuipageobjects.ShopLoginLogoutPO;
import com.depositsolutions.common.utils.ConfigManager;
import com.depositsolutions.common.utils.TestLogger;
import java.lang.reflect.Method;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import org.testng.Assert;
import org.testng.ITestResult;
import org.testng.annotations.*;

/**
 * Feature: RekYC Tests Link:https://depositsolutions.testrail.io/index.php?/cases/view/4182 author:
 * Shalini.Sudam
 */
public class ReKYC extends BaseTestClassUI {

  private String testDataInjection = ConfigManager.getInstance().getString("testDataInjection");
  String CustomerEmail = "";

  @BeforeTest(alwaysRun = true)
  public void setupDB() {
    DBReusables.getInstance().dbConnect();
  }

  @BeforeMethod(alwaysRun = true)
  public void preLoadSQLTestDataAndLaunchShop() {
    if (testDataInjection.equalsIgnoreCase("Yes")) {
      // Truncate All Tables
      DBReusables.getInstance().executeSqlScript("TruncateAllTables.sql");
      // Test Data Injection for Customer and Service Bank
      DBReusables.getInstance().executeSqlScript("serviceBank-sutor.sql");
      DBReusables.getInstance().executeSqlScript("customer.sql");

      // Getting customer details
      CustomerEmail = DBReusables.getInstance().getCustomerEmail();
      TestLogger.logInfo("Getting Customer Email: " + CustomerEmail);
    }
    setUpForTest(ConfigManager.getInstance().getString(SHOP_URL_CONFIG_KEY));
  }

  @Test(
      enabled = true,
      groups = {"Profile", "Regression", "Re-Kyc"})
  @Parameters({"customerEmail"})
  public void C5958_testReReKYCFromProfile(Method methodName, String customerEmail) {

    String testCaseName = "4182_5959_5960_5961" + methodName.getName();
    String postIdentCaseNumberObserved,
        identProviderUrlLastIssueDateObserved,
        identProviderRedirectUrlValidUntilObserved,
        identReferenceIdObserved;
    String identProviderUrlExpected,
        identProviderRedirectUrlValidUntil,
        postIdentCaseNumberExpected,
        identProviderUrlLastIssueDateExpected,
        identProviderRedirectUrlValidUntilExpected,
        identReferenceIdExpected;
    String postIdentCaseNumber_before,
        identProviderUrlLastIssueDate_before,
        identProviderReferenceId_before,
        identProviderUrl_before;
    String postIdentCaseNumber,
        identProviderUrlLastIssueDate,
        identProviderReferenceId,
        identProviderUrl;

    TestLogger.logMsg("================ " + testCaseName + " =====================");
    TestLogger.logMsg("+++++ReReKyc+++++");
    TestLogger.logMsg("Step-1: Loginto Shop Portal");
    if (testDataInjection.equalsIgnoreCase("Yes")) {
      ShopLoginLogoutPO.getInstance().shopLogin(ENV, CustomerEmail);
    } else ShopLoginLogoutPO.getInstance().shopLogin(ENV, customerEmail);

    TestLogger.logMsg("Step-2 Click on Profile Link and Navigate to Profile Details Page");
    WebUIOperations.getInstance()
        .waitForElementAndClick(getWebElement(ShopLoginLogoutPO.getInstance().customerName));
    String headerText =
        getWebElement(ProfileDetailsPO.getInstance().myRegistrationHeaderText).getText();
    Assert.assertEquals(
        headerText,
        "Meine Registrierungsdaten",
        "Expected Header text: Meine Registrierungsdaten but observed is: " + headerText);

    WebUIOperations.getInstance().scrollDownThePage();
    WebUIOperations.getInstance().scrollDownThePage();

    postIdentCaseNumber_before =
        DBReusables.getInstance().getColumnValueFromSbaffAccountOpening("identProviderCaseNumber");
    identProviderUrlLastIssueDate_before =
        DBReusables.getInstance()
            .getColumnValueFromSbaffAccountOpening("identProviderUrlLastIssueDate");
    identProviderReferenceId_before =
        DBReusables.getInstance().getColumnValueFromSbaffAccountOpening("identProviderReferenceId");
    identProviderUrl_before =
        DBReusables.getInstance().getColumnValueFromSbaffAccountOpening("identProviderRedirectUrl");

    TestLogger.logMsg("Step-3: Click on ZumPostIdent Button in Profile Details Page");
    WebUIOperations.getInstance()
        .waitForElementAndClick(getWebElement(ProfileDetailsPO.getInstance().ZumPostidentButton));
    // DOWNLOAD and Check the coupon step is not automated as there is a Zum Portal Bug - Deepthi
    // informed

    Calendar cal = Calendar.getInstance();
    cal.add(Calendar.MONTH, 3);
    Date dateProviderRedirectUrl = cal.getTime();
    SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
    identProviderRedirectUrlValidUntilExpected = format.format(dateProviderRedirectUrl);

    TestLogger.logMsg(
        "Step-4: Retrieve the postIdentCaseNumber, identProviderLastIssueDate,identProviderReferenceId values from DB and validate them with the expected values");
    postIdentCaseNumber =
        DBReusables.getInstance().getColumnValueFromSbaffAccountOpening("identProviderCaseNumber");
    identProviderUrlLastIssueDate =
        DBReusables.getInstance()
            .getColumnValueFromSbaffAccountOpening("identProviderUrlLastIssueDate");
    identProviderRedirectUrlValidUntil =
        DBReusables.getInstance()
            .getColumnValueFromSbaffAccountOpening("identProviderRedirectUrlValidUntil");
    identProviderReferenceId =
        DBReusables.getInstance().getColumnValueFromSbaffAccountOpening("identProviderReferenceId");
    identProviderUrl =
        DBReusables.getInstance().getColumnValueFromSbaffAccountOpening("identProviderRedirectUrl");

    Assert.assertTrue(
        !postIdentCaseNumber.equalsIgnoreCase(postIdentCaseNumber_before),
        "Expected  Value Observed  Value should not be same "
            + postIdentCaseNumber
            + " "
            + postIdentCaseNumber_before);
    Assert.assertTrue(
        !identProviderUrl_before.equalsIgnoreCase(identProviderUrl),
        "Expected case Number and Observed case Number should not be same"
            + identProviderUrl
            + " "
            + identProviderUrl_before);
    Assert.assertTrue(
        DRIVER.getCurrentUrl().contains(postIdentCaseNumber), "Indent Provider URL is incorrect");
    Assert.assertTrue(
        !identProviderUrlLastIssueDate_before.equalsIgnoreCase(identProviderUrlLastIssueDate),
        "Expected Date and Observed value: should not be same"
            + identProviderUrlLastIssueDate
            + " "
            + identProviderUrlLastIssueDate_before);
    Assert.assertFalse(
        identProviderRedirectUrlValidUntil.contains(identProviderRedirectUrlValidUntilExpected),
        "Expected Date and Observed value: should not be same"
            + identProviderUrlLastIssueDate
            + " "
            + identProviderUrlLastIssueDate_before);
    Assert.assertTrue(
        !identProviderReferenceId.equalsIgnoreCase(identProviderReferenceId_before),
        "Expected  Value Observed URL Value should not be same "
            + identProviderReferenceId
            + " "
            + identProviderReferenceId_before);
    Assert.assertEquals(
        identProviderReferenceId,
        "RL11158126-1",
        "ReferenceId does not increment when there is a change in the ident url");

    TestLogger.logMsg("+++++Validate ReReKyc as per 1st or 2nd cycle+++++");
    TestLogger.logMsg("Step-5: Setting the Date as per cycle");
    setDateAsPerCycle();

    TestLogger.logMsg("Step-6: Click on ZumPostIdent Button");
    DRIVER.navigate().back();
    WebUIOperations.getInstance()
        .waitForElementAndClick(getWebElement(ProfileDetailsPO.getInstance().ZumPostidentButton));

    Calendar cal1 = Calendar.getInstance();
    cal1.add(Calendar.MONTH, 3);
    Date dateProviderRedirectUrl1 = cal1.getTime();
    SimpleDateFormat format1 = new SimpleDateFormat("yyyy-MM-dd");
    identProviderRedirectUrlValidUntilExpected = format1.format(dateProviderRedirectUrl1);

    postIdentCaseNumberExpected =
        DBReusables.getInstance().getColumnValueFromSbaffAccountOpening("identProviderCaseNumber");
    identProviderUrlLastIssueDateExpected =
        DBReusables.getInstance()
            .getColumnValueFromSbaffAccountOpening("identProviderUrlLastIssueDate");
    identReferenceIdExpected =
        DBReusables.getInstance().getColumnValueFromSbaffAccountOpening("identProviderReferenceId");
    identProviderRedirectUrlValidUntil =
        DBReusables.getInstance()
            .getColumnValueFromSbaffAccountOpening("identProviderRedirectUrlValidUntil");
    identProviderUrlExpected =
        DBReusables.getInstance().getColumnValueFromSbaffAccountOpening("identProviderRedirectUrl");

    TestLogger.logMsg(
        "Step-7: Validate if new caseNumber, issuedate, RedirectUrlValidUntil,referenceID are not same");
    Assert.assertTrue(
        !postIdentCaseNumber.equalsIgnoreCase(postIdentCaseNumberExpected),
        "Expected  Value Observed  Value should not be same "
            + postIdentCaseNumber
            + " "
            + postIdentCaseNumber_before);
    Assert.assertTrue(
        !identProviderUrlExpected.equalsIgnoreCase(identProviderUrl),
        "Expected case Number and Observed case Number should not be same"
            + identProviderUrl
            + " "
            + identProviderUrl_before);
    Assert.assertTrue(
        DRIVER.getCurrentUrl().contains(postIdentCaseNumberExpected),
        "Indent Provider URL is incorrect");
    Assert.assertFalse(
        identProviderRedirectUrlValidUntil.equals(identProviderRedirectUrlValidUntilExpected),
        "Expected Date and Observed value: should not be same"
            + identProviderUrlLastIssueDate
            + " "
            + identProviderUrlLastIssueDate_before);
    Assert.assertTrue(
        !identProviderReferenceId.equalsIgnoreCase(identReferenceIdExpected),
        "Expected  Value Observed URL Value should not be same "
            + identProviderReferenceId
            + " "
            + identProviderReferenceId_before);
    Assert.assertEquals(
        identReferenceIdExpected,
        "RL11158126-2",
        "ReferenceId does not increment when there is a change in the ident url");

    TestLogger.logMsg("+++++Validate ReReKyc in same cycle+++++");

    TestLogger.logMsg(
        "Step-8: Go back to shop and click ZumPostIdentNumber and validate that the date is set to current date and a new postIdentCaseNUmber is not generated.");
    DRIVER.navigate().back();
    WebUIOperations.getInstance()
        .waitForElementAndClick(getWebElement(ProfileDetailsPO.getInstance().ZumPostidentButton));

    String postIdentCaseNumber_secondtime =
        DBReusables.getInstance().getColumnValueFromSbaffAccountOpening("identProviderCaseNumber");
    String identProviderUrlLastIssueDate_secondtime =
        DBReusables.getInstance()
            .getColumnValueFromSbaffAccountOpening("identProviderUrlLastIssueDate");
    String identReferenceId_secondtime =
        DBReusables.getInstance().getColumnValueFromSbaffAccountOpening("identProviderReferenceId");

    Assert.assertTrue(
        postIdentCaseNumber_secondtime.equalsIgnoreCase(postIdentCaseNumberExpected),
        "Expected  Value Observed  Value should not be same "
            + postIdentCaseNumber
            + " "
            + postIdentCaseNumber_before);
    Assert.assertTrue(
        identProviderUrlLastIssueDate_secondtime.equalsIgnoreCase(
            identProviderUrlLastIssueDateExpected),
        "Expected Date and Observed value: should not be same"
            + identProviderUrlLastIssueDate
            + " "
            + identProviderUrlLastIssueDate_before);
    Assert.assertTrue(
        identReferenceId_secondtime.equalsIgnoreCase(identReferenceIdExpected),
        "Expected  Value Observed URL Value should not be same "
            + identProviderReferenceId
            + " "
            + identProviderReferenceId_before);
  }

  @Test(
      enabled = true,
      groups = {"Profile", "Regression", "Re-Kyc"})
  @Parameters({"customerEmail"})
  public void C6034_testReReKYCFromPDP(Method methodName, String customerEmail)
      throws InterruptedException {

    String testCaseName = "4182_5959_5960_5961" + methodName.getName();

    String identProviderUrlExpected,
        identProviderRedirectUrlValidUntil,
        postIdentCaseNumberExpected,
        identProviderUrlLastIssueDateExpected,
        identProviderRedirectUrlValidUntilExpected,
        identReferenceIdExpected;
    String postIdentCaseNumber_before,
        identProviderUrlLastIssueDate_before,
        identProviderReferenceId_before,
        identProviderUrl_before;
    String postIdentCaseNumber,
        identProviderUrlLastIssueDate,
        identProviderReferenceId,
        identProviderUrl;

    TestLogger.logMsg("================ " + testCaseName + " =====================");
    TestLogger.logMsg("+++++ReReKyc+++++");
    TestLogger.logMsg("Step-1: Loginto Shop Portal");
    if (testDataInjection.equalsIgnoreCase("Yes")) {
      DBReusables.getInstance().executeSqlScript("productBank-SUFGDE-DRM.sql");
      DBReusables.getInstance().executeSqlScript("Tranche-SUFGDE-FG1Y.sql");
      ShopLoginLogoutPO.getInstance().shopLogin(ENV, CustomerEmail);
    } else ShopLoginLogoutPO.getInstance().shopLogin(ENV, customerEmail);
    DBReusables.getInstance()
        .executeSql(
            "UPDATE `comonea_b2c`.`b2c_trustor_service_bank_data` SET `identMethod` = '2018-08-02', `identProduct` = 'postIdent' WHERE (`id` = '365');");

    postIdentCaseNumber_before =
        DBReusables.getInstance().getColumnValueFromSbaffAccountOpening("identProviderCaseNumber");
    identProviderUrlLastIssueDate_before =
        DBReusables.getInstance()
            .getColumnValueFromSbaffAccountOpening("identProviderUrlLastIssueDate");
    identProviderReferenceId_before =
        DBReusables.getInstance().getColumnValueFromSbaffAccountOpening("identProviderReferenceId");
    identProviderUrl_before =
        DBReusables.getInstance().getColumnValueFromSbaffAccountOpening("identProviderRedirectUrl");

    TestLogger.logMsg(
        "Step-2: Click on Jest Analegen Button on Product Page and then on Product Details Page");
    WebUIOperations.getInstance()
        .waitForElementAndClick(getWebElement(ProductDetailsPO.CREATE_NOW_PRODUCTDETAILS));

    WebUIOperations.getInstance()
        .waitForElementAndClick(getWebElement(ProductDetailsPO.LEGITIMISATION_LINK_PDP));

    Thread.sleep(2000);

    Calendar cal = Calendar.getInstance();
    cal.add(Calendar.MONTH, 3);
    cal.add(Calendar.DAY_OF_YEAR, 1);
    Date dateProviderRedirectUrl = cal.getTime();
    SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
    identProviderRedirectUrlValidUntilExpected = format.format(dateProviderRedirectUrl);

    TestLogger.logMsg(
        "Step-3: Retrieve the postIdentCaseNumber, identProviderLastIssueDate,identProviderReferenceId values from DB and validate them with the expected values");
    postIdentCaseNumber =
        DBReusables.getInstance().getColumnValueFromSbaffAccountOpening("identProviderCaseNumber");
    identProviderUrlLastIssueDate =
        DBReusables.getInstance()
            .getColumnValueFromSbaffAccountOpening("identProviderUrlLastIssueDate");
    identProviderRedirectUrlValidUntil =
        DBReusables.getInstance()
            .getColumnValueFromSbaffAccountOpening("identProviderRedirectUrlValidUntil");
    identProviderReferenceId =
        DBReusables.getInstance().getColumnValueFromSbaffAccountOpening("identProviderReferenceId");
    identProviderUrl =
        DBReusables.getInstance().getColumnValueFromSbaffAccountOpening("identProviderRedirectUrl");

    Assert.assertTrue(
        !postIdentCaseNumber.equalsIgnoreCase(postIdentCaseNumber_before),
        "Expected  Value Observed  Value should not be same "
            + postIdentCaseNumber
            + " "
            + postIdentCaseNumber_before);
    Assert.assertTrue(
        !identProviderUrl_before.equalsIgnoreCase(identProviderUrl),
        "Expected case Number and Observed case Number should not be same"
            + identProviderUrl
            + " "
            + identProviderUrl_before);

    WebUIOperations.getInstance().switchTab(1);
    TestLogger.logMsg(DRIVER.getCurrentUrl());
    postIdentCaseNumber =
        DBReusables.getInstance().getColumnValueFromSbaffAccountOpening("identProviderCaseNumber");
    Assert.assertTrue(
        DRIVER.getCurrentUrl().contains(postIdentCaseNumber), "Indent Provider URL is incorrect");
    DRIVER.close();
    Assert.assertFalse(
        identProviderUrlLastIssueDate_before.equalsIgnoreCase(identProviderUrlLastIssueDate),
        "Expected Date and Observed value: should not be same "
            + identProviderUrlLastIssueDate
            + " "
            + identProviderUrlLastIssueDate_before);
    Assert.assertFalse(
        identProviderRedirectUrlValidUntil.equals(identProviderRedirectUrlValidUntilExpected),
        "Expected URL and Observed value: should not be same"
            + identProviderRedirectUrlValidUntil
            + " "
            + identProviderRedirectUrlValidUntilExpected);
    Assert.assertTrue(
        !identProviderReferenceId.equalsIgnoreCase(identProviderReferenceId_before),
        "Expected  Value Observed URL Value should not be same "
            + identProviderReferenceId
            + " "
            + identProviderReferenceId_before);
    Assert.assertEquals(
        identProviderReferenceId,
        "RL11158126-1",
        "ReferenceId does not increment when there is a change in the ident url");

    TestLogger.logMsg("+++++Validate ReReKyc as per 1st or 2nd cycle+++++");
    TestLogger.logMsg("Step-4: Setting the Date as per cycle");
    setDateAsPerCycle();

    TestLogger.logMsg("Step-5: Click on ZumPostIdent Button");
    WebUIOperations.getInstance().switchTab(0);
    WebUIOperations.getInstance()
        .waitForElementAndClick(getWebElement(ProductDetailsPO.LEGITIMISATION_LINK_PDP));

    Calendar cal1 = Calendar.getInstance();
    cal1.add(Calendar.MONTH, 3);
    cal1.add(Calendar.DAY_OF_YEAR, 1);
    Date dateProviderRedirectUrl1 = cal1.getTime();
    SimpleDateFormat format1 = new SimpleDateFormat("yyyy-MM-dd");
    identProviderRedirectUrlValidUntilExpected = format1.format(dateProviderRedirectUrl1);
    WebUIOperations.getInstance().switchTab(1);
    TestLogger.logMsg(DRIVER.getCurrentUrl());
    postIdentCaseNumberExpected =
        DBReusables.getInstance().getColumnValueFromSbaffAccountOpening("identProviderCaseNumber");

    identReferenceIdExpected =
        DBReusables.getInstance().getColumnValueFromSbaffAccountOpening("identProviderReferenceId");
    identProviderRedirectUrlValidUntil =
        DBReusables.getInstance()
            .getColumnValueFromSbaffAccountOpening("identProviderRedirectUrlValidUntil");

    TestLogger.logMsg(
        "Step-6: Validate if new caseNumber, issuedate, RedirectUrlValidUntil,referenceID are not same");
    Assert.assertFalse(
        postIdentCaseNumberExpected.equalsIgnoreCase(postIdentCaseNumber_before),
        "Expected  Value Observed  Value should not be same "
            + postIdentCaseNumberExpected
            + " "
            + postIdentCaseNumber_before);

    Assert.assertFalse(
        identProviderUrl_before.equalsIgnoreCase(identProviderUrl),
        "Expected case Number and Observed case Number should not be same"
            + identProviderUrl
            + " "
            + identProviderUrl_before);
    Assert.assertTrue(
        DRIVER.getCurrentUrl().contains(postIdentCaseNumberExpected),
        "Indent Provider URL is incorrect" + postIdentCaseNumberExpected);
    Assert.assertFalse(
        identProviderRedirectUrlValidUntil.equals(identProviderRedirectUrlValidUntilExpected),
        "Expected Date and Observed value: should not be same"
            + identProviderUrlLastIssueDate
            + " "
            + identProviderUrlLastIssueDate_before);
    Assert.assertTrue(
        !identProviderReferenceId.equalsIgnoreCase(identReferenceIdExpected),
        "Expected  Value Observed URL Value should not be same "
            + identProviderReferenceId
            + " "
            + identProviderReferenceId_before);
    Assert.assertEquals(
        identReferenceIdExpected,
        "RL11158126-2",
        "ReferenceId does not increment when there is a change in the ident url");
  }

  @Test(
      enabled = true,
      groups = {"P1", "Profile", "Regression"})
  @Parameters({"customerEmail"})
  public void C7381_testPostIdentButtonForAllTitles(Method methodName, String customerEmail) {

    String testCaseName = methodName.getName();
    String postIdentCaseNumberExpected;
    TestLogger.logMsg("================ " + testCaseName + " =====================");

    TestLogger.logMsg("]Loginto Shop Portal");
    if (testDataInjection.equalsIgnoreCase("Yes")) {
      ShopLoginLogoutPO.getInstance().shopLogin(ENV, CustomerEmail);
    } else ShopLoginLogoutPO.getInstance().shopLogin(ENV, customerEmail);

    TestLogger.logMsg("Step-1 Click on Profile link DR and Navigate to Profile Details Page");
    WebUIOperations.getInstance()
        .waitForElementAndClick(getWebElement(ShopLoginLogoutPO.getInstance().customerName));
    String headerText =
        getWebElement(ProfileDetailsPO.getInstance().myRegistrationHeaderText).getText();
    Assert.assertEquals(
        headerText,
        "Meine Registrierungsdaten",
        "Expected Header text: Meine Registrierungsdaten but observed is: " + headerText);

    TestLogger.logMsg(
        "Step-2: Change the title to DR and Click on ZumPostIdent Button in Profile Details Page");
    postIdentCaseNumberExpected =
        DBReusables.getInstance().getColumnValueFromSbaffAccountOpening("identProviderCaseNumber");
    verifyPostIdentURLWithChangingTitle("DR", postIdentCaseNumberExpected);

    TestLogger.logMsg(
        "Step-3: Change the title to PROF and click on PostIdent button.Navigation should be successful");
    DRIVER.navigate().back();
    verifyPostIdentURLWithChangingTitle("PROF", postIdentCaseNumberExpected);

    TestLogger.logMsg(
        "Step-4: Change the title to NONE and click on PostIdent button.Navigation should be successful");
    DRIVER.navigate().back();
    verifyPostIdentURLWithChangingTitle("NONE", postIdentCaseNumberExpected);
  }

  public void verifyPostIdentURLWithChangingTitle(
      String title, String postIdentCaseNumberExpected) {
    WebUIOperations.getInstance().scrollUpThePage();
    WebUIOperations.getInstance()
        .selectDropdownByValue(getWebElement(ProfileDetailsPO.getInstance().titel), title);
    WebUIOperations.getInstance()
        .waitForElementAndClick(getWebElement(ProfileDetailsPO.getInstance().saveTitelButton));
    WebUIOperations.getInstance().scrollDownThePage();
    WebUIOperations.getInstance().scrollDownThePage();
    WebUIOperations.getInstance()
        .waitForElementAndClick(getWebElement(ProfileDetailsPO.getInstance().ZumPostidentButton));
    TestLogger.logMsg(DRIVER.getCurrentUrl());
    Assert.assertTrue(
        !DRIVER.getCurrentUrl().contains(postIdentCaseNumberExpected),
        "Indent Provider URL is incorrect");
  }

  public void setDateAsPerCycle() {

    String date = "";
    Calendar cal = Calendar.getInstance();
    Integer year = cal.get(Calendar.YEAR);
    Integer month = cal.get(Calendar.MONTH);
    Integer day = cal.get(Calendar.DATE);
    if (day >= 10 && day <= 24) {
      month = month + 1;
      date = year.toString() + "-" + month.toString() + "-" + "09";
      DBReusables.getInstance()
          .updateSbaffAccountOpeningTable(
              "identProviderUrlLastIssueDate", date, "WHERE (`id` = '388')");
      TestLogger.logInfo("Date lies between 10 and 24 and hence setting to: " + date);

    } else if (day >= 1 && day <= 9) {
      date = year.toString() + "-" + month.toString() + "-" + "24";
      DBReusables.getInstance()
          .updateSbaffAccountOpeningTable(
              "identProviderUrlLastIssueDate", date, "WHERE (`id` = '388')");
      TestLogger.logInfo("Date lies between 1 and 9 and hence setting to: " + date);
    } else if (day >= 25 && day <= 31) {
      month = month + 1;
      date = year.toString() + "-" + month.toString() + "-" + "24";
      DBReusables.getInstance()
          .updateSbaffAccountOpeningTable(
              "identProviderUrlLastIssueDate", date, "WHERE (`id` = '388')");
      TestLogger.logInfo("Date is >=25 and hence setting to: " + date);
    }
  }

  @AfterMethod(alwaysRun = true)
  public void teardown(ITestResult result) {
    if (ITestResult.FAILURE == result.getStatus()) {
      takeScreenshot(result.getName());
    }
    DBReusables.getInstance()
        .updateSbaffAccountOpeningTable(
            "identProviderUrlLastIssueDate", "2021-01-01", "WHERE (`id` = '388')");
    ShopLoginLogoutPO.getInstance().closeAllBrowsers();
  }

  @AfterClass(alwaysRun = true)
  public void cleanup() throws SQLException {
    DBReusables.getInstance().closeDBCon();
  }
}
