package com.depositsolutions.zinspilot.e2e.shopui;

import static com.depositsolutions.common.reusables.TestConstants.SHOP_URL_CONFIG_KEY;

import com.depositsolutions.common.reusables.DBReusables;
import com.depositsolutions.common.ui.helpers.BaseTestClassUI;
import com.depositsolutions.common.ui.helpers.WebUIOperations;
import com.depositsolutions.common.ui.zpuipageobjects.ProductDetailsPO;
import com.depositsolutions.common.ui.zpuipageobjects.ShopLoginLogoutPO;
import com.depositsolutions.common.utils.ConfigManager;
import com.depositsolutions.common.utils.TestLogger;
import java.lang.reflect.Method;
import java.sql.SQLException;
import java.util.List;
import org.openqa.selenium.WebElement;
import org.testng.Assert;
import org.testng.ITestResult;
import org.testng.annotations.*;

/**
 * Feature: ShopLoginLogout test-scripts TestRail
 * Link:https://depositsolutions.testrail.io/index.php?/cases/view/1658 author: Shalini.Sudam
 */
public class ShopFilterFunctionality extends BaseTestClassUI {
  private String testDataInjection = ConfigManager.getInstance().getString("testDataInjection");
  String CustomerEmail = "";

  @BeforeTest(alwaysRun = true)
  public void setupDB() {
    DBReusables.getInstance().dbConnect();
  }

  @BeforeMethod(alwaysRun = true)
  public void preLoadSQLTestDataAndLaunchShop() {
    if (testDataInjection.equalsIgnoreCase("Yes")) {
      // Truncate All Tables
      DBReusables.getInstance().executeSqlScript("TruncateAllTables.sql");
      // Test Data Injection for Customer and Service Bank
      DBReusables.getInstance().executeSqlScript("serviceBank-sutor.sql");
      DBReusables.getInstance().executeSqlScript("customer.sql");
      DBReusables.getInstance().executeSqlScript("b2c_product_bank.sql");
      DBReusables.getInstance().executeSqlScript("b2c_interest_product.sql");

      DBReusables.getInstance()
          .executeSqlScript("AEB_GR_Tranches_InterestApproval_InterestRate.sql");
      DBReusables.getInstance()
          .executeSqlScript("BNIF_MT_Tranches_InterestApproval_InterestRate.sql");
      DBReusables.getInstance()
          .executeSqlScript("BUCU_RO_Tranches_InterestApproval_InterestRate.sql");
      DBReusables.getInstance()
          .executeSqlScript("CKV_BE_Tranches_InterestApproval_InterestRate.sql");
      DBReusables.getInstance()
          .executeSqlScript("CPLU_DE_Tranches_InterestApproval_InterestRate.sql");
      DBReusables.getInstance()
          .executeSqlScript("LHV_EE_Tranches_InterestApproval_InterestRate.sql");
      DBReusables.getInstance().executeSqlScript("b2c_product_bank_logos.sql");
      DBReusables.getInstance().executeSqlScript("b2c_product_bank_validation_requirement.sql");
      TestLogger.logInfo("SQL Import Successful");
      // Getting customer details
      CustomerEmail = DBReusables.getInstance().getCustomerEmail();
      TestLogger.logInfo("Getting Customer Email: " + CustomerEmail);
    } else {
      // Truncate sps Tables
      DBReusables.getInstance().executeSqlScript("TruncateSPSTables.sql");
    }
    setUpForTest(ConfigManager.getInstance().getString(SHOP_URL_CONFIG_KEY));
  }

  @Test(
      enabled = true,
      groups = {"Filters", "Regression"})
  @Parameters({"countries", "homePageTerms", "sortOptions"})
  public void C5227_MultipleFilters(
      Method methodName, String countries, String homePageTerms, String sortOptions)
      throws InterruptedException {
    String testCaseName = methodName.getName();

    TestLogger.logInfo("========================== " + testCaseName + " ====================");
    TestLogger.logMsg("Step-1: Log into Shop ");
    ShopLoginLogoutPO.getInstance().shopLogin(ENV, CustomerEmail);
    ShopLoginLogoutPO.getInstance().shopCache();
    DRIVER.findElement(ProductDetailsPO.getInstance().Anlageangebote).click();
    TestLogger.logMsg("Step-2: Verify if Sort Drop Downs are displayed");
    WebUIOperations.getInstance()
        .verifyElementIsPresent(
            getWebElement(ProductDetailsPO.getInstance().zpShopHomePageTerms), "Terms DropDown");
    WebUIOperations.getInstance()
        .verifyElementIsPresent(
            getWebElement(ProductDetailsPO.getInstance().zpShopHomePageAllCountries),
            "All Countries DropDown");
    WebUIOperations.getInstance()
        .verifyElementIsPresent(
            getWebElement(ProductDetailsPO.getInstance().zpShopHomePageSort), "Sort DropDown");

    TestLogger.logMsg(
        "Step-3: Validate Countries, HomePage Products and Product Sort Filter Values");
    ProductDetailsPO.getInstance()
        .validateFilterValues(
            countries, getWebElement(ProductDetailsPO.getInstance().zpShopHomePageAllCountries));
    ProductDetailsPO.getInstance()
        .validateFilterValues(
            homePageTerms, getWebElement(ProductDetailsPO.getInstance().zpShopHomePageTerms));
    ProductDetailsPO.getInstance()
        .validateFilterValues(
            sortOptions, getWebElement(ProductDetailsPO.getInstance().zpShopHomePageSort));

    TestLogger.logMsg(
        "Step-4: Select a Country and a term value from the drop-down and validate the Result");
    WebUIOperations.getInstance()
        .selectDropdownByText(
            getWebElement(ProductDetailsPO.getInstance().zpShopHomePageTerms),
            "Tagesgeld/Flexgeld24");
    WebUIOperations.getInstance()
        .selectDropdownByText(
            getWebElement(ProductDetailsPO.getInstance().zpShopHomePageAllCountries),
            "Deutschland");

    List<WebElement> webElement = DRIVER.findElements(ProductDetailsPO.getInstance().badgeTitleBD);
    ProductDetailsPO.getInstance().validateResults("Deutschland", webElement);
    webElement = DRIVER.findElements(ProductDetailsPO.getInstance().badgeStatusInterestRate);
    ProductDetailsPO.getInstance().validateResults("0,15%", webElement);
    webElement = DRIVER.findElements(ProductDetailsPO.getInstance().badgeStatusDuration);
    ProductDetailsPO.getInstance().validateResults("Tagesgeld/ Flexgeld24", webElement);

    TestLogger.logMsg(
        "Step-5: Select a Country and a Sort value from the drop-down and validate the Result");
    WebUIOperations.getInstance()
        .selectDropdownByText(
            getWebElement(ProductDetailsPO.getInstance().zpShopHomePageTerms), "Alle Laufzeiten");
    WebUIOperations.getInstance()
        .selectDropdownByText(
            getWebElement(ProductDetailsPO.getInstance().zpShopHomePageAllCountries), "Estland");
    WebUIOperations.getInstance()
        .selectDropdownByText(
            getWebElement(ProductDetailsPO.getInstance().zpShopHomePageSort),
            "Laufzeiten aufsteigend");

    webElement = DRIVER.findElements(ProductDetailsPO.getInstance().badgeTitleBD);
    ProductDetailsPO.getInstance().validateResults("Estland", webElement);
    webElement = DRIVER.findElements(ProductDetailsPO.getInstance().badgeStatusDuration);
    ProductDetailsPO.getInstance().validateResults("6 Monate", webElement);
    webElement = DRIVER.findElements(ProductDetailsPO.getInstance().badgeStatusInterestRate);
    ProductDetailsPO.getInstance().validateResults("0,06%", webElement);

    TestLogger.logMsg(
        "Step-6: Select a Sort and a term value from the drop-down and validate the Result");
    WebUIOperations.getInstance()
        .selectDropdownByText(
            getWebElement(ProductDetailsPO.getInstance().zpShopHomePageTerms), "Alle Laufzeiten");
    WebUIOperations.getInstance()
        .selectDropdownByText(
            getWebElement(ProductDetailsPO.getInstance().zpShopHomePageAllCountries),
            "Alle Länder");
    WebUIOperations.getInstance()
        .selectDropdownByText(
            getWebElement(ProductDetailsPO.getInstance().zpShopHomePageSort),
            "Zinssatz absteigend");

    webElement = DRIVER.findElements(ProductDetailsPO.getInstance().badgeTitleBD);
    ProductDetailsPO.getInstance().validateResults("Belgien", webElement);
    webElement = DRIVER.findElements(ProductDetailsPO.getInstance().badgeStatusDuration);
    ProductDetailsPO.getInstance().validateResults("84 Monate", webElement);
    webElement = DRIVER.findElements(ProductDetailsPO.getInstance().badgeStatusInterestRate);
    ProductDetailsPO.getInstance().validateResults("0,75%", webElement);

    TestLogger.logMsg(
        "Step-7: Select Sort , Country and a term value from the drop-down and validate the Result");
    // Product Not working as expected

    TestLogger.logMsg(
        "Step-8: Refresh Browser and verify if the dropdown values are reset to original and the results are reset to the Original values");
    DRIVER.navigate().refresh();

    Assert.assertTrue(
        (WebUIOperations.getInstance()
            .getFirstSelectedOption(
                getWebElement(ProductDetailsPO.getInstance().zpShopHomePageSort))
            .equals("Sortieren nach …")));
    Assert.assertTrue(
        (WebUIOperations.getInstance()
            .getFirstSelectedOption(
                getWebElement(ProductDetailsPO.getInstance().zpShopHomePageAllCountries))
            .equals("Alle Länder")));
    Assert.assertTrue(
        (WebUIOperations.getInstance()
            .getFirstSelectedOption(
                getWebElement(ProductDetailsPO.getInstance().zpShopHomePageTerms))
            .equals("Alle Laufzeiten")));

    webElement = DRIVER.findElements(ProductDetailsPO.getInstance().badgeTitleBD);
    ProductDetailsPO.getInstance().validateResults("Rumänien", webElement);
    webElement = DRIVER.findElements(ProductDetailsPO.getInstance().badgeStatusDuration);
    ProductDetailsPO.getInstance().validateResults("Tagesgeld", webElement);
    webElement = DRIVER.findElements(ProductDetailsPO.getInstance().badgeStatusInterestRate);
    ProductDetailsPO.getInstance().validateResults("0,25%", webElement);
    //    ShopLoginLogoutPO.getInstance().validateResults("12 Monate",webElement);

    ProductDetailsPO.getInstance().validateProductSelectMaturityFilter();

    TestLogger.logMsg("Step-9: Logout from Shop");
    ShopLoginLogoutPO.getInstance().shopLogOut();
  }

  @AfterMethod(alwaysRun = true)
  public void teardown(ITestResult result) {
    if (ITestResult.FAILURE == result.getStatus()) {
      takeScreenshot(result.getName());
    }
    ShopLoginLogoutPO.getInstance().closeAllBrowsers();
  }

  @AfterTest(alwaysRun = true)
  public void cleanup() throws SQLException {
    //    DBReusables.getInstance().executeSqlScript("TruncateAllTables.sql");
    DBReusables.getInstance().closeDBCon();
  }
}
