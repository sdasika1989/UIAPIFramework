package com.depositsolutions.zinspilot.e2e.shopui;

import static com.depositsolutions.common.reusables.TestConstants.SHOP_URL_CONFIG_KEY;

import com.depositsolutions.common.reusables.DBReusables;
import com.depositsolutions.common.reusables.DynamicDataReusables;
import com.depositsolutions.common.reusables.TestConstants;
import com.depositsolutions.common.ui.helpers.BaseTestClassUI;
import com.depositsolutions.common.ui.helpers.TestDataValidations;
import com.depositsolutions.common.ui.helpers.WebUIOperations;
import com.depositsolutions.common.ui.zpuipageobjects.*;
import com.depositsolutions.common.utils.ConfigManager;
import com.depositsolutions.common.utils.TestLogger;
import java.awt.*;
import java.awt.datatransfer.DataFlavor;
import java.awt.datatransfer.UnsupportedFlavorException;
import java.io.File;
import java.io.IOException;
import java.lang.reflect.Method;
import java.sql.SQLException;
import org.openqa.selenium.Keys;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;
import org.testng.ITestResult;
import org.testng.annotations.*;

/**
 * Feature: Customer Profile Tests TestRail
 * Link:https://depositsolutions.testrail.io/index.php?/cases/view/1634&group_by=cases:section_id&group_order=asc&display_deleted_cases=0&group_id=720
 * Change and Open Profile Feature. author: Shalini.Sudam
 */
public class CustomerProfile extends BaseTestClassUI {

  private String testDataInjection = ConfigManager.getInstance().getString("testDataInjection");
  String CustomerEmail = "";

  @BeforeTest(alwaysRun = true)
  public void setupDB() {
    DBReusables.getInstance().dbConnect();
  }

  @BeforeMethod(alwaysRun = true)
  public void preLoadSQLTestDataAndLaunchShop() {
    if (testDataInjection.equalsIgnoreCase("Yes")) {
      // Truncate All Tables
      DBReusables.getInstance().executeSqlScript("TruncateAllTables.sql");
      // Test Data Injection for Customer and Service Bank
      DBReusables.getInstance().executeSqlScript("serviceBank-sutor.sql");
      DBReusables.getInstance().executeSqlScript("customer.sql");

      // Getting customer details
      CustomerEmail = DBReusables.getInstance().getCustomerEmail();
      TestLogger.logInfo("Getting Customer Email: " + CustomerEmail);
    } else {
      // Truncate sps Tables
      DBReusables.getInstance().executeSqlScript("TruncateSPSTables.sql");
    }
    setUpForTest(ConfigManager.getInstance().getString(SHOP_URL_CONFIG_KEY));
  }

  @Test(
      enabled = true,
      groups = {"Profile", "Regression"})
  @Parameters({"customerEmail"})
  public void C1634_ChangeIdCard(Method methodName, String customerEmail) {

    String testCaseName = methodName.getName();
    String expiryDate = "";
    String issueDate = "";
    TestLogger.logMsg("================ " + testCaseName + " =====================");

    TestLogger.logMsg("Step-1: Loginto Shop Portal");
    if (testDataInjection.equalsIgnoreCase("Yes")) {
      ShopLoginLogoutPO.getInstance().shopLogin(ENV, CustomerEmail);
    } else ShopLoginLogoutPO.getInstance().shopLogin(ENV, customerEmail);

    TestLogger.logMsg(
        "Step-2: Validate if an error message is thrown when issuedDate and expiry date has > 10 years gap");
    issueDate = ProfileDetailsPO.getInstance().getDate(0, 0);
    expiryDate = ProfileDetailsPO.getInstance().getDate(10, 1);
    String observedErrorMessageForExpiryDate =
        ProfileDetailsPO.getInstance()
            .updateInvalidData("PASSPORT", "12345678", expiryDate, issueDate, "Hamburg");
    Assert.assertTrue(
        observedErrorMessageForExpiryDate.equals(
            TestDataValidations.expectedErrorMessageExpiryDate),
        "Expected Error Message is: "
            + TestDataValidations.expectedErrorMessageExpiryDate
            + "Observed Error Message is: "
            + observedErrorMessageForExpiryDate);

    TestLogger.logMsg(
        "Step-3: Validate if an error message is thrown when issuedDate is -10 years  and expiry date is proper and has > 10 years gap");
    issueDate = ProfileDetailsPO.getInstance().getDate(-10, -1);
    expiryDate = ProfileDetailsPO.getInstance().getDate(10, 0);
    String observedErrorMessageForIssueDate =
        ProfileDetailsPO.getInstance()
            .updateInvalidData("PASSPORT", "12345678", expiryDate, issueDate, "Hamburg");
    Assert.assertTrue(
        observedErrorMessageForIssueDate.equals(TestDataValidations.expectedErrorMessageIssueDate),
        "Expected Error Message is: "
            + TestDataValidations.expectedErrorMessageIssueDate
            + "Observed Error Message is: "
            + observedErrorMessageForIssueDate);

    TestLogger.logMsg(
        "Step-4: Validate if an error message is thrown when issuedDate and expiry date has < 10 years gap");
    issueDate = ProfileDetailsPO.getInstance().getDate(1, 1);
    expiryDate = ProfileDetailsPO.getInstance().getDate(7, 1);
    String observedErrorMessageForIssueDate1 =
        ProfileDetailsPO.getInstance()
            .updateInvalidData("PASSPORT", "12345678", expiryDate, issueDate, "Hamburg");
    Assert.assertTrue(
        observedErrorMessageForIssueDate1.equals(
            TestDataValidations.expectedErrorMessageForIssueDate1),
        "Expected Error Message is: "
            + TestDataValidations.expectedErrorMessageForIssueDate1
            + "Observed Error Message is: "
            + observedErrorMessageForIssueDate1);

    TestLogger.logMsg(
        "Step-5: Validate if an error message is thrown when  expiry date format is invalid");
    String observedDateFormatErrorMessage =
        ProfileDetailsPO.getInstance()
            .updateInvalidData("PASSPORT", "12345678", "01.13.2030", "01.12.2020", "Hamburg");
    Assert.assertTrue(
        observedDateFormatErrorMessage.equals(TestDataValidations.expectedDateFormatErrorMessage),
        "Expected Error Message is: "
            + TestDataValidations.expectedDateFormatErrorMessage
            + "Observed Error Message is: "
            + observedDateFormatErrorMessage);

    TestLogger.logMsg(
        "Step-6: Validate if an error message is thrown when  issue date format is invalid");
    observedDateFormatErrorMessage =
        ProfileDetailsPO.getInstance()
            .updateInvalidData("PASSPORT", "12345678", "01.01.2030", "32.12.2022", "Hamburg");
    Assert.assertTrue(
        observedDateFormatErrorMessage.equals(TestDataValidations.expectedDateFormatErrorMessage),
        "Expected Error Message is: "
            + TestDataValidations.expectedDateFormatErrorMessage
            + "Observed Error Message is: "
            + observedDateFormatErrorMessage);

    TestLogger.logMsg(
        "Step-7: Validate if a success message is thrown when all the details are properly entered");
    issueDate = ProfileDetailsPO.getInstance().getDate(0, 0);
    expiryDate = ProfileDetailsPO.getInstance().getDate(10, 0);
    ProfileDetailsPO.getInstance()
        .updateIDData("PASSPORT", "12345678", expiryDate, issueDate, "Hamburg");
    String successMessage = getWebElement(ProfileDetailsPO.getInstance().successMessage).getText();
    Assert.assertTrue(
        successMessage.equals(TestDataValidations.idDataSuccessMessage),
        "Expected Message does not match with Observed Message");

    WebUIOperations.getInstance().scrollDownThePage();
    String savedData =
        getWebElement(ProfileDetailsPO.getInstance().savedData).getAttribute("value");
    TestLogger.logMsg(
        "Step-8: Validate if the ID card field is masked and only last 4 digits are shown");
    Assert.assertTrue(
        savedData.equals("****5678"),
        "Expected data is: +****5678 and observed data is: " + savedData);
  }

  @Test(
      enabled = true,
      groups = {"Regression", "ShopUI"})
  @Parameters({"customerEmail"})
  public void C1635_ChangeTitle(Method methodName, String customerEmail) {

    String testCaseName = methodName.getName();
    TestLogger.logMsg("================ " + testCaseName + " =====================");

    TestLogger.logMsg("Step-1: Log into Shop Portal");
    if (testDataInjection.equalsIgnoreCase("Yes"))
      ShopLoginLogoutPO.getInstance().shopLogin(ENV, CustomerEmail);
    else ShopLoginLogoutPO.getInstance().shopLogin(ENV, customerEmail);

    TestLogger.logMsg(
        "Step-2: Click on Customer Name and validate the web labels present in the Customer Form");
    WebUIOperations.getInstance()
        .waitForElementAndClick(getWebElement(ShopLoginLogoutPO.getInstance().customerName));

    TestLogger.logMsg(
        "Step-3: Verify if Anrede,titel,vorname,pflichtfelder,email,nachname and kundennummer labels are present");
    Assert.assertTrue(
        getWebElement(ProfileDetailsPO.getInstance().anredeLabel).isDisplayed(),
        "Web Element Anrede label is not present");
    Assert.assertTrue(
        getWebElement(ProfileDetailsPO.getInstance().titelLabel).isDisplayed(),
        "Web Element titel label is not present");
    Assert.assertTrue(
        getWebElement(ProfileDetailsPO.getInstance().vornameLabel).isDisplayed(),
        "Web Element firstName label is not present");
    Assert.assertTrue(
        getWebElement(ProfileDetailsPO.getInstance().pflichtfelderLabel).isDisplayed(),
        "Web pflitch label is not present");
    Assert.assertTrue(
        getWebElement(ProfileDetailsPO.getInstance().emailLabel).isDisplayed(),
        "Web Element Email label is not present");
    Assert.assertTrue(
        getWebElement(ProfileDetailsPO.getInstance().KundennummerLabel).isDisplayed(),
        "Web Element Kunennumer label is not present");
    Assert.assertTrue(
        getWebElement(ProfileDetailsPO.getInstance().NachnameLabel).isDisplayed(),
        "Web Element LastName label is not present");

    //    ProductDetailsPO.getInstance().validateFilterValues("
    // ,Dr.,Prof.",getWebElement(ProfileDetailsPO.getInstance().titel));
    TestLogger.logMsg("Step-4: Select Dr. from Title dropdown and click Save");
    WebUIOperations.getInstance()
        .selectDropdownByValue(getWebElement(ProfileDetailsPO.getInstance().titel), "DR");
    WebUIOperations.getInstance()
        .waitForElementAndClick(getWebElement(ProfileDetailsPO.getInstance().saveCustomerDetails));

    TestLogger.logMsg("Step-6: Validate if a Success Message is shown to the user");
    String successMessage =
        getWebElement(ProfileDetailsPO.SUCCESS_MESSAGE_FOR_CUSTOMER_DETAIL_CHANGE).getText();
    Assert.assertTrue(
        successMessage.equals(TestDataValidations.profileDataSuccessMessage),
        "Expected Message: "
            + TestDataValidations.profileDataSuccessMessage
            + " Observed message: "
            + successMessage);

    TestLogger.logMsg("Step-7: Verify if Customer Name is updated with the Title");
    String titleChange = getWebElement(ShopLoginLogoutPO.getInstance().customerName).getText();
    Assert.assertTrue(titleChange.contains("Dr."), "Title Name does not contain: Dr.");
  }

  @Test(
      enabled = true,
      groups = {"Regression", "ShopUI"})
  @Parameters({"customerEmail"})
  public void C7378_VerifyPhoneNumber(Method methodName, String customerEmail) {

    String testCaseName = methodName.getName();
    TestLogger.logMsg("================ " + testCaseName + " =====================");

    TestLogger.logMsg("Step-1: Log into Shop Portal");
    if (testDataInjection.equalsIgnoreCase("Yes"))
      ShopLoginLogoutPO.getInstance().shopLogin(ENV, CustomerEmail);
    else ShopLoginLogoutPO.getInstance().shopLogin(ENV, customerEmail);

    TestLogger.logMsg(
        "Step-2: Click on Customer Name and validate the PhoneNumber field in Meine Bankdaten section");
    WebUIOperations.getInstance()
        .waitForElementAndClick(getWebElement(ShopLoginLogoutPO.getInstance().customerName));
    Assert.assertTrue(
        getWebElement(ProfileDetailsPO.getInstance().phoneNumberLabel).isDisplayed(),
        "Web Element PhoneNumber label is not present");

    TestLogger.logMsg("Step-3: Validate if a Phone Number shown to the user is masked in UI");
    String phoneNumber =
        getWebElement(ProfileDetailsPO.getInstance().phoneNumber).getAttribute("value");
    Assert.assertTrue(
        phoneNumber.equals(TestDataValidations.phoneNumberMasked),
        "Expected Message: "
            + TestDataValidations.phoneNumberMasked
            + " Observed message: "
            + phoneNumber);
  }

  @Test(
      enabled = true,
      groups = {"Regression", "ShopUI"})
  @Parameters({"customerEmail"})
  public void C7376_VerifyPhoneAndCustomerDetails(Method methodName, String customerEmail) {

    String testCaseName = methodName.getName();
    TestLogger.logMsg("================ " + testCaseName + " =====================");

    TestLogger.logMsg("Step-1: Log into Shop Portal");
    if (testDataInjection.equalsIgnoreCase("Yes"))
      ShopLoginLogoutPO.getInstance().shopLogin(ENV, CustomerEmail);
    else ShopLoginLogoutPO.getInstance().shopLogin(ENV, customerEmail);

    TestLogger.logMsg(
        "Step-2: Click on Customer Name and validate the fields  in Meine Bankdaten section");
    WebUIOperations.getInstance()
        .waitForElementAndClick(getWebElement(ShopLoginLogoutPO.getInstance().customerName));
    Assert.assertTrue(
        getWebElement(ProfileDetailsPO.getInstance().phoneNumberLabel).isDisplayed(),
        "Web Element PhoneNumber label is not present");
    String observedValue =
        getWebElement(ProfileDetailsPO.getInstance().phoneNumber).getAttribute("value");
    Assert.assertTrue(
        observedValue.equals(TestDataValidations.phoneNumberMasked),
        "Expected Message: "
            + TestDataValidations.phoneNumberMasked
            + " Observed message: "
            + observedValue);

    Assert.assertTrue(
        getWebElement(ProfileDetailsPO.getInstance().ZPPartnerBankLabel).isDisplayed(),
        "Web Element ZP PartnerBank label is not present");
    String expectedValue =
        getWebElement(ProfileDetailsPO.getInstance().ZPPartnerBank).getAttribute("value");
    Assert.assertTrue(
        expectedValue.equals("Sutor Bank"),
        "Expected Message and  Observed message are not same" + expectedValue);

    Assert.assertTrue(
        getWebElement(ProfileDetailsPO.getInstance().KontoinhaberLabel).isDisplayed(),
        "Web Element KontoinhaberLabel label is not present");
    expectedValue =
        getWebElement(ProfileDetailsPO.getInstance().Kontoinhaber).getAttribute("value");
    Assert.assertTrue(
        expectedValue.equals("Herr fffJolie fffStoutjesdijk"),
        "Expected Message and  Observed message are not same" + expectedValue);

    Assert.assertTrue(
        getWebElement(ProfileDetailsPO.getInstance().IBANZINSPILOT_KontoLabel).isDisplayed(),
        "Web Element IBANZINSPILOT_KontoLabel label is not present");
    expectedValue =
        getWebElement(ProfileDetailsPO.getInstance().IBANZINSPILOT_Konto).getAttribute("value");
    Assert.assertTrue(
        expectedValue.equals("DE81202308006564946146"),
        "Expected Message and  Observed message are not same" + expectedValue);

    Assert.assertTrue(
        getWebElement(ProfileDetailsPO.getInstance().StraßeLabel).isDisplayed(),
        "Web Element Street/House label is not present");
    expectedValue = getWebElement(ProfileDetailsPO.getInstance().Straße).getAttribute("value");
    Assert.assertTrue(
        expectedValue.equals("Allensteiner Str. 30a"),
        "Expected Message and  Observed message are not same" + expectedValue);

    Assert.assertTrue(
        getWebElement(ProfileDetailsPO.getInstance().postalCodeLabel).isDisplayed(),
        "Web Element Postal Code label is not present");
    expectedValue = getWebElement(ProfileDetailsPO.getInstance().postalCode).getAttribute("value");
    Assert.assertTrue(
        expectedValue.equals("55151 Filipowskiburg"),
        "Expected Message and  Observed message are not same" + expectedValue);

    Assert.assertTrue(
        getWebElement(ProfileDetailsPO.getInstance().LandLabel).isDisplayed(),
        "Web Element Land label is not present");
    expectedValue = getWebElement(ProfileDetailsPO.getInstance().Land).getAttribute("value");
    Assert.assertTrue(
        expectedValue.equals("DE"),
        "Expected Message and  Observed message are not same" + expectedValue);

    Assert.assertTrue(
        getWebElement(ProfileDetailsPO.getInstance().IBANLabel).isDisplayed(),
        "Web Element IBAN label is not present");
    expectedValue = getWebElement(ProfileDetailsPO.getInstance().IBANNumber).getAttribute("value");
    Assert.assertTrue(
        expectedValue.equals("Bankverbindung ungültig / liegt nicht vor"),
        "Expected Message and  Observed message are not same" + expectedValue);

    Assert.assertTrue(
        getWebElement(ProfileDetailsPO.getInstance().BICLabel).isDisplayed(),
        "Web Element BIC label is not present");
    expectedValue = getWebElement(ProfileDetailsPO.getInstance().BIC).getAttribute("value");
    Assert.assertTrue(
        expectedValue.equals("Bankverbindung ungültig / liegt nicht vor"),
        "Expected Message and  Observed message are not same" + expectedValue);
  }

  @Test(
      enabled = true,
      groups = {"Regression", "ShopUI"})
  @Parameters({"customerEmail", "newPassword"})
  public void C1637_ChangeProfilePassword(
      Method methodName, String customerEmail, String newPassword) throws InterruptedException {
    String testCaseName = methodName.getName();
    TestLogger.logMsg("================ " + testCaseName + " =====================");

    TestLogger.logMsg("Step-1: Log into Shop Portal");
    if (testDataInjection.equalsIgnoreCase("Yes")) {
      ShopLoginLogoutPO.getInstance().shopLogin(ENV, CustomerEmail);
    } else ShopLoginLogoutPO.getInstance().shopLogin(ENV, customerEmail);

    ProfileDetailsPO.getInstance().updatePassword(TestConstants.SHOP_PASSWORD, newPassword);
    String passwordChangeMessage =
        getWebElement(ProfileDetailsPO.getInstance().passwordSaveMessage).getText();
    Assert.assertTrue(
        passwordChangeMessage.equals(TestDataValidations.passwordchngMessage),
        "Expected Message: "
            + passwordChangeMessage
            + " found message: "
            + TestDataValidations.passwordchngMessage);
    Thread.sleep(3000);
    ShopLoginLogoutPO.getInstance().shopLogOut();
    if (testDataInjection.equalsIgnoreCase("Yes")) {
      ShopLoginLogoutPO.getInstance().shopLogin(ENV, CustomerEmail, newPassword);
    } else ShopLoginLogoutPO.getInstance().shopLogin(ENV, customerEmail, newPassword);
    WebUIOperations.getInstance()
        .verifyElementIsPresent(
            getWebElement(ShopLoginLogoutPO.getInstance().customerName), "Shop HomePage");
    MailHogPO.getInstance().openMailhog();
    MailHogPO.getInstance().verifyEmail(CustomerEmail, "Zinspilot Passwortänderung");
  }

  @Test(
      enabled = true,
      groups = {"P1", "customerProfile", "Regression"})
  public void C1636_ChangeProfileAfterRegistration()
      throws InterruptedException, SQLException, AWTException {
    DynamicDataReusables LOAD_INPUTS;
    String dob = "09.09.1990",
        marital = "verheiratet",
        pob = "12/12/2000",
        cob = "Deutschland",
        street = "West Street",
        streetNum = "19-A",
        postal = "14109",
        job = "Hausmann",
        birthName = "Dietrich",
        branch = "Test";
    LOAD_INPUTS = new DynamicDataReusables();

    TestLogger.logMsg(
        "================ C1636_ChangeProfileAfterRegistration =====================");
    if (testDataInjection.equalsIgnoreCase("Yes")) {
      // Truncate All Tables
      DBReusables.getInstance().executeSqlScript("TruncateAllTables.sql");
      // Test Data Injection for Service Bank
      DBReusables.getInstance().executeSqlScript("serviceBank-sutor.sql");
    } else {
      // Test data till sbaff abd sbaff_cd bug is resolved
      DBReusables.getInstance().executeSqlScript("sbaff_sbaff_cd.sql");
    }
    TestLogger.logMsg("Step-1: Do the Customer Registration");
    LOAD_INPUTS.generateInputs();
    CustomerRegistrationPO.getInstance()
        .customerRegistration(
            LOAD_INPUTS.firstName,
            LOAD_INPUTS.surName,
            LOAD_INPUTS.emailAddress,
            LOAD_INPUTS.password,
            LOAD_INPUTS.saluation,
            "Prof.");
    CustomerRegistrationPO.getInstance()
        .verifyCustomerStatus(LOAD_INPUTS.emailAddress, "REGISTERED");
    MailHogPO.getInstance()
        .customerRegistration_ActivationButton(
            LOAD_INPUTS.emailAddress, "Ihre Anmeldung bei Zinspilot");
    String CustNo = DBReusables.getInstance().getCustomerNumber(LOAD_INPUTS.emailAddress);
    TestLogger.logMsg("Customer Number : " + CustNo);
    String CustomerIban = LOAD_INPUTS.CustomerIban(CustNo);
    CustomerRegistrationPO.getInstance()
        .accountOpening(
            LOAD_INPUTS.saluation,
            "Prof.",
            LOAD_INPUTS.firstName,
            LOAD_INPUTS.surName,
            LOAD_INPUTS.emailAddress,
            LOAD_INPUTS.phone,
            dob,
            marital,
            cob,
            street,
            streetNum,
            postal,
            job,
            birthName,
            CustomerIban,
            branch);

    CustomerRegistrationPO.getInstance().accountConfirmation();
    CustomerRegistrationPO.getInstance()
        .verifyCustomerStatus(LOAD_INPUTS.emailAddress, "ACTIVATED");

    TestLogger.logMsg("Step-2: Click on Profile Name without logging out after registration");
    WebUIOperations.getInstance()
        .waitForElementAndClick(getWebElement(ShopLoginLogoutPO.getInstance().customerName));

    TestLogger.logMsg(
        "Step-3: Select the title value as Dr. in Registration details section and save the value");
    WebUIOperations.getInstance()
        .selectDropdownByValue(getWebElement(ProfileDetailsPO.getInstance().titel), "DR");
    WebUIOperations.getInstance()
        .waitForElementAndClick(getWebElement(ProfileDetailsPO.getInstance().saveTitelButton));
    String titleText =
        getWebElement(ProfileDetailsPO.SUCCESS_MESSAGE_FOR_CUSTOMER_DETAIL_CHANGE).getText();
    Select select = new Select(getWebElement(ProfileDetailsPO.getInstance().titel));
    String titleValue = select.getFirstSelectedOption().getText();

    TestLogger.logMsg(
        "Step-4: Validate if the selected value is Dr. and the validation message shows up  successful message");
    Assert.assertTrue(titleValue.equals("Dr."), "Expected and Observed Title value are not same");
    Assert.assertTrue(
        titleText.equals("Ihre Kundendaten wurden erfolgreich gespeichert."),
        "Expected Message is not same as observed message");
  }

  @Test(
      enabled = true,
      groups = {"P1", "Regression", "customerProfile", "shopUI"})
  @Parameters("customerEmail")
  public void C9938_9939_9940_VerifyInviteLink(Method methodName, String customerEmail)
      throws InterruptedException, IOException, UnsupportedFlavorException {

    String testCaseName = methodName.getName();
    TestLogger.logMsg("================ " + testCaseName + " =====================");
    TestLogger.logMsg("Step-1: Login to Shop and click on Customer link");
    if (testDataInjection.equalsIgnoreCase("Yes")) {
      ShopLoginLogoutPO.getInstance().shopLogin(ENV, CustomerEmail);
    } else ShopLoginLogoutPO.getInstance().shopLogin(ENV, customerEmail);
    WebUIOperations.getInstance()
        .waitForElementAndClick(getWebElement(ShopLoginLogoutPO.getInstance().customerName));

    TestLogger.logMsg(
        "Step-2: Validate if Referral section is present and check if referral code and link are present");
    String referralCode =
        getWebElement(ProfileDetailsPO.getInstance().referralCodeInput).getAttribute("value");
    String referralLink =
        getWebElement(ProfileDetailsPO.getInstance().referralCodeLink).getAttribute("value");
    Assert.assertTrue(!referralCode.isEmpty(), "Referral Code is not empty");

    Assert.assertTrue(!referralLink.isEmpty(), "Referral Code is not empty");

    TestLogger.logMsg(
        "Step-3: Validate if Action link page is present and click on action link page should navigate to typo3 Page");
    WebUIOperations.getInstance()
        .waitForElementAndClick(getWebElement(ProfileDetailsPO.getInstance().actionPageLink));
    CustomerRegistrationPO.getInstance().switchTab(1);
    System.out.println(DRIVER.getCurrentUrl());
    Assert.assertTrue(
        DRIVER.getCurrentUrl().contains("kunden-werben?promo=" + referralCode),
        "The URL contains typo3 Page link");
    DRIVER.close();
    CustomerRegistrationPO.getInstance().switchTab(0);

    TestLogger.logMsg(
        "Step-4: Validate if User can click Copy Code referral link and navigate to Typo3 Page");
    WebUIOperations.getInstance()
        .waitForElementAndClick(getWebElement(ProfileDetailsPO.getInstance().copyReferralLink));
    if (ConfigManager.getInstance().getString("os").equals("mac")) {
      String myText =
          (String)
              Toolkit.getDefaultToolkit().getSystemClipboard().getData(DataFlavor.stringFlavor);
      Actions actions = new Actions(DRIVER);
      actions.sendKeys(Keys.chord(Keys.COMMAND, "t")).build().perform();
      TestLogger.logMsg(myText);
      DRIVER.get("http://localhost:8896/werbepraemie?promo=zp0aa426e");
      waitTillBrowserLoads();
      // change the validation once tested on int environment
      TestLogger.logMsg("Title is:" + DRIVER.getTitle());
      Assert.assertTrue(DRIVER.getTitle().contains("404"), "Typo 3 page is opened");
      Thread.sleep(3000);
    } else {
      Actions actions = new Actions(DRIVER);
      actions.sendKeys(Keys.chord(Keys.CONTROL, "t")).build().perform();

      DRIVER.get("http://localhost:8896/werbepraemie?promo=zp0aa426e");
      //            actions.sendKeys(Keys.chord(Keys.CONTROL, "v")).build().perform();
      //            actions.sendKeys(Keys.chord(Keys.ENTER)).build().perform();
      TestLogger.logMsg("Title is:" + DRIVER.getTitle());
      Assert.assertTrue(DRIVER.getTitle().contains("404"), "Typo 3 page is opened");
    }
  }

  /*
   * Feature: ResetPassword from UI
   * TestRail Link:https://depositsolutions.testrail.io/index.php?/cases/view/1665
   * Author: shalini.sudam
   */

  @Test(
      enabled = true,
      groups = {"Regression", "ShopUI", "S3"})
  @Parameters({"customerEmail", "newPassword"})
  public void C1665_ResetPasswordFromUI(Method methodName, String customerEmail, String newPassword)
      throws InterruptedException {
    String testCaseName = methodName.getName();
    TestLogger.logMsg("================ " + testCaseName + " =====================");

    TestLogger.logMsg("Step-1: Log into Shop Portal");

    TestLogger.logMsg(
        "Step-2: Click on Reset Password Link and enter the email ID in the next screen");
    WebUIOperations.getInstance()
        .waitForElementAndClick(getWebElement(ProfileDetailsPO.getInstance().resetPasswordLink));

    WebUIOperations.getInstance()
        .sendKeys(getWebElement(ProfileDetailsPO.getInstance().emailAddress), CustomerEmail);

    WebUIOperations.getInstance()
        .waitForElementAndClick(getWebElement(ProfileDetailsPO.getInstance().submitEmail));

    TestLogger.logMsg("Step-3: Open MailHog and verify if Password reset link is sent to the user");
    MailHogPO.getInstance().openMailhog();
    MailHogPO.getInstance()
        .clickPasswordResetLink(CustomerEmail, "Zinspilot Neues Passwort erstellen");

    TestLogger.logMsg("Step-4: Reset the password using the link given in email and click submit");
    WebUIOperations.getInstance().switchTab(2);

    WebUIOperations.getInstance()
        .waitForElementAndClick(getWebElement(ProfileDetailsPO.getInstance().newPasswordInput));
    WebUIOperations.getInstance()
        .sendKeys(getWebElement(ProfileDetailsPO.getInstance().newPasswordInput), newPassword);
    WebUIOperations.getInstance()
        .waitForElementAndClick(getWebElement(ProfileDetailsPO.getInstance().passwordChangeButton));

    TestLogger.logMsg("Step-6: Verify if success message is displayed after password change.");
    String successMessage =
        getWebElement(ProfileDetailsPO.getInstance().successMessage).getText().toString();
    Assert.assertTrue(successMessage.equals(TestDataValidations.getPasswordchngMessage));

    TestLogger.logMsg(
        "Step-7: Logout of the shop and verify if user is able to login with new password");
    ShopLoginLogoutPO.getInstance().shopLogOut();
    if (testDataInjection.equalsIgnoreCase("Yes")) {
      ShopLoginLogoutPO.getInstance().shopLogin(ENV, CustomerEmail, newPassword);
    } else ShopLoginLogoutPO.getInstance().shopLogin(ENV, customerEmail, newPassword);
  }

  /*
   * Feature: Print Bank Transfer Details
   * Product Type:Call/Call-a-like
   * TestRail Link:https://depositsolutions.testrail.io/index.php?/cases/view/1646
   * Author: shalini.sudam
   */
  @Test(
      enabled = true,
      groups = {"Payout", "Regression", "ShopUI", "PB"})
  @Parameters({"customerEmail"})
  public void C1646_PrintBankTransferDetails(Method methodName, String customerEmail)
      throws InterruptedException {
    String testName = methodName.getName();

    TestLogger.logMsg("==========" + testName + " Started==========");
    TestLogger.logMsg("Step-1: Inject the Product Bank Details into the system and perform Login");

    if (testDataInjection.equalsIgnoreCase("Yes")) {
      DBReusables.getInstance().executeSqlScript("productBank_CreditPlus.sql");
      DBReusables.getInstance().executeSqlScript("Tranche-CreditPlus-TG.sql");
      ShopLoginLogoutPO.getInstance().shopLogin(ENV, CustomerEmail);
    } else ShopLoginLogoutPO.getInstance().shopLogin(ENV, customerEmail);

    ShopLoginLogoutPO.getInstance().shopCache();
    TestLogger.logMsg(
        "Step-2: Click on Jest Analegen Button on Product Page and then on Product Details Page");
    WebUIOperations.getInstance()
        .waitForElementAndClick(getWebElement(ProductDetailsPO.CREATE_NOW_PRODUCTDETAILS));
    WebUIOperations.getInstance()
        .waitForElementAndClick(getWebElement(ProductDetailsPO.CREATE_NOW_PRODUCTDETAILS));

    TestLogger.logMsg(
        "Step-3: Click on Print Transfer Details Button and a PDF file is downloaded");
    WebUIOperations.getInstance()
        .waitForElementAndClick(getWebElement(ProductDetailsPO.PRINT_TRANSFER_DETAILS));
    Thread.sleep(2000);
    TestLogger.logMsg(
        "Step-4: Verify if the file is downloaded and exists in the Downloads location");
    String home = System.getProperty("user.home");

    //    for (File file : filesArray) {
    //      if (file.isFile()) {
    //        TestLogger.logMsg(file.getName());
    //      } else {
    //        TestLogger.logMsg("No Files Found");
    //      }
    //    }

    //    File directory1 =
    //        new File(
    //            File.separator + "home" + File.separator + "seluser" + File.separator +
    // "Downloads");
    //    File[] filesArray1 = directory1.listFiles();
    //    TestLogger.logMsg(
    //        File.separator
    //            + "home"
    //            + File.separator
    //            + "seluser"
    //            + File.separator
    //            + "Downloads"
    //            + " Length: "
    //            + filesArray1.length);
    //    for (File file : filesArray1) {
    //      if (file.isFile()) {
    //        TestLogger.logMsg(file.getName());
    //      } else {
    //        TestLogger.logMsg("No Files Found");
    //      }
    //    }
    File pdfFile =
        new File(home + File.separator + "downloads" + File.separator + "ueberweisungstraeger.pdf");

    Assert.assertTrue(pdfFile.exists(), "PDF File Exists in the location");
  }

  /*
   * Feature: Print Bank Transfer Details
   * Product Type:Call/Call-a-like
   * TestRail Link:https://depositsolutions.testrail.io/index.php?/cases/view/1565
   * Author: shalini.sudam
   */
  @Test(
      enabled = true,
      groups = {"Payout", "Regression", "ShopUI", "PB"})
  @Parameters({"customerEmail"})
  public void C1565_OKEEnterForeignTaxID(Method methodName, String customerEmail)
      throws InterruptedException {
    String testName = methodName.getName();

    TestLogger.logMsg("==========" + testName + " Started==========");
    TestLogger.logMsg("Step-1: Inject the Product Bank Details into the system and perform Login");

    if (testDataInjection.equalsIgnoreCase("Yes")) {
      ShopLoginLogoutPO.getInstance().shopLogin(ENV, CustomerEmail);
    } else ShopLoginLogoutPO.getInstance().shopLogin(ENV, customerEmail);

    TestLogger.logMsg(
        "Step-2: Click on Customer Name and validate the fields  in Meine Bankdaten section");
    WebUIOperations.getInstance()
        .waitForElementAndClick(getWebElement(ShopLoginLogoutPO.getInstance().customerName));

    TestLogger.logMsg("Step-3: Click TIN Section and enter the details of different TINS");
    WebUIOperations.getInstance()
        .waitForElementAndClick(getWebElement(ProfileDetailsPO.EDIT_TIN_SECTION));
    WebUIOperations.getInstance()
        .waitForElementAndClick(getWebElement(ProfileDetailsPO.RADIO_BUTTON_TIN_NONGERMAN));
    ProfileDetailsPO.getInstance().selectTIN("BG", "8508010133", 0);
    ProfileDetailsPO.getInstance().selectTIN("FI", "8508010132", 1);
    ProfileDetailsPO.getInstance().selectTIN("IT", "8508010131", 2);

    WebUIOperations.getInstance()
        .waitForElementAndClick(getWebElement(ProfileDetailsPO.getInstance().passwordChangeButton));

    TestLogger.logMsg(
        "Step-4: Validate the Success Message and also validate if values are displayed in Mask format");
    String messageObserved =
        getWebElement(ProfileDetailsPO.SUCCESS_MESSAGE_FOR_CUSTOMER_DETAIL_CHANGE).getText();
    Assert.assertTrue(messageObserved.equals(TestDataValidations.profileDataSuccessMessage));

    String message_value = ProfileDetailsPO.getInstance().verifyMaskedTinValues(1);
    String message_value_1 = ProfileDetailsPO.getInstance().verifyMaskedTinValues(2);
    String message_value_2 = ProfileDetailsPO.getInstance().verifyMaskedTinValues(3);

    Assert.assertTrue(message_value.equals("******0133"));
    Assert.assertTrue(message_value_1.equals("******0132"));
    Assert.assertTrue(message_value_2.equals("******0131"));
  }

  @Test(
      enabled = true,
      groups = {"Regression1"})
  // @Parameters({"sourceTrancheIdentifier", "icAmount", "customerEmail",
  // "targetTrancheIdentifier"})
  public void C2022_InterestRateConfirmationEmail(Method methodName) throws SQLException {
    if (testDataInjection.equalsIgnoreCase("Yes")) {
      // Test Data Injection for Product Bank
      DBReusables.getInstance().executeSqlScript("productBank_CreditPlus.sql");
      DBReusables.getInstance().executeSqlScript("Tranche-CreditPlus-FG1Y.sql");

      //      DBReusables.getInstance()
      //          .executeSql("delete * from table " +
      // "`comone_b2c.b2c_fixed_term_interest_approval`");
      DBReusables.getInstance()
          .executeSql(
              "DELETE FROM `comonea_b2c`.`b2c_fixed_term_interest_approval` WHERE (`id` = '1')");
      DBReusables.getInstance()
          .executeSql(
              ("DELETE FROM `comonea_b2c`.`b2c_fixed_term_interest_approval` WHERE (`id` = '2')"));
      //      ProdOpsPO
    }
  }

  @Test(
      enabled = true,
      groups = {"Regression"})
  public void C4155_PDP_NoticedProduct(Method methodName) throws SQLException {
    TestLogger.logMsg("Step-1: Inject CALL Product and perform Shop Login");
    // Test Data Injection for Product Bank
    DBReusables.getInstance().executeSqlScript("productBank_CreditPlus.sql");
    DBReusables.getInstance().executeSqlScript("Tranche-CreditPlus-NP.sql");
    DBReusables.getInstance().executeSqlScript("customerWithPayIn-CreditPlus-NP.sql");
    ShopLoginLogoutPO.getInstance().shopLogin(ENV, CustomerEmail);

    TestLogger.logMsg(
        "Step-2: Navigate to Analagenbote page and validate if noticed period for CALL product is displayed as Spar+NoticePeriod");
    String NP_TEXT = getWebElement(MeineAnlagenPO.NOTICEPERIOD_TEXT).getText();
    String NP_MESSAGE = getWebElement(MeineAnlagenPO.NOTICEPERIOD_MESSAGE).getText();
    TestLogger.logInfo(NP_MESSAGE);
    Assert.assertTrue(NP_TEXT.equals("Spar33Flex"));

    TestLogger.logMsg(
        "Step-3: Navigate to Analagenbote page and validate if noticed period for CALL product is displayed as Kündigungsfrist: 10 Tage");
    Assert.assertTrue(
        NP_MESSAGE.equals("Kündigungsfrist: 33 Tage zum nächstmöglichen Auszahlungstermin"));
    TestLogger.logMsg("Step-4: Click on Jetzt Analegn");
    WebUIOperations.getInstance()
        .waitForElementAndClick(getWebElement(ProductDetailsPO.CREATE_NOW_PRODUCTDETAILS));

    TestLogger.logMsg("Step-5: Validate Notice Period text");
    NP_MESSAGE = getWebElement(MeineAnlagenPO.NP_MESSAGE).getText();
    TestLogger.logInfo(getWebElement(MeineAnlagenPO.NP_TEXT).getText());
    NP_TEXT = getWebElement(MeineAnlagenPO.NP_TEXT).getText();
    Assert.assertTrue(NP_TEXT.equals("Spar33Flex"));
    Assert.assertTrue(
        NP_MESSAGE.equals("Kündigungsfrist: 33 Tage zum nächstmöglichen Auszahlungstermin"));
  }

  @Test(
      enabled = true,
      groups = {"Regression"})
  public void C4156_PDP_NoticedProduct(Method methodName) throws SQLException {

    // Test Data Injection for Product Bank
    TestLogger.logMsg("Step-1: Inject CALL Product and perform Shop Login");
    DBReusables.getInstance().executeSqlScript("productBank-BUCUROBUwithNATG.sql");

    ShopLoginLogoutPO.getInstance().shopLogin(ENV, CustomerEmail);

    TestLogger.logMsg(
        "Step-2: Navigate to Analagenbote page and validate if noticed period for CALL product is displayed as Spar+NoticePeriod");
    String NP_TEXT = getWebElement(MeineAnlagenPO.NOTICEPERIOD_TEXT).getText();
    String NP_MESSAGE = getWebElement(MeineAnlagenPO.NOTICEPERIOD_MESSAGE).getText();

    Assert.assertTrue(NP_TEXT.equals("Spar10"));

    TestLogger.logMsg(
        "Step-3: Navigate to Analagenbote page and validate if noticed period for CALL product is displayed as Kündigungsfrist: 10 Tage");
    Assert.assertTrue(NP_MESSAGE.equals("Kündigungsfrist: 10 Tage"));

    TestLogger.logMsg("Step-4: Click on Jetzt Analegn");
    WebUIOperations.getInstance()
        .waitForElementAndClick(getWebElement(ProductDetailsPO.CREATE_NOW_PRODUCTDETAILS));

    TestLogger.logMsg("Step-5: Validate Notice Period text");
    NP_MESSAGE = getWebElement(MeineAnlagenPO.NP_MESSAGE).getText();
    TestLogger.logInfo(getWebElement(MeineAnlagenPO.NP_TEXT).getText());
    NP_TEXT = getWebElement(MeineAnlagenPO.NP_TEXT).getText();
    Assert.assertTrue(NP_TEXT.equals(" Spar10"));
    Assert.assertTrue(NP_MESSAGE.equals("Kündigungsfrist: 10 Tage"));
  }

  @AfterMethod(alwaysRun = true)
  public void teardown(ITestResult result) {
    if (ITestResult.FAILURE == result.getStatus()) {
      takeScreenshot(result.getName());
    }

    TestLogger.logInfo("Executing Browser tearDown method");
    ShopLoginLogoutPO.getInstance().closeAllBrowsers();
  }

  @AfterTest(alwaysRun = true)
  public void cleanup() throws SQLException {
    //        DBReusables.getInstance().executeSqlScript("TruncateAllTables.sql");
    DBReusables.getInstance().closeDBCon();
  }
}
