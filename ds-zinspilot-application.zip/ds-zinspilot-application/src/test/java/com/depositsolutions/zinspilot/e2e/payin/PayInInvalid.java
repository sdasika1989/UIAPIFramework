package com.depositsolutions.zinspilot.e2e.payin;

import static com.depositsolutions.common.reusables.TestConstants.SHOP_URL_CONFIG_KEY;

import com.depositsolutions.common.restapi.helpers.WebServiceOperations;
import com.depositsolutions.common.restapi.services.Gunda;
import com.depositsolutions.common.reusables.DBReusables;
import com.depositsolutions.common.reusables.GundaServices;
import com.depositsolutions.common.reusables.PaymentServices;
import com.depositsolutions.common.ui.helpers.BaseTestClassUI;
import com.depositsolutions.common.ui.helpers.WebUIOperations;
import com.depositsolutions.common.ui.zpuipageobjects.*;
import com.depositsolutions.common.utils.ConfigManager;
import com.depositsolutions.common.utils.TestLogger;
import de.depositsolutions.common.IBAN;
import java.lang.reflect.Method;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.*;
import org.testng.Assert;
import org.testng.ITestResult;
import org.testng.annotations.*;

public class PayInInvalid extends BaseTestClassUI {

  private String testDataInjection = ConfigManager.getInstance().getString("testDataInjection");
  String CustomerEmail, TrancheIdentifier, PayInAmount;
  Map<String, String> actualMap;
  HashMap<String, String> expectedMap = new HashMap();
  HashSet<String> actualErrorList = new HashSet();
  Set<String> expectedErrorList = new HashSet();

  @BeforeTest(alwaysRun = true)
  public void setupDB() {
    DBReusables.getInstance().dbConnect();
  }

  @BeforeMethod(alwaysRun = true)
  public void preLoadSQLTestData() {
    if (testDataInjection.equalsIgnoreCase("Yes")) {
      // Truncate All Tables
      DBReusables.getInstance().executeSqlScript("TruncateAllTables.sql");
      // Test Data Injection for Customer and Service Bank
      DBReusables.getInstance().executeSqlScript("serviceBank-sutor.sql");
      DBReusables.getInstance().executeSqlScript("customer.sql");
      // Getting customer details
      CustomerEmail = DBReusables.getInstance().getCustomerEmail();
    } else {
      // Truncate sps Tables
      DBReusables.getInstance().executeSqlScript("TruncateSPSTables.sql");
    }
    setUpForTest(ConfigManager.getInstance().getString(SHOP_URL_CONFIG_KEY));
  }

  /*
   * Feature: Invalid PayIn-SOF,QUE and DRM
   * Product Type:Fixed Term
   * Product Bank Model:DIRECT_RELATIONSHIP_MODEL(DRM)
   * TestRail Links:
   *               https://depositsolutions.testrail.io/index.php?/cases/view/4479
   *                https://depositsolutions.testrail.io/index.php?/cases/view/1908
   * https://depositsolutions.testrail.io/index.php?/cases/view/10382
   * https://depositsolutions.testrail.io/index.php?/cases/view/10381
   * Author: deepthi.gorre
   */
  @Test(
      enabled = true,
      groups = {"PayIn", "Regression", "DRM", "SOF", "QUE"})
  @Parameters({"trancheIdentifier", "payInAmount", "customerEmail"})
  public void C10381_C10382_C1908_C4479_Invalid_PayIn_SOF_QUE_DRM_FG(
      Method methodName, String sTrancheIdentifier, String sPayInAmount, String sCustomerEmail)
      throws InterruptedException {
    if (testDataInjection.equalsIgnoreCase("Yes")) {
      // Test Data Injection for Product Bank
      DBReusables.getInstance().executeSqlScript("productBank-CKV.sql");
      DBReusables.getInstance().executeSqlScript("Tranche-CKV-FG1Y.sql");
      // Getting Product Details
      TrancheIdentifier = DBReusables.getInstance().getTrancheIdentifier("FG");
      PayInAmount = DBReusables.getInstance().getRamdomPayInAmount(TrancheIdentifier);
    } else {
      CustomerEmail = sCustomerEmail;
      TrancheIdentifier = sTrancheIdentifier;
      PayInAmount = sPayInAmount;
    }
    String testName = methodName.getName();
    TestLogger.logMsg("==========" + testName + " Started==========");
    actualMap =
        PaymentServices.getInstance().invalidPayIn(CustomerEmail, TrancheIdentifier, PayInAmount);
    actualErrorList.addAll(actualMap.keySet());
    expectedMap.clear();
    expectedMap.put(
        "QUE",
        "<b>Following  questions are not answered.</b><ul><li>MARITAL_STATUS</li></ul><ul><li>TYPE_EMPLOYMENT</li></ul>");
    expectedMap.put("DRM", "DRM contract is Invalid");
    expectedMap.put(
        "SOF",
        "Wenn Mittelherkunft nicht angegeben ist, den Kunden auffordern, im Anlage-Cockpit bei dem eingezahlten Produkt auf „Jetzt anlegen“ zu klicken, die Herkunft anzugeben und diese per erneutem Klick auf „Jetzt anlegen“ zu übermitteln");
    expectedErrorList.add("QUE");
    expectedErrorList.add("DRM");
    expectedErrorList.add("SOF");
    Assert.assertTrue(
        actualErrorList.equals(expectedErrorList), "Gunda error reason/s is not correct");
    Assert.assertTrue(actualMap.equals(expectedMap), "Gunda error message/s is not correct");
    // check for Bookings message
    Assert.assertEquals(
        DRIVER.findElement(MeineAnlagenPO.getInstance().drm_warningmsg).getText(),
        "Damit die automatische Prolongation durch Sie wieder aktiviert werden kann, benötigen wir Ihre Zustimmung zum Kundenrahmenvertrag. Bitte klicken Sie auf \"Vertrag einsehen\".",
        "Incorrect warning message");
    TestLogger.logInfo("DRM Warning message validated successfully");

    TestLogger.logInfo("Step-7: Click on Vertrag einsehen button");
    // Button Validation color of button Bug-ZA-583.Button functionality is still under discussion
    DRIVER.findElement(MeineAnlagenPO.getInstance().VertragEinsehen).click();

    TestLogger.logInfo("Step-8: Select SOF,QUE and DRM");
    // select QUE from Shop
    ProductDetailsPO.getInstance().selectingQuestionary_CKV();
    // accept DRM from Shop
    DRIVER.findElement(ProductDetailsPO.getInstance().drm_agreement).click();
    // check for ennable of DRM button
    Assert.assertEquals(
        DRIVER.findElement(ProductDetailsPO.getInstance().drm_accept).getAttribute("class"),
        "btn btn-info",
        "DRM button is not enabled");
    // accept DRM Contract
    DRIVER.findElement(ProductDetailsPO.getInstance().drm_accept).click();
    // check for DRM success message
    Assert.assertEquals(
        DRIVER.findElement(MeineAnlagenPO.getInstance().SuccessMessage).getText(),
        "Ihre Zustimmung zum Kundenrahmenvertrag wurde hinterlegt. Der Kundenrahmenvertrag der "
            + DBReusables.getInstance().getBankName_FromTrancheIdentifier(TrancheIdentifier)
            + " wurde Ihnen in “Archiv & Dokumente” bereitgestellt.",
        "DRM button is not enabled");
    TestLogger.logInfo("DRM Contract accepted successfully");
    // Check in Archive and Documents
    ArchiveAndDocumentsPO.getInstance()
        .validatePersonalDocument(
            DBReusables.getInstance().formatDate("dd.MM.yyyy")
                + " Kundenrahmenvertrag - "
                + DBReusables.getInstance().getBankName_FromTrancheIdentifier(TrancheIdentifier)
                + "\n"
                + "Zum Vertragsabschluss wird Ihre Einzahlung benötigt"
                + " Download Kundenrahmenvertrag",
            "present");
    // check for DRM Status
    Assert.assertEquals(
        DBReusables.getInstance().checkDRM(), "INITIATED", "DRM state is not INITIATED");
    TestLogger.logInfo("validated DRM Status is INITIATED");
    // select Product from Shop
    ProductDetailsPO.getInstance().selectingProductFromProductListPage(TrancheIdentifier);
    // select SOF from Shop
    ProductDetailsPO.getInstance().selectingSourceOfFunds1("REGULAR_INCOME");
    WebUIOperations.getInstance().scrollDownThePage();
    DRIVER.findElement(ProductDetailsPO.getInstance().button_payin).click();
    // check for SOF in DB
    Assert.assertEquals(
        DBReusables.getInstance().checkSOF(CustomerEmail),
        "REGULAR_INCOME",
        "SOF data saved to DB in sbtr trustor table");
    TestLogger.logInfo("validated selected SOF in DB ");
    TestLogger.logInfo("Step-9: Run Gunda Validation endpoint");
    Gunda.getInstance().Gunda_validate();

    String table = DBReusables.getInstance().ct2iTable;
    String CustomerNumber = DBReusables.getInstance().getCustomerNumber(CustomerEmail);
    String FormatedPayInAmount =
        (DBReusables.getInstance()
            .formatCurrency(PayInAmount)
            .substring(0, DBReusables.getInstance().formatCurrency(PayInAmount).indexOf(" ")));

    // PayIn Ticket
    String CustomerTicket_id = DBReusables.getInstance().getCustomerTicket_id(table, CustomerEmail);
    // DB Validation
    TestLogger.logMsg("Step-10: Validate Customer Ticket");
    Assert.assertEquals(
        DBReusables.getInstance().getTicketState(CustomerTicket_id, table),
        "VALID",
        "Customer ticket state is INVALID with reason");
    TestLogger.logInfo(
        "Customer Ticket is Invalid with Reason: "
            + DBReusables.getInstance().getTicketStateMessage(CustomerTicket_id, table));

    // Gunda validation
    TestLogger.logMsg("Step-11: Validate Inprogress ticket in Gunda");
    int num =
        GundaServices.getInstance()
            .getInprogressTicket_Array(
                CustomerNumber, DBReusables.getInstance().getTicket_uuid(CustomerTicket_id, table));
    Assert.assertEquals(
        (WebServiceOperations.getInstance()
            .convertStringToJson(Gunda.getInstance().Gunda_GetCustomer(CustomerNumber))
            .getString("notExecutedTickets[" + num + "].ticketState")),
        "VALID",
        "Gunda ticketState is not correct");
    WebServiceOperations.getInstance()
        .convertStringToJson(Gunda.getInstance().Gunda_GetCustomer(CustomerNumber))
        .getString("notExecutedTickets[" + num + "].validationErrors");

    // Email validation.Email link functionality is still under discussion
    TestLogger.logMsg("Step-12: Validate Email in MailHog");
    MailHogPO.getInstance().openMailhog();
    MailHogPO.getInstance()
        .verifyEmail(
            CustomerEmail, "Einzahlungsbestätigung Ihres Anlagebetrags auf Ihrem ZINSPILOT-Konto");
    // Need to add the email content
    MailHogPO.getInstance().closeMailhog();
    WebUIOperations.getInstance().switchTab(0);

    // Shop validation
    TestLogger.logMsg("Step-13: Validate Inprogress ticket in Shop");
    MeineAnlagenPO.getInstance().getInvestmentDetails(TrancheIdentifier, CustomerEmail);
    MeineAnlagenPO.getInstance()
        .validateShopBookings(
            2,
            DateTimeFormatter.ofPattern("dd.MM.yyyy")
                    .format(
                        LocalDate.parse(
                            (CharSequence)
                                DBReusables.getInstance().getTrancheStartDate(TrancheIdentifier)))
                + " vorgemerkt Einzahlung * "
                + FormatedPayInAmount);
    MeineAnlagenPO.getInstance()
        .validateShopHint(
            "Ihr Anlagebetrag wird von Ihrer ZINSPILOT-Partnerbank zum Anlagestart automatisch bei der "
                + DBReusables.getInstance().getBankName_FromTrancheIdentifier(TrancheIdentifier)
                + " angelegt.");
    TestLogger.logMsg("==========" + testName + " Completed==========");
  }

  /*
   * Feature: Invalid PayIn-SOF,QUE and DRM
   * Product Type:Call-a-Like
   * Product Bank Model:DIRECT_RELATIONSHIP_MODEL(DRM)
   * TestRail Links:
   *               https://depositsolutions.testrail.io/index.php?/cases/view/4509
   * https://depositsolutions.testrail.io/index.php?/cases/view/10385
   * Author: deepthi.gorre
   */
  @Test(
      enabled = true,
      groups = {"PayIn", "Regression", "DRM", "QUE"})
  @Parameters({"trancheIdentifier", "payInAmount", "customerEmail"})
  public void C10385_C4509_Invalid_PayIn_QUE_DRM_TG(
      Method methodName, String sTrancheIdentifier, String sPayInAmount, String sCustomerEmail)
      throws InterruptedException {
    if (testDataInjection.equalsIgnoreCase("Yes")) {
      // Test Data Injection for Product Bank
      DBReusables.getInstance().executeSqlScript("productBank-QLIRO.sql");
      DBReusables.getInstance().executeSqlScript("Tranche-QLIRO-TG.sql");
      // Getting Product Details
      TrancheIdentifier = DBReusables.getInstance().getTrancheIdentifier("TG");
      PayInAmount = DBReusables.getInstance().getRamdomPayInAmount(TrancheIdentifier);
    } else {
      CustomerEmail = sCustomerEmail;
      TrancheIdentifier = sTrancheIdentifier;
      PayInAmount = sPayInAmount;
    }
    String testName = methodName.getName();
    TestLogger.logMsg("==========" + testName + " Started==========");
    actualMap =
        PaymentServices.getInstance().invalidPayIn(CustomerEmail, TrancheIdentifier, PayInAmount);
    actualErrorList.addAll(actualMap.keySet());
    expectedMap.clear();
    expectedMap.put(
        "QUE",
        "<b>Following  questions are not answered.</b><ul><li>MARITAL_STATUS</li></ul><ul><li>TYPE_EMPLOYMENT</li></ul>");
    expectedMap.put("DRM", "DRM contract is Invalid");
    expectedErrorList.add("QUE");
    expectedErrorList.add("DRM");
    Assert.assertTrue(
        actualErrorList.equals(expectedErrorList), "Gunda error reason/s is not correct");
    Assert.assertTrue(actualMap.equals(expectedMap), "Gunda error message/s is not correct");
    // check for Bookings message
    Assert.assertEquals(
        DRIVER.findElement(MeineAnlagenPO.getInstance().drm_warningmsg).getText(),
        "Damit ihre Anlage am nächstmöglichen Anlagestarttermin ausgeführt werden kann, ist Ihre Zustimmung zum Kundenrahmenvertrag erforderlich. Bitte klicken Sie hierfür auf „Vertrag einsehen“.");
    TestLogger.logInfo("DRM Warning message validated successfully");

    TestLogger.logInfo("Step-7: Click on Vertrag einsehen button");
    // Button Validation color of button Bug-ZA-583.Button functionality is still under discussion
    DRIVER.findElement(MeineAnlagenPO.getInstance().VertragEinsehen).click();

    TestLogger.logInfo("Step-8: Select QUE and DRM");
    // select QUE from Shop
    ProductDetailsPO.getInstance().selectingQuestionary_QLIRO();
    // accept DRM from Shop
    DRIVER.findElement(ProductDetailsPO.getInstance().drm_agreement).click();
    // check for ennable of DRM button
    Assert.assertEquals(
        DRIVER.findElement(ProductDetailsPO.getInstance().drm_accept).getAttribute("class"),
        "btn btn-info",
        "DRM button is not enabled");
    // accept DRM Contract
    DRIVER.findElement(ProductDetailsPO.getInstance().drm_accept).click();
    // check for DRM success message
    Assert.assertEquals(
        DRIVER.findElement(MeineAnlagenPO.getInstance().SuccessMessage).getText(),
        "Ihre Zustimmung zum Kundenrahmenvertrag wurde hinterlegt. Der Kundenrahmenvertrag der "
            + DBReusables.getInstance().getBankName_FromTrancheIdentifier(TrancheIdentifier)
            + " wurde Ihnen in “Archiv & Dokumente” bereitgestellt.",
        "DRM button is not enabled");
    TestLogger.logInfo("DRM Contract accepted successfully");
    // Check in Archive and Documents
    ArchiveAndDocumentsPO.getInstance()
        .validatePersonalDocument(
            DBReusables.getInstance().formatDate("dd.MM.yyyy")
                + " Kundenrahmenvertrag - "
                + DBReusables.getInstance().getBankName_FromTrancheIdentifier(TrancheIdentifier)
                + "\n"
                + "Zum Vertragsabschluss wird Ihre Einzahlung benötigt"
                + " Download Kundenrahmenvertrag",
            "present");
    // check for DRM Status
    Assert.assertEquals(
        DBReusables.getInstance().checkDRM(), "INITIATED", "DRM state is not INITIATED");
    TestLogger.logInfo("validated DRM Status is INITIATED");

    TestLogger.logInfo("Step-9: Run Gunda Validation endpoint");
    Gunda.getInstance().Gunda_validate();

    String table = DBReusables.getInstance().ct2iTable;
    String CustomerNumber = DBReusables.getInstance().getCustomerNumber(CustomerEmail);
    String FormatedPayInAmount =
        (DBReusables.getInstance()
            .formatCurrency(PayInAmount)
            .substring(0, DBReusables.getInstance().formatCurrency(PayInAmount).indexOf(" ")));

    // PayIn Ticket
    String CustomerTicket_id = DBReusables.getInstance().getCustomerTicket_id(table, CustomerEmail);
    // DB Validation
    TestLogger.logMsg("Step-10: Validate Customer Ticket");
    Assert.assertEquals(
        DBReusables.getInstance().getTicketState(CustomerTicket_id, table),
        "VALID",
        "Customer ticket state is INVALID with reason");
    TestLogger.logInfo(
        "Customer Ticket is Invalid with Reason: "
            + DBReusables.getInstance().getTicketStateMessage(CustomerTicket_id, table));

    // Gunda validation
    TestLogger.logMsg("Step-11: Validate Inprogress ticket in Gunda");
    int num =
        GundaServices.getInstance()
            .getInprogressTicket_Array(
                CustomerNumber, DBReusables.getInstance().getTicket_uuid(CustomerTicket_id, table));
    Assert.assertEquals(
        (WebServiceOperations.getInstance()
            .convertStringToJson(Gunda.getInstance().Gunda_GetCustomer(CustomerNumber))
            .getString("notExecutedTickets[" + num + "].ticketState")),
        "VALID",
        "Gunda ticketState is not correct");
    WebServiceOperations.getInstance()
        .convertStringToJson(Gunda.getInstance().Gunda_GetCustomer(CustomerNumber))
        .getString("notExecutedTickets[" + num + "].validationErrors");

    // Email validation.Email link functionality is still under discussion
    TestLogger.logMsg("Step-12: Validate Email in MailHog");
    MailHogPO.getInstance().openMailhog();
    MailHogPO.getInstance()
        .verifyEmail(
            CustomerEmail, "Einzahlungsbestätigung Ihres Anlagebetrags auf Ihrem ZINSPILOT-Konto");
    // Need to add the email content
    MailHogPO.getInstance().closeMailhog();
    WebUIOperations.getInstance().switchTab(0);

    // Shop validation
    TestLogger.logMsg("Step-13: Validate Inprogress ticket in Shop");
    MeineAnlagenPO.getInstance().getInvestmentDetails(TrancheIdentifier, CustomerEmail);
    MeineAnlagenPO.getInstance()
        .validateShopBookings(
            2,
            DateTimeFormatter.ofPattern("dd.MM.yyyy")
                    .format(
                        LocalDate.parse(
                            (CharSequence)
                                DBReusables.getInstance().getTrancheStartDate(TrancheIdentifier)))
                + " vorgemerkt Einzahlung * "
                + FormatedPayInAmount);
    MeineAnlagenPO.getInstance()
        .validateShopHint(
            "Ihr Anlagebetrag wird von Ihrer ZINSPILOT-Partnerbank zum Anlagestart automatisch bei der "
                + DBReusables.getInstance().getBankName_FromTrancheIdentifier(TrancheIdentifier)
                + " angelegt.");
    TestLogger.logMsg("==========" + testName + " Completed==========");
  }

  /*
   * Feature: Invalid UEB
   * Product Type:Call-a-Like
   * Product Bank Model:FAM
   * TestRail Link:https://depositsolutions.testrail.io/index.php?/cases/view/2974
   * Author: deepthi.gorre
   */
  @Test(
      enabled = true,
      groups = {"PayIn", "Regression"})
  @Parameters({"trancheIdentifier", "payInAmount", "customerEmail"})
  public void C2974_Invalid_PayIn_UEB(
      Method methodName, String sTrancheIdentifier, String sPayInAmount, String sCustomerEmail)
      throws InterruptedException {
    if (testDataInjection.equalsIgnoreCase("Yes")) {
      // Test Data Injection for Product Bank
      DBReusables.getInstance().executeSqlScript("productBank_CreditPlus.sql");
      DBReusables.getInstance().executeSqlScript("Tranche-CreditPlus-TG.sql");
      // Getting Product Details
      TrancheIdentifier = DBReusables.getInstance().getTrancheIdentifier("TG");
      PayInAmount = "1234567";
    } else {
      CustomerEmail = sCustomerEmail;
      TrancheIdentifier = sTrancheIdentifier;
      PayInAmount = sPayInAmount;
    }
    String testName = methodName.getName();
    TestLogger.logMsg("==========" + testName + " Started==========");
    actualMap =
        PaymentServices.getInstance().invalidPayIn(CustomerEmail, TrancheIdentifier, PayInAmount);
    actualErrorList.addAll(actualMap.keySet());
    expectedMap.clear();
    expectedMap.put(
        "UEB",
        "Der zusätzliche Betrag von [EUR 1234567.00] würde den Maximalanlagebetrag von [EUR 1000000.00] um [EUR 234567.00] überschreiten. Die Service Bank Affiliations [[0c5b791d-b4f7-4032-b37a-88af994f35bf]] haben einen aktuellen Anlagebetrag von [EUR 0.00].");
    expectedErrorList.add("UEB");
    Assert.assertTrue(
        actualErrorList.equals(expectedErrorList), "Gunda error reason/s is not correct");
    Assert.assertTrue(actualMap.equals(expectedMap), "Gunda error message/s is not correct");
    // Need to add the email content
    MailHogPO.getInstance().closeMailhog();
    TestLogger.logMsg("==========" + testName + " Completed==========");
  }

  /*
   * Feature: Invalid UNT
   * Product Type:Call-a-Like
   * Product Bank Model:FAM
   * TestRail Link:https://depositsolutions.testrail.io/index.php?/cases/view/2973
   * Author: deepthi.gorre
   */
  @Test(
      enabled = true,
      groups = {"PayIn", "Regression"})
  @Parameters({"trancheIdentifier", "payInAmount", "customerEmail"})
  public void C2973_Invalid_PayIn_UNT(
      Method methodName, String sTrancheIdentifier, String sPayInAmount, String sCustomerEmail)
      throws InterruptedException {
    if (testDataInjection.equalsIgnoreCase("Yes")) {
      // Test Data Injection for Product Bank
      DBReusables.getInstance().executeSqlScript("productBank_CreditPlus.sql");
      DBReusables.getInstance().executeSqlScript("Tranche-CreditPlus-TG.sql");
      // Getting Product Details
      TrancheIdentifier = DBReusables.getInstance().getTrancheIdentifier("TG");
      PayInAmount = "0.1";
    } else {
      CustomerEmail = sCustomerEmail;
      TrancheIdentifier = sTrancheIdentifier;
      PayInAmount = sPayInAmount;
    }
    String testName = methodName.getName();
    TestLogger.logMsg("==========" + testName + " Started==========");
    actualMap =
        PaymentServices.getInstance().invalidPayIn(CustomerEmail, TrancheIdentifier, PayInAmount);
    actualErrorList.addAll(actualMap.keySet());
    expectedMap.clear();
    expectedMap.put(
        "UNT",
        "Der Betrag von [EUR 0.10] plus dem bereits bestehenden Anlagebetrag und plus weiterer Einzahlungen von derzeit [EUR 0.00] würden den Minimalanlagebetrag des Produkts [CPLUDES1XXX-TG] von [EUR 1.00] um [EUR 0.90] unterschreiten.");
    expectedErrorList.add("UNT");
    Assert.assertTrue(
        actualErrorList.equals(expectedErrorList), "Gunda error reason/s is not correct");
    Assert.assertTrue(actualMap.equals(expectedMap), "Gunda error message/s is not correct");
    // Need to add the email content
    MailHogPO.getInstance().closeMailhog();
    TestLogger.logMsg("==========" + testName + " Completed==========");
  }

  /*
   * Feature: Cancel payin from gunda
   * Product Type:Call-a-Like
   * Product Bank Model:FAM
   * TestRail Link:https://depositsolutions.testrail.io/index.php?/cases/view/1848
   * Author: deepthi.gorre
   */
  @Test(
      enabled = true,
      groups = {"PayIn", "Regression"})
  @Parameters({"trancheIdentifier", "payInAmount", "customerEmail"})
  public void C1848_Gunda_Cancel_PayIn(
      Method methodName, String sTrancheIdentifier, String sPayInAmount, String sCustomerEmail)
      throws InterruptedException {
    if (testDataInjection.equalsIgnoreCase("Yes")) {
      // Test Data Injection for Product Bank
      DBReusables.getInstance().executeSqlScript("productBank_CreditPlus.sql");
      DBReusables.getInstance().executeSqlScript("Tranche-CreditPlus-TG.sql");
      // Getting Product Details
      TrancheIdentifier = DBReusables.getInstance().getTrancheIdentifier("TG");
      PayInAmount = "1000";
    } else {
      CustomerEmail = sCustomerEmail;
      TrancheIdentifier = sTrancheIdentifier;
      PayInAmount = sPayInAmount;
    }
    String testName = methodName.getName();
    TestLogger.logMsg("==========" + testName + " Started==========");
    String table = DBReusables.getInstance().ct2iTable;
    String ticketType = "TRANSIT_TO_INTEREST";
    // Shop Login
    ShopLoginLogoutPO.getInstance().shopLogin(ENV, CustomerEmail);

    // calling SB & PB Iban method
    PaymentServices.getInstance().SBandPB_IBAN("MHSBDEHBXXX", TrancheIdentifier);

    TestLogger.logMsg("Step-1: Get CustomerNumber,MultiPurposeText and CounterPartAccNumber");
    String CustomerNumber = DBReusables.getInstance().getCustomerNumber(CustomerEmail);
    String MULTI_PURPOSE_TEXT =
        DBReusables.getInstance().getPayInCodeFromTrancheIdentifier(TrancheIdentifier);
    String COUNTER_PART_ACCOUNT_NUMBER =
        new IBAN(DBReusables.getInstance().getCustomerServiceBankIban(CustomerNumber))
            .getBankAccountNumber();
    String FormatedPayInAmount =
        (DBReusables.getInstance()
            .formatCurrency(PayInAmount)
            .substring(0, DBReusables.getInstance().formatCurrency(PayInAmount).indexOf(" ")));

    // Payin ticket creation
    TestLogger.logMsg("Step-2: Create Valid Payin Ticket");
    PaymentServices.getInstance()
        .customerPayin(MULTI_PURPOSE_TEXT, COUNTER_PART_ACCOUNT_NUMBER, PayInAmount);

    // PayIn Ticket
    String CustomerTicket_id = DBReusables.getInstance().getCustomerTicket_id(table, CustomerEmail);

    // DB Validation
    TestLogger.logMsg("Step-3: Validate Customer Ticket in DB");
    Assert.assertEquals(
        DBReusables.getInstance().getTicketState(CustomerTicket_id, table),
        "VALID",
        "Customer ticket state is INVALID with reason");

    // Shop validation
    TestLogger.logMsg("Step-4: Validate Inprogress ticket in Shop");
    MeineAnlagenPO.getInstance().getInvestmentDetails(TrancheIdentifier, CustomerEmail);
    MeineAnlagenPO.getInstance()
        .validateShopBookings(
            2,
            DateTimeFormatter.ofPattern("dd.MM.yyyy")
                    .format(
                        LocalDate.parse(
                            (CharSequence)
                                DBReusables.getInstance().getTrancheStartDate(TrancheIdentifier)))
                + " vorgemerkt Einzahlung * "
                + FormatedPayInAmount);

    // Gunda validation
    TestLogger.logMsg("Step-5: Validate Inprogress ticket in Gunda");
    int num =
        GundaServices.getInstance()
            .getInprogressTicket_Array(
                CustomerNumber, DBReusables.getInstance().getTicket_uuid(CustomerTicket_id, table));
    Assert.assertEquals(
        (WebServiceOperations.getInstance()
            .convertStringToJson(Gunda.getInstance().Gunda_GetCustomer(CustomerNumber))
            .getString("notExecutedTickets[" + num + "].productIdentifier")),
        TrancheIdentifier,
        "Gunda TrancheIdentifier is not correct");
    Assert.assertEquals(
        (WebServiceOperations.getInstance()
            .convertStringToJson(Gunda.getInstance().Gunda_GetCustomer(CustomerNumber))
            .getString("notExecutedTickets[" + num + "].ticketType")),
        ticketType,
        "Gunda ticketType is not correct");
    Assert.assertEquals(
        (WebServiceOperations.getInstance()
            .convertStringToJson(Gunda.getInstance().Gunda_GetCustomer(CustomerNumber))
            .getString("notExecutedTickets[" + num + "].ticketState")),
        "VALID",
        "Gunda ticketState is not correct");

    // Gunda Cancel
    TestLogger.logMsg("Step-6: Cancel Payin from Gunda");
    GundaPO.getInstance().gundaCancel(CustomerTicket_id, ticketType, table, CustomerNumber);

    // DB Validation
    TestLogger.logMsg("Step-7: Validate Customer Ticket in DB after cancellation");
    Assert.assertEquals(
        DBReusables.getInstance().getTicketState(CustomerTicket_id, table),
        "CANCELLED",
        "Customer ticket state is not cancelled");

    // Gunda validation
    TestLogger.logMsg("Step-8: Validate Inprogress ticket in Gunda after cancellation");
    Assert.assertEquals(
        (WebServiceOperations.getInstance()
            .convertStringToJson(Gunda.getInstance().Gunda_GetCustomer(CustomerNumber))
            .getString("notExecutedTickets[" + num + "].productIdentifier")),
        TrancheIdentifier,
        "Gunda TrancheIdentifier is not correct");
    Assert.assertEquals(
        (WebServiceOperations.getInstance()
            .convertStringToJson(Gunda.getInstance().Gunda_GetCustomer(CustomerNumber))
            .getString("notExecutedTickets[" + num + "].ticketType")),
        "TRANSIT_TO_CUSTOMER",
        "Gunda ticketType is not correct");
    Assert.assertEquals(
        (WebServiceOperations.getInstance()
            .convertStringToJson(Gunda.getInstance().Gunda_GetCustomer(CustomerNumber))
            .getString("notExecutedTickets[" + num + "].ticketState")),
        "CREATED",
        "Gunda ticketState is not correct");

    // Shop validation
    TestLogger.logMsg("Step-9: Validate Inprogress ticket in Shop after cancellation");
    MeineAnlagenPO.getInstance().validateTranche(TrancheIdentifier, "absent");

    TestLogger.logMsg("==========" + testName + " Completed==========");
  }

  @AfterMethod(alwaysRun = true)
  public void teardown(ITestResult result) {
    if (ITestResult.FAILURE == result.getStatus()) {
      takeScreenshot(result.getName());
    }
    TestLogger.logInfo("Executing Browser tearDown method");
    ShopLoginLogoutPO.getInstance().closeAllBrowsers();
  }

  @AfterTest(alwaysRun = true)
  public void cleanup() throws SQLException {
    DBReusables.getInstance().closeDBCon();
  }
}
