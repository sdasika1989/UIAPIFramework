package com.depositsolutions.zinspilot.e2e.payin;

import static com.depositsolutions.common.reusables.TestConstants.SHOP_URL_CONFIG_KEY;

import com.depositsolutions.common.restapi.helpers.WebServiceOperations;
import com.depositsolutions.common.restapi.services.Gunda;
import com.depositsolutions.common.reusables.DBReusables;
import com.depositsolutions.common.reusables.GundaServices;
import com.depositsolutions.common.reusables.PaymentServices;
import com.depositsolutions.common.ui.helpers.BaseTestClassUI;
import com.depositsolutions.common.ui.helpers.WebUIOperations;
import com.depositsolutions.common.ui.zpuipageobjects.*;
import com.depositsolutions.common.utils.ConfigManager;
import com.depositsolutions.common.utils.TestLogger;
import de.depositsolutions.common.IBAN;
import java.lang.reflect.Method;
import java.sql.SQLException;
import java.text.ParseException;
import java.util.List;
import org.openqa.selenium.WebElement;
import org.testng.Assert;
import org.testng.ITestResult;
import org.testng.annotations.*;

public class PayInE2E extends BaseTestClassUI {

  private String testDataInjection = ConfigManager.getInstance().getString("testDataInjection");
  String CustomerEmail, TrancheIdentifier, PayInAmount;
  String ServiceBank_BIC = "MHSBDEHBXXX";

  @BeforeTest(alwaysRun = true)
  public void setupDB() {
    DBReusables.getInstance().dbConnect();
  }

  @BeforeMethod(alwaysRun = true)
  public void preLoadSQLTestData() {
    if (testDataInjection.equalsIgnoreCase("Yes")) {
      // Truncate All Tables
      DBReusables.getInstance().executeSqlScript("TruncateAllTables.sql");
      // Test Data Injection for Customer and Service Bank
      DBReusables.getInstance().executeSqlScript("serviceBank-sutor.sql");
      DBReusables.getInstance().executeSqlScript("customer.sql");
      // Getting customer details
      CustomerEmail = DBReusables.getInstance().getCustomerEmail();
    } else {
      // Truncate sps Tables
      DBReusables.getInstance().executeSqlScript("TruncateSPSTables.sql");
    }
    setUpForTest(ConfigManager.getInstance().getString(SHOP_URL_CONFIG_KEY));
  }

  /*
   * Feature: PayIn
   * Product Type:Call
   * Product Bank Model:FIDUCIARY_ACCOUNT_MODEL(FAM)
   * TestRail Link: https://depositsolutions.testrail.io/index.php?/cases/view/6106
   * Author: deepthi.gorre
   */
  @Test(
      enabled = true,
      groups = {"PayIn", "Regression"})
  @Parameters({"trancheIdentifier", "payInAmount", "customerEmail"})
  public void C6106_PayIn_FAM_Call(
      Method methodName, String sTrancheIdentifier, String sPayInAmount, String sCustomerEmail)
      throws SQLException, ClassNotFoundException, InterruptedException {

    if (testDataInjection.equalsIgnoreCase("Yes")) {
      // Test Data Injection for Product Bank
      DBReusables.getInstance().executeSqlScript("productBank-BUCUROBUwithTG.sql");
      // Getting Product Details
      TrancheIdentifier = DBReusables.getInstance().getTrancheIdentifier("TG");
      PayInAmount = DBReusables.getInstance().getRamdomPayInAmount(TrancheIdentifier);
    } else {
      CustomerEmail = sCustomerEmail;
      TrancheIdentifier = sTrancheIdentifier;
      PayInAmount = sPayInAmount;
    }
    String testName = methodName.getName();
    TestLogger.logMsg("==========" + testName + " Started==========");

    // Shop Login
    ShopLoginLogoutPO.getInstance().shopLogin(ENV, CustomerEmail);

    // Calling PayIn method
    PaymentServices.getInstance().payIn(TrancheIdentifier, CustomerEmail, PayInAmount);

    TestLogger.logMsg("==========" + testName + " Completed==========");
  }

  /*
   * Feature: PayIn
   * Product Type:Noticed Call
   * Product Bank Model:FIDUCIARY_ACCOUNT_MODEL(FAM)
   * TestRail Link: https://depositsolutions.testrail.io/index.php?/cases/view/6030
   * Author: deepthi.gorre
   */
  @Test(
      priority = 0,
      enabled = true,
      groups = {"PayIn", "Regression"})
  @Parameters({"trancheIdentifier", "payInAmount", "customerEmail"})
  public void C6030_PayIn_FAM_Call_NoticedPeriod(
      Method methodName, String sTrancheIdentifier, String sPayInAmount, String sCustomerEmail)
      throws SQLException, ClassNotFoundException, InterruptedException, ParseException {
    if (testDataInjection.equalsIgnoreCase("Yes")) {
      // Test Data Injection for Product Bank
      DBReusables.getInstance().executeSqlScript("productBank-BUCUROBUwithNATG.sql");
      // Getting Product Details
      TrancheIdentifier = DBReusables.getInstance().getTrancheIdentifier("TG");
      PayInAmount = DBReusables.getInstance().getRamdomPayInAmount(TrancheIdentifier);
    } else {
      CustomerEmail = sCustomerEmail;
      TrancheIdentifier = sTrancheIdentifier;
      PayInAmount = sPayInAmount;
    }
    String testName = methodName.getName();
    TestLogger.logMsg("==========" + testName + " Started==========");

    // Shop Login
    ShopLoginLogoutPO.getInstance().shopLogin(ENV, CustomerEmail);

    // Calling PayIn method
    PaymentServices.getInstance().payIn(TrancheIdentifier, CustomerEmail, PayInAmount);
    TestLogger.logMsg("==========" + testName + " Completed==========");
  }

  /*
   * Feature: PayIn
   * Product Type:Call-a-like
   * Product Bank Model:FIDUCIARY_ACCOUNT_MODEL(FAM)
   * TestRail Link: https://depositsolutions.testrail.io/index.php?/cases/view/6105
   * Author: deepthi.gorre
   */
  @Test(
      enabled = true,
      groups = {"PayIn", "Regression", "e2e"})
  @Parameters({"trancheIdentifier", "payInAmount", "customerEmail"})
  public void C6105_PayIn_FAM_CallaLike(
      Method methodName, String sTrancheIdentifier, String sPayInAmount, String sCustomerEmail)
      throws SQLException, ClassNotFoundException, InterruptedException, ParseException {
    if (testDataInjection.equalsIgnoreCase("Yes")) {
      // Test Data Injection for Product Bank
      DBReusables.getInstance().executeSqlScript("productBank_CreditPlus.sql");
      DBReusables.getInstance().executeSqlScript("Tranche-CreditPlus-TG.sql");
      // Getting Product Details
      TrancheIdentifier = DBReusables.getInstance().getTrancheIdentifier("TG");
      PayInAmount = DBReusables.getInstance().getRamdomPayInAmount(TrancheIdentifier);
    } else {
      CustomerEmail = sCustomerEmail;
      TrancheIdentifier = sTrancheIdentifier;
      PayInAmount = sPayInAmount;
    }
    String testName = methodName.getName();
    TestLogger.logMsg("==========" + testName + " Started==========");

    // Shop Login
    ShopLoginLogoutPO.getInstance().shopLogin(ENV, CustomerEmail);

    // Calling PayIn method
    PaymentServices.getInstance().payIn(TrancheIdentifier, CustomerEmail, PayInAmount);

    TestLogger.logMsg("==========" + testName + " Completed==========");
  }

  /*
   * Feature: PayIn
   * Product Type:Noticed Call-a-like
   * Product Bank Model:FIDUCIARY_ACCOUNT_MODEL(FAM)
   * TestRail Link: https://depositsolutions.testrail.io/index.php?/cases/view/6029
   * Author: deepthi.gorre
   */
  @Test(
      enabled = true,
      groups = {"PayIn", "Regression"})
  @Parameters({"trancheIdentifier", "payInAmount", "customerEmail"})
  public void C6029_PayIn_FAM_Call_A_Like_NoticedPeriod(
      Method methodName, String sTrancheIdentifier, String sPayInAmount, String sCustomerEmail)
      throws SQLException, ClassNotFoundException, InterruptedException, ParseException {
    if (testDataInjection.equalsIgnoreCase("Yes")) {
      // Test Data Injection for Product Bank
      DBReusables.getInstance().executeSqlScript("productBank_CreditPlus.sql");
      DBReusables.getInstance().executeSqlScript("Tranche-CreditPlus-NATG.sql");
      // Getting Product Details
      TrancheIdentifier = DBReusables.getInstance().getTrancheIdentifier("TG");
      PayInAmount = DBReusables.getInstance().getRamdomPayInAmount(TrancheIdentifier);
    } else {
      CustomerEmail = sCustomerEmail;
      TrancheIdentifier = sTrancheIdentifier;
      PayInAmount = sPayInAmount;
    }
    String testName = methodName.getName();
    TestLogger.logMsg("==========" + testName + " Started==========");

    // Shop Login
    ShopLoginLogoutPO.getInstance().shopLogin(ENV, CustomerEmail);

    // Calling PayIn method
    PaymentServices.getInstance().payIn(TrancheIdentifier, CustomerEmail, PayInAmount);

    TestLogger.logMsg("==========" + testName + " Completed==========");
  }

  /*
   * Feature: PayIn
   * Product Type:Fixed Term
   * Product Bank Model:FIDUCIARY_ACCOUNT_MODEL(FAM)
   * TestRail Link: https://depositsolutions.testrail.io/index.php?/cases/view/6107
   * Author: deepthi.gorre
   */
  @Test(
      enabled = true,
      groups = {"PayIn", "Regression"})
  @Parameters({"trancheIdentifier", "payInAmount", "customerEmail"})
  public void C6107_PayIn_FAM_FixedTerm(
      Method methodName, String sTrancheIdentifier, String sPayInAmount, String sCustomerEmail)
      throws SQLException, ClassNotFoundException, InterruptedException {
    if (testDataInjection.equalsIgnoreCase("Yes")) {
      // Test Data Injection for Product Bank
      DBReusables.getInstance().executeSqlScript("productBank_CreditPlus.sql");
      DBReusables.getInstance().executeSqlScript("Tranche-CreditPlus-FG1Y.sql");
      // Getting Product Details
      TrancheIdentifier = DBReusables.getInstance().getTrancheIdentifier("FG");
      PayInAmount = DBReusables.getInstance().getRamdomPayInAmount(TrancheIdentifier);
    } else {
      CustomerEmail = sCustomerEmail;
      TrancheIdentifier = sTrancheIdentifier;
      PayInAmount = sPayInAmount;
    }
    String testName = methodName.getName();
    TestLogger.logMsg("==========" + testName + " Started==========");

    // Shop Login
    ShopLoginLogoutPO.getInstance().shopLogin(ENV, CustomerEmail);

    // Calling PayIn method
    PaymentServices.getInstance().payIn(TrancheIdentifier, CustomerEmail, PayInAmount);

    TestLogger.logMsg("==========" + testName + " Completed==========");
  }

  /*
   * Feature: PayIn
   * Product Type:Call-a-Like
   * Product Bank Model:DIRECT_RELATIONSHIP_MODEL(DRM)
   * TestRail Link:https://depositsolutions.testrail.io/index.php?/cases/view/11872
   * Author: deepthi.gorre
   */
  @Test(
      enabled = true,
      groups = {"PayIn", "DRM", "QUE", "Regression"})
  @Parameters({"trancheIdentifier", "payInAmount", "customerEmail"})
  public void C11872_PayIn_QUE_DRM_Call_A_Like(
      Method methodName, String sTrancheIdentifier, String sPayInAmount, String sCustomerEmail)
      throws SQLException, ClassNotFoundException, InterruptedException {
    if (testDataInjection.equalsIgnoreCase("Yes")) {
      // Test Data Injection for Product Bank
      DBReusables.getInstance().executeSqlScript("productBank-QLIRO.sql");
      DBReusables.getInstance().executeSqlScript("Tranche-QLIRO-TG.sql");
      // Getting Product Details
      TrancheIdentifier = DBReusables.getInstance().getTrancheIdentifier("TG");
      PayInAmount = DBReusables.getInstance().getRamdomPayInAmount(TrancheIdentifier);
    } else {
      CustomerEmail = sCustomerEmail;
      TrancheIdentifier = sTrancheIdentifier;
      PayInAmount = sPayInAmount;
    }
    String testName = methodName.getName();

    TestLogger.logMsg("==========" + testName + " Started==========");

    // Shop Login
    ShopLoginLogoutPO.getInstance().shopLogin(ENV, CustomerEmail);

    // select Product from Shop
    ProductDetailsPO.getInstance().selectingProductFromProductListPage(TrancheIdentifier);
    // select QUE from Shop
    ProductDetailsPO.getInstance().selectingQuestionary_QLIRO();
    // accept DRM from Shop
    ProductDetailsPO.getInstance().selectingDRM_Contract(TrancheIdentifier);

    // Calling PayIn method
    PaymentServices.getInstance().payIn(TrancheIdentifier, CustomerEmail, PayInAmount);
    // check for DRM Status
    Assert.assertEquals(
        DBReusables.getInstance().checkDRM(), "SETTLED", "DRM state is not SETTLED");
    TestLogger.logInfo("validated DRM Status is SETTLED");
    // Check in Archive and Documents
    ArchiveAndDocumentsPO.getInstance()
        .validatePersonalDocument(
            DBReusables.getInstance().formatDate("dd.MM.yyyy")
                + " Kundenrahmenvertrag - "
                + DBReusables.getInstance().getBankName_FromTrancheIdentifier(TrancheIdentifier)
                + "\n"
                + "Download Kundenrahmenvertrag",
            "present");

    // DRM Email validation
    TestLogger.logInfo("Validate DRM Email in MailHog");
    MailHogPO.getInstance().openMailhog();
    MailHogPO.getInstance()
        .verifyEmail(
            CustomerEmail,
            "Ihre Anlagebestätigung von ZINSPILOT bei der "
                + DBReusables.getInstance().getBankName_FromTrancheIdentifier(TrancheIdentifier));
    MailHogPO.getInstance().closeMailhog();
    WebUIOperations.getInstance().switchTab(0);

    TestLogger.logMsg("==========" + testName + " Completed==========");
  }

  /*
   * Feature: PayIn
   * Product Type:Call-a-Like with notice period
   * Product Bank Model:DIRECT_RELATIONSHIP_MODEL(DRM)
   * TestRail Link:https://depositsolutions.testrail.io/index.php?/cases/view/6031
   * Author: deepthi.gorre
   */
  @Test(
      enabled = true,
      groups = {"PayIn", "DRM", "QUE", "Regression"})
  @Parameters({"trancheIdentifier", "payInAmount", "customerEmail"})
  public void C6031_PayIn_QUE_DRM_Call_A_Like_NoticedPeriod(
      Method methodName, String sTrancheIdentifier, String sPayInAmount, String sCustomerEmail)
      throws SQLException, ClassNotFoundException, InterruptedException {
    if (testDataInjection.equalsIgnoreCase("Yes")) {
      // Test Data Injection for Product Bank
      DBReusables.getInstance().executeSqlScript("productBank-QLIRO.sql");
      DBReusables.getInstance().executeSqlScript("Tranche-QLIRO-NATG.sql");
      // Getting Product Details
      TrancheIdentifier = DBReusables.getInstance().getTrancheIdentifier("TG");
      PayInAmount = DBReusables.getInstance().getRamdomPayInAmount(TrancheIdentifier);
    } else {
      CustomerEmail = sCustomerEmail;
      TrancheIdentifier = sTrancheIdentifier;
      PayInAmount = sPayInAmount;
    }
    String testName = methodName.getName();

    TestLogger.logMsg("==========" + testName + " Started==========");

    // Shop Login
    ShopLoginLogoutPO.getInstance().shopLogin(ENV, CustomerEmail);

    // select Product from Shop
    ProductDetailsPO.getInstance().selectingProductFromProductListPage(TrancheIdentifier);
    // select QUE from Shop
    ProductDetailsPO.getInstance().selectingQuestionary_QLIRO();
    // accept DRM from Shop
    ProductDetailsPO.getInstance().selectingDRM_Contract(TrancheIdentifier);

    // Calling PayIn method
    PaymentServices.getInstance().payIn(TrancheIdentifier, CustomerEmail, PayInAmount);
    // check for DRM Status
    Assert.assertEquals(
        DBReusables.getInstance().checkDRM(), "SETTLED", "DRM state is not SETTLED");
    TestLogger.logInfo("validated DRM Status is SETTLED");
    // Check in Archive and Documents
    ArchiveAndDocumentsPO.getInstance()
        .validatePersonalDocument(
            DBReusables.getInstance().formatDate("dd.MM.yyyy")
                + " Kundenrahmenvertrag - "
                + DBReusables.getInstance().getBankName_FromTrancheIdentifier(TrancheIdentifier)
                + "\n"
                + "Download Kundenrahmenvertrag",
            "present");

    // DRM Email validation
    TestLogger.logInfo("Validate DRM Email in MailHog");
    MailHogPO.getInstance().openMailhog();
    MailHogPO.getInstance()
        .verifyEmail(
            CustomerEmail,
            "Ihre Anlagebestätigung von ZINSPILOT bei der "
                + DBReusables.getInstance().getBankName_FromTrancheIdentifier(TrancheIdentifier));
    MailHogPO.getInstance().closeMailhog();
    WebUIOperations.getInstance().switchTab(0);

    TestLogger.logMsg("==========" + testName + " Completed==========");
  }

  /*
  * Feature: PayIn
  * Product Type:Fixed Term
  * Product Bank Model:DIRECT_RELATIONSHIP_MODEL(DRM)
  * TestRail Links:
                 https://depositsolutions.testrail.io/index.php?/cases/view/11874
                 https://depositsolutions.testrail.io/index.php?/cases/view/7024
                 https://depositsolutions.testrail.io/index.php?/cases/view/7026
                 https://depositsolutions.testrail.io/index.php?/cases/view/1697
                 https://depositsolutions.testrail.io/index.php?/cases/view/1718
                 https://depositsolutions.testrail.io/index.php?/cases/view/1708
  * Author: deepthi.gorre
  */
  @Test(
      enabled = true,
      groups = {"PayIn", "DRM", "SOF", "QUE", "Regression", "e2e"})
  @Parameters({"trancheIdentifier", "payInAmount", "customerEmail"})
  public void C1708_C1718_C1697_C7026_C11874_C7024_PayIn_DRM_FixedTerm(
      Method methodName, String sTrancheIdentifier, String sPayInAmount, String sCustomerEmail)
      throws SQLException, ClassNotFoundException, InterruptedException {
    if (testDataInjection.equalsIgnoreCase("Yes")) {
      // Test Data Injection for Product Bank
      DBReusables.getInstance().executeSqlScript("productBank-CKV.sql");
      DBReusables.getInstance().executeSqlScript("Tranche-CKV-FG1Y.sql");
      // Getting Product Details
      TrancheIdentifier = DBReusables.getInstance().getTrancheIdentifier("FG");
      PayInAmount = DBReusables.getInstance().getRamdomPayInAmount(TrancheIdentifier);
    } else {
      CustomerEmail = sCustomerEmail;
      TrancheIdentifier = sTrancheIdentifier;
      PayInAmount = sPayInAmount;
    }
    String testName = methodName.getName();

    TestLogger.logMsg("==========" + testName + " Started==========");

    // Shop Login
    ShopLoginLogoutPO.getInstance().shopLogin(ENV, CustomerEmail);

    // select Product from Shop
    ProductDetailsPO.getInstance().selectingProductFromProductListPage(TrancheIdentifier);
    // select SOF from Shop
    ProductDetailsPO.getInstance().selectingSourceOfFunds1("REGULAR_INCOME");
    // select QUE from Shop
    ProductDetailsPO.getInstance().selectingQuestionary_CKV();
    // check for SOF in DB
    Assert.assertEquals(
        DBReusables.getInstance().checkSOF(CustomerEmail),
        "REGULAR_INCOME",
        "SOF data saved to DB in sbtr trustor table");
    TestLogger.logInfo("validated selected SOF in DB ");
    // accept DRM from Shop
    ProductDetailsPO.getInstance().selectingDRM_Contract(TrancheIdentifier);

    // Calling PayIn method
    PaymentServices.getInstance().payIn(TrancheIdentifier, CustomerEmail, PayInAmount);
    String CustomerNumber = DBReusables.getInstance().getCustomerNumber(CustomerEmail);
    String CIA =
        DBReusables.getInstance().getCIA(CustomerNumber, TrancheIdentifier, ServiceBank_BIC);
    // check for SOF Status of CIA in DB
    DBReusables.getInstance().getCIA_sof(CIA);
    TestLogger.logInfo("CIA is updated with selected SOF value in DB");
    // check for SOF Status of CIA in DB
    Assert.assertEquals(
        (WebServiceOperations.getInstance()
            .convertStringToJson(Gunda.getInstance().Gunda_GetCustomer(CustomerNumber))
            .getString(
                "affiliations[0].customerInterestAccountsDetails["
                    + GundaServices.getInstance().getCIA_Array(CustomerNumber, CIA)
                    + "].sourceOfFunds")),
        "REGULAR_INCOME",
        "Gunda TrancheIdentifier is not correct");
    TestLogger.logInfo("CIA is updated with selected SOF value in Gunda");
    // check for DRM Status
    Assert.assertEquals(
        DBReusables.getInstance().checkDRM(), "SETTLED", "DRM state is not SETTLED");
    TestLogger.logInfo("validated DRM Status is SETTLED");
    // Check in Archive and Documents
    ArchiveAndDocumentsPO.getInstance()
        .validatePersonalDocument(
            DBReusables.getInstance().formatDate("dd.MM.yyyy")
                + " Kundenrahmenvertrag - "
                + DBReusables.getInstance().getBankName_FromTrancheIdentifier(TrancheIdentifier)
                + "\n"
                + "Download Kundenrahmenvertrag",
            "present");

    // DRM Email validation
    TestLogger.logInfo("Validate DRM Email in MailHog");
    MailHogPO.getInstance().openMailhog();
    MailHogPO.getInstance()
        .verifyEmail(
            CustomerEmail,
            "Ihre Anlagebestätigung von ZINSPILOT bei der "
                + DBReusables.getInstance().getBankName_FromTrancheIdentifier(TrancheIdentifier));
    MailHogPO.getInstance().closeMailhog();
    WebUIOperations.getInstance().switchTab(0);

    TestLogger.logMsg("==========" + testName + " Completed==========");
  }

  /*
   * Feature: Perform Invalid Payin for POA and apply POA
   * Product Type:Call-a-Like
   * Product Bank Model:CKV
   * TestRail Link:https://depositsolutions.testrail.io/index.php?/cases/view/4480
   * Author: shalini.sudam
   */
  @Test(
      enabled = true,
      groups = {"PayIn", "Regression"})
  @Parameters({"trancheIdentifier", "payInAmount", "customerEmail"})
  public void C4480_ChangeofPOA_Gunda(
      Method methodName, String sTrancheIdentifier, String sPayInAmount, String sCustomerEmail)
      throws InterruptedException {
    if (testDataInjection.equalsIgnoreCase("Yes")) {

      DBReusables.getInstance().executeSqlScript("productBank-CKV-POA.sql");
      DBReusables.getInstance().executeSqlScript("Tranche-CKV-FG1Y.sql");
      // Getting Product Details
      TrancheIdentifier = DBReusables.getInstance().getTrancheIdentifier("FG");
      PayInAmount = "1000";
    } else {
      CustomerEmail = sCustomerEmail;
      TrancheIdentifier = sTrancheIdentifier;
      PayInAmount = sPayInAmount;
    }
    String testName = methodName.getName();
    TestLogger.logMsg("==========" + testName + " Started==========");

    String table = DBReusables.getInstance().ct2iTable;
    // Shop Login
    ShopLoginLogoutPO.getInstance().shopLogin(ENV, CustomerEmail);

    // calling SB & PB Iban method
    PaymentServices.getInstance()
        .SBandPB_IBAN(PaymentServices.getInstance().ServiceBank_BIC, TrancheIdentifier);

    TestLogger.logMsg("Step-1: Get CustomerNumber,MultiPurposeText and CounterPartAccNumber");
    String CustomerNumber = DBReusables.getInstance().getCustomerNumber(CustomerEmail);
    String MULTI_PURPOSE_TEXT =
        DBReusables.getInstance().getPayInCodeFromTrancheIdentifier(TrancheIdentifier);
    String COUNTER_PART_ACCOUNT_NUMBER =
        new IBAN(DBReusables.getInstance().getCustomerServiceBankIban(CustomerNumber))
            .getBankAccountNumber();

    // Payin ticket creation
    TestLogger.logMsg("Step-2: Create Invalid Payin Ticket");
    PaymentServices.getInstance()
        .customerPayin(MULTI_PURPOSE_TEXT, COUNTER_PART_ACCOUNT_NUMBER, PayInAmount);

    TestLogger.logMsg("Step-3: Navigate to Gunda Login and click on Bad Tickets Link");
    GundaPO.getInstance().gundaLogin();
    WebUIOperations.getInstance()
        .waitForElementAndClick(getWebElement(GundaPO.getInstance().fehlerhafteTicketsButton));

    TestLogger.logMsg(
        "Step-4: Verify if Bad Tickets section is shown and click on ShowCustomer Button");
    WebUIOperations.getInstance()
        .waitForElementAndClick(getWebElement(GundaPO.getInstance().showCustomer));
    WebUIOperations.getInstance().switchTab(2);
    getWebElement(GundaPO.getInstance().searchString).click();

    TestLogger.logMsg(
        "Step-5: Validate if POA is present in the status of the ticket before applying POA");
    String ticketStatusBeforePOAValidation =
        getWebElement(GundaPO.getInstance().statusCheck).getText().toString();
    Assert.assertTrue(ticketStatusBeforePOAValidation.contains("POA"));

    TestLogger.logMsg(
        "Step-6: Click on ID Card copy  select the IDCARD and enter the details , click save");
    WebUIOperations.getInstance()
        .verifyElementIsPresent(getWebElement(GundaPO.getInstance().idcardCopy), "IDCard");
    WebUIOperations.getInstance()
        .waitForElementAndClick(getWebElement(GundaPO.getInstance().idcardCopy));
    WebUIOperations.getInstance()
        .selectDropdownByValue(getWebElement(GundaPO.getInstance().selectIDType), "ID_CARD");
    WebUIOperations.getInstance()
        .sendKeys(getWebElement(GundaPO.getInstance().idCardExpiryDate), "01.01.2030");
    WebUIOperations.getInstance()
        .sendKeys(getWebElement(GundaPO.getInstance().issuingCountry), "DE");
    WebUIOperations.getInstance()
        .waitForElementAndClick(getWebElement(GundaPO.getInstance().Gunda_submit3));

    TestLogger.logMsg(
        "Step-7: Click on ID Card Authority  select the IDCARD and enter the details , click save");
    WebUIOperations.getInstance()
        .verifyElementIsPresent(getWebElement(GundaPO.getInstance().idcardAuthority), "IDCard");
    WebUIOperations.getInstance()
        .waitForElementAndClick(getWebElement(GundaPO.getInstance().idcardAuthority));
    WebUIOperations.getInstance()
        .selectDropdownByValue(getWebElement(GundaPO.getInstance().selectIDType), "ID_CARD");
    WebUIOperations.getInstance()
        .sendKeys(getWebElement(GundaPO.getInstance().idCardNumber), "12341234");
    WebUIOperations.getInstance()
        .sendKeys(getWebElement(GundaPO.getInstance().idCardIssueDate), "01.01.2021");
    WebUIOperations.getInstance()
        .sendKeys(getWebElement(GundaPO.getInstance().idCardExpiryDate), "01.01.2030");
    WebUIOperations.getInstance()
        .sendKeys(getWebElement(GundaPO.getInstance().issuingAuthority), "Hamburg");
    WebUIOperations.getInstance()
        .waitForElementAndClick(getWebElement(GundaPO.getInstance().Gunda_submit3));

    TestLogger.logMsg("Step-8: Click on Validate Ticket and check the status of the ticket");
    WebUIOperations.getInstance()
        .waitForElementAndClick(getWebElement(GundaPO.getInstance().validateTicket));

    TestLogger.logMsg("Step-9: Verify that ticket status should not contain POA");
    String ticketStatusAfterPOAValidation =
        getWebElement(GundaPO.getInstance().statusCheck).getText().toString();
    Assert.assertTrue(
        !ticketStatusBeforePOAValidation.equals(ticketStatusAfterPOAValidation),
        "Ticket Status before applying POA is not same as after applying POA - Before: "
            + ticketStatusBeforePOAValidation
            + "After: "
            + ticketStatusAfterPOAValidation);
    Assert.assertTrue(!ticketStatusAfterPOAValidation.contains("POA"));

    TestLogger.logMsg("==========" + testName + " Completed==========");
  }

  /*
   * Feature: create Platform Payin ticket and split payin payout
   * Product Type:Call-a-Like
   * Product Bank Model:CKV
   * TestRail Link:https://depositsolutions.testrail.io/index.php?/cases/view/4481
   * Author: shalini.sudam
   */

  @Test(
      enabled = true,
      groups = {"PayIn", "Regression"})
  @Parameters({"trancheIdentifier", "payInAmount", "customerEmail"})
  public void C4481_SplitPayInPayOut_Gunda(
      Method methodName, String sTrancheIdentifier, String sPayInAmount, String sCustomerEmail)
      throws InterruptedException {
    if (testDataInjection.equalsIgnoreCase("Yes")) {
      // Test Data Injection for Product Bank

      DBReusables.getInstance().executeSqlScript("productBank-CKV-POA.sql");
      DBReusables.getInstance().executeSqlScript("Tranche-CKV-FG1Y.sql");
      // Getting Product Details
      TrancheIdentifier = DBReusables.getInstance().getTrancheIdentifier("FG");
      PayInAmount = "1000";
    } else {
      CustomerEmail = sCustomerEmail;
      TrancheIdentifier = sTrancheIdentifier;
      PayInAmount = sPayInAmount;
    }
    String testName = methodName.getName();
    TestLogger.logMsg("==========" + testName + " Started==========");

    String table = DBReusables.getInstance().ct2iTable;
    // Shop Login
    ShopLoginLogoutPO.getInstance().shopLogin(ENV, CustomerEmail);

    // calling SB & PB Iban method
    PaymentServices.getInstance()
        .SBandPB_IBAN(PaymentServices.getInstance().ServiceBank_BIC, TrancheIdentifier);

    TestLogger.logMsg("Step-1: Get CustomerNumber,MultiPurposeText and CounterPartAccNumber");
    String CustomerNumber = DBReusables.getInstance().getCustomerNumber(CustomerEmail);
    String MULTI_PURPOSE_TEXT =
        DBReusables.getInstance().getPayInCodeFromTrancheIdentifier(TrancheIdentifier);
    String COUNTER_PART_ACCOUNT_NUMBER =
        new IBAN(DBReusables.getInstance().getCustomerServiceBankIban(CustomerNumber))
            .getBankAccountNumber();

    // Payin ticket creation
    TestLogger.logMsg("Step-2: Create Invalid Payin Ticket");
    PaymentServices.getInstance().customerPayin("", COUNTER_PART_ACCOUNT_NUMBER, PayInAmount);
    TestLogger.logMsg("Step-3: Navigate to Gunda Login and click on Bad Tickets Link");
    GundaPO.getInstance().gundaLogin();
    WebUIOperations.getInstance()
        .waitForElementAndClick(getWebElement(GundaPO.getInstance().fehlerhafteTicketsButton));

    TestLogger.logMsg(
        "Step-4: Verify if Bad Tickets section is shown and click on ShowCustomer Button");
    WebUIOperations.getInstance()
        .waitForElementAndClick(getWebElement(GundaPO.getInstance().showCustomer));
    WebUIOperations.getInstance().switchTab(2);
    getWebElement(GundaPO.getInstance().searchString).click();

    TestLogger.logInfo("Step-5: Click on Edit Button and click on addTo Button");
    WebUIOperations.getInstance()
        .waitForElementAndClick(getWebElement(GundaPO.getInstance().toEdit));
    WebUIOperations.getInstance()
        .waitForElementAndClick(getWebElement(GundaPO.getInstance().addTo));

    TestLogger.logInfo("Step-6: Select ProductCode to PayinBank Code and enter amount. ");
    WebUIOperations.getInstance()
        .selectDropdownByValue(getWebElement(GundaPO.getInstance().selectProductCode), "CKVFG12M");
    getWebElement(GundaPO.getInstance().enterAmount).clear();
    WebUIOperations.getInstance()
        .sendKeys(getWebElement(GundaPO.getInstance().enterAmount), "500 EUR");

    TestLogger.logInfo("Step-6: Select ProductCode to Payout Code and enter amount and click save");
    WebUIOperations.getInstance()
        .waitForElementAndClick(getWebElement(GundaPO.getInstance().addTo));
    WebUIOperations.getInstance()
        .selectDropdownByValue(getWebElement(GundaPO.getInstance().selectProductCode1), "PAY_OUT");
    getWebElement(GundaPO.getInstance().enterAmount1).clear();
    WebUIOperations.getInstance()
        .sendKeys(getWebElement(GundaPO.getInstance().enterAmount1), "500 EUR");
    WebUIOperations.getInstance().waitForElementAndClick(getWebElement(GundaPO.getInstance().save));

    TestLogger.logInfo(
        "Step 8: Validate if two rows are created with one Type as Payin and other typ is Payout.");
    List<WebElement> rows = DRIVER.findElements(GundaPO.getInstance().ticketTable);
    int count = rows.size();

    Assert.assertEquals(count, 2, "Expected Rows creation is 2 but found: " + count);

    Assert.assertTrue(
        getWebElement(GundaPO.getInstance().payinCheck).getText().contains("Einzahlung"),
        "Payin Row is not created");
    Assert.assertTrue(
        getWebElement(GundaPO.getInstance().payoutCheck)
            .getText()
            .contains("Auszahlung an den Kunden"),
        "Payin Row is not created");
  }

  @Test(
      enabled = true,
      groups = {"PayIn", "Regression", "POA"})
  @Parameters({"trancheIdentifier", "payInAmount", "customerEmail"})
  public void C2978_PayIn_DAT(
      Method methodName, String sTrancheIdentifier, String sPayInAmount, String sCustomerEmail)
      throws SQLException, ClassNotFoundException, InterruptedException {
    if (testDataInjection.equalsIgnoreCase("Yes")) {

      DBReusables.getInstance().executeSqlScript("productBank-CKV-POA.sql");
      DBReusables.getInstance().executeSqlScript("Tranche-CKV-FG1Y.sql");
      // Getting Product Details
      TrancheIdentifier = DBReusables.getInstance().getTrancheIdentifier("FG");
      PayInAmount = "1000";
    } else {
      CustomerEmail = sCustomerEmail;
      TrancheIdentifier = sTrancheIdentifier;
      PayInAmount = sPayInAmount;
    }
    String testName = methodName.getName();
    TestLogger.logMsg("==========" + testName + " Started==========");

    String table = DBReusables.getInstance().ct2iTable;
    // Shop Login
    ShopLoginLogoutPO.getInstance().shopLogin(ENV, CustomerEmail);

    // calling SB & PB Iban method
    PaymentServices.getInstance()
        .SBandPB_IBAN(PaymentServices.getInstance().ServiceBank_BIC, TrancheIdentifier);

    TestLogger.logMsg("Step-1: Get CustomerNumber,MultiPurposeText and CounterPartAccNumber");
    String CustomerNumber = DBReusables.getInstance().getCustomerNumber(CustomerEmail);
    String MULTI_PURPOSE_TEXT =
        DBReusables.getInstance().getPayInCodeFromTrancheIdentifier(TrancheIdentifier);
    String COUNTER_PART_ACCOUNT_NUMBER =
        new IBAN(DBReusables.getInstance().getCustomerServiceBankIban(CustomerNumber))
            .getBankAccountNumber();

    // Payin ticket creation
    TestLogger.logMsg("Step-2: Create Invalid Payin Ticket");
    PaymentServices.getInstance()
        .customerPayin(MULTI_PURPOSE_TEXT, COUNTER_PART_ACCOUNT_NUMBER, PayInAmount);

    TestLogger.logMsg("Step-3: Navigate to Gunda Login and click on Bad Tickets Link");
    GundaPO.getInstance().gundaLogin();
    WebUIOperations.getInstance()
        .waitForElementAndClick(getWebElement(GundaPO.getInstance().fehlerhafteTicketsButton));

    TestLogger.logMsg(
        "Step-4: Verify if Bad Tickets section is shown and click on ShowCustomer Button");
    WebUIOperations.getInstance()
        .waitForElementAndClick(getWebElement(GundaPO.getInstance().showCustomer));
    WebUIOperations.getInstance().switchTab(2);
    getWebElement(GundaPO.getInstance().searchString).click();

    TestLogger.logMsg(
        "Step-5: Validate if DAT is present in the status of the ticket before applying DAT");
    String ticketStatusBeforeDATValidation =
        getWebElement(GundaPO.getInstance().statusCheck).getText().toString();
    Assert.assertTrue(ticketStatusBeforeDATValidation.contains("DAT"));

    TestLogger.logMsg(
        "Step-6: Enter the idCardTYpe, issuedate and expiry date details in the Database in trustor_service_bank_details table");
    DBReusables.getInstance().insertDataintotrustorServiceBankData("idCardType", "ID_CARD");
    DBReusables.getInstance().insertDataintotrustorServiceBankData("idCardIssueDate", "2021-02-15");
    DBReusables.getInstance()
        .insertDataintotrustorServiceBankData("idCardExpiryDate", "2031-02-15");

    TestLogger.logMsg("Step-7: Click on Validate Ticket and check the status of the ticket");
    WebUIOperations.getInstance()
        .waitForElementAndClick(getWebElement(GundaPO.getInstance().validateTicket));

    TestLogger.logMsg("Step-8: Verify that ticket status should not contain DAT");
    String ticketStatusAfterDATValidation =
        getWebElement(GundaPO.getInstance().statusCheck).getText().toString();
    Assert.assertFalse(
        ticketStatusBeforeDATValidation.equals(ticketStatusAfterDATValidation),
        "Ticket Status before applying DAT is not same as after applying DAT - Before: "
            + ticketStatusBeforeDATValidation
            + "After: "
            + ticketStatusAfterDATValidation);
    Assert.assertFalse(ticketStatusAfterDATValidation.contains("DAT"));

    TestLogger.logMsg(
        "Step-9: Remove idCardAuthority from trustor_service_bank_details and validate if DAT is shown in ticket status");
    DBReusables.getInstance().insertDataintotrustorServiceBankData("idCardAuthority", "");
    WebUIOperations.getInstance()
        .waitForElementAndClick(getWebElement(GundaPO.getInstance().validateTicket));
    ticketStatusAfterDATValidation =
        getWebElement(GundaPO.getInstance().statusCheck).getText().toString();
    Assert.assertTrue(ticketStatusAfterDATValidation.contains("DAT"));
    DBReusables.getInstance()
        .insertDataintotrustorServiceBankData("idCardAuthority", " Klein Melanie, TH");

    TestLogger.logMsg(
        "Step-10: Remove idCardNumber from trustor_service_bank_details and validate if DAT is shown in ticket status");
    DBReusables.getInstance().insertDataintotrustorServiceBankData("idCardNumber", "");
    WebUIOperations.getInstance()
        .waitForElementAndClick(getWebElement(GundaPO.getInstance().validateTicket));
    ticketStatusAfterDATValidation =
        getWebElement(GundaPO.getInstance().statusCheck).getText().toString();
    Assert.assertTrue(ticketStatusAfterDATValidation.contains("DAT"));
    DBReusables.getInstance().insertDataintotrustorServiceBankData("idCardNumber", "VJ4S21ATI");

    TestLogger.logMsg(
        "Step-11: Remove ExpiryDate from trustor_service_bank_details and validate if DAT is shown in ticket status");
    DBReusables.getInstance().insertDataintotrustorServiceBankData("idCardExpiryDate");
    WebUIOperations.getInstance()
        .waitForElementAndClick(getWebElement(GundaPO.getInstance().validateTicket));
    ticketStatusAfterDATValidation =
        getWebElement(GundaPO.getInstance().statusCheck).getText().toString();
    Assert.assertTrue(ticketStatusAfterDATValidation.contains("DAT"));
    DBReusables.getInstance()
        .insertDataintotrustorServiceBankData("idCardExpiryDate", "2031-02-15");

    WebUIOperations.getInstance()
        .waitForElementAndClick(getWebElement(GundaPO.getInstance().validateTicket));

    ticketStatusAfterDATValidation =
        getWebElement(GundaPO.getInstance().statusCheck).getText().toString();
    Assert.assertFalse(ticketStatusAfterDATValidation.contains("DAT"));

    TestLogger.logMsg(
        "Step-12: Set ExpiryDate to past from trustor_service_bank_details and validate if DAT is shown in ticket status");
    DBReusables.getInstance()
        .insertDataintotrustorServiceBankData("idCardExpiryDate", "2021-02-15");
    WebUIOperations.getInstance()
        .waitForElementAndClick(getWebElement(GundaPO.getInstance().validateTicket));
    ticketStatusAfterDATValidation =
        getWebElement(GundaPO.getInstance().statusCheck).getText().toString();
    Assert.assertTrue(ticketStatusAfterDATValidation.contains("DAT"));
    DBReusables.getInstance()
        .insertDataintotrustorServiceBankData("idCardExpiryDate", "2031-02-15");

    WebUIOperations.getInstance()
        .waitForElementAndClick(getWebElement(GundaPO.getInstance().validateTicket));

    ticketStatusAfterDATValidation =
        getWebElement(GundaPO.getInstance().statusCheck).getText().toString();
    Assert.assertFalse(ticketStatusAfterDATValidation.contains("DAT"));

    TestLogger.logMsg("==========" + testName + " Completed==========");
  }

  @Test(
      enabled = true,
      groups = {"PayIn", "Regression", "POA"})
  @Parameters({"trancheIdentifier", "payInAmount", "customerEmail"})
  public void C2977_PayIn_KOP(
      Method methodName, String sTrancheIdentifier, String sPayInAmount, String sCustomerEmail)
      throws SQLException, ClassNotFoundException, InterruptedException {
    if (testDataInjection.equalsIgnoreCase("Yes")) {

      DBReusables.getInstance().executeSqlScript("productBank-CKV-POA.sql");
      DBReusables.getInstance().executeSqlScript("Tranche-CKV-FG1Y.sql");
      // Getting Product Details
      TrancheIdentifier = DBReusables.getInstance().getTrancheIdentifier("FG");
      PayInAmount = "1000";
    } else {
      CustomerEmail = sCustomerEmail;
      TrancheIdentifier = sTrancheIdentifier;
      PayInAmount = sPayInAmount;
    }
    String testName = methodName.getName();
    TestLogger.logMsg("==========" + testName + " Started==========");

    String table = DBReusables.getInstance().ct2iTable;
    // Shop Login
    ShopLoginLogoutPO.getInstance().shopLogin(ENV, CustomerEmail);

    // calling SB & PB Iban method
    PaymentServices.getInstance()
        .SBandPB_IBAN(PaymentServices.getInstance().ServiceBank_BIC, TrancheIdentifier);

    TestLogger.logMsg("Step-1: Get CustomerNumber,MultiPurposeText and CounterPartAccNumber");
    String CustomerNumber = DBReusables.getInstance().getCustomerNumber(CustomerEmail);
    String MULTI_PURPOSE_TEXT =
        DBReusables.getInstance().getPayInCodeFromTrancheIdentifier(TrancheIdentifier);
    String COUNTER_PART_ACCOUNT_NUMBER =
        new IBAN(DBReusables.getInstance().getCustomerServiceBankIban(CustomerNumber))
            .getBankAccountNumber();

    // Payin ticket creation
    TestLogger.logMsg("Step-2: Create Invalid Payin Ticket");
    PaymentServices.getInstance()
        .customerPayin(MULTI_PURPOSE_TEXT, COUNTER_PART_ACCOUNT_NUMBER, PayInAmount);

    TestLogger.logMsg("Step-3: Navigate to Gunda Login and click on Bad Tickets Link");
    GundaPO.getInstance().gundaLogin();
    WebUIOperations.getInstance()
        .waitForElementAndClick(getWebElement(GundaPO.getInstance().fehlerhafteTicketsButton));

    TestLogger.logMsg(
        "Step-4: Verify if Bad Tickets section is shown and click on ShowCustomer Button");
    WebUIOperations.getInstance()
        .waitForElementAndClick(getWebElement(GundaPO.getInstance().showCustomer));
    WebUIOperations.getInstance().switchTab(2);
    getWebElement(GundaPO.getInstance().searchString).click();

    TestLogger.logMsg(
        "Step-5: Validate if KOP is present in the status of the ticket before applying KOP");
    String ticketStatusBeforeKOPValidation =
        getWebElement(GundaPO.getInstance().statusCheck).getText().toString();
    Assert.assertTrue(ticketStatusBeforeKOPValidation.contains("KOP"));

    TestLogger.logMsg(
        "Step-6: Click on ID Card copy  select the IDCARD and enter the details , click save");
    WebUIOperations.getInstance()
        .verifyElementIsPresent(getWebElement(GundaPO.getInstance().idcardCopy), "IDCard");
    WebUIOperations.getInstance()
        .waitForElementAndClick(getWebElement(GundaPO.getInstance().idcardCopy));
    WebUIOperations.getInstance()
        .selectDropdownByValue(getWebElement(GundaPO.getInstance().selectIDType), "ID_CARD");
    WebUIOperations.getInstance()
        .sendKeys(getWebElement(GundaPO.getInstance().idCardExpiryDate), "01.01.2030");
    WebUIOperations.getInstance()
        .sendKeys(getWebElement(GundaPO.getInstance().issuingCountry), "DE");
    WebUIOperations.getInstance()
        .waitForElementAndClick(getWebElement(GundaPO.getInstance().Gunda_submit3));

    TestLogger.logMsg("Step-7: Click on Validate Ticket and check the status of the ticket");
    WebUIOperations.getInstance()
        .waitForElementAndClick(getWebElement(GundaPO.getInstance().validateTicket));

    TestLogger.logMsg("Step-9: Verify that ticket status should not contain KOP");
    String ticketStatusAfterDATValidation =
        getWebElement(GundaPO.getInstance().statusCheck).getText().toString();
    Assert.assertFalse(
        ticketStatusBeforeKOPValidation.equals(ticketStatusAfterDATValidation),
        "Ticket Status before applying KOP is not same as after applying KOP - Before: "
            + ticketStatusBeforeKOPValidation
            + "After: "
            + ticketStatusAfterDATValidation);
    Assert.assertFalse(ticketStatusAfterDATValidation.contains("KOP"));

    TestLogger.logMsg("Step-9: Delete the ID card copy details");
    WebUIOperations.getInstance()
        .waitForElementAndClick(getWebElement(GundaPO.getInstance().extinguishIdCardCopy));

    DRIVER.switchTo().alert().accept();

    TestLogger.logMsg("Step-10: Validate the ticket and status should contain KOP");
    WebUIOperations.getInstance()
        .waitForElementAndClick(getWebElement(GundaPO.getInstance().validateTicket));

    ticketStatusAfterDATValidation =
        getWebElement(GundaPO.getInstance().statusCheck).getText().toString();
    Assert.assertTrue(ticketStatusAfterDATValidation.contains("KOP"));
    TestLogger.logMsg("==========" + testName + " Completed==========");
  }

  @AfterMethod(alwaysRun = true)
  public void teardown(ITestResult result) {
    if (ITestResult.FAILURE == result.getStatus()) {
      takeScreenshot(result.getName());
    }
    TestLogger.logInfo("Executing Browser tearDown method");
    ShopLoginLogoutPO.getInstance().closeAllBrowsers();
  }

  @AfterTest(alwaysRun = true)
  public void cleanup() throws SQLException {
    DBReusables.getInstance().closeDBCon();
  }
}
