package com.depositsolutions.zinspilot.e2e.payin;

import static com.depositsolutions.common.reusables.TestConstants.SHOP_URL_CONFIG_KEY;

import com.depositsolutions.common.reusables.DBReusables;
import com.depositsolutions.common.reusables.PaymentServices;
import com.depositsolutions.common.ui.helpers.BaseTestClassUI;
import com.depositsolutions.common.ui.helpers.WebUIOperations;
import com.depositsolutions.common.ui.zpuipageobjects.*;
import com.depositsolutions.common.utils.ConfigManager;
import com.depositsolutions.common.utils.TestLogger;
import de.depositsolutions.common.IBAN;
import java.lang.reflect.Method;
import java.sql.SQLException;
import org.openqa.selenium.By;
import org.testng.Assert;
import org.testng.annotations.*;

public class PayInButtonNDocuments extends BaseTestClassUI {

  private String testDataInjection = ConfigManager.getInstance().getString("testDataInjection");
  String CustomerEmail, TrancheIdentifier, PayInAmount;

  @BeforeTest(alwaysRun = true)
  public void setupDB() {
    DBReusables.getInstance().dbConnect();
  }

  @BeforeMethod(alwaysRun = true)
  public void preLoadSQLTestData() {
    if (testDataInjection.equalsIgnoreCase("Yes")) {
      // Truncate All Tables
      DBReusables.getInstance().executeSqlScript("TruncateAllTables.sql");
      // Test Data Injection for Customer and Service Bank
      DBReusables.getInstance().executeSqlScript("serviceBank-sutor.sql");

    } else {
      // Truncate sps Tables
      DBReusables.getInstance().executeSqlScript("TruncateSPSTables.sql");
    }
    setUpForTest(ConfigManager.getInstance().getString(SHOP_URL_CONFIG_KEY));
  }

  /*
   * Feature: SOF Autoselect Validation
   * Product Type:Fixed Term
   * Product Bank Model:DIRECT_RELATIONSHIP_MODEL(DRM)
   * TestRail Link:https://depositsolutions.testrail.io/index.php?/cases/view/1699
   * Author: deepthi.gorre
   */
  @Test(
      enabled = true,
      groups = {"PayIn", "SOF", "Regression", "ShopUI"})
  @Parameters({"trancheIdentifier", "payInAmount", "customerEmail"})
  public void C1699_AutoSelect_SOF_DRM_FixedTerm(
      Method methodName, String sTrancheIdentifier, String sPayInAmount, String sCustomerEmail)
      throws InterruptedException {
    if (testDataInjection.equalsIgnoreCase("Yes")) {
      // Test Data Injection for Product Bank
      DBReusables.getInstance().executeSqlScript("productBank-CKV.sql");
      DBReusables.getInstance().executeSqlScript("Tranche-CKV-FG1Y.sql");
      DBReusables.getInstance().executeSqlScript("customer.sql");
      // Getting customer details
      CustomerEmail = DBReusables.getInstance().getCustomerEmail();
      // Getting Product Details
      TrancheIdentifier = DBReusables.getInstance().getTrancheIdentifier("FG");
      PayInAmount = DBReusables.getInstance().getRamdomPayInAmount(TrancheIdentifier);
    } else {
      CustomerEmail = sCustomerEmail;
      TrancheIdentifier = sTrancheIdentifier;
      PayInAmount = sPayInAmount;
    }
    String testName = methodName.getName();

    TestLogger.logMsg("==========" + testName + " Started==========");

    // Shop Login
    ShopLoginLogoutPO.getInstance().shopLogin(ENV, CustomerEmail);

    // select Product from Shop
    ProductDetailsPO.getInstance().selectingProductFromProductListPage(TrancheIdentifier);
    TestLogger.logMsg("Step1: Select SOF for first time");
    // select SOF from Shop
    ProductDetailsPO.getInstance().selectingSourceOfFunds1("REGULAR_INCOME");
    // select QUE from Shop
    ProductDetailsPO.getInstance().selectingQuestionary_CKV();
    // check for SOF in DB
    Assert.assertEquals(
        DBReusables.getInstance().checkSOF(CustomerEmail),
        "REGULAR_INCOME",
        "SOF data saved to DB in sbtr trustor table");
    TestLogger.logInfo("validated selected SOF in DB ");
    // Shop Logout
    ShopLoginLogoutPO.getInstance().shopLogOut();
    // Shop Login
    ShopLoginLogoutPO.getInstance().shopLogin(ENV, CustomerEmail);
    // select Product from Shop
    ProductDetailsPO.getInstance().selectingProductFromProductListPage(TrancheIdentifier);
    TestLogger.logMsg("Step2: Validate SOF Autoselection");
    // Verify for selected SOF
    ProductDetailsPO.getInstance().VerifyPreSelectedSOF("Regelmäßiges Gehalt");
    TestLogger.logMsg("Step3: Select SOF for second time");
    // select new SOF from Shop
    ProductDetailsPO.getInstance().selectingSourceOfFunds2("SALE_OF_ASSETS");
    // select QUE from Shop
    ProductDetailsPO.getInstance().selectingQuestionary_CKV();
    // check for SOF in DB
    Assert.assertEquals(
        DBReusables.getInstance().checkSOF(CustomerEmail),
        "SALE_OF_ASSETS",
        "SOF data saved to DB in sbtr trustor table");
    TestLogger.logInfo("validated new selected SOF in DB ");
    TestLogger.logMsg("==========" + testName + " Completed==========");
  }

  /*
   * Feature: DRM error message when contract not accepted
   * Product Type:Fixed Term
   * Product Bank Model:DIRECT_RELATIONSHIP_MODEL(DRM)
   * TestRail Link:https://depositsolutions.testrail.io/index.php?/cases/view/1707
   * Author: deepthi.gorre
   */
  @Test(
      enabled = true,
      groups = {"PayIn", "DRM", "Regression"})
  @Parameters({"trancheIdentifier", "payInAmount", "customerEmail"})
  public void C1707_DRM_ErrorMessage(
      Method methodName, String sTrancheIdentifier, String sPayInAmount, String sCustomerEmail)
      throws SQLException, ClassNotFoundException, InterruptedException {
    if (testDataInjection.equalsIgnoreCase("Yes")) {
      // Test Data Injection for Product Bank
      DBReusables.getInstance().executeSqlScript("productBank-CKV.sql");
      DBReusables.getInstance().executeSqlScript("Tranche-CKV-FG1Y.sql");
      DBReusables.getInstance().executeSqlScript("customer.sql");
      // Getting customer details
      CustomerEmail = DBReusables.getInstance().getCustomerEmail();
      // Getting Product Details
      TrancheIdentifier = DBReusables.getInstance().getTrancheIdentifier("FG");
      PayInAmount = DBReusables.getInstance().getRamdomPayInAmount(TrancheIdentifier);
    } else {
      CustomerEmail = sCustomerEmail;
      TrancheIdentifier = sTrancheIdentifier;
      PayInAmount = sPayInAmount;
    }
    String testName = methodName.getName();

    TestLogger.logMsg("==========" + testName + " Started==========");

    // Shop Login
    ShopLoginLogoutPO.getInstance().shopLogin(ENV, CustomerEmail);

    // select Product from Shop
    ProductDetailsPO.getInstance().selectingProductFromProductListPage(TrancheIdentifier);
    // select SOF from Shop
    ProductDetailsPO.getInstance().selectingSourceOfFunds1("REGULAR_INCOME");
    // select QUE from Shop
    ProductDetailsPO.getInstance().selectingQuestionary_CKV();
    TestLogger.logMsg("Step1: Validate appearance of DRM Button");
    // check for grey colour of button
    Assert.assertEquals(
        DRIVER.findElement(ProductDetailsPO.getInstance().drm_accept).getAttribute("class"),
        "btn btn-grayed",
        "DRM button is not disabled");
    TestLogger.logInfo("DRM button is greyed-out as expected");
    TestLogger.logMsg("Step2: Validate DRM error message");
    // accept DRM from Shop without accepting
    DRIVER.findElement(ProductDetailsPO.getInstance().drm_accept).click();
    // check for error message
    Assert.assertEquals(
        DRIVER.findElement(ProductDetailsPO.getInstance().drmErrorText).getText(),
        "Bitte akzeptieren Sie die rechtlichen Hinweise.",
        "DRM error ytext is not correct");
    TestLogger.logInfo("DRM Error message is as expected");
    TestLogger.logMsg("==========" + testName + " Completed==========");
  }

  /*
   * Feature: Second time accept of DRM after NON_EXISTENT_REVOKED_BY_CUSTOMER
   * Product Type:Fixed Term
   * Product Bank Model:DIRECT_RELATIONSHIP_MODEL(DRM)
   * TestRail Link:https://depositsolutions.testrail.io/index.php?/cases/view/1731
   * Author: deepthi.gorre
   */
  @Test(
      enabled = true,
      groups = {"PayIn", "DRM", "Regression"})
  @Parameters({"trancheIdentifier", "payInAmount", "customerEmail"})
  public void C1731_DRM_After_NonExistentRevokedByCustomer(
      Method methodName, String sTrancheIdentifier, String sPayInAmount, String sCustomerEmail)
      throws SQLException, ClassNotFoundException, InterruptedException {
    if (testDataInjection.equalsIgnoreCase("Yes")) {
      // Test Data Injection for Product Bank
      DBReusables.getInstance().executeSqlScript("productBank-CKV.sql");
      DBReusables.getInstance().executeSqlScript("Tranche-CKV-FG1Y.sql");
      DBReusables.getInstance().executeSqlScript("customer.sql");
      // Getting customer details
      CustomerEmail = DBReusables.getInstance().getCustomerEmail();
      // Getting Product Details
      TrancheIdentifier = DBReusables.getInstance().getTrancheIdentifier("FG");
      PayInAmount = DBReusables.getInstance().getRamdomPayInAmount(TrancheIdentifier);
    } else {
      CustomerEmail = sCustomerEmail;
      TrancheIdentifier = sTrancheIdentifier;
      PayInAmount = sPayInAmount;
    }
    String testName = methodName.getName();

    TestLogger.logMsg("==========" + testName + " Started==========");

    // Shop Login
    ShopLoginLogoutPO.getInstance().shopLogin(ENV, CustomerEmail);

    // select Product from Shop
    ProductDetailsPO.getInstance().selectingProductFromProductListPage(TrancheIdentifier);
    // select SOF from Shop
    ProductDetailsPO.getInstance().selectingSourceOfFunds1("REGULAR_INCOME");
    // select QUE from Shop
    ProductDetailsPO.getInstance().selectingQuestionary_CKV();
    // accept DRM from Shop
    ProductDetailsPO.getInstance().selectingDRM_Contract(TrancheIdentifier);
    TestLogger.logMsg("Step1: Change DRM Status");
    // change DRM status
    DBReusables.getInstance().setDrmStatus("NON_EXISTENT_REVOKED_BY_CUSTOMER");
    TestLogger.logMsg("Step2: Validate DRM entry in A&D Page");
    ArchiveAndDocumentsPO.getInstance()
        .validatePersonalDocument(
            DBReusables.getInstance().formatDate("dd.MM.yyyy")
                + " Kundenrahmenvertrag - "
                + DBReusables.getInstance().getBankName_FromTrancheIdentifier(TrancheIdentifier)
                + "\n"
                + "Zum Vertragsabschluss wird Ihre Einzahlung benötigt"
                + " Download Kundenrahmenvertrag",
            "absent");
    // select Product from Shop
    ProductDetailsPO.getInstance().selectingProductFromProductListPage(TrancheIdentifier);
    DRIVER.findElement(By.id("proceed_with_product_selected")).click();
    TestLogger.logMsg("Step3: Accept DRM Contract for second time");
    // accept DRM for second time from Shop
    ProductDetailsPO.getInstance().selectingDRM_Contract(TrancheIdentifier);
    TestLogger.logMsg("==========" + testName + " Completed==========");
  }

  /*
   * Feature: pay out and pay in button of DRM after IN_TERMINATION_TERMINATED_BY_CUSTOMER
   * Product Type:Call-a-Like
   * Product Bank Model:DIRECT_RELATIONSHIP_MODEL(DRM)
   * TestRail Link:https://depositsolutions.testrail.io/index.php?/cases/view/7552
   * Author: deepthi.gorre
   */
  @Test(
      enabled = true,
      groups = {"PayIn", "DRM", "Regression"})
  @Parameters({"trancheIdentifier", "payInAmount", "customerEmail"})
  public void C7552_DRM_After_InTerminationTerminatedByCustomer(
      Method methodName, String sTrancheIdentifier, String sPayInAmount, String sCustomerEmail)
      throws SQLException, ClassNotFoundException, InterruptedException {
    if (testDataInjection.equalsIgnoreCase("Yes")) {

      // Test Data Injection for Product Bank
      DBReusables.getInstance().executeSqlScript("productBank-QLIRO.sql");
      DBReusables.getInstance().executeSqlScript("Tranche-QLIRO-TG.sql");
      // Test Data Injection for Customer with Deposit
      DBReusables.getInstance().executeSqlScript("customerWithPayIn-QLIRO-TG.sql");
      // Getting customer details
      CustomerEmail = DBReusables.getInstance().getCustomerEmail();
      // Getting Product Details
      TrancheIdentifier = DBReusables.getInstance().getTrancheIdentifier("TG");
      PayInAmount = DBReusables.getInstance().getRamdomPayInAmount(TrancheIdentifier);
    } else {
      CustomerEmail = sCustomerEmail;
      TrancheIdentifier = sTrancheIdentifier;
      PayInAmount = sPayInAmount;
    }
    String testName = methodName.getName();

    TestLogger.logMsg("==========" + testName + " Started==========");

    // Shop Login
    ShopLoginLogoutPO.getInstance().shopLogin(ENV, CustomerEmail);
    TestLogger.logMsg("Step: Change DRM Status");
    // change DRM status
    DBReusables.getInstance().setDrmStatus("IN_TERMINATION_TERMINATED_BY_CUSTOMER");
    TestLogger.logMsg("Step2: Validate DRM entry in A&D Page");
    ArchiveAndDocumentsPO.getInstance()
        .validatePersonalDocument(
            DBReusables.getInstance().formatDate("dd.MM.yyyy")
                + " Kundenrahmenvertrag - "
                + DBReusables.getInstance().getBankName_FromTrancheIdentifier(TrancheIdentifier)
                + "\n"
                + "Zum Vertragsabschluss wird Ihre Einzahlung benötigt"
                + " Download Kundenrahmenvertrag",
            "absent");

    TestLogger.logMsg("Step-3: Click on Meine Analgen link");
    WebUIOperations.getInstance()
        .waitForElementAndClick(DRIVER.findElement(MeineAnlagenPO.getInstance().ZP_MeineAnlagen));

    TestLogger.logMsg("Step-4: Click on Tranche to see Bookings Page");
    MeineAnlagenPO.getInstance().verifyZPProductDetails(TrancheIdentifier);

    TestLogger.logMsg("Step-5: Validate if Payout button is disabled or not");
    Assert.assertTrue(
        DRIVER
            .findElement(MeineAnlagenPO.getInstance().ZP_PayOut)
            .getAttribute("class")
            .contains("disabled"),
        "PayOut button is Disabled");
    TestLogger.logMsg("Step-6: Validate if PayIn button is disabled or not  in MeineAnlagen");
    Assert.assertTrue(
        DRIVER
            .findElement(MeineAnlagenPO.getInstance().ZP_PayIn)
            .getAttribute("class")
            .contains("disabled"),
        "PayIn button is Disabled");
    TestLogger.logMsg("Step-7: Validate drm hint in MeineAnlagen");
    Assert.assertEquals(
        DRIVER.findElement(MeineAnlagenPO.getInstance().DRM_hint).getText(),
        "Warum ist das Angebot nicht verfügbar?",
        "Link text is not correct");
    TestLogger.logInfo("hint link is correct");
    Assert.assertEquals(
        DRIVER.findElement(MeineAnlagenPO.getInstance().DRM_hint).getAttribute("href"),
        ConfigManager.getInstance().getString(SHOP_URL_CONFIG_KEY)
            + "benutzer/anlagen/details/"
            + DBReusables.getInstance()
                .getCIA_UUID(
                    DBReusables.getInstance()
                        .getCIA(
                            DBReusables.getInstance().getCustomerNumber(CustomerEmail),
                            TrancheIdentifier,
                            "MHSBDEHBXXX"))
            + "/contractNotSupportedByDrm",
        "Url is not correct");
    TestLogger.logInfo("hint url is correct");

    TestLogger.logMsg("Step-8: Validate if PayIn button in Product List Page");
    ShopLoginLogoutPO.getInstance().shopCache();
    DRIVER.findElement(ProductDetailsPO.getInstance().Anlageangebote).click();
    Assert.assertEquals(
        DRIVER
            .findElement(
                By.id(
                    "proceed_with_product_"
                        + DBReusables.getInstance()
                            .getPayInCodeFromTrancheIdentifier(TrancheIdentifier)))
            .getText(),
        "Nicht verfügbar",
        "PayIn button name is incorrect");
    TestLogger.logInfo("PayIn button name validated");
    Assert.assertTrue(
        DRIVER
            .findElement(
                By.id(
                    "proceed_with_product_"
                        + DBReusables.getInstance()
                            .getPayInCodeFromTrancheIdentifier(TrancheIdentifier)))
            .getAttribute("class")
            .contains("disabled"),
        "PayIn button is Disabled");
    TestLogger.logInfo("PayIn button is dissabled");
    TestLogger.logMsg("Step-9: Validate drm hint in Product List Page");
    Assert.assertEquals(
        DRIVER.findElement(ProductDetailsPO.getInstance().DRM_hint).getText(),
        "Warum ist das Angebot nicht verfügbar?",
        "Link text is not correct");
    TestLogger.logInfo("hint link is correct");
    TestLogger.logMsg("==========" + testName + " Completed=========");
  }

  /*
   * Feature: pay out and pay in button of DRM after IN_TERMINATION_TERMINATED_BY_PB
   * Product Type:Call-a-Like
   * Product Bank Model:DIRECT_RELATIONSHIP_MODEL(DRM)
   * TestRail Link:https://depositsolutions.testrail.io/index.php?/cases/view/7562
   * Author: deepthi.gorre
   */
  @Test(
      enabled = true,
      groups = {"PayIn", "DRM", "Regression"})
  @Parameters({"trancheIdentifier", "payInAmount", "customerEmail"})
  public void C7562_DRM_After_InTerminationTerminatedByPB(
      Method methodName, String sTrancheIdentifier, String sPayInAmount, String sCustomerEmail)
      throws SQLException, ClassNotFoundException, InterruptedException {
    if (testDataInjection.equalsIgnoreCase("Yes")) {

      // Test Data Injection for Product Bank
      DBReusables.getInstance().executeSqlScript("productBank-QLIRO.sql");
      DBReusables.getInstance().executeSqlScript("Tranche-QLIRO-TG.sql");
      // Test Data Injection for Customer with Deposit
      DBReusables.getInstance().executeSqlScript("customerWithPayIn-QLIRO-TG.sql");
      // Getting customer details
      CustomerEmail = DBReusables.getInstance().getCustomerEmail();
      // Getting Product Details
      TrancheIdentifier = DBReusables.getInstance().getTrancheIdentifier("TG");
      PayInAmount = DBReusables.getInstance().getRamdomPayInAmount(TrancheIdentifier);
    } else {
      CustomerEmail = sCustomerEmail;
      TrancheIdentifier = sTrancheIdentifier;
      PayInAmount = sPayInAmount;
    }
    String testName = methodName.getName();

    TestLogger.logMsg("==========" + testName + " Started=========");

    // Shop Login
    ShopLoginLogoutPO.getInstance().shopLogin(ENV, CustomerEmail);
    TestLogger.logMsg("Step1: Change DRM Status");
    // change DRM status
    DBReusables.getInstance().setDrmStatus("IN_TERMINATION_TERMINATED_BY_PB");
    TestLogger.logMsg("Step2: Validate DRM entry in A&D Page");
    ArchiveAndDocumentsPO.getInstance()
        .validatePersonalDocument(
            DBReusables.getInstance().formatDate("dd.MM.yyyy")
                + " Kundenrahmenvertrag - "
                + DBReusables.getInstance().getBankName_FromTrancheIdentifier(TrancheIdentifier)
                + "\n"
                + "Zum Vertragsabschluss wird Ihre Einzahlung benötigt"
                + " Download Kundenrahmenvertrag",
            "absent");

    TestLogger.logMsg("Step-3: Click on Meine Analgen link");
    WebUIOperations.getInstance()
        .waitForElementAndClick(DRIVER.findElement(MeineAnlagenPO.getInstance().ZP_MeineAnlagen));

    TestLogger.logMsg("Step-4: Click on Tranche to see Bookings Page");
    MeineAnlagenPO.getInstance().verifyZPProductDetails(TrancheIdentifier);

    TestLogger.logMsg("Step-5: Validate if Payout button is disabled or not");
    Assert.assertTrue(
        DRIVER
            .findElement(MeineAnlagenPO.getInstance().ZP_PayOut)
            .getAttribute("class")
            .contains("disabled"),
        "PayOut button is Disabled");
    TestLogger.logMsg("Step-6: Validate if PayIn button is disabled or not  in MeineAnlagen");
    Assert.assertTrue(
        DRIVER
            .findElement(MeineAnlagenPO.getInstance().ZP_PayIn)
            .getAttribute("class")
            .contains("disabled"),
        "PayIn button is Disabled");
    TestLogger.logMsg("Step-7: Validate drm hint in MeineAnlagen");
    Assert.assertEquals(
        DRIVER.findElement(MeineAnlagenPO.getInstance().DRM_hint).getText(),
        "Warum ist das Angebot nicht verfügbar?",
        "Link text is not correct");
    TestLogger.logInfo("hint link is correct");
    Assert.assertEquals(
        DRIVER.findElement(MeineAnlagenPO.getInstance().DRM_hint).getAttribute("href"),
        ConfigManager.getInstance().getString(SHOP_URL_CONFIG_KEY)
            + "benutzer/anlagen/details/"
            + DBReusables.getInstance()
                .getCIA_UUID(
                    DBReusables.getInstance()
                        .getCIA(
                            DBReusables.getInstance().getCustomerNumber(CustomerEmail),
                            TrancheIdentifier,
                            "MHSBDEHBXXX"))
            + "/contractNotSupportedByDrm",
        "Url is not correct");
    TestLogger.logInfo("hint url is correct");

    TestLogger.logMsg("Step-8: Validate if PayIn button in Product List Page");
    ShopLoginLogoutPO.getInstance().shopCache();
    DRIVER.findElement(ProductDetailsPO.getInstance().Anlageangebote).click();
    Assert.assertEquals(
        DRIVER
            .findElement(
                By.id(
                    "proceed_with_product_"
                        + DBReusables.getInstance()
                            .getPayInCodeFromTrancheIdentifier(TrancheIdentifier)))
            .getText(),
        "Nicht verfügbar",
        "PayIn button name is incorrect");
    TestLogger.logInfo("PayIn button name validated");
    Assert.assertTrue(
        DRIVER
            .findElement(
                By.id(
                    "proceed_with_product_"
                        + DBReusables.getInstance()
                            .getPayInCodeFromTrancheIdentifier(TrancheIdentifier)))
            .getAttribute("class")
            .contains("disabled"),
        "PayIn button is Disabled");
    TestLogger.logInfo("PayIn button is dissabled");
    TestLogger.logMsg("Step-9: Validate drm hint in Product List Page");
    Assert.assertEquals(
        DRIVER.findElement(ProductDetailsPO.getInstance().DRM_hint).getText(),
        "Warum ist das Angebot nicht verfügbar?",
        "Link text is not correct");
    TestLogger.logInfo("hint link is correct");
    TestLogger.logMsg("==========" + testName + " Completed=========");
  }

  /*
   * Feature: IFE validation
   * Product Type:Call-a-like
   * Product Bank Model:FAM
   * TestRail Link:https://depositsolutions.testrail.io/index.php?/cases/view/1631
   *               https://depositsolutions.testrail.io/index.php?/cases/view/1642
   * Author: deepthi.gorre
   */
  @Test(
      enabled = true,
      groups = {"Regression", "ShopUI"})
  @Parameters({"trancheIdentifier", "customerEmail"})
  public void C1642_C1631_Validate_IFE(
      Method methodName, String sTrancheIdentifier, String sCustomerEmail)
      throws SQLException, ClassNotFoundException, InterruptedException {
    if (testDataInjection.equalsIgnoreCase("Yes")) {
      // SELECT
      // from zp_int_b2c.b2c_document_depositors_information_accepted order by creationDate desc;
      // Test Data Injection for Product Bank
      DBReusables.getInstance().executeSqlScript("productBank_CreditPlus.sql");
      DBReusables.getInstance().executeSqlScript("Tranche-CreditPlus-TG.sql");
      DBReusables.getInstance().executeSqlScript("customer.sql");
      // Getting customer details
      CustomerEmail = DBReusables.getInstance().getCustomerEmail();
      // Getting Product Details
      TrancheIdentifier = DBReusables.getInstance().getTrancheIdentifier("TG");
      PayInAmount = DBReusables.getInstance().getRamdomPayInAmount(TrancheIdentifier);
    } else {
      CustomerEmail = sCustomerEmail;
      TrancheIdentifier = sTrancheIdentifier;
    }
    String testName = methodName.getName();

    TestLogger.logMsg("==========" + testName + " Started==========");

    // Shop Login
    ShopLoginLogoutPO.getInstance().shopLogin(ENV, CustomerEmail);

    TestLogger.logMsg("Step 1: Click tranche in Product List Page");
    // select Product from Shop
    ProductDetailsPO.getInstance().selectingProductFromProductListPage(TrancheIdentifier);
    TestLogger.logMsg("Step-2: Validate IFE Link Text");
    Assert.assertEquals(
        DRIVER.findElement(ProductDetailsPO.getInstance().ife).getText(),
        "Informationsbogen für Einleger",
        "Link text is not correct");
    TestLogger.logMsg("Step-3: Validate IFE Link Url");
    Assert.assertEquals(
        DRIVER.findElement(ProductDetailsPO.getInstance().ife).getAttribute("href"),
        ConfigManager.getInstance().getString(SHOP_URL_CONFIG_KEY)
            + "customer-document/depositors-information/PRODUCT_BANK/"
            + DBReusables.getInstance().getPB_BIC_FromTrancheIdentifier(TrancheIdentifier)
            + "/document",
        "Url is not correct");
    TestLogger.logMsg("Step-4: Click IFE link");
    DRIVER.findElement(ProductDetailsPO.getInstance().ife).click();
    TestLogger.logMsg("Step-5: Click PayIn button");
    DRIVER.findElement(ProductDetailsPO.getInstance().button_payin).click();
    TestLogger.logMsg("Step-6: Validate document_depositors_information_accepted entry");

    TestLogger.logMsg("==========" + testName + " Completed==========");
  }
  /*
   * Feature: PIB validation
   * Product Type:Call-a-like
   * Product Bank Model:FAM
   * TestRail Link:https://depositsolutions.testrail.io/index.php?/cases/view/1643
   * Author: deepthi.gorre
   */
  @Test(
      enabled = true,
      groups = {"Regression", "ShopUI"})
  @Parameters({"trancheIdentifier", "customerEmail"})
  public void C1643_Validate_PIB(
      Method methodName, String sTrancheIdentifier, String sCustomerEmail)
      throws SQLException, ClassNotFoundException, InterruptedException {
    if (testDataInjection.equalsIgnoreCase("Yes")) {
      // Test Data Injection for Product Bank
      DBReusables.getInstance().executeSqlScript("productBank_CreditPlus.sql");
      DBReusables.getInstance().executeSqlScript("Tranche-CreditPlus-TG.sql");
      DBReusables.getInstance().executeSqlScript("customer.sql");
      // Getting customer details
      CustomerEmail = DBReusables.getInstance().getCustomerEmail();
      // Getting Product Details
      TrancheIdentifier = DBReusables.getInstance().getTrancheIdentifier("TG");
      PayInAmount = DBReusables.getInstance().getRamdomPayInAmount(TrancheIdentifier);
    } else {
      CustomerEmail = sCustomerEmail;
      TrancheIdentifier = sTrancheIdentifier;
    }
    String testName = methodName.getName();

    TestLogger.logMsg("==========" + testName + " Started==========");

    // Shop Login
    ShopLoginLogoutPO.getInstance().shopLogin(ENV, CustomerEmail);

    // select Product from Shop
    ProductDetailsPO.getInstance().selectingProductFromProductListPage(TrancheIdentifier);
    TestLogger.logMsg("Step-1: Validate PIB Link-Produktinformationsblatt Link Text");
    Assert.assertEquals(
        DRIVER.findElement(ProductDetailsPO.getInstance().pib1).getText(),
        "Produktinformationsblatt",
        "Link text is not correct");
    TestLogger.logMsg("Step-2: Validate PIB Link-Produktinformationsblatt Link Url");
    Assert.assertEquals(
        DRIVER.findElement(ProductDetailsPO.getInstance().pib1).getAttribute("href"),
        ConfigManager.getInstance().getString(SHOP_URL_CONFIG_KEY)
            + "customer-document/product-information/"
            + DBReusables.getInstance().getPB_BIC_FromTrancheIdentifier(TrancheIdentifier)
            + "/"
            + DBReusables.getInstance().getTrancheUUID(TrancheIdentifier)
            + "/"
            + DBReusables.getInstance().getPIBString(TrancheIdentifier),
        "Url is not correct");
    TestLogger.logMsg("Step-3: Click PIB Link-Produktinformationsblatt");
    DRIVER.findElement(ProductDetailsPO.getInstance().pib1).click();
    // DRIVER.close();
    WebUIOperations.getInstance().switchTab(0);
    TestLogger.logMsg("Step-4: Validate PIB Link-Hier herunterladen Link Text");
    Assert.assertEquals(
        DRIVER.findElement(ProductDetailsPO.getInstance().pib2).getText(),
        "Hier herunterladen",
        "Link text is not correct");
    TestLogger.logMsg("Step-5: Validate PIB Link-Hier herunterladen Link Url");
    Assert.assertEquals(
        DRIVER.findElement(ProductDetailsPO.getInstance().pib2).getAttribute("href"),
        ConfigManager.getInstance().getString(SHOP_URL_CONFIG_KEY)
            + "customer-document/product-information/"
            + DBReusables.getInstance().getPB_BIC_FromTrancheIdentifier(TrancheIdentifier)
            + "/"
            + DBReusables.getInstance().getTrancheUUID(TrancheIdentifier)
            + "/"
            + DBReusables.getInstance().getPIBString(TrancheIdentifier),
        "Url is not correct");
    TestLogger.logMsg("Step-6: Click PIB Link-Hier herunterladen");
    DRIVER.findElement(ProductDetailsPO.getInstance().pib2).click();
    TestLogger.logMsg("==========" + testName + " Completed==========");
  }

  @Test(
      enabled = true,
      groups = {"PayIn", "Regression", "P1"})
  @Parameters({"trancheIdentifier", "payInAmount", "customerEmail"})
  public void C7001_VerifyIRAndSDInShop(
      Method methodName, String sTrancheIdentifier, String sPayInAmount, String sCustomerEmail)
      throws InterruptedException {
    String prodopsUrl = ConfigManager.getInstance().getString("prodopsUrl");
    String prodopsUserName = ConfigManager.getInstance().getString("gundaUsername");
    String prodopsPassword = ConfigManager.getInstance().getString("gundaPassword");
    if (testDataInjection.equalsIgnoreCase("Yes")) {

      DBReusables.getInstance().executeSqlScript("productBank-CKV-POA.sql");
      DBReusables.getInstance().executeSqlScript("Tranche-CKV-FG1Y.sql");
      // Getting Product Details
      DBReusables.getInstance().executeSqlScript("customer.sql");
      // Getting customer details
      CustomerEmail = DBReusables.getInstance().getCustomerEmail();
      TrancheIdentifier = DBReusables.getInstance().getTrancheIdentifier("FG");
      PayInAmount = "1000";
    } else {
      CustomerEmail = sCustomerEmail;
      TrancheIdentifier = sTrancheIdentifier;
      PayInAmount = sPayInAmount;
    }
    String testName = methodName.getName();
    TestLogger.logMsg("==========" + testName + " Started==========");

    //    String table = DBReusables.getInstance().ct2iTable;
    // Shop Login
    //    ShopLoginLogoutPO.getInstance().shopCache();
    ShopLoginLogoutPO.getInstance().shopLogin(ENV, CustomerEmail);

    // calling SB & PB Iban method
    PaymentServices.getInstance()
        .SBandPB_IBAN(PaymentServices.getInstance().ServiceBank_BIC, TrancheIdentifier);

    TestLogger.logMsg("Step-1: Get CustomerNumber,MultiPurposeText and CounterPartAccNumber");
    String CustomerNumber = DBReusables.getInstance().getCustomerNumber(CustomerEmail);
    String MULTI_PURPOSE_TEXT =
        DBReusables.getInstance().getPayInCodeFromTrancheIdentifier(TrancheIdentifier);
    String COUNTER_PART_ACCOUNT_NUMBER =
        new IBAN(DBReusables.getInstance().getCustomerServiceBankIban(CustomerNumber))
            .getBankAccountNumber();

    // Payin ticket creation
    TestLogger.logMsg("Step-2: Create Invalid Payin Ticket");
    PaymentServices.getInstance()
        .customerPayin(MULTI_PURPOSE_TEXT, COUNTER_PART_ACCOUNT_NUMBER, PayInAmount);

    TestLogger.logMsg("Step-3: Note down the badge Interest Rate in Shop");
    DBReusables.getInstance()
        .executeSql("truncate table comonea_b2c.b2c_fixed_term_interest_approval");
    String interestRateBefore =
        getWebElement(ProductDetailsPO.getInstance().badgeStatusInterestRate).getText();

    TestLogger.logMsg("Step-4: Log into Prodops and change the interest-rate for upcoming tranche");
    ProdOpsPO.getInstance().prodOpsLogin(prodopsUserName, prodopsPassword, prodopsUrl);
    WebUIOperations.getInstance().waitForElementAndClick(getWebElement(ProdOpsPO.TRANCHES));
    WebUIOperations.getInstance().waitForElementAndClick(getWebElement(ProdOpsPO.SHOWBANKS));
    WebUIOperations.getInstance().waitForElementAndClick(getWebElement(ProdOpsPO.EDIT_INTEREST));
    WebUIOperations.getInstance().sendKeys(getWebElement(ProdOpsPO.INTEREST_RATE), "0.05");
    //    WebUIOperations.getInstance().sendKeys(getWebElement(ProdOpsPO.startDate),"28.02.2022");

    WebUIOperations.getInstance().waitForElementAndClick(getWebElement(ProdOpsPO.SAVE_DETAILS));
    WebUIOperations.getInstance().waitForElementAndClick(getWebElement(ProdOpsPO.SAVE));
    WebUIOperations.getInstance()
        .waitForElementAndClick(getWebElement(ProdOpsPO.CONFIRM_CHANGEOF_INTEREST));
    DRIVER.switchTo().alert().accept();
    //
    // WebUIOperations.getInstance().waitForElementAndClick(getWebElement(ProdOpsPO.publishChanges));
    //    DRIVER.switchTo().alert().accept();

    TestLogger.logMsg(
        "Step-5: Hit ShopCache endpoint and validate if the changed interest rate in prodops is reflected in Shop UI");
    WebUIOperations.getInstance().switchTab(0);
    //    ShopLoginLogoutPO.getInstance().shopCache();
    // Thread.sleep(20000);
    ShopLoginLogoutPO.getInstance().shopLogOut();
    ShopLoginLogoutPO.getInstance().shopCache();
    ShopLoginLogoutPO.getInstance().shopLogin(ENV, CustomerEmail);
    DRIVER.navigate().refresh();
    String interestRateAfter =
        getWebElement(ProductDetailsPO.getInstance().badgeStatusInterestRate).getText();
    Assert.assertFalse(
        interestRateBefore.equals(interestRateAfter), interestRateAfter + " " + interestRateBefore);
  }

  @AfterMethod(alwaysRun = true)
  public void teardown() {
    TestLogger.logInfo("Executing Browser tearDown method");
    //    DBReusables.getInstance().executeSqlScript("TruncateAllTables.sql");
    ShopLoginLogoutPO.getInstance().closeAllBrowsers();
  }

  @AfterTest(alwaysRun = true)
  // Closing All connections
  public void cleanup() throws SQLException {

    DBReusables.getInstance().closeDBCon();
  }
}
