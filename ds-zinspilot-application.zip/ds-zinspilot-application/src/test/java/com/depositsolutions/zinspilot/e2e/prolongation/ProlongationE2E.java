package com.depositsolutions.zinspilot.e2e.prolongation;

import static com.depositsolutions.common.reusables.TestConstants.SHOP_URL_CONFIG_KEY;

import com.depositsolutions.common.reusables.DBReusables;
import com.depositsolutions.common.reusables.PaymentServices;
import com.depositsolutions.common.ui.helpers.BaseTestClassUI;
import com.depositsolutions.common.ui.zpuipageobjects.ShopLoginLogoutPO;
import com.depositsolutions.common.utils.ConfigManager;
import com.depositsolutions.common.utils.TestLogger;
import java.awt.AWTException;
import java.lang.reflect.Method;
import java.sql.SQLException;
import org.testng.ITestResult;
import org.testng.annotations.*;

public class ProlongationE2E extends BaseTestClassUI {
  private String testDataInjection = ConfigManager.getInstance().getString("testDataInjection");
  String CustomerEmail, TargetTrancheIdentifier, SourceTrancheIdentifier, PayOutType, PayOutAmount;

  @BeforeTest(alwaysRun = true)
  public void setupDB() {
    DBReusables.getInstance().dbConnect();
  }

  @BeforeMethod(alwaysRun = true)
  public void preLoadSQLTestData() {
    if (testDataInjection.equalsIgnoreCase("Yes")) {
      DBReusables.getInstance().executeSqlScript("TruncateAllTables.sql");
      DBReusables.getInstance().executeSqlScript("serviceBank-sutor.sql");
    } else {
      // Truncate sps Tables
      DBReusables.getInstance().executeSqlScript("TruncateSPSTables.sql");
    }
    setUpForTest(ConfigManager.getInstance().getString(SHOP_URL_CONFIG_KEY));
  }

  /*
   * Feature: Customer Settings FullProlongation from Shop
   * Product Type:Fixed Term
   * TestRail Link:https://depositsolutions.testrail.io/index.php?/cases/view/11887
   * Author: deepthi.gorre
   */
  @Parameters({
    "sourceTrancheIdentifier",
    "payOutAmount",
    "customerEmail",
    "payOutType",
    "targetTrancheIdentifier"
  })
  @Test(
      enabled = true,
      groups = {"Prolongation", "Regression"})
  public void C11887_Shop_FullProlongation_NoPayOut(
      Method methodName,
      String sSourceTrancheIdentifier,
      String sPayOutAmount,
      String sCustomerEmail,
      String sPayOutType,
      String sTargetTrancheIdentifier)
      throws SQLException, ClassNotFoundException, InterruptedException, AWTException {

    if (testDataInjection.equalsIgnoreCase("Yes")) {
      // Test Data Injection for Product Bank
      DBReusables.getInstance().executeSqlScript("productBank_CreditPlus.sql");
      DBReusables.getInstance().executeSqlScript("Tranche-CreditPlus-FG1Y.sql");
      // Test Data Injection for Customer with Deposit
      DBReusables.getInstance().executeSqlScript("customerWithPayIn-CreditPlus-FG1Y.sql");
      // Getting customer details
      CustomerEmail = DBReusables.getInstance().getCustomerEmail();
      // Getting Product Details
      SourceTrancheIdentifier = DBReusables.getInstance().getPreviousTrancheIdentifier("FG");
      TargetTrancheIdentifier = DBReusables.getInstance().getTrancheIdentifier("FG");
      PayOutType = "FullProlongation";
    } else {
      CustomerEmail = sCustomerEmail;
      SourceTrancheIdentifier = sSourceTrancheIdentifier;
      TargetTrancheIdentifier = sTargetTrancheIdentifier;
      PayOutAmount = sPayOutAmount;
      PayOutType = sPayOutType;
    }
    String testName = methodName.getName();

    TestLogger.logMsg("==========" + testName + " Started==========");
    // Calling PayOut method
    PaymentServices.getInstance()
        .PayOut(
            testName,
            SourceTrancheIdentifier,
            PayOutAmount,
            CustomerEmail,
            PayOutType,
            TargetTrancheIdentifier);
    TestLogger.logMsg("==========" + testName + " Completed==========");
  }

  /*
   * Feature: Customer settings FullProlongation from Gunda
   * Product Type:Fixed Term
   * TestRail Link:https://depositsolutions.testrail.io/index.php?/cases/view/11886
   * Author: deepthi.gorre
   */
  @Test(
      enabled = true,
      groups = {"Prolongation", "Regression"})
  @Parameters({
    "sourceTrancheIdentifier",
    "payOutAmount",
    "customerEmail",
    "payOutType",
    "targetTrancheIdentifier"
  })
  public void C11886_Gunda_FullProlongation_NoPayOut(
      Method methodName,
      String sSourceTrancheIdentifier,
      String sPayOutAmount,
      String sCustomerEmail,
      String sPayOutType,
      String sTargetTrancheIdentifier)
      throws SQLException, ClassNotFoundException, InterruptedException, AWTException {

    if (testDataInjection.equalsIgnoreCase("Yes")) {
      // Test Data Injection for Product Bank
      DBReusables.getInstance().executeSqlScript("productBank_CreditPlus.sql");
      DBReusables.getInstance().executeSqlScript("Tranche-CreditPlus-FG1Y.sql");
      // Test Data Injection for Customer with Deposit
      DBReusables.getInstance().executeSqlScript("customerWithPayIn-CreditPlus-FG1Y.sql");
      // Getting customer details
      CustomerEmail = DBReusables.getInstance().getCustomerEmail();
      // Getting Product Details
      SourceTrancheIdentifier = DBReusables.getInstance().getPreviousTrancheIdentifier("FG");
      TargetTrancheIdentifier = DBReusables.getInstance().getTrancheIdentifier("FG");
      PayOutType = "FullProlongation";
    } else {
      CustomerEmail = sCustomerEmail;
      SourceTrancheIdentifier = sSourceTrancheIdentifier;
      TargetTrancheIdentifier = sTargetTrancheIdentifier;
      PayOutAmount = sPayOutAmount;
      PayOutType = sPayOutType;
    }
    String testName = methodName.getName();

    TestLogger.logMsg("==========" + testName + " Started==========");
    // Calling PayOut method
    PaymentServices.getInstance()
        .PayOut(
            testName,
            SourceTrancheIdentifier,
            PayOutAmount,
            CustomerEmail,
            PayOutType,
            TargetTrancheIdentifier);
    TestLogger.logMsg("==========" + testName + " Completed==========");
  }

  /*
   * Feature: Default Prolongation Strategy-PROLONGATION
   * Product Type:Fixed Term
   * TestRail Link:https://depositsolutions.testrail.io/index.php?/cases/view/2061
   * Author: deepthi.gorre
   */
  @Test(
      enabled = true,
      groups = {"Prolongation", "Regression", "e2e"})
  @Parameters({
    "sourceTrancheIdentifier",
    "payOutAmount",
    "customerEmail",
    "payOutType",
    "targetTrancheIdentifier"
  })
  public void C2061_DefaultProlongationStrategy_Prolongation(
      Method methodName,
      String sSourceTrancheIdentifier,
      String sPayOutAmount,
      String sCustomerEmail,
      String sPayOutType,
      String sTargetTrancheIdentifier)
      throws SQLException, ClassNotFoundException, InterruptedException, AWTException {

    if (testDataInjection.equalsIgnoreCase("Yes")) {
      // Test Data Injection for Product Bank
      DBReusables.getInstance().executeSqlScript("productBank_CreditPlus.sql");
      DBReusables.getInstance().executeSqlScript("Tranche-CreditPlus-FG1Y.sql");
      // Test Data Injection for Customer with Deposit
      DBReusables.getInstance().executeSqlScript("customerWithPayIn-CreditPlus-FG1Y.sql");
      // Getting customer details
      CustomerEmail = DBReusables.getInstance().getCustomerEmail();
      // Getting Product Details
      SourceTrancheIdentifier = DBReusables.getInstance().getPreviousTrancheIdentifier("FG");
      TargetTrancheIdentifier = DBReusables.getInstance().getTrancheIdentifier("FG");
      PayOutType = "FullProlongation";
    } else {
      CustomerEmail = sCustomerEmail;
      SourceTrancheIdentifier = sSourceTrancheIdentifier;
      TargetTrancheIdentifier = sTargetTrancheIdentifier;
      PayOutAmount = sPayOutAmount;
      PayOutType = sPayOutType;
    }
    String testName = methodName.getName();

    TestLogger.logMsg("==========" + testName + " Started==========");
    // Calling PayOut method
    PaymentServices.getInstance()
        .PayOut(
            testName,
            SourceTrancheIdentifier,
            PayOutAmount,
            CustomerEmail,
            PayOutType,
            TargetTrancheIdentifier);
    TestLogger.logMsg("==========" + testName + " Completed==========");
  }

  @AfterMethod(alwaysRun = true)
  public void teardown(ITestResult result) {
    if (ITestResult.FAILURE == result.getStatus()) {
      takeScreenshot(result.getName());
    }
    TestLogger.logInfo("Executing Browser tearDown method");
    ShopLoginLogoutPO.getInstance().closeAllBrowsers();
  }

  @AfterTest(alwaysRun = true)
  public void cleanup() throws SQLException {
    DBReusables.getInstance().closeDBCon();
  }
}
