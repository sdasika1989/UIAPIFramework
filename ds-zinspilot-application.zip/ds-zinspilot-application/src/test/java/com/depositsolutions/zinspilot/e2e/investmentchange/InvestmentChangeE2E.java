package com.depositsolutions.zinspilot.e2e.investmentchange;

import static com.depositsolutions.common.reusables.TestConstants.SHOP_URL_CONFIG_KEY;

import com.depositsolutions.common.restapi.services.Deposit;
import com.depositsolutions.common.reusables.DBReusables;
import com.depositsolutions.common.reusables.PaymentServices;
import com.depositsolutions.common.ui.helpers.BaseTestClassUI;
import com.depositsolutions.common.ui.helpers.WebUIOperations;
import com.depositsolutions.common.ui.zpuipageobjects.MeineAnlagenPO;
import com.depositsolutions.common.ui.zpuipageobjects.ProductDetailsPO;
import com.depositsolutions.common.ui.zpuipageobjects.ShopLoginLogoutPO;
import com.depositsolutions.common.utils.ConfigManager;
import com.depositsolutions.common.utils.TestLogger;
import java.awt.AWTException;
import java.lang.reflect.Method;
import java.sql.SQLException;
import java.text.DecimalFormat;
import org.openqa.selenium.By;
import org.testng.Assert;
import org.testng.ITestResult;
import org.testng.annotations.*;

public class InvestmentChangeE2E extends BaseTestClassUI {

  private String testDataInjection = ConfigManager.getInstance().getString("testDataInjection");
  String CustomerEmail,
      TargetTrancheIdentifier,
      SourceTrancheIdentifier,
      IcAmount,
      IcType,
      ProlongationTrancheIdentifier;

  @BeforeTest(alwaysRun = true)
  public void setupDB() {
    DBReusables.getInstance().dbConnect();
  }

  @BeforeMethod(alwaysRun = true)
  public void preLoadSQLTestData() {
    if (testDataInjection.equalsIgnoreCase("Yes")) {
      DBReusables.getInstance().executeSqlScript("TruncateAllTables.sql");
      DBReusables.getInstance().executeSqlScript("serviceBank-sutor.sql");
    } else {
      // Truncate sps Tables
      DBReusables.getInstance().executeSqlScript("TruncateSPSTables.sql");
    }
    setUpForTest(ConfigManager.getInstance().getString(SHOP_URL_CONFIG_KEY));
  }

  /*
   * Feature: Partial Internal InvestmentChange from Shop
   * Product Type: FG to TG
   * ProductBank Model: FAM
   * TestRail Link: https://depositsolutions.testrail.io/index.php?/cases/view/11893
   * Author: deepthi.gorre
   */
  @Test(
      enabled = true,
      groups = {"InvestmentChange", "Regression"})
  @Parameters({"sourceTrancheIdentifier", "icAmount", "customerEmail", "targetTrancheIdentifier"})
  public void C11893_Shop_Internal_Partial_InvestmentChange_FAM_FG2TG(
      Method methodName,
      String sSourceTrancheIdentifier,
      String sIcAmount,
      String sCustomerEmail,
      String sTargetTrancheIdentifier)
      throws SQLException, ClassNotFoundException, InterruptedException, AWTException {
    if (testDataInjection.equalsIgnoreCase("Yes")) {
      // Test Data Injection for Product Bank
      DBReusables.getInstance().executeSqlScript("productBank_CreditPlus.sql");
      DBReusables.getInstance().executeSqlScript("Tranche-CreditPlus-TG.sql");
      DBReusables.getInstance().executeSqlScript("Tranche-CreditPlus-FG1Y.sql");
      // Test Data Injection for Customer with Deposit
      DBReusables.getInstance().executeSqlScript("customerWithPayIn-CreditPlus-FG1Y.sql");
      // Getting customer details
      CustomerEmail = DBReusables.getInstance().getCustomerEmail();
      // Getting Product Details
      SourceTrancheIdentifier = DBReusables.getInstance().getPreviousTrancheIdentifier("FG");
      TargetTrancheIdentifier = DBReusables.getInstance().getTrancheIdentifier("TG");
      ProlongationTrancheIdentifier = DBReusables.getInstance().getTrancheIdentifier("FG");
      IcAmount = "513.00";
      IcType = "PartialIc";
    } else {
      CustomerEmail = sCustomerEmail;
      SourceTrancheIdentifier = sSourceTrancheIdentifier;
      TargetTrancheIdentifier = sTargetTrancheIdentifier;
      IcAmount = sIcAmount;
    }
    String testName = methodName.getName();

    TestLogger.logMsg("==========" + testName + " Started=========");

    // Calling PayOut method
    PaymentServices.getInstance()
        .InvestmentChange(
            testName,
            SourceTrancheIdentifier,
            IcAmount,
            CustomerEmail,
            IcType,
            TargetTrancheIdentifier,
            ProlongationTrancheIdentifier);

    TestLogger.logMsg("==========" + testName + " Completed=========");
  }

  /*
   * Feature: Partial Internal InvestmentChange from Gunda
   * Product Type: FG to TG
   * ProductBank Model: FAM
   * TestRail Link:https://depositsolutions.testrail.io/index.php?/cases/view/11907
   * Author: deepthi.gorre

  @Test(enabled = true, groups = {"InvestmentChange", "Regression"})
  @Parameters({"sourceTrancheIdentifier", "icAmount", "customerEmail", "targetTrancheIdentifier"})
  public void C11907_Gunda_Internal_Partial_InvestmentChange_FAM_FG2TG(Method methodName, String sSourceTrancheIdentifier, String sIcAmount, String sCustomerEmail, String sTargetTrancheIdentifier) throws SQLException, ClassNotFoundException, InterruptedException, AWTException {
      if (testDataInjection.equalsIgnoreCase("Yes")) {
          //Test Data Injection for Product Bank
          DBReusables.getInstance().executeSqlScript("productBank_CreditPlus.sql");
          DBReusables.getInstance().executeSqlScript("Tranche-CreditPlus-TG.sql");
          DBReusables.getInstance().executeSqlScript("Tranche-CreditPlus-FG1Y.sql");
          //Test Data Injection for Customer with Deposit
          DBReusables.getInstance().executeSqlScript("customerWithPayIn-CreditPlus-FG1Y.sql");
          //Getting customer details
          CustomerEmail = DBReusables.getInstance().getCustomerEmail();
          //Getting Product Details
          SourceTrancheIdentifier = DBReusables.getInstance().getPreviousTrancheIdentifier("FG");
          TargetTrancheIdentifier = DBReusables.getInstance().getTrancheIdentifier("TG");
          ProlongationTrancheIdentifier = DBReusables.getInstance().getTrancheIdentifier("FG");
          IcAmount = "513.00";
          IcType = "PartialIc";
      } else {
          CustomerEmail = sCustomerEmail;
          SourceTrancheIdentifier = sSourceTrancheIdentifier;
          TargetTrancheIdentifier = sTargetTrancheIdentifier;
          IcAmount = sIcAmount;
      }
      String testName = methodName.getName();

      TestLogger.logMsg("==========" + testName + " Started=========");

      //Calling PayOut method
      PaymentServices.getInstance().InvestmentChange(testName, SourceTrancheIdentifier, IcAmount, CustomerEmail, IcType, TargetTrancheIdentifier, ProlongationTrancheIdentifier);


      TestLogger.logMsg("==========" + testName + " Completed=========");
  }

   */

  /*
   * Feature: Full Internal InvestmentChange from Shop
   * Product Type: FG to TG
   * ProductBank Model: FAM
   * TestRail Link:https://depositsolutions.testrail.io/index.php?/cases/view/11923
   * Author: deepthi.gorre
   */
  @Test(
      enabled = true,
      groups = {"InvestmentChange", "Regression", "e2e"})
  @Parameters({"sourceTrancheIdentifier", "icAmount", "customerEmail", "targetTrancheIdentifier"})
  public void C11923_Shop_Internal_Full_InvestmentChange_FAM_FG2TG(
      Method methodName,
      String sSourceTrancheIdentifier,
      String sIcAmount,
      String sCustomerEmail,
      String sTargetTrancheIdentifier)
      throws SQLException, ClassNotFoundException, InterruptedException, AWTException {
    if (testDataInjection.equalsIgnoreCase("Yes")) {
      // Test Data Injection for Product Bank
      DBReusables.getInstance().executeSqlScript("productBank_CreditPlus.sql");
      DBReusables.getInstance().executeSqlScript("Tranche-CreditPlus-TG.sql");
      DBReusables.getInstance().executeSqlScript("Tranche-CreditPlus-FG1Y.sql");
      // Test Data Injection for Customer with Deposit
      DBReusables.getInstance().executeSqlScript("customerWithPayIn-CreditPlus-FG1Y.sql");
      // Getting customer details
      CustomerEmail = DBReusables.getInstance().getCustomerEmail();
      // Getting Product Details
      SourceTrancheIdentifier = DBReusables.getInstance().getPreviousTrancheIdentifier("FG");
      TargetTrancheIdentifier = DBReusables.getInstance().getTrancheIdentifier("TG");
      IcType = "FullIc";
    } else {
      CustomerEmail = sCustomerEmail;
      SourceTrancheIdentifier = sSourceTrancheIdentifier;
      TargetTrancheIdentifier = sTargetTrancheIdentifier;
      IcAmount = sIcAmount;
    }
    String testName = methodName.getName();

    TestLogger.logMsg("==========" + testName + " Started=========");

    // Calling PayOut method
    PaymentServices.getInstance()
        .InvestmentChange(
            testName,
            SourceTrancheIdentifier,
            IcAmount,
            CustomerEmail,
            IcType,
            TargetTrancheIdentifier,
            ProlongationTrancheIdentifier);

    TestLogger.logMsg("==========" + testName + " Completed=========");
  }

  /*
   * Feature: Full Internal InvestmentChange from Gunda
   * Product Type: FG to TG
   * ProductBank Model: FAM
   * TestRail Link:https://depositsolutions.testrail.io/index.php?/cases/view/9973
   * Author: deepthi.gorre

  @Test(enabled = true, groups = {"InvestmentChange", "Regression"})
  @Parameters({"sourceTrancheIdentifier", "icAmount", "customerEmail", "targetTrancheIdentifier"})
  public void C9973_Gunda_Internal_Full_InvestmentChange_FAM_FG2TG(Method methodName, String sSourceTrancheIdentifier, String sIcAmount, String sCustomerEmail, String sTargetTrancheIdentifier) throws SQLException, ClassNotFoundException, InterruptedException, AWTException {
      if (testDataInjection.equalsIgnoreCase("Yes")) {
          //Test Data Injection for Product Bank
          DBReusables.getInstance().executeSqlScript("productBank_CreditPlus.sql");
          DBReusables.getInstance().executeSqlScript("Tranche-CreditPlus-TG.sql");
          DBReusables.getInstance().executeSqlScript("Tranche-CreditPlus-FG1Y.sql");
          //Test Data Injection for Customer with Deposit
          DBReusables.getInstance().executeSqlScript("customerWithPayIn-CreditPlus-FG1Y.sql");
          //Getting customer details
          CustomerEmail = DBReusables.getInstance().getCustomerEmail();
          //Getting Product Details
          SourceTrancheIdentifier = DBReusables.getInstance().getPreviousTrancheIdentifier("FG");
          TargetTrancheIdentifier = DBReusables.getInstance().getTrancheIdentifier("TG");
          IcType = "FullIc";
      } else {
          CustomerEmail = sCustomerEmail;
          SourceTrancheIdentifier = sSourceTrancheIdentifier;
          TargetTrancheIdentifier = sTargetTrancheIdentifier;
          IcAmount = sIcAmount;
      }
      String testName = methodName.getName();

      TestLogger.logMsg("==========" + testName + " Started=========");

      //Calling PayOut method
      PaymentServices.getInstance().InvestmentChange(testName, SourceTrancheIdentifier, IcAmount, CustomerEmail, IcType, TargetTrancheIdentifier, ProlongationTrancheIdentifier);


      TestLogger.logMsg("==========" + testName + " Completed=========");
  }

   */

  /*
   * Feature: Partial Internal InvestmentChange from Shop
   * Product Type: TG to FG
   * ProductBank Model: FAM
   * TestRail Link:https://depositsolutions.testrail.io/index.php?/cases/view/11892
   * Author: deepthi.gorre
   */
  @Test(
      enabled = true,
      groups = {"InvestmentChange", "Regression", "e2e"})
  @Parameters({"sourceTrancheIdentifier", "icAmount", "customerEmail", "targetTrancheIdentifier"})
  public void C11892_Shop_Internal_Partial_InvestmentChange_FAM_TG2FG(
      Method methodName,
      String sSourceTrancheIdentifier,
      String sIcAmount,
      String sCustomerEmail,
      String sTargetTrancheIdentifier)
      throws SQLException, ClassNotFoundException, InterruptedException, AWTException {
    if (testDataInjection.equalsIgnoreCase("Yes")) {
      // Test Data Injection for Product Bank
      DBReusables.getInstance().executeSqlScript("productBank_CreditPlus.sql");
      DBReusables.getInstance().executeSqlScript("Tranche-CreditPlus-TG.sql");
      DBReusables.getInstance().executeSqlScript("Tranche-CreditPlus-FG1Y.sql");
      // Test Data Injection for Customer with Deposit
      DBReusables.getInstance().executeSqlScript("customerWithPayIn-CreditPlus-TG.sql");
      // Getting customer details
      CustomerEmail = DBReusables.getInstance().getCustomerEmail();
      // Getting Product Details
      SourceTrancheIdentifier = DBReusables.getInstance().getTrancheIdentifier("TG");
      TargetTrancheIdentifier = DBReusables.getInstance().getTrancheIdentifier("FG");
      IcAmount = "1513.00";
      IcType = "PartialIc";
    } else {
      CustomerEmail = sCustomerEmail;
      SourceTrancheIdentifier = sSourceTrancheIdentifier;
      TargetTrancheIdentifier = sTargetTrancheIdentifier;
      IcAmount = sIcAmount;
    }
    String testName = methodName.getName();

    TestLogger.logMsg("==========" + testName + " Started=========");

    // Calling PayOut method
    PaymentServices.getInstance()
        .InvestmentChange(
            testName,
            SourceTrancheIdentifier,
            IcAmount,
            CustomerEmail,
            IcType,
            TargetTrancheIdentifier,
            ProlongationTrancheIdentifier);

    TestLogger.logMsg("==========" + testName + " Completed=========");
  }

  /*
   * Feature: Partial Internal InvestmentChange from Gunda
   * Product Type: TG to FG
   * ProductBank Model: FAM
   * TestRail Link:https://depositsolutions.testrail.io/index.php?/cases/view/11906
   * Author: deepthi.gorre

  @Test(enabled = true, groups = {"InvestmentChange", "Regression"})
  @Parameters({"sourceTrancheIdentifier", "icAmount", "customerEmail", "targetTrancheIdentifier"})
  public void C11906_Gunda_Internal_Partial_InvestmentChange_FAM_TG2FG(Method methodName, String sSourceTrancheIdentifier, String sIcAmount, String sCustomerEmail, String sTargetTrancheIdentifier) throws SQLException, ClassNotFoundException, InterruptedException, AWTException {
      if (testDataInjection.equalsIgnoreCase("Yes")) {
          //Test Data Injection for Product Bank
          DBReusables.getInstance().executeSqlScript("productBank_CreditPlus.sql");
          DBReusables.getInstance().executeSqlScript("Tranche-CreditPlus-TG.sql");
          DBReusables.getInstance().executeSqlScript("Tranche-CreditPlus-FG1Y.sql");
          //Test Data Injection for Customer with Deposit
          DBReusables.getInstance().executeSqlScript("customerWithPayIn-CreditPlus-TG.sql");
          //Getting customer details
          CustomerEmail = DBReusables.getInstance().getCustomerEmail();
          //Getting Product Details
          SourceTrancheIdentifier = DBReusables.getInstance().getTrancheIdentifier("TG");
          TargetTrancheIdentifier = DBReusables.getInstance().getTrancheIdentifier("FG");
          IcAmount = "1513.00";
          IcType = "PartialIc";
      } else {
          CustomerEmail = sCustomerEmail;
          SourceTrancheIdentifier = sSourceTrancheIdentifier;
          TargetTrancheIdentifier = sTargetTrancheIdentifier;
          IcAmount = sIcAmount;
      }
      String testName = methodName.getName();

      TestLogger.logMsg("==========" + testName + " Started=========");

      //Calling PayOut method
      PaymentServices.getInstance().InvestmentChange(testName, SourceTrancheIdentifier, IcAmount, CustomerEmail, IcType, TargetTrancheIdentifier, ProlongationTrancheIdentifier);


      TestLogger.logMsg("==========" + testName + " Completed=========");
  }

   */

  /*
   * Feature: Full Internal InvestmentChange from Shop
   * Product Type: TG to FG
   * ProductBank Model: FAM
   * TestRail Link:https://depositsolutions.testrail.io/index.php?/cases/view/11922
   * Author: deepthi.gorre
   */
  @Test(
      enabled = true,
      groups = {"InvestmentChange", "Regression"})
  @Parameters({"sourceTrancheIdentifier", "icAmount", "customerEmail", "targetTrancheIdentifier"})
  public void C11922_Shop_Internal_Full_InvestmentChange_FAM_TG2FG(
      Method methodName,
      String sSourceTrancheIdentifier,
      String sIcAmount,
      String sCustomerEmail,
      String sTargetTrancheIdentifier)
      throws SQLException, ClassNotFoundException, InterruptedException, AWTException {
    if (testDataInjection.equalsIgnoreCase("Yes")) {
      // Test Data Injection for Product Bank
      DBReusables.getInstance().executeSqlScript("productBank_CreditPlus.sql");
      DBReusables.getInstance().executeSqlScript("Tranche-CreditPlus-TG.sql");
      DBReusables.getInstance().executeSqlScript("Tranche-CreditPlus-FG1Y.sql");
      // Test Data Injection for Customer with Deposit
      DBReusables.getInstance().executeSqlScript("customerWithPayIn-CreditPlus-TG.sql");
      // Getting customer details
      CustomerEmail = DBReusables.getInstance().getCustomerEmail();
      // Getting Product Details
      SourceTrancheIdentifier = DBReusables.getInstance().getTrancheIdentifier("TG");
      TargetTrancheIdentifier = DBReusables.getInstance().getTrancheIdentifier("FG");
      IcType = "FullIc";
    } else {
      CustomerEmail = sCustomerEmail;
      SourceTrancheIdentifier = sSourceTrancheIdentifier;
      TargetTrancheIdentifier = sTargetTrancheIdentifier;
      IcAmount = sIcAmount;
    }
    String testName = methodName.getName();

    TestLogger.logMsg("==========" + testName + " Started=========");

    // Calling PayOut method
    PaymentServices.getInstance()
        .InvestmentChange(
            testName,
            SourceTrancheIdentifier,
            IcAmount,
            CustomerEmail,
            IcType,
            TargetTrancheIdentifier,
            ProlongationTrancheIdentifier);

    TestLogger.logMsg("==========" + testName + " Completed=========");
  }

  /*
   * Feature: Full Internal InvestmentChange from Gunda
   * Product Type: TG to FG
   * ProductBank Model: FAM
   * TestRail Link:https://depositsolutions.testrail.io/index.php?/cases/view/9971
   * Author: deepthi.gorre

  @Test(enabled = true, groups = {"InvestmentChange", "Regression"})
  @Parameters({"sourceTrancheIdentifier", "icAmount", "customerEmail", "targetTrancheIdentifier"})
  public void C9971_Gunda_Internal_Full_InvestmentChange_FAM_TG2FG(Method methodName, String sSourceTrancheIdentifier, String sIcAmount, String sCustomerEmail, String sTargetTrancheIdentifier) throws SQLException, ClassNotFoundException, InterruptedException, AWTException {
      if (testDataInjection.equalsIgnoreCase("Yes")) {
          //Test Data Injection for Product Bank
          DBReusables.getInstance().executeSqlScript("productBank_CreditPlus.sql");
          DBReusables.getInstance().executeSqlScript("Tranche-CreditPlus-TG.sql");
          DBReusables.getInstance().executeSqlScript("Tranche-CreditPlus-FG1Y.sql");
          //Test Data Injection for Customer with Deposit
          DBReusables.getInstance().executeSqlScript("customerWithPayIn-CreditPlus-TG.sql");
          //Getting customer details
          CustomerEmail = DBReusables.getInstance().getCustomerEmail();
          //Getting Product Details
          SourceTrancheIdentifier = DBReusables.getInstance().getTrancheIdentifier("TG");
          TargetTrancheIdentifier = DBReusables.getInstance().getTrancheIdentifier("FG");
          IcType = "FullIc";
      } else {
          CustomerEmail = sCustomerEmail;
          SourceTrancheIdentifier = sSourceTrancheIdentifier;
          TargetTrancheIdentifier = sTargetTrancheIdentifier;
          IcAmount = sIcAmount;
      }
      String testName = methodName.getName();

      TestLogger.logMsg("==========" + testName + " Started=========");

      //Calling PayOut method
      PaymentServices.getInstance().InvestmentChange(testName, SourceTrancheIdentifier, IcAmount, CustomerEmail, IcType, TargetTrancheIdentifier, ProlongationTrancheIdentifier);


      TestLogger.logMsg("==========" + testName + " Completed=========");
  }

   */

  /*
   * Feature: Full Internal InvestmentChange from Shop
   * Product Type: FG to FG
   * ProductBank Model: FAM
   * TestRail Link:https://depositsolutions.testrail.io/index.php?/cases/view/11925
   * Author: deepthi.gorre

  @Test(enabled = true, groups = {"InvestmentChange", "Regression"})
  @Parameters({"sourceTrancheIdentifier", "icAmount", "customerEmail", "targetTrancheIdentifier"})
  public void C11925_Shop_Internal_Full_InvestmentChange_FAM_FG2FG(Method methodName, String sSourceTrancheIdentifier, String sIcAmount, String sCustomerEmail, String sTargetTrancheIdentifier) throws SQLException, ClassNotFoundException, InterruptedException, AWTException {
      if (testDataInjection.equalsIgnoreCase("Yes")) {
          //Test Data Injection for Product Bank
          DBReusables.getInstance().executeSqlScript("productBank_CreditPlus.sql");
          DBReusables.getInstance().executeSqlScript("Tranche-CreditPlus-FG1Y.sql");
          DBReusables.getInstance().executeSqlScript("Tranche-CreditPlus-FG2Y.sql");
          //Test Data Injection for Customer with Deposit
          DBReusables.getInstance().executeSqlScript("customerWithPayIn-CreditPlus-FG1Y.sql");
          //Getting customer details
          CustomerEmail = DBReusables.getInstance().getCustomerEmail();
          //Getting Product Details
          SourceTrancheIdentifier = DBReusables.getInstance().getPreviousTrancheIdentifier("CPLUDES1XXX-FG12M");
          TargetTrancheIdentifier = DBReusables.getInstance().getTrancheIdentifier("CPLUDES1XXX-FG2Y");
          IcType = "FullIc";
      } else {
          CustomerEmail = sCustomerEmail;
          SourceTrancheIdentifier = sSourceTrancheIdentifier;
          TargetTrancheIdentifier = sTargetTrancheIdentifier;
          IcAmount = sIcAmount;
      }
      String testName = methodName.getName();

      TestLogger.logMsg("==========" + testName + " Started=========");

      //Calling PayOut method
      PaymentServices.getInstance().InvestmentChange(testName, SourceTrancheIdentifier, IcAmount, CustomerEmail, IcType, TargetTrancheIdentifier, ProlongationTrancheIdentifier);


      TestLogger.logMsg("==========" + testName + " Completed=========");
  }

   */

  /*
       * Feature: Full Internal InvestmentChange from Gunda
       * Product Type: FG to FG
       * ProductBank Model: FAM
       * TestRail Link:https://depositsolutions.testrail.io/index.php?/cases/view/11888
       * Author: deepthi.gorre

  @Test(enabled = true, groups = {"InvestmentChange", "Regression"})
  @Parameters({"sourceTrancheIdentifier", "icAmount", "customerEmail", "targetTrancheIdentifier"})
  public void C11888_Gunda_Internal_Full_InvestmentChange_FAM_FG2FG(Method methodName, String sSourceTrancheIdentifier, String sIcAmount, String sCustomerEmail, String sTargetTrancheIdentifier) throws SQLException, ClassNotFoundException, InterruptedException, AWTException {
      if (testDataInjection.equalsIgnoreCase("Yes")) {
          //Test Data Injection for Product Bank
          DBReusables.getInstance().executeSqlScript("productBank_CreditPlus.sql");
          DBReusables.getInstance().executeSqlScript("Tranche-CreditPlus-FG1Y.sql");
          DBReusables.getInstance().executeSqlScript("Tranche-CreditPlus-FG2Y.sql");
          //Test Data Injection for Customer with Deposit
          DBReusables.getInstance().executeSqlScript("customerWithPayIn-CreditPlus-FG1Y.sql");
          //Getting customer details
          CustomerEmail = DBReusables.getInstance().getCustomerEmail();
          //Getting Product Details
          SourceTrancheIdentifier = DBReusables.getInstance().getPreviousTrancheIdentifier("CPLUDES1XXX-FG12M");
          TargetTrancheIdentifier = DBReusables.getInstance().getTrancheIdentifier("CPLUDES1XXX-FG2Y");
          IcType = "FullIc";
      } else {
          CustomerEmail = sCustomerEmail;
          SourceTrancheIdentifier = sSourceTrancheIdentifier;
          TargetTrancheIdentifier = sTargetTrancheIdentifier;
          IcAmount = sIcAmount;
      }
      String testName = methodName.getName();

      TestLogger.logMsg("==========" + testName + " Started=========");

      //Calling PayOut method
      PaymentServices.getInstance().InvestmentChange(testName, SourceTrancheIdentifier, IcAmount, CustomerEmail, IcType, TargetTrancheIdentifier, ProlongationTrancheIdentifier);


      TestLogger.logMsg("==========" + testName + " Completed=========");
  }

       */

  /*
   * Feature: Partial Internal InvestmentChange from Shop
   * Product Type: FG to FG
   * ProductBank Model: FAM
   * TestRail Link:https://depositsolutions.testrail.io/index.php?/cases/view/1651
   * Author: deepthi.gorre

  @Test(enabled = true, groups = {"InvestmentChange", "Regression"})
  @Parameters({"sourceTrancheIdentifier", "icAmount", "customerEmail", "targetTrancheIdentifier"})
  public void C1651_Shop_Internal_Partial_InvestmentChange_FAM_FG2FG(Method methodName, String sSourceTrancheIdentifier, String sIcAmount, String sCustomerEmail, String sTargetTrancheIdentifier) throws SQLException, ClassNotFoundException, InterruptedException, AWTException {
      if (testDataInjection.equalsIgnoreCase("Yes")) {
          //Test Data Injection for Product Bank
          DBReusables.getInstance().executeSqlScript("productBank_CreditPlus.sql");
          DBReusables.getInstance().executeSqlScript("Tranche-CreditPlus-FG1Y.sql");
          DBReusables.getInstance().executeSqlScript("Tranche-CreditPlus-FG2Y.sql");
          //Test Data Injection for Customer with Deposit
          DBReusables.getInstance().executeSqlScript("customerWithPayIn-CreditPlus-FG1Y.sql");
          //Getting customer details
          CustomerEmail = DBReusables.getInstance().getCustomerEmail();
          //Getting Product Details
          SourceTrancheIdentifier = DBReusables.getInstance().getPreviousTrancheIdentifier("CPLUDES1XXX-FG12M");
          TargetTrancheIdentifier = DBReusables.getInstance().getTrancheIdentifier("CPLUDES1XXX-FG2Y");
          ProlongationTrancheIdentifier = DBReusables.getInstance().getTrancheIdentifier("CPLUDES1XXX-FG1Y");
          IcAmount = "513.00";
          IcType = "PartialIc";
      } else {
          CustomerEmail = sCustomerEmail;
          SourceTrancheIdentifier = sSourceTrancheIdentifier;
          TargetTrancheIdentifier = sTargetTrancheIdentifier;
          IcAmount = sIcAmount;
      }
      String testName = methodName.getName();

      TestLogger.logMsg("==========" + testName + " Started=========");

      //Calling PayOut method
      PaymentServices.getInstance().InvestmentChange(testName, SourceTrancheIdentifier, IcAmount, CustomerEmail, IcType, TargetTrancheIdentifier, ProlongationTrancheIdentifier);


      TestLogger.logMsg("==========" + testName + " Completed=========");
  }

   */

  /*
       * Feature: Partial Internal InvestmentChange from Gunda
       * Product Type: FG to FG
       * ProductBank Model: FAM
       * TestRail Link:https://depositsolutions.testrail.io/index.php?/cases/view/11905
       * Author: deepthi.gorre

  @Test(enabled = true, groups = {"InvestmentChange", "Regression"})
  @Parameters({"sourceTrancheIdentifier", "icAmount", "customerEmail", "targetTrancheIdentifier"})
  public void C11905_Gunda_Internal_Partial_InvestmentChange_FAM_FG2FG(Method methodName, String sSourceTrancheIdentifier, String sIcAmount, String sCustomerEmail, String sTargetTrancheIdentifier) throws SQLException, ClassNotFoundException, InterruptedException, AWTException {
      if (testDataInjection.equalsIgnoreCase("Yes")) {
          //Test Data Injection for Product Bank
          DBReusables.getInstance().executeSqlScript("productBank_CreditPlus.sql");
          DBReusables.getInstance().executeSqlScript("Tranche-CreditPlus-FG1Y.sql");
          DBReusables.getInstance().executeSqlScript("Tranche-CreditPlus-FG2Y.sql");
          //Test Data Injection for Customer with Deposit
          DBReusables.getInstance().executeSqlScript("customerWithPayIn-CreditPlus-FG1Y.sql");
          //Getting customer details
          CustomerEmail = DBReusables.getInstance().getCustomerEmail();
          //Getting Product Details
          SourceTrancheIdentifier = DBReusables.getInstance().getPreviousTrancheIdentifier("CPLUDES1XXX-FG12M");
          TargetTrancheIdentifier = DBReusables.getInstance().getTrancheIdentifier("CPLUDES1XXX-FG2Y");
          ProlongationTrancheIdentifier = DBReusables.getInstance().getTrancheIdentifier("CPLUDES1XXX-FG1Y");
          IcAmount = "513.00";
          IcType = "PartialIc";
      } else {
          CustomerEmail = sCustomerEmail;
          SourceTrancheIdentifier = sSourceTrancheIdentifier;
          TargetTrancheIdentifier = sTargetTrancheIdentifier;
          IcAmount = sIcAmount;
      }
      String testName = methodName.getName();

      TestLogger.logMsg("==========" + testName + " Started=========");

      //Calling PayOut method
      PaymentServices.getInstance().InvestmentChange(testName, SourceTrancheIdentifier, IcAmount, CustomerEmail, IcType, TargetTrancheIdentifier, ProlongationTrancheIdentifier);


      TestLogger.logMsg("==========" + testName + " Completed=========");
  }

       */

  /*
   * Feature: Full External/CrossBank InvestmentChange from Shop
   * Product Type: TG to FG
   * ProductBank Model: FAM to FAM
   * TestRail Link:https://depositsolutions.testrail.io/index.php?/cases/view/11902
   * Author: deepthi.gorre
   */
  @Test(
      enabled = true,
      groups = {"InvestmentChange", "Regression"})
  @Parameters({"sourceTrancheIdentifier", "icAmount", "customerEmail", "targetTrancheIdentifier"})
  public void C11902_Shop_External_Full_InvestmentChange_FAM2FAM_TG2FG(
      Method methodName,
      String sSourceTrancheIdentifier,
      String sIcAmount,
      String sCustomerEmail,
      String sTargetTrancheIdentifier)
      throws SQLException, ClassNotFoundException, InterruptedException, AWTException {
    if (testDataInjection.equalsIgnoreCase("Yes")) {
      // Test Data Injection for Product Bank
      DBReusables.getInstance().executeSqlScript("productBank_CreditPlus.sql");
      DBReusables.getInstance().executeSqlScript("Tranche-CreditPlus-TG.sql");
      DBReusables.getInstance().executeSqlScript("productBank_MyMoney.sql");
      DBReusables.getInstance().executeSqlScript("Tranche-MyMoney-FG1Y.sql");
      // Test Data Injection for Customer with Deposit
      DBReusables.getInstance().executeSqlScript("customerWithPayIn-CreditPlus-TG.sql");
      // Getting customer details
      CustomerEmail = DBReusables.getInstance().getCustomerEmail();
      // Getting Product Details
      SourceTrancheIdentifier = DBReusables.getInstance().getTrancheIdentifier("TG");
      TargetTrancheIdentifier = DBReusables.getInstance().getTrancheIdentifier("FG");
      IcType = "FullIc";
    } else {
      CustomerEmail = sCustomerEmail;
      SourceTrancheIdentifier = sSourceTrancheIdentifier;
      TargetTrancheIdentifier = sTargetTrancheIdentifier;
      IcAmount = sIcAmount;
    }
    String testName = methodName.getName();

    TestLogger.logMsg("==========" + testName + " Started=========");

    // Calling PayOut method
    PaymentServices.getInstance()
        .InvestmentChange(
            testName,
            SourceTrancheIdentifier,
            IcAmount,
            CustomerEmail,
            IcType,
            TargetTrancheIdentifier,
            ProlongationTrancheIdentifier);

    TestLogger.logMsg("==========" + testName + " Completed=========");
  }

  /*
   * Feature: Full External/CrossBank InvestmentChange from Shop
   * Product Type: TG to TG
   * ProductBank Model: FAM to FAM
   * TestRail Link:https://depositsolutions.testrail.io/index.php?/cases/view/8873
   * Author: deepthi.gorre
   */
  @Test(
      enabled = true,
      groups = {"InvestmentChange", "Regression", "e2e"})
  @Parameters({"sourceTrancheIdentifier", "icAmount", "customerEmail", "targetTrancheIdentifier"})
  public void C8873_Shop_External_Full_InvestmentChange_FAM2FAM_TG2TG(
      Method methodName,
      String sSourceTrancheIdentifier,
      String sIcAmount,
      String sCustomerEmail,
      String sTargetTrancheIdentifier)
      throws SQLException, ClassNotFoundException, InterruptedException, AWTException {
    if (testDataInjection.equalsIgnoreCase("Yes")) {
      // Test Data Injection for Product Bank
      DBReusables.getInstance().executeSqlScript("productBank_CreditPlus.sql");
      DBReusables.getInstance().executeSqlScript("Tranche-CreditPlus-TG.sql");
      DBReusables.getInstance().executeSqlScript("productBank_MyMoney.sql");
      DBReusables.getInstance().executeSqlScript("Tranche-MyMoney-TG.sql");
      // Test Data Injection for Customer with Deposit
      DBReusables.getInstance().executeSqlScript("customerWithPayIn-CreditPlus-TG.sql");
      // Getting customer details
      CustomerEmail = DBReusables.getInstance().getCustomerEmail();
      // Getting Product Details
      SourceTrancheIdentifier = DBReusables.getInstance().getTrancheIdentifier("CPLUDES1XXX-TG");
      TargetTrancheIdentifier = DBReusables.getInstance().getTrancheIdentifier("MOEYFRPPXXX-TG");
      IcType = "FullIc";
    } else {
      CustomerEmail = sCustomerEmail;
      SourceTrancheIdentifier = sSourceTrancheIdentifier;
      TargetTrancheIdentifier = sTargetTrancheIdentifier;
      IcAmount = sIcAmount;
    }
    String testName = methodName.getName();

    TestLogger.logMsg("==========" + testName + " Started=========");

    // Calling PayOut method
    PaymentServices.getInstance()
        .InvestmentChange(
            testName,
            SourceTrancheIdentifier,
            IcAmount,
            CustomerEmail,
            IcType,
            TargetTrancheIdentifier,
            ProlongationTrancheIdentifier);

    TestLogger.logMsg("==========" + testName + " Completed=========");
  }

  /*
   * Feature: Full External/CrossBank InvestmentChange from Shop
   * Product Type: FG to TG
   * ProductBank Model: FAM to FAM
   * TestRail Link:https://depositsolutions.testrail.io/index.php?/cases/view/11903
   * Author: deepthi.gorre
   */
  @Test(
      enabled = true,
      groups = {"InvestmentChange", "Regression"})
  @Parameters({"sourceTrancheIdentifier", "icAmount", "customerEmail", "targetTrancheIdentifier"})
  public void C11903_Shop_External_Full_InvestmentChange_FAM2FAM_FG2TG(
      Method methodName,
      String sSourceTrancheIdentifier,
      String sIcAmount,
      String sCustomerEmail,
      String sTargetTrancheIdentifier)
      throws SQLException, ClassNotFoundException, InterruptedException, AWTException {
    if (testDataInjection.equalsIgnoreCase("Yes")) {
      // Test Data Injection for Product Bank
      DBReusables.getInstance().executeSqlScript("productBank_CreditPlus.sql");
      DBReusables.getInstance().executeSqlScript("Tranche-CreditPlus-FG1Y.sql");
      DBReusables.getInstance().executeSqlScript("productBank_MyMoney.sql");
      DBReusables.getInstance().executeSqlScript("Tranche-MyMoney-TG.sql");
      // Test Data Injection for Customer with Deposit
      DBReusables.getInstance().executeSqlScript("customerWithPayIn-CreditPlus-FG1Y.sql");
      // Getting customer details
      CustomerEmail = DBReusables.getInstance().getCustomerEmail();
      // Getting Product Details
      SourceTrancheIdentifier = DBReusables.getInstance().getPreviousTrancheIdentifier("FG");
      TargetTrancheIdentifier = DBReusables.getInstance().getTrancheIdentifier("TG");
      IcType = "FullIc";
    } else {
      CustomerEmail = sCustomerEmail;
      SourceTrancheIdentifier = sSourceTrancheIdentifier;
      TargetTrancheIdentifier = sTargetTrancheIdentifier;
      IcAmount = sIcAmount;
    }
    String testName = methodName.getName();

    TestLogger.logMsg("==========" + testName + " Started=========");

    // Calling PayOut method
    PaymentServices.getInstance()
        .InvestmentChange(
            testName,
            SourceTrancheIdentifier,
            IcAmount,
            CustomerEmail,
            IcType,
            TargetTrancheIdentifier,
            ProlongationTrancheIdentifier);

    TestLogger.logMsg("==========" + testName + " Completed=========");
  }

  /*
   * Feature: Full External/CrossBank InvestmentChange from Shop
   * Product Type: FG to FG
   * ProductBank Model: FAM to FAM
   * TestRail Link:https://depositsolutions.testrail.io/index.php?/cases/view/11907
   * Author: deepthi.gorre
   */
  @Test(
      enabled = true,
      groups = {"InvestmentChange", "Regression"})
  @Parameters({"sourceTrancheIdentifier", "icAmount", "customerEmail", "targetTrancheIdentifier"})
  public void C11907_Shop_External_Full_InvestmentChange_FAM2FAM_FG2FG(
      Method methodName,
      String sSourceTrancheIdentifier,
      String sIcAmount,
      String sCustomerEmail,
      String sTargetTrancheIdentifier)
      throws SQLException, ClassNotFoundException, InterruptedException, AWTException {
    if (testDataInjection.equalsIgnoreCase("Yes")) {
      // Test Data Injection for Product Bank
      DBReusables.getInstance().executeSqlScript("productBank_CreditPlus.sql");
      DBReusables.getInstance().executeSqlScript("Tranche-CreditPlus-FG1Y.sql");
      DBReusables.getInstance().executeSqlScript("productBank_MyMoney.sql");
      DBReusables.getInstance().executeSqlScript("Tranche-MyMoney-FG1Y.sql");
      // Test Data Injection for Customer with Deposit
      DBReusables.getInstance().executeSqlScript("customerWithPayIn-CreditPlus-FG1Y.sql");
      // Getting customer details
      CustomerEmail = DBReusables.getInstance().getCustomerEmail();
      // Getting Product Details
      SourceTrancheIdentifier =
          DBReusables.getInstance().getPreviousTrancheIdentifier("CPLUDES1XXX");
      TargetTrancheIdentifier = DBReusables.getInstance().getTrancheIdentifier("MOEYFRPPXXX");
      IcType = "FullIc";
    } else {
      CustomerEmail = sCustomerEmail;
      SourceTrancheIdentifier = sSourceTrancheIdentifier;
      TargetTrancheIdentifier = sTargetTrancheIdentifier;
      IcAmount = sIcAmount;
    }
    String testName = methodName.getName();

    TestLogger.logMsg("==========" + testName + " Started=========");

    // Calling PayOut method
    PaymentServices.getInstance()
        .InvestmentChange(
            testName,
            SourceTrancheIdentifier,
            IcAmount,
            CustomerEmail,
            IcType,
            TargetTrancheIdentifier,
            ProlongationTrancheIdentifier);

    TestLogger.logMsg("==========" + testName + " Completed=========");
  }

  /*
   * Feature: Partial External/CrossBank InvestmentChange from Shop
   * Product Type: TG to FG
   * ProductBank Model: FAM to FAM
   * TestRail Link:https://depositsolutions.testrail.io/index.php?/cases/view/3056
   * Author: deepthi.gorre
   */
  @Test(
      enabled = true,
      groups = {"InvestmentChange", "Regression"})
  @Parameters({"sourceTrancheIdentifier", "icAmount", "customerEmail", "targetTrancheIdentifier"})
  public void C3056_Shop_External_Partial_InvestmentChange_FAM2FAM_TG2FG(
      Method methodName,
      String sSourceTrancheIdentifier,
      String sIcAmount,
      String sCustomerEmail,
      String sTargetTrancheIdentifier)
      throws SQLException, ClassNotFoundException, InterruptedException, AWTException {
    if (testDataInjection.equalsIgnoreCase("Yes")) {
      // Test Data Injection for Product Bank
      DBReusables.getInstance().executeSqlScript("productBank_CreditPlus.sql");
      DBReusables.getInstance().executeSqlScript("Tranche-CreditPlus-TG.sql");
      DBReusables.getInstance().executeSqlScript("productBank_MyMoney.sql");
      DBReusables.getInstance().executeSqlScript("Tranche-MyMoney-FG1Y.sql");
      // Test Data Injection for Customer with Deposit
      DBReusables.getInstance().executeSqlScript("customerWithPayIn-CreditPlus-TG.sql");
      // Getting customer details
      CustomerEmail = DBReusables.getInstance().getCustomerEmail();
      // Getting Product Details
      SourceTrancheIdentifier = DBReusables.getInstance().getTrancheIdentifier("TG");
      TargetTrancheIdentifier = DBReusables.getInstance().getTrancheIdentifier("FG");
      IcAmount = "513.00";
      IcType = "PartialIc";
    } else {
      CustomerEmail = sCustomerEmail;
      SourceTrancheIdentifier = sSourceTrancheIdentifier;
      TargetTrancheIdentifier = sTargetTrancheIdentifier;
      IcAmount = sIcAmount;
    }
    String testName = methodName.getName();

    TestLogger.logMsg("==========" + testName + " Started=========");

    // Calling PayOut method
    PaymentServices.getInstance()
        .InvestmentChange(
            testName,
            SourceTrancheIdentifier,
            IcAmount,
            CustomerEmail,
            IcType,
            TargetTrancheIdentifier,
            ProlongationTrancheIdentifier);

    TestLogger.logMsg("==========" + testName + " Completed=========");
  }

  /*
   * Feature: Partial External/CrossBank InvestmentChange from Shop
   * Product Type: TG to TG
   * ProductBank Model: FAM to FAM
   * TestRail Link:https://depositsolutions.testrail.io/index.php?/cases/view/11869
   * Author: deepthi.gorre
   */
  @Test(
      enabled = true,
      groups = {"InvestmentChange", "Regression"})
  @Parameters({"sourceTrancheIdentifier", "icAmount", "customerEmail", "targetTrancheIdentifier"})
  public void C11869_Shop_External_Partial_InvestmentChange_FAM2FAM_TG2TG(
      Method methodName,
      String sSourceTrancheIdentifier,
      String sIcAmount,
      String sCustomerEmail,
      String sTargetTrancheIdentifier)
      throws SQLException, ClassNotFoundException, InterruptedException, AWTException {
    if (testDataInjection.equalsIgnoreCase("Yes")) {
      // Test Data Injection for Product Bank
      DBReusables.getInstance().executeSqlScript("productBank_CreditPlus.sql");
      DBReusables.getInstance().executeSqlScript("Tranche-CreditPlus-TG.sql");
      DBReusables.getInstance().executeSqlScript("productBank_MyMoney.sql");
      DBReusables.getInstance().executeSqlScript("Tranche-MyMoney-TG.sql");
      // Test Data Injection for Customer with Deposit
      DBReusables.getInstance().executeSqlScript("customerWithPayIn-CreditPlus-TG.sql");
      // Getting customer details
      CustomerEmail = DBReusables.getInstance().getCustomerEmail();
      // Getting Product Details
      SourceTrancheIdentifier = DBReusables.getInstance().getTrancheIdentifier("CPLUDES1XXX");
      TargetTrancheIdentifier = DBReusables.getInstance().getTrancheIdentifier("MOEYFRPPXXX");
      IcAmount = "513.00";
      IcType = "PartialIc";
    } else {
      CustomerEmail = sCustomerEmail;
      SourceTrancheIdentifier = sSourceTrancheIdentifier;
      TargetTrancheIdentifier = sTargetTrancheIdentifier;
      IcAmount = sIcAmount;
    }
    String testName = methodName.getName();

    TestLogger.logMsg("==========" + testName + " Started=========");

    // Calling PayOut method
    PaymentServices.getInstance()
        .InvestmentChange(
            testName,
            SourceTrancheIdentifier,
            IcAmount,
            CustomerEmail,
            IcType,
            TargetTrancheIdentifier,
            ProlongationTrancheIdentifier);

    TestLogger.logMsg("==========" + testName + " Completed=========");
  }

  /*
   * Feature: Partial External/CrossBank InvestmentChange from Shop
   * Product Type: FG to TG
   * ProductBank Model: FAM to FAM
   * TestRail Link:https://depositsolutions.testrail.io/index.php?/cases/view/7555
   * Author: deepthi.gorre
   */
  @Test(
      enabled = true,
      groups = {"InvestmentChange", "Regression"})
  @Parameters({"sourceTrancheIdentifier", "icAmount", "customerEmail", "targetTrancheIdentifier"})
  public void C7555_Shop_External_Partial_InvestmentChange_FAM2FAM_FG2TG(
      Method methodName,
      String sSourceTrancheIdentifier,
      String sIcAmount,
      String sCustomerEmail,
      String sTargetTrancheIdentifier)
      throws SQLException, ClassNotFoundException, InterruptedException, AWTException {
    if (testDataInjection.equalsIgnoreCase("Yes")) {
      // Test Data Injection for Product Bank
      DBReusables.getInstance().executeSqlScript("productBank_CreditPlus.sql");
      DBReusables.getInstance().executeSqlScript("Tranche-CreditPlus-FG1Y.sql");
      DBReusables.getInstance().executeSqlScript("productBank_MyMoney.sql");
      DBReusables.getInstance().executeSqlScript("Tranche-MyMoney-TG.sql");
      // Test Data Injection for Customer with Deposit
      DBReusables.getInstance().executeSqlScript("customerWithPayIn-CreditPlus-FG1Y.sql");
      // Getting customer details
      CustomerEmail = DBReusables.getInstance().getCustomerEmail();
      // Getting Product Details
      SourceTrancheIdentifier = DBReusables.getInstance().getPreviousTrancheIdentifier("FG");
      TargetTrancheIdentifier = DBReusables.getInstance().getTrancheIdentifier("TG");
      ProlongationTrancheIdentifier = DBReusables.getInstance().getTrancheIdentifier("FG");
      IcAmount = "513.00";
      IcType = "PartialIc";
    } else {
      CustomerEmail = sCustomerEmail;
      SourceTrancheIdentifier = sSourceTrancheIdentifier;
      TargetTrancheIdentifier = sTargetTrancheIdentifier;
      IcAmount = sIcAmount;
    }
    String testName = methodName.getName();

    TestLogger.logMsg("==========" + testName + " Started=========");

    // Calling PayOut method
    PaymentServices.getInstance()
        .InvestmentChange(
            testName,
            SourceTrancheIdentifier,
            IcAmount,
            CustomerEmail,
            IcType,
            TargetTrancheIdentifier,
            ProlongationTrancheIdentifier);

    TestLogger.logMsg("==========" + testName + " Completed=========");
  }

  /*
   * Feature: Partial External/CrossBank InvestmentChange from Shop
   * Product Type: FG to FG
   * ProductBank Model: FAM to FAM
   * TestRail Link:https://depositsolutions.testrail.io/index.php?/cases/view/1650
   * Author: deepthi.gorre
   */
  @Test(
      enabled = true,
      groups = {"InvestmentChange", "Regression", "e2e"})
  @Parameters({"sourceTrancheIdentifier", "icAmount", "customerEmail", "targetTrancheIdentifier"})
  public void C1650_Shop_External_Partial_InvestmentChange_FAM2FAM_FG2FG(
      Method methodName,
      String sSourceTrancheIdentifier,
      String sIcAmount,
      String sCustomerEmail,
      String sTargetTrancheIdentifier)
      throws SQLException, ClassNotFoundException, InterruptedException, AWTException {
    if (testDataInjection.equalsIgnoreCase("Yes")) {
      // Test Data Injection for Product Bank
      DBReusables.getInstance().executeSqlScript("productBank_CreditPlus.sql");
      DBReusables.getInstance().executeSqlScript("Tranche-CreditPlus-FG1Y.sql");
      DBReusables.getInstance().executeSqlScript("productBank_MyMoney.sql");
      DBReusables.getInstance().executeSqlScript("Tranche-MyMoney-FG1Y.sql");
      // Test Data Injection for Customer with Deposit
      DBReusables.getInstance().executeSqlScript("customerWithPayIn-CreditPlus-FG1Y.sql");
      // Getting customer details
      CustomerEmail = DBReusables.getInstance().getCustomerEmail();
      // Getting Product Details
      SourceTrancheIdentifier =
          DBReusables.getInstance().getPreviousTrancheIdentifier("CPLUDES1XXX");
      TargetTrancheIdentifier = DBReusables.getInstance().getTrancheIdentifier("MOEYFRPPXXX");
      ProlongationTrancheIdentifier = DBReusables.getInstance().getTrancheIdentifier("CPLUDES1XXX");
      IcAmount = "513.00";
      IcType = "PartialIc";
    } else {
      CustomerEmail = sCustomerEmail;
      SourceTrancheIdentifier = sSourceTrancheIdentifier;
      TargetTrancheIdentifier = sTargetTrancheIdentifier;
      IcAmount = sIcAmount;
    }
    String testName = methodName.getName();

    TestLogger.logMsg("==========" + testName + " Started=========");

    // Calling PayOut method
    PaymentServices.getInstance()
        .InvestmentChange(
            testName,
            SourceTrancheIdentifier,
            IcAmount,
            CustomerEmail,
            IcType,
            TargetTrancheIdentifier,
            ProlongationTrancheIdentifier);

    TestLogger.logMsg("==========" + testName + " Completed=========");
  }

  /*
   * Feature: Full External/CrossBank InvestmentChange from Gunda
   * Product Type: TG to FG
   * ProductBank Model: FAM to FAM
   * TestRail Link:https://depositsolutions.testrail.io/index.php?/cases/view/11910
   * Author: deepthi.gorre
   */
  @Test(
      enabled = true,
      groups = {"InvestmentChange", "Regression"})
  @Parameters({"sourceTrancheIdentifier", "icAmount", "customerEmail", "targetTrancheIdentifier"})
  public void C11910_Gunda_External_Full_InvestmentChange_FAM2FAM_TG2FG(
      Method methodName,
      String sSourceTrancheIdentifier,
      String sIcAmount,
      String sCustomerEmail,
      String sTargetTrancheIdentifier)
      throws SQLException, ClassNotFoundException, InterruptedException, AWTException {
    if (testDataInjection.equalsIgnoreCase("Yes")) {
      // Test Data Injection for Product Bank
      DBReusables.getInstance().executeSqlScript("productBank_CreditPlus.sql");
      DBReusables.getInstance().executeSqlScript("Tranche-CreditPlus-TG.sql");
      DBReusables.getInstance().executeSqlScript("productBank_MyMoney.sql");
      DBReusables.getInstance().executeSqlScript("Tranche-MyMoney-FG1Y.sql");
      // Test Data Injection for Customer with Deposit
      DBReusables.getInstance().executeSqlScript("customerWithPayIn-CreditPlus-TG.sql");
      // Getting customer details
      CustomerEmail = DBReusables.getInstance().getCustomerEmail();
      // Getting Product Details
      SourceTrancheIdentifier = DBReusables.getInstance().getTrancheIdentifier("TG");
      TargetTrancheIdentifier = DBReusables.getInstance().getTrancheIdentifier("FG");
      IcType = "FullIc";
    } else {
      CustomerEmail = sCustomerEmail;
      SourceTrancheIdentifier = sSourceTrancheIdentifier;
      TargetTrancheIdentifier = sTargetTrancheIdentifier;
      IcAmount = sIcAmount;
    }
    String testName = methodName.getName();

    TestLogger.logMsg("==========" + testName + " Started=========");

    // Calling PayOut method
    PaymentServices.getInstance()
        .InvestmentChange(
            testName,
            SourceTrancheIdentifier,
            IcAmount,
            CustomerEmail,
            IcType,
            TargetTrancheIdentifier,
            ProlongationTrancheIdentifier);

    TestLogger.logMsg("==========" + testName + " Completed=========");
  }

  /*
   * Feature: Full External/CrossBank InvestmentChange from Gunda
   * Product Type: TG to TG
   * ProductBank Model: FAM to FAM
   * TestRail Link:https://depositsolutions.testrail.io/index.php?/cases/view/11908
   * Author: deepthi.gorre
   */
  @Test(
      enabled = true,
      groups = {"InvestmentChange", "Regression"})
  @Parameters({"sourceTrancheIdentifier", "icAmount", "customerEmail", "targetTrancheIdentifier"})
  public void C11908_Gunda_External_Full_InvestmentChange_FAM2FAM_TG2TG(
      Method methodName,
      String sSourceTrancheIdentifier,
      String sIcAmount,
      String sCustomerEmail,
      String sTargetTrancheIdentifier)
      throws SQLException, ClassNotFoundException, InterruptedException, AWTException {
    if (testDataInjection.equalsIgnoreCase("Yes")) {
      // Test Data Injection for Product Bank
      DBReusables.getInstance().executeSqlScript("productBank_CreditPlus.sql");
      DBReusables.getInstance().executeSqlScript("Tranche-CreditPlus-TG.sql");
      DBReusables.getInstance().executeSqlScript("productBank_MyMoney.sql");
      DBReusables.getInstance().executeSqlScript("Tranche-MyMoney-TG.sql");
      // Test Data Injection for Customer with Deposit
      DBReusables.getInstance().executeSqlScript("customerWithPayIn-CreditPlus-TG.sql");
      // Getting customer details
      CustomerEmail = DBReusables.getInstance().getCustomerEmail();
      // Getting Product Details
      SourceTrancheIdentifier = DBReusables.getInstance().getTrancheIdentifier("CPLUDES1XXX-TG");
      TargetTrancheIdentifier = DBReusables.getInstance().getTrancheIdentifier("MOEYFRPPXXX-TG");
      IcType = "FullIc";
    } else {
      CustomerEmail = sCustomerEmail;
      SourceTrancheIdentifier = sSourceTrancheIdentifier;
      TargetTrancheIdentifier = sTargetTrancheIdentifier;
      IcAmount = sIcAmount;
    }
    String testName = methodName.getName();

    TestLogger.logMsg("==========" + testName + " Started=========");

    // Calling PayOut method
    PaymentServices.getInstance()
        .InvestmentChange(
            testName,
            SourceTrancheIdentifier,
            IcAmount,
            CustomerEmail,
            IcType,
            TargetTrancheIdentifier,
            ProlongationTrancheIdentifier);

    TestLogger.logMsg("==========" + testName + " Completed=========");
  }

  /*
   * Feature: Full External/CrossBank InvestmentChange from Gunda
   * Product Type: FG to TG
   * ProductBank Model: FAM to FAM
   * TestRail Link:https://depositsolutions.testrail.io/index.php?/cases/view/11911
   * Author: deepthi.gorre
   */
  @Test(
      enabled = true,
      groups = {"InvestmentChange", "Regression"})
  @Parameters({"sourceTrancheIdentifier", "icAmount", "customerEmail", "targetTrancheIdentifier"})
  public void C11911_Gunda_External_Full_InvestmentChange_FAM2FAM_FG2TG(
      Method methodName,
      String sSourceTrancheIdentifier,
      String sIcAmount,
      String sCustomerEmail,
      String sTargetTrancheIdentifier)
      throws SQLException, ClassNotFoundException, InterruptedException, AWTException {
    if (testDataInjection.equalsIgnoreCase("Yes")) {
      // Test Data Injection for Product Bank
      DBReusables.getInstance().executeSqlScript("productBank_CreditPlus.sql");
      DBReusables.getInstance().executeSqlScript("Tranche-CreditPlus-FG1Y.sql");
      DBReusables.getInstance().executeSqlScript("productBank_MyMoney.sql");
      DBReusables.getInstance().executeSqlScript("Tranche-MyMoney-TG.sql");
      // Test Data Injection for Customer with Deposit
      DBReusables.getInstance().executeSqlScript("customerWithPayIn-CreditPlus-FG1Y.sql");
      // Getting customer details
      CustomerEmail = DBReusables.getInstance().getCustomerEmail();
      // Getting Product Details
      SourceTrancheIdentifier = DBReusables.getInstance().getPreviousTrancheIdentifier("FG");
      TargetTrancheIdentifier = DBReusables.getInstance().getTrancheIdentifier("TG");
      IcType = "FullIc";
    } else {
      CustomerEmail = sCustomerEmail;
      SourceTrancheIdentifier = sSourceTrancheIdentifier;
      TargetTrancheIdentifier = sTargetTrancheIdentifier;
      IcAmount = sIcAmount;
    }
    String testName = methodName.getName();

    TestLogger.logMsg("==========" + testName + " Started=========");

    // Calling PayOut method
    PaymentServices.getInstance()
        .InvestmentChange(
            testName,
            SourceTrancheIdentifier,
            IcAmount,
            CustomerEmail,
            IcType,
            TargetTrancheIdentifier,
            ProlongationTrancheIdentifier);

    TestLogger.logMsg("==========" + testName + " Completed=========");
  }

  /*
   * Feature: Full External/CrossBank InvestmentChange from Gunda
   * Product Type: FG to FG
   * ProductBank Model: FAM to FAM
   * TestRail Link:https://depositsolutions.testrail.io/index.php?/cases/view/11912
   * Author: deepthi.gorre
   */
  @Test(
      enabled = true,
      groups = {"InvestmentChange", "Regression"})
  @Parameters({"sourceTrancheIdentifier", "icAmount", "customerEmail", "targetTrancheIdentifier"})
  public void C11912_Gunda_External_Full_InvestmentChange_FAM2FAM_FG2FG(
      Method methodName,
      String sSourceTrancheIdentifier,
      String sIcAmount,
      String sCustomerEmail,
      String sTargetTrancheIdentifier)
      throws SQLException, ClassNotFoundException, InterruptedException, AWTException {
    if (testDataInjection.equalsIgnoreCase("Yes")) {
      // Test Data Injection for Product Bank
      DBReusables.getInstance().executeSqlScript("productBank_CreditPlus.sql");
      DBReusables.getInstance().executeSqlScript("Tranche-CreditPlus-FG1Y.sql");
      DBReusables.getInstance().executeSqlScript("productBank_MyMoney.sql");
      DBReusables.getInstance().executeSqlScript("Tranche-MyMoney-FG1Y.sql");
      // Test Data Injection for Customer with Deposit
      DBReusables.getInstance().executeSqlScript("customerWithPayIn-CreditPlus-FG1Y.sql");
      // Getting customer details
      CustomerEmail = DBReusables.getInstance().getCustomerEmail();
      // Getting Product Details
      SourceTrancheIdentifier =
          DBReusables.getInstance().getPreviousTrancheIdentifier("CPLUDES1XXX");
      TargetTrancheIdentifier = DBReusables.getInstance().getTrancheIdentifier("MOEYFRPPXXX");
      IcType = "FullIc";
    } else {
      CustomerEmail = sCustomerEmail;
      SourceTrancheIdentifier = sSourceTrancheIdentifier;
      TargetTrancheIdentifier = sTargetTrancheIdentifier;
      IcAmount = sIcAmount;
    }
    String testName = methodName.getName();

    TestLogger.logMsg("==========" + testName + " Started=========");

    // Calling PayOut method
    PaymentServices.getInstance()
        .InvestmentChange(
            testName,
            SourceTrancheIdentifier,
            IcAmount,
            CustomerEmail,
            IcType,
            TargetTrancheIdentifier,
            ProlongationTrancheIdentifier);

    TestLogger.logMsg("==========" + testName + " Completed=========");
  }

  /*
   * Feature: Partial External/CrossBank InvestmentChange from Gunda
   * Product Type: TG to FG
   * ProductBank Model: FAM to FAM
   * TestRail Link:https://depositsolutions.testrail.io/index.php?/cases/view/11930
   * Author: deepthi.gorre
   */
  @Test(
      enabled = true,
      groups = {"InvestmentChange", "Regression"})
  @Parameters({"sourceTrancheIdentifier", "icAmount", "customerEmail", "targetTrancheIdentifier"})
  public void C11930_Gunda_External_Partial_InvestmentChange_FAM2FAM_TG2FG(
      Method methodName,
      String sSourceTrancheIdentifier,
      String sIcAmount,
      String sCustomerEmail,
      String sTargetTrancheIdentifier)
      throws SQLException, ClassNotFoundException, InterruptedException, AWTException {
    if (testDataInjection.equalsIgnoreCase("Yes")) {
      // Test Data Injection for Product Bank
      DBReusables.getInstance().executeSqlScript("productBank_CreditPlus.sql");
      DBReusables.getInstance().executeSqlScript("Tranche-CreditPlus-TG.sql");
      DBReusables.getInstance().executeSqlScript("productBank_MyMoney.sql");
      DBReusables.getInstance().executeSqlScript("Tranche-MyMoney-FG1Y.sql");
      // Test Data Injection for Customer with Deposit
      DBReusables.getInstance().executeSqlScript("customerWithPayIn-CreditPlus-TG.sql");
      // Getting customer details
      CustomerEmail = DBReusables.getInstance().getCustomerEmail();
      // Getting Product Details
      SourceTrancheIdentifier = DBReusables.getInstance().getTrancheIdentifier("TG");
      TargetTrancheIdentifier = DBReusables.getInstance().getTrancheIdentifier("FG");
      IcAmount = "513.00";
      IcType = "PartialIc";
    } else {
      CustomerEmail = sCustomerEmail;
      SourceTrancheIdentifier = sSourceTrancheIdentifier;
      TargetTrancheIdentifier = sTargetTrancheIdentifier;
      IcAmount = sIcAmount;
    }
    String testName = methodName.getName();

    TestLogger.logMsg("==========" + testName + " Started=========");

    // Calling PayOut method
    PaymentServices.getInstance()
        .InvestmentChange(
            testName,
            SourceTrancheIdentifier,
            IcAmount,
            CustomerEmail,
            IcType,
            TargetTrancheIdentifier,
            ProlongationTrancheIdentifier);

    TestLogger.logMsg("==========" + testName + " Completed=========");
  }

  /*
   * Feature: Partial External/CrossBank InvestmentChange from Gunda
   * Product Type: TG to TG
   * ProductBank Model: FAM to FAM
   * TestRail Link:https://depositsolutions.testrail.io/index.php?/cases/view/11933
   * Author: deepthi.gorre
   */
  @Test(
      enabled = true,
      groups = {"InvestmentChange", "Regression"})
  @Parameters({"sourceTrancheIdentifier", "icAmount", "customerEmail", "targetTrancheIdentifier"})
  public void C11933_Gunda_External_Partial_InvestmentChange_FAM2FAM_TG2TG(
      Method methodName,
      String sSourceTrancheIdentifier,
      String sIcAmount,
      String sCustomerEmail,
      String sTargetTrancheIdentifier)
      throws SQLException, ClassNotFoundException, InterruptedException, AWTException {
    if (testDataInjection.equalsIgnoreCase("Yes")) {
      // Test Data Injection for Product Bank
      DBReusables.getInstance().executeSqlScript("productBank_CreditPlus.sql");
      DBReusables.getInstance().executeSqlScript("Tranche-CreditPlus-TG.sql");
      DBReusables.getInstance().executeSqlScript("productBank_MyMoney.sql");
      DBReusables.getInstance().executeSqlScript("Tranche-MyMoney-TG.sql");
      // Test Data Injection for Customer with Deposit
      DBReusables.getInstance().executeSqlScript("customerWithPayIn-CreditPlus-TG.sql");
      // Getting customer details
      CustomerEmail = DBReusables.getInstance().getCustomerEmail();
      // Getting Product Details
      SourceTrancheIdentifier = DBReusables.getInstance().getTrancheIdentifier("CPLUDES1XXX-TG");
      TargetTrancheIdentifier = DBReusables.getInstance().getTrancheIdentifier("MOEYFRPPXXX-TG");
      IcAmount = "513.00";
      IcType = "PartialIc";
    } else {
      CustomerEmail = sCustomerEmail;
      SourceTrancheIdentifier = sSourceTrancheIdentifier;
      TargetTrancheIdentifier = sTargetTrancheIdentifier;
      IcAmount = sIcAmount;
    }
    String testName = methodName.getName();

    TestLogger.logMsg("==========" + testName + " Started=========");

    // Calling PayOut method
    PaymentServices.getInstance()
        .InvestmentChange(
            testName,
            SourceTrancheIdentifier,
            IcAmount,
            CustomerEmail,
            IcType,
            TargetTrancheIdentifier,
            ProlongationTrancheIdentifier);

    TestLogger.logMsg("==========" + testName + " Completed=========");
  }

  /*
   * Feature: Partial External/CrossBank InvestmentChange from Gunda
   * Product Type: FG to TG
   * ProductBank Model: FAM to FAM
   * TestRail Link:https://depositsolutions.testrail.io/index.php?/cases/view/11932
   * Author: deepthi.gorre
   */
  @Test(
      enabled = true,
      groups = {"InvestmentChange", "Regression"})
  @Parameters({"sourceTrancheIdentifier", "icAmount", "customerEmail", "targetTrancheIdentifier"})
  public void C11932_Gunda_External_Partial_InvestmentChange_FAM2FAM_FG2TG(
      Method methodName,
      String sSourceTrancheIdentifier,
      String sIcAmount,
      String sCustomerEmail,
      String sTargetTrancheIdentifier)
      throws SQLException, ClassNotFoundException, InterruptedException, AWTException {
    if (testDataInjection.equalsIgnoreCase("Yes")) {
      // Test Data Injection for Product Bank
      DBReusables.getInstance().executeSqlScript("productBank_CreditPlus.sql");
      DBReusables.getInstance().executeSqlScript("Tranche-CreditPlus-FG1Y.sql");
      DBReusables.getInstance().executeSqlScript("productBank_MyMoney.sql");
      DBReusables.getInstance().executeSqlScript("Tranche-MyMoney-TG.sql");
      // Test Data Injection for Customer with Deposit
      DBReusables.getInstance().executeSqlScript("customerWithPayIn-CreditPlus-FG1Y.sql");
      // Getting customer details
      CustomerEmail = DBReusables.getInstance().getCustomerEmail();
      // Getting Product Details
      SourceTrancheIdentifier = DBReusables.getInstance().getPreviousTrancheIdentifier("FG");
      TargetTrancheIdentifier = DBReusables.getInstance().getTrancheIdentifier("TG");
      ProlongationTrancheIdentifier = DBReusables.getInstance().getTrancheIdentifier("FG");
      IcAmount = "513.00";
      IcType = "PartialIc";
    } else {
      CustomerEmail = sCustomerEmail;
      SourceTrancheIdentifier = sSourceTrancheIdentifier;
      TargetTrancheIdentifier = sTargetTrancheIdentifier;
      IcAmount = sIcAmount;
    }
    String testName = methodName.getName();

    TestLogger.logMsg("==========" + testName + " Started=========");

    // Calling PayOut method
    PaymentServices.getInstance()
        .InvestmentChange(
            testName,
            SourceTrancheIdentifier,
            IcAmount,
            CustomerEmail,
            IcType,
            TargetTrancheIdentifier,
            ProlongationTrancheIdentifier);

    TestLogger.logMsg("==========" + testName + " Completed=========");
  }

  /*
   * Feature: Partial External/CrossBank InvestmentChange from Gunda
   * Product Type: FG to FG
   * ProductBank Model: FAM to FAM
   * TestRail Link:https://depositsolutions.testrail.io/index.php?/cases/view/11929
   * Author: deepthi.gorre
   */
  @Test(
      enabled = true,
      groups = {"InvestmentChange", "Regression"})
  @Parameters({"sourceTrancheIdentifier", "icAmount", "customerEmail", "targetTrancheIdentifier"})
  public void C11929_Gunda_External_Partial_InvestmentChange_FAM2FAM_FG2FG(
      Method methodName,
      String sSourceTrancheIdentifier,
      String sIcAmount,
      String sCustomerEmail,
      String sTargetTrancheIdentifier)
      throws SQLException, ClassNotFoundException, InterruptedException, AWTException {
    if (testDataInjection.equalsIgnoreCase("Yes")) {
      // Test Data Injection for Product Bank
      DBReusables.getInstance().executeSqlScript("productBank_CreditPlus.sql");
      DBReusables.getInstance().executeSqlScript("Tranche-CreditPlus-FG1Y.sql");
      DBReusables.getInstance().executeSqlScript("productBank_MyMoney.sql");
      DBReusables.getInstance().executeSqlScript("Tranche-MyMoney-FG1Y.sql");
      // Test Data Injection for Customer with Deposit
      DBReusables.getInstance().executeSqlScript("customerWithPayIn-CreditPlus-FG1Y.sql");
      // Getting customer details
      CustomerEmail = DBReusables.getInstance().getCustomerEmail();
      // Getting Product Details
      SourceTrancheIdentifier =
          DBReusables.getInstance().getPreviousTrancheIdentifier("CPLUDES1XXX");
      TargetTrancheIdentifier = DBReusables.getInstance().getTrancheIdentifier("MOEYFRPPXXX");
      ProlongationTrancheIdentifier = DBReusables.getInstance().getTrancheIdentifier("CPLUDES1XXX");
      IcAmount = "513.00";
      IcType = "PartialIc";
    } else {
      CustomerEmail = sCustomerEmail;
      SourceTrancheIdentifier = sSourceTrancheIdentifier;
      TargetTrancheIdentifier = sTargetTrancheIdentifier;
      IcAmount = sIcAmount;
    }
    String testName = methodName.getName();

    TestLogger.logMsg("==========" + testName + " Started=========");

    // Calling PayOut method
    PaymentServices.getInstance()
        .InvestmentChange(
            testName,
            SourceTrancheIdentifier,
            IcAmount,
            CustomerEmail,
            IcType,
            TargetTrancheIdentifier,
            ProlongationTrancheIdentifier);

    TestLogger.logMsg("==========" + testName + " Completed=========");
  }
  /*
   * Feature: Partial External/CrossBank InvestmentChange from Shop into CACF Call-a-like
   * Product Type: FG to TG
   * ProductBank Model: FAM to DRM
   * TestRail Links:https://depositsolutions.testrail.io/index.php?/cases/view/9484
   * https://depositsolutions.testrail.io/index.php?/cases/view/4275
   * Author: deepthi.gorre
   */
  @Test(
      enabled = true,
      groups = {"InvestmentChange", "Regression", "CACF"})
  @Parameters({"sourceTrancheIdentifier", "icAmount", "customerEmail", "targetTrancheIdentifier"})
  public void C4275_C9484_Shop_External_Partial_InvestmentChange_FAM2DRM_FG2TGCACF(
      Method methodName,
      String sSourceTrancheIdentifier,
      String sIcAmount,
      String sCustomerEmail,
      String sTargetTrancheIdentifier)
      throws SQLException, ClassNotFoundException, InterruptedException, AWTException {
    if (testDataInjection.equalsIgnoreCase("Yes")) {
      // Test Data Injection for Product Bank
      DBReusables.getInstance().executeSqlScript("productBank_CreditPlus.sql");
      DBReusables.getInstance().executeSqlScript("Tranche-CreditPlus-FG1Y.sql");
      DBReusables.getInstance().executeSqlScript("productBank-CACF.sql");
      DBReusables.getInstance().executeSqlScript("Tranche-CACF-TG.sql");
      // Test Data Injection for Customer with Deposit
      DBReusables.getInstance().executeSqlScript("customerWithPayIn-CreditPlus-FG1Y.sql");
      // Getting customer details
      CustomerEmail = DBReusables.getInstance().getCustomerEmail();
      // Getting Product Details
      SourceTrancheIdentifier = DBReusables.getInstance().getPreviousTrancheIdentifier("FG");
      TargetTrancheIdentifier = DBReusables.getInstance().getTrancheIdentifier("TG");
      ProlongationTrancheIdentifier = DBReusables.getInstance().getTrancheIdentifier("FG");
      IcAmount = "513.00";
      IcType = "PartialIc";
    } else {
      CustomerEmail = sCustomerEmail;
      SourceTrancheIdentifier = sSourceTrancheIdentifier;
      TargetTrancheIdentifier = sTargetTrancheIdentifier;
      IcAmount = sIcAmount;
    }
    String testName = methodName.getName();

    TestLogger.logMsg("==========" + testName + " Started=========");

    // Calling PayOut method
    PaymentServices.getInstance()
        .InvestmentChange(
            testName,
            SourceTrancheIdentifier,
            IcAmount,
            CustomerEmail,
            IcType,
            TargetTrancheIdentifier,
            ProlongationTrancheIdentifier);

    TestLogger.logMsg("==========" + testName + " Completed=========");
  }

  @Test(
      enabled = true,
      groups = {"InvestmentChange", "Regression"})
  @Parameters({"sourceTrancheIdentifier", "icAmount", "customerEmail", "targetTrancheIdentifier"})
  public void C7573_Shop_InvestmentChange_FAM2DRM_Rekyc(
      Method methodName,
      String sSourceTrancheIdentifier,
      String sIcAmount,
      String sCustomerEmail,
      String sTargetTrancheIdentifier)
      throws SQLException, ClassNotFoundException, InterruptedException, AWTException {
    if (testDataInjection.equalsIgnoreCase("Yes")) {
      // Test Data Injection for Product Bank
      DBReusables.getInstance().executeSqlScript("productBank_CreditPlus.sql");
      DBReusables.getInstance().executeSqlScript("Tranche-CreditPlus-FG1Y.sql");
      DBReusables.getInstance().executeSqlScript("productBank-SUFGDE-DRM.sql");
      DBReusables.getInstance().executeSqlScript("Tranche-SUFGDE-FG1Y.sql");
      // Test Data Injection for Customer with Deposit
      DBReusables.getInstance().executeSqlScript("customerWithPayIn-CreditPlus-FG1Y.sql");
      // Getting customer details
      CustomerEmail = DBReusables.getInstance().getCustomerEmail();
      // Getting Product Details
      SourceTrancheIdentifier =
          DBReusables.getInstance().getPreviousTrancheIdentifier("CPLUDES1XXX");
      TargetTrancheIdentifier = DBReusables.getInstance().getTrancheIdentifier("SUFGDE51XXX");
      IcType = "FullIc";
    } else {
      CustomerEmail = sCustomerEmail;
      SourceTrancheIdentifier = sSourceTrancheIdentifier;
      TargetTrancheIdentifier = sTargetTrancheIdentifier;
      IcAmount = sIcAmount;
    }
    String testName = methodName.getName();

    TestLogger.logMsg("==========" + testName + " Started=========");

    DecimalFormat twoPlaces = new DecimalFormat("0.00");
    String ServiceBank_BIC = "MHSBDEHBXXX";

    // calling SB & PB Iban method
    PaymentServices.getInstance().SBandPB_IBAN(ServiceBank_BIC, SourceTrancheIdentifier);

    String TotalBalanceAmount =
        DBReusables.getInstance().getCIAB_Balance(SourceTrancheIdentifier, CustomerEmail);

    IcAmount = TotalBalanceAmount;

    String FormatedIcAmount =
        (DBReusables.getInstance()
            .formatCurrency(IcAmount)
            .substring(0, DBReusables.getInstance().formatCurrency(IcAmount).indexOf(" ")));
    String ProlongationAmount =
        String.valueOf(
            twoPlaces.format(
                Double.parseDouble(TotalBalanceAmount) - (Double.parseDouble(IcAmount))));

    ShopLoginLogoutPO.getInstance().shopLogin(ENV, CustomerEmail);
    MeineAnlagenPO.getInstance().getInvestmentDetails(SourceTrancheIdentifier, CustomerEmail);
    TestLogger.logMsg("Step-1: Investment Change Mapping and Create IC from UI");
    // Investment Change Mapping
    Deposit.getInstance().investmentChangeMapping(SourceTrancheIdentifier, TargetTrancheIdentifier);
    // Initiating IC from UI

    ShopLoginLogoutPO.getInstance().shopCache();
    WebUIOperations.getInstance()
        .waitForElementAndClick(getWebElement(MeineAnlagenPO.getInstance().ZP_IC));

    DRIVER
        .findElement(
            By.id(
                "btn-change-product-"
                    + DBReusables.getInstance().getTrancheUUID(TargetTrancheIdentifier)))
        .click();

    WebUIOperations.getInstance()
        .sendKeys(getWebElement(MeineAnlagenPO.getInstance().ZP_Amount), FormatedIcAmount);
    WebUIOperations.getInstance()
        .waitForElementAndClick(getWebElement(MeineAnlagenPO.getInstance().ZP_confirm));

    WebUIOperations.getInstance()
        .waitForElementAndClick(getWebElement(MeineAnlagenPO.getInstance().drm_agreement));

    // check for ennable of DRM button
    Assert.assertEquals(
        DRIVER.findElement(ProductDetailsPO.getInstance().drm_accept).getAttribute("class"),
        "btn btn-info",
        "DRM button is not enabled");
    WebUIOperations.getInstance()
        .waitForElementAndClick(getWebElement(MeineAnlagenPO.getInstance().drm_accept));

    WebUIOperations.getInstance()
        .verifyElementIsPresent(getWebElement(MeineAnlagenPO.getInstance().Rekyc_Hint), "Rekyc");
    String Rekyc_HintText = getWebElement(MeineAnlagenPO.getInstance().Rekyc_Hint).getText();

    Assert.assertTrue(
        Rekyc_HintText.contains("Bitte klicken Sie hier, um eine erneute Legitimation zu starten"));
  }

  @AfterMethod(alwaysRun = true)
  public void teardown(ITestResult result) {
    if (ITestResult.FAILURE == result.getStatus()) {
      takeScreenshot(result.getName());
    }
    TestLogger.logInfo("Executing Browser tearDown method");
    ShopLoginLogoutPO.getInstance().closeAllBrowsers();
  }

  @AfterTest(alwaysRun = true)
  public void cleanup() throws SQLException {
    TestLogger.logInfo("Executing DB Cleanup");
    DBReusables.getInstance().closeDBCon();
  }
}
