package com.depositsolutions.zinspilot.e2e.shopui;

import static com.depositsolutions.common.reusables.TestConstants.SHOP_URL_CONFIG_KEY;

import com.depositsolutions.common.reusables.DBReusables;
import com.depositsolutions.common.ui.helpers.BaseTestClassUI;
import com.depositsolutions.common.ui.zpuipageobjects.MeineAnlagenPO;
import com.depositsolutions.common.ui.zpuipageobjects.ShopLoginLogoutPO;
import com.depositsolutions.common.utils.ConfigManager;
import com.depositsolutions.common.utils.TestLogger;
import java.lang.reflect.Method;
import java.sql.SQLException;
import org.testng.annotations.*;

public class CreatePayoutFromShop extends BaseTestClassUI {

  public String ServiceBank_BIC = "MHSBDEHBXXX";
  String CIA;
  String FormatedPayOutAmount;
  private String testDataInjection = ConfigManager.getInstance().getString("testDataInjection");
  String CustomerEmail, SourceTrancheIdentifier, PayOutType, PayOutAmount;

  @BeforeTest(alwaysRun = true)
  public void setupDB() {
    DBReusables.getInstance().dbConnect();
  }

  @BeforeMethod(alwaysRun = true)
  @Parameters({"sourceTrancheIdentifier", "payOutAmount", "customerEmail", "payOutType"})
  public void preLoadSQLTestData(
      String sSourceTrancheIdentifier,
      String sPayOutAmount,
      String sCustomerEmail,
      String sPayOutType)
      throws InterruptedException {
    if (testDataInjection.equalsIgnoreCase("Yes")) {
      DBReusables.getInstance().executeSqlScript("TruncateAllTables.sql");
      DBReusables.getInstance().executeSqlScript("serviceBank-sutor.sql");
      // Test Data Injection for Product Bank
      DBReusables.getInstance().executeSqlScript("productBank_CreditPlus.sql");
      DBReusables.getInstance().executeSqlScript("Tranche-CreditPlus-TG.sql");
      // Test Data Injection for Customer with Deposit
      DBReusables.getInstance().executeSqlScript("customerWithPayIn-CreditPlus-TG.sql");
      // Getting customer details
      CustomerEmail = DBReusables.getInstance().getCustomerEmail();
      // Getting Product Details
      SourceTrancheIdentifier = DBReusables.getInstance().getTrancheIdentifier("TG");
      PayOutType = "PartialPayOut";
      PayOutAmount = "513.00";
    } else {
      // Truncate sps Tables
      DBReusables.getInstance().executeSqlScript("TruncateSPSTables.sql");
      CustomerEmail = sCustomerEmail;
      SourceTrancheIdentifier = sSourceTrancheIdentifier;
      PayOutAmount = sPayOutAmount;
      PayOutType = sPayOutType;
    }
    setUpForTest(ConfigManager.getInstance().getString(SHOP_URL_CONFIG_KEY));
    CIA =
        DBReusables.getInstance()
            .getCIA(
                DBReusables.getInstance().getCustomerNumber(CustomerEmail),
                SourceTrancheIdentifier,
                ServiceBank_BIC);
    FormatedPayOutAmount =
        (DBReusables.getInstance()
            .formatCurrency(PayOutAmount)
            .substring(0, DBReusables.getInstance().formatCurrency(PayOutAmount).indexOf(" ")));
    // Shop Login
    ShopLoginLogoutPO.getInstance().shopLogin(ENV, CustomerEmail);
    MeineAnlagenPO.getInstance().getInvestmentDetails(SourceTrancheIdentifier, CustomerEmail);
  }

  /*
   * Feature: Create PayOut from Shop
   * Product Type:Call/Call-a-like
   * TestRail Link:https://depositsolutions.testrail.io/index.php?/cases/view/1648
   *              https://depositsolutions.testrail.io/index.php?/cases/view/1649
   * Author: deepthi.gorre
   */
  @Test(
      enabled = true,
      groups = {"Payout", "Regression", "ShopUI"})
  public void C1649_C1648_Complete_Flex_UI_PayOut(Method methodName) throws InterruptedException {
    String testName = methodName.getName();

    TestLogger.logMsg("==========" + testName + " Started==========");
    // complete pay Out from Shop
    MeineAnlagenPO.getInstance().initiatePayOutShop(FormatedPayOutAmount, PayOutType, CIA);
    TestLogger.logMsg("==========" + testName + " Completed==========");
  }

  /*
   * Feature: Cancel PayOut in Shop
   * Product Type:Call/Call-a-like
   * TestRail Link:https://depositsolutions.testrail.io/index.php?/cases/view/11875
   * Author: deepthi.gorre
   */
  @Test(
      enabled = true,
      groups = {"Payout", "Regression", "ShopUI"})
  public void C11875_Cancel_Flex_UI_PayOut(Method methodName) throws InterruptedException {
    String testName = methodName.getName();

    TestLogger.logMsg("==========" + testName + " Started==========");
    // Cancel Pay Out from Shop
    MeineAnlagenPO.getInstance().cancelPayOutShop(FormatedPayOutAmount, PayOutType, CIA);
    TestLogger.logMsg("==========" + testName + " Completed==========");
  }

  @AfterMethod(alwaysRun = true)
  public void teardown() {

    TestLogger.logInfo("Executing Browser tearDown method");
    ShopLoginLogoutPO.getInstance().closeAllBrowsers();
  }

  @AfterTest(alwaysRun = true)
  public void cleanup() throws SQLException {
    DBReusables.getInstance().closeDBCon();
  }
}
