package com.depositsolutions.zinspilot.e2e.prolongation;

import static com.depositsolutions.common.reusables.TestConstants.SHOP_URL_CONFIG_KEY;

import com.depositsolutions.common.restapi.helpers.WebServiceOperations;
import com.depositsolutions.common.restapi.services.Gunda;
import com.depositsolutions.common.restapi.services.ProdOps;
import com.depositsolutions.common.reusables.DBReusables;
import com.depositsolutions.common.reusables.GundaServices;
import com.depositsolutions.common.ui.helpers.BaseTestClassUI;
import com.depositsolutions.common.ui.zpuipageobjects.GundaPO;
import com.depositsolutions.common.ui.zpuipageobjects.MeineAnlagenPO;
import com.depositsolutions.common.ui.zpuipageobjects.ShopLoginLogoutPO;
import com.depositsolutions.common.utils.ConfigManager;
import com.depositsolutions.common.utils.TestLogger;
import java.awt.AWTException;
import java.lang.reflect.Method;
import java.sql.SQLException;
import org.testng.Assert;
import org.testng.ITestResult;
import org.testng.annotations.*;

public class C1694_CustomerProlongationSettings extends BaseTestClassUI {
  public String ServiceBank_BIC = "MHSBDEHBXXX";
  private String testDataInjection = ConfigManager.getInstance().getString("testDataInjection");
  String CustomerEmail, SourceTrancheIdentifier, PayOutAmount;

  @BeforeTest(alwaysRun = true)
  public void setupDB() {
    DBReusables.getInstance().dbConnect();
  }

  @BeforeMethod(alwaysRun = true)
  public void preLoadSQLTestData() {
    if (testDataInjection.equalsIgnoreCase("Yes")) {
      // Truncate All Tables
      DBReusables.getInstance().executeSqlScript("TruncateAllTables.sql");
      // Test Data Injection for Customer and Service Bank
      DBReusables.getInstance().executeSqlScript("serviceBank-sutor.sql");
      // Test Data Injection for Product Bank
      DBReusables.getInstance().executeSqlScript("productBank_CreditPlus.sql");
      DBReusables.getInstance().executeSqlScript("Tranche-CreditPlus-FG1Y.sql");
      // Test Data Injection for Customer with Deposit
      DBReusables.getInstance().executeSqlScript("customerWithPayIn-CreditPlus-FG1Y.sql");
      // Getting customer details
      CustomerEmail = DBReusables.getInstance().getCustomerEmail();
      // Getting Product Details
      SourceTrancheIdentifier = DBReusables.getInstance().getPreviousTrancheIdentifier("FG");
      PayOutAmount = "513.00";
    }
    setUpForTest(ConfigManager.getInstance().getString(SHOP_URL_CONFIG_KEY));
  }

  /*
   * Feature: Customer Prolongation Settings from Shop
   * Product Type:Fixed Term
   * Product Bank Model:FIDUCIARY_ACCOUNT_MODEL(FAM)
   * TestRail Link: https://depositsolutions.testrail.io/index.php?/cases/view/1694
   * Author: deepthi.gorre
   */
  @Test(
      enabled = true,
      groups = {"Prolongation", "Regression", "e2e"})
  @Parameters({"sourceTrancheIdentifier", "payOutAmount", "customerEmail"})
  public void C1694_Shop_CustomerProlongationSettings(
      Method methodName,
      String sSourceTrancheIdentifier,
      String sPayOutAmount,
      String sCustomerEmail)
      throws InterruptedException, AWTException {
    if (testDataInjection.equalsIgnoreCase("No")) {

      CustomerEmail = sCustomerEmail;
      SourceTrancheIdentifier = sSourceTrancheIdentifier;
      PayOutAmount = sPayOutAmount;
    }
    String testName = methodName.getName();
    TestLogger.logMsg("==========" + testName + " Started==========");
    String CustomerNumber = DBReusables.getInstance().getCustomerNumber(CustomerEmail);
    String CIA =
        DBReusables.getInstance().getCIA(CustomerNumber, SourceTrancheIdentifier, ServiceBank_BIC);
    String FormatedPayOutAmount =
        (DBReusables.getInstance()
            .formatCurrency(PayOutAmount)
            .substring(0, DBReusables.getInstance().formatCurrency(PayOutAmount).indexOf(" ")));
    // checking prolongation and changing to active if needed
    if (DBReusables.getInstance()
        .getProlongation_status(SourceTrancheIdentifier)
        .equalsIgnoreCase("false")) {
      ProdOps.getInstance().Prodops_PB_Prolongation_setting("true", SourceTrancheIdentifier);
    }

    // shop login
    ShopLoginLogoutPO.getInstance().shopLogin(ENV, CustomerEmail);
    DRIVER.findElement(MeineAnlagenPO.getInstance().ZP_MeineAnlagen).click();
    MeineAnlagenPO.getInstance().verifyZPProductDetails(SourceTrancheIdentifier);
    TestLogger.logMsg("*** CustomerProlongationSettings for FullProlongation ***");

    // shop setting and validation
    TestLogger.logMsg("Step-1: Setting FullProlongation in Shop");
    MeineAnlagenPO.getInstance()
        .shopProlongationSettings(
            SourceTrancheIdentifier, "FullProlongation", FormatedPayOutAmount);
    MeineAnlagenPO.getInstance().initiateProlongation();
    Assert.assertNotNull(
        DRIVER.findElement(MeineAnlagenPO.getInstance().FullProlongation).getAttribute("checked"));
    Assert.assertNull(
        DRIVER
            .findElement(MeineAnlagenPO.getInstance().PartialProlongation)
            .getAttribute("checked"));
    Assert.assertNull(
        DRIVER.findElement(MeineAnlagenPO.getInstance().NoProlongation).getAttribute("checked"));
    TestLogger.logInfo("Validated customerProlongationSettings in Shop");
    System.out.println("Validated customerProlongationSettings in Shop");
    // DB validation
    Assert.assertEquals(
        DBReusables.getInstance().getCustomerProlongationEntry(CIA),
        "ALL",
        "DB status is not correct");
    TestLogger.logInfo("Validated customerProlongationSettings in DB");

    // Gunda validation
    Assert.assertEquals(
        (WebServiceOperations.getInstance()
            .convertStringToJson(Gunda.getInstance().Gunda_GetCustomer(CustomerNumber))
            .getString(
                "affiliations[0].customerInterestAccountsDetails["
                    + GundaServices.getInstance().getCIA_Array(CustomerNumber, CIA)
                    + "].prolongationType")),
        "ALL",
        "Gunda status is not correct");
    Assert.assertNull(
        (WebServiceOperations.getInstance()
            .convertStringToJson(Gunda.getInstance().Gunda_GetCustomer(CustomerNumber))
            .getString(
                "affiliations[0].customerInterestAccountsDetails["
                    + GundaServices.getInstance().getCIA_Array(CustomerNumber, CIA)
                    + "].prolongationPayOutAmount")),
        "Gunda prolongation amount is not correct");

    TestLogger.logInfo("Validated customerProlongationSettings in Gunda");

    TestLogger.logMsg("*** CustomerProlongationSettings for NoProlongation ***");

    // shop setting and validation
    TestLogger.logMsg("Step-2: Setting NoProlongation in Shop");
    MeineAnlagenPO.getInstance()
        .shopProlongationSettings(SourceTrancheIdentifier, "NoProlongation", FormatedPayOutAmount);
    MeineAnlagenPO.getInstance().initiateProlongation();
    Assert.assertNull(
        DRIVER.findElement(MeineAnlagenPO.getInstance().FullProlongation).getAttribute("checked"));
    Assert.assertNull(
        DRIVER
            .findElement(MeineAnlagenPO.getInstance().PartialProlongation)
            .getAttribute("checked"));
    Assert.assertNotNull(
        DRIVER.findElement(MeineAnlagenPO.getInstance().NoProlongation).getAttribute("checked"));
    TestLogger.logInfo("Validated customerProlongationSettings in Shop");

    // DB validation
    Assert.assertEquals(
        DBReusables.getInstance().getCustomerProlongationEntry(CIA),
        "NONE",
        "DB status is not correct");
    TestLogger.logInfo("Validated customerProlongationSettings in DB");

    // Gunda validation
    String amount =
        DBReusables.getInstance().getCIAB_Balance(SourceTrancheIdentifier, CustomerEmail);
    Assert.assertEquals(
        (WebServiceOperations.getInstance()
            .convertStringToJson(Gunda.getInstance().Gunda_GetCustomer(CustomerNumber))
            .getString(
                "affiliations[0].customerInterestAccountsDetails["
                    + GundaServices.getInstance().getCIA_Array(CustomerNumber, CIA)
                    + "].prolongationType")),
        "NONE",
        "Gunda status is not correct");
    // this is a bug raised with CCA Team
    // Assert.assertEquals((WebServiceOperations.getInstance().convertStringToJson(CoreBLServices.getInstance().Gunda_GetCustomer(CustomerNumber)).getString("affiliations[0].customerInterestAccountsDetails["+ GundaServices.getInstance().getCIA_Array(CustomerNumber,CIA) +"].prolongationPayOutAmount")),DBReusables.getInstance().formatCurrency1(amount).substring(1,DBReusables.getInstance().formatCurrency1(amount).length())+" EUR","Gunda prolongation amount is not correct");
    TestLogger.logInfo("Validated customerProlongationSettings in Gunda");

    TestLogger.logMsg("*** CustomerProlongationSettings for PartialProlongation ***");

    // shop setting and validation
    TestLogger.logMsg("Step-3: Setting PartialProlongation in Shop");
    MeineAnlagenPO.getInstance()
        .shopProlongationSettings(
            SourceTrancheIdentifier, "PartialProlongation", FormatedPayOutAmount);
    MeineAnlagenPO.getInstance().initiateProlongation();
    Assert.assertNull(
        DRIVER.findElement(MeineAnlagenPO.getInstance().FullProlongation).getAttribute("checked"));
    Assert.assertNotNull(
        DRIVER
            .findElement(MeineAnlagenPO.getInstance().PartialProlongation)
            .getAttribute("checked"));
    Assert.assertNull(
        DRIVER.findElement(MeineAnlagenPO.getInstance().NoProlongation).getAttribute("checked"));
    TestLogger.logInfo("Validated customerProlongationSettings in Shop");

    // DB validation
    Assert.assertEquals(
        DBReusables.getInstance().getCustomerProlongationEntry(CIA),
        "PARTIAL",
        "DB status is not correct");
    TestLogger.logInfo("Validated customerProlongationSettings in DB");

    // Gunda validation
    Assert.assertEquals(
        (WebServiceOperations.getInstance()
            .convertStringToJson(Gunda.getInstance().Gunda_GetCustomer(CustomerNumber))
            .getString(
                "affiliations[0].customerInterestAccountsDetails["
                    + GundaServices.getInstance().getCIA_Array(CustomerNumber, CIA)
                    + "].prolongationType")),
        "PARTIAL",
        "Gunda status is not correct");
    // this is a bug raised with CCA Team
    // Assert.assertEquals((WebServiceOperations.getInstance().convertStringToJson(CoreBLServices.getInstance().Gunda_GetCustomer(CustomerNumber)).getString("affiliations[0].customerInterestAccountsDetails["+ GundaServices.getInstance().getCIA_Array(CustomerNumber,CIA) +"].prolongationPayOutAmount")),DBReusables.getInstance().formatCurrency1(amount).substring(1,DBReusables.getInstance().formatCurrency1(amount).length())+" EUR","Gunda prolongation amount is not correct");

    TestLogger.logInfo("Validated customerProlongationSettings in Gunda");
    TestLogger.logMsg("==========" + testName + " Completed==========");
  }

  /*
   * Feature: Customer Prolongation Settings from Gunda
   * Product Type:Fixed Term
   * Product Bank Model:FIDUCIARY_ACCOUNT_MODEL(FAM)
   * TestRail Link: https://depositsolutions.testrail.io/index.php?/cases/view/1695
   * Author: deepthi.gorre
   */
  @Test(
      enabled = true,
      groups = {"Prolongation", "Regression"})
  @Parameters({"sourceTrancheIdentifier", "payOutAmount", "customerEmail"})
  public void C1695_Gunda_CustomerProlongationSettings(
      Method methodName,
      String sSourceTrancheIdentifier,
      String sPayOutAmount,
      String sCustomerEmail)
      throws InterruptedException {
    if (testDataInjection.equalsIgnoreCase("No")) {
      CustomerEmail = sCustomerEmail;
      SourceTrancheIdentifier = sSourceTrancheIdentifier;
      PayOutAmount = sPayOutAmount;
    }
    String testName = methodName.getName();
    TestLogger.logMsg("==========" + testName + " Started==========");
    String CustomerNumber = DBReusables.getInstance().getCustomerNumber(CustomerEmail);
    String CIA =
        DBReusables.getInstance().getCIA(CustomerNumber, SourceTrancheIdentifier, ServiceBank_BIC);
    String FormatedPayOutAmount =
        (DBReusables.getInstance()
            .formatCurrency(PayOutAmount)
            .substring(0, DBReusables.getInstance().formatCurrency(PayOutAmount).indexOf(" ")));
    // checking prolongation and changing to active if needed
    if (DBReusables.getInstance()
        .getProlongation_status(SourceTrancheIdentifier)
        .equalsIgnoreCase("false")) {
      ProdOps.getInstance().Prodops_PB_Prolongation_setting("true", SourceTrancheIdentifier);
    }

    // shop login
    ShopLoginLogoutPO.getInstance().shopLogin(ENV, CustomerEmail);
    DRIVER.findElement(MeineAnlagenPO.getInstance().ZP_MeineAnlagen).click();
    MeineAnlagenPO.getInstance().verifyZPProductDetails(SourceTrancheIdentifier);
    TestLogger.logMsg("*** CustomerProlongationSettings for FullProlongation ***");

    // Gunda setting and validation
    TestLogger.logMsg("Step-1: Setting FullProlongation in Gunda");
    GundaPO.getInstance()
        .gundaProlongationSettings(
            SourceTrancheIdentifier, "FullProlongation", FormatedPayOutAmount, CustomerNumber, CIA);

    // Shop validation
    MeineAnlagenPO.getInstance().initiateProlongation();
    Assert.assertNotNull(
        DRIVER.findElement(MeineAnlagenPO.getInstance().FullProlongation).getAttribute("checked"));
    Assert.assertNull(
        DRIVER
            .findElement(MeineAnlagenPO.getInstance().PartialProlongation)
            .getAttribute("checked"));
    Assert.assertNull(
        DRIVER.findElement(MeineAnlagenPO.getInstance().NoProlongation).getAttribute("checked"));
    TestLogger.logInfo("Validated customerProlongationSettings in Shop");

    // DB validation
    Assert.assertEquals(
        DBReusables.getInstance().getCustomerProlongationEntry(CIA),
        "ALL",
        "DB status is not correct");
    TestLogger.logInfo("Validated customerProlongationSettings in DB");
    TestLogger.logMsg("*** CustomerProlongationSettings for NoProlongation ***");

    // Gunda setting and validation
    TestLogger.logMsg("Step-2: Setting NoProlongation in Gunda");
    GundaPO.getInstance()
        .gundaProlongationSettings(
            SourceTrancheIdentifier, "NoProlongation", FormatedPayOutAmount, CustomerNumber, CIA);
    TestLogger.logInfo("Validated customerProlongationSettings in Gunda");

    // Shop validation
    MeineAnlagenPO.getInstance().initiateProlongation();
    Assert.assertNull(
        DRIVER.findElement(MeineAnlagenPO.getInstance().FullProlongation).getAttribute("checked"));
    Assert.assertNull(
        DRIVER
            .findElement(MeineAnlagenPO.getInstance().PartialProlongation)
            .getAttribute("checked"));
    Assert.assertNotNull(
        DRIVER.findElement(MeineAnlagenPO.getInstance().NoProlongation).getAttribute("checked"));
    TestLogger.logInfo("Validated customerProlongationSettings in Shop");

    // DB validation
    Assert.assertEquals(
        DBReusables.getInstance().getCustomerProlongationEntry(CIA),
        "NONE",
        "DB status is not correct");
    TestLogger.logInfo("Validated customerProlongationSettings in DB");

    TestLogger.logMsg("*** CustomerProlongationSettings for PartialProlongation ***");

    // Gunda setting and validation
    TestLogger.logMsg("Step-3: Setting PartialProlongation in Gunda");
    GundaPO.getInstance()
        .gundaProlongationSettings(
            SourceTrancheIdentifier,
            "PartialProlongation",
            FormatedPayOutAmount,
            CustomerNumber,
            CIA);
    TestLogger.logInfo("Validated customerProlongationSettings in Gunda");

    // Shop validation
    MeineAnlagenPO.getInstance().initiateProlongation();
    Assert.assertNull(
        DRIVER.findElement(MeineAnlagenPO.getInstance().FullProlongation).getAttribute("checked"));
    Assert.assertNotNull(
        DRIVER
            .findElement(MeineAnlagenPO.getInstance().PartialProlongation)
            .getAttribute("checked"));
    Assert.assertNull(
        DRIVER.findElement(MeineAnlagenPO.getInstance().NoProlongation).getAttribute("checked"));
    TestLogger.logInfo("Validated customerProlongationSettings in Shop");

    // DB validation
    Assert.assertEquals(
        DBReusables.getInstance().getCustomerProlongationEntry(CIA),
        "PARTIAL",
        "DB status is not correct");
    TestLogger.logInfo("Validated customerProlongationSettings in DB");

    TestLogger.logMsg("==========" + testName + " Completed==========");
  }

  @AfterMethod(alwaysRun = true)
  public void teardown(ITestResult result) {
    if (ITestResult.FAILURE == result.getStatus()) {
      takeScreenshot(result.getName());
    }
    TestLogger.logInfo("Executing Browser tearDown method");
    ShopLoginLogoutPO.getInstance().closeAllBrowsers();
  }

  @AfterTest(alwaysRun = true)
  public void cleanup() throws SQLException {
    DBReusables.getInstance().closeDBCon();
  }
}
