package com.depositsolutions.zinspilot.e2e.payout;

import static com.depositsolutions.common.reusables.TestConstants.SHOP_URL_CONFIG_KEY;

import com.depositsolutions.common.restapi.helpers.WebServiceOperations;
import com.depositsolutions.common.restapi.services.Gunda;
import com.depositsolutions.common.reusables.DBReusables;
import com.depositsolutions.common.reusables.GundaServices;
import com.depositsolutions.common.reusables.PaymentServices;
import com.depositsolutions.common.ui.helpers.BaseTestClassUI;
import com.depositsolutions.common.ui.zpuipageobjects.GundaPO;
import com.depositsolutions.common.ui.zpuipageobjects.MeineAnlagenPO;
import com.depositsolutions.common.ui.zpuipageobjects.ShopLoginLogoutPO;
import com.depositsolutions.common.utils.ConfigManager;
import com.depositsolutions.common.utils.TestLogger;
import io.restassured.path.json.JsonPath;
import java.lang.reflect.Method;
import java.sql.SQLException;
import java.text.DecimalFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import org.testng.Assert;
import org.testng.ITestResult;
import org.testng.annotations.*;

public class PayOutButton extends BaseTestClassUI {

  private String testDataInjection = ConfigManager.getInstance().getString("testDataInjection");
  String CustomerEmail,
      TrancheIdentifier,
      SourceTrancheIdentifier,
      PayOutType = null,
      PayOutAmount = null;

  @BeforeTest(alwaysRun = true)
  public void setupDB() {
    DBReusables.getInstance().dbConnect();
  }

  @BeforeMethod(alwaysRun = true)
  public void preLoadSQLTestData() throws InterruptedException {
    if (testDataInjection.equalsIgnoreCase("Yes")) {
      DBReusables.getInstance().executeSqlScript("TruncateAllTables.sql");
      DBReusables.getInstance().executeSqlScript("serviceBank-sutor.sql");
    }
    setUpForTest(ConfigManager.getInstance().getString(SHOP_URL_CONFIG_KEY));
  }

  /*
   * Feature: Validate Payout Button is in disabled Mode
   *
   * TestRail Link:https://depositsolutions.testrail.io/index.php?/cases/view/7566
   *  Author: shalini.sudam
   */
  @Test(
      enabled = true,
      groups = {"Payout", "Regression", "ShopUI"})
  @Parameters({"sourceTrancheIdentifier", "customerEmail"})
  public void C7566_testPayOutButtonIsDisabledForFAM(
      Method methodName, String sSourceTrancheIdentifier, String sCustomerEmail) {

    if (testDataInjection.equalsIgnoreCase("Yes")) {
      // Test Data Injection for Product Bank
      DBReusables.getInstance().executeSqlScript("productBank_CreditPlus.sql");
      DBReusables.getInstance().executeSqlScript("Tranche-CreditPlus-TG.sql");
      // Test Data Injection for Customer with Deposit
      DBReusables.getInstance().executeSqlScript("customerWithPayIn-CreditPlus-TG.sql");
      // Getting customer details
      CustomerEmail = DBReusables.getInstance().getCustomerEmail();
      // Getting Product Details
      TrancheIdentifier = DBReusables.getInstance().getTrancheIdentifier("TG");
    } else {
      CustomerEmail = sCustomerEmail;
      TrancheIdentifier = sSourceTrancheIdentifier;
    }
    String testName = methodName.getName();
    TestLogger.logMsg("==========" + testName + " Started==========");
    TestLogger.logMsg("Make All Payout Assignment as CLOSED");
    DBReusables.getInstance().UpdatePayOutAssignment(TrancheIdentifier, "CLOSED");

    TestLogger.logMsg("Step-1: Log into Shop ");
    ShopLoginLogoutPO.getInstance().shopLogin(ENV, CustomerEmail);
    // calling sub method
    MeineAnlagenPO.getInstance().verifyDisabledPayOutButton(CustomerEmail, TrancheIdentifier);
    TestLogger.logMsg("==========" + testName + " Completed==========");
  }

  /*
   * Feature: Validate Payout Button is in disabled Mode for DRM
   * TestRail Link:https://depositsolutions.testrail.io/index.php?/cases/view/7567
   * Author: deepthi.gorre
   */
  @Test(
      enabled = true,
      groups = {"Payout", "Regression", "ShopUI", "DRM"})
  @Parameters({"sourceTrancheIdentifier", "customerEmail"})
  public void C7567_testPayOutButtonIsDisabledForDRM(
      Method methodName, String sSourceTrancheIdentifier, String sCustomerEmail) {
    if (testDataInjection.equalsIgnoreCase("Yes")) {
      // Test Data Injection for Product Bank
      DBReusables.getInstance().executeSqlScript("productBank-QLIRO.sql");
      DBReusables.getInstance().executeSqlScript("Tranche-QLIRO-TG.sql");
      // Test Data Injection for Customer with Deposit
      DBReusables.getInstance().executeSqlScript("customerWithPayIn-QLIRO-TG.sql");
      // Getting customer details
      CustomerEmail = DBReusables.getInstance().getCustomerEmail();
      // Getting Product Details
      TrancheIdentifier = DBReusables.getInstance().getTrancheIdentifier("TG");
    } else {
      CustomerEmail = sCustomerEmail;
      TrancheIdentifier = sSourceTrancheIdentifier;
    }
    String testName = methodName.getName();
    TestLogger.logMsg("==========" + testName + " Started==========");
    TestLogger.logMsg("Make All Payout Assignment as CLOSED");
    DBReusables.getInstance().UpdatePayOutAssignment(TrancheIdentifier, "CLOSED");

    TestLogger.logMsg("Step-1: Log into Shop ");
    ShopLoginLogoutPO.getInstance().shopLogin(ENV, CustomerEmail);
    // calling sub method
    MeineAnlagenPO.getInstance().verifyDisabledPayOutButton(CustomerEmail, TrancheIdentifier);
    TestLogger.logMsg("==========" + testName + " Completed==========");
  }

  /*
   * Feature: Cancel Payout from gunda
   * Product Type:Call-a-Like
   * Product Bank Model:FAM
   * TestRail Link:https://depositsolutions.testrail.io/index.php?/cases/view/1847
   * Author: deepthi.gorre
   */
  @Test(
      enabled = true,
      groups = {"PayOut", "Regression"})
  @Parameters({"sourceTrancheIdentifier", "payOutAmount", "customerEmail", "payOutType"})
  public void C1847_Gunda_Cancel_PayOut(
      Method methodName,
      String sSourceTrancheIdentifier,
      String sPayOutAmount,
      String sCustomerEmail,
      String sPayOutType)
      throws InterruptedException {
    if (testDataInjection.equalsIgnoreCase("Yes")) {
      // Test Data Injection for Product Bank
      DBReusables.getInstance().executeSqlScript("productBank_CreditPlus.sql");
      DBReusables.getInstance().executeSqlScript("Tranche-CreditPlus-TG.sql");
      // Test Data Injection for Customer with Deposit
      DBReusables.getInstance().executeSqlScript("customerWithPayIn-CreditPlus-TG.sql");
      // Getting customer details
      CustomerEmail = DBReusables.getInstance().getCustomerEmail();
      // Getting Product Details
      SourceTrancheIdentifier = DBReusables.getInstance().getTrancheIdentifier("TG");
      PayOutType = "PartialPayOut";
      PayOutAmount = "513.00";
    } else {
      CustomerEmail = sCustomerEmail;
      SourceTrancheIdentifier = sSourceTrancheIdentifier;
      PayOutAmount = sPayOutAmount;
    }
    String testName = methodName.getName();
    TestLogger.logMsg("==========" + testName + " Started==========");
    String table = DBReusables.getInstance().ct2iTable;
    String ServiceBank_BIC = "MHSBDEHBXXX";
    DecimalFormat twoPlaces = new DecimalFormat("0.00");
    // calling SB & PB Iban method
    PaymentServices.getInstance().SBandPB_IBAN(ServiceBank_BIC, SourceTrancheIdentifier);
    String CustomerNumber = DBReusables.getInstance().getCustomerNumber(CustomerEmail);
    String CIA =
        DBReusables.getInstance().getCIA(CustomerNumber, SourceTrancheIdentifier, ServiceBank_BIC);
    String FormatedPayOutAmount =
        (DBReusables.getInstance()
            .formatCurrency(PayOutAmount)
            .substring(0, DBReusables.getInstance().formatCurrency(PayOutAmount).indexOf(" ")));
    // Shop Login
    ShopLoginLogoutPO.getInstance().shopLogin(ENV, CustomerEmail);
    MeineAnlagenPO.getInstance().getInvestmentDetails(SourceTrancheIdentifier, CustomerEmail);
    TestLogger.logMsg("Step-1: Create PayOut");
    // Pay Out from Shop
    MeineAnlagenPO.getInstance().initiatePayOutShop(FormatedPayOutAmount, PayOutType, CIA);

    // Principal Tickets
    String i2tPTicket_id =
        DBReusables.getInstance()
            .getCustomerTicket_id(DBReusables.getInstance().ci2tTable, CustomerEmail);
    String t2cPTicket_id =
        DBReusables.getInstance()
            .getCustomerTicket_id(DBReusables.getInstance().ct2cTable, CustomerEmail);

    // Principal Ticket validations
    TestLogger.logMsg("Step-2: Validate Principal Ticket/s in DB");
    TestLogger.logInfo("***i2t Principal PayOut ticket validation***");
    Assert.assertEquals(
        DBReusables.getInstance()
            .getTicketState(i2tPTicket_id, DBReusables.getInstance().ci2tTable),
        "CREATED",
        "Customer ticket state is INVALID with reason : "
            + DBReusables.getInstance().getTicketStateMessage(i2tPTicket_id, table));
    TestLogger.logInfo("***t2c Principal PayOut ticket validation***");
    Assert.assertEquals(
        DBReusables.getInstance()
            .getTicketState(t2cPTicket_id, DBReusables.getInstance().ct2cTable),
        "CREATED",
        "Customer ticket state is INVALID with reason : "
            + DBReusables.getInstance().getTicketStateMessage(t2cPTicket_id, table));

    // Shop Validation
    TestLogger.logMsg("Step-3: Validate Inprogress ticket in Shop");
    MeineAnlagenPO.getInstance().getInvestmentDetails(SourceTrancheIdentifier, CustomerEmail);
    MeineAnlagenPO.getInstance()
        .validateShopBookings(
            2,
            DateTimeFormatter.ofPattern("dd.MM.yyyy")
                    .format(
                        LocalDate.parse(
                            (CharSequence)
                                DBReusables.getInstance()
                                    .getTrancheStartDate(SourceTrancheIdentifier)))
                + " vorgemerkt Auszahlung -"
                + FormatedPayOutAmount);

    // Gunda validation
    TestLogger.logMsg("Step-4: Validate Inprogress ticket in Gunda");
    int num =
        GundaServices.getInstance()
            .getInprogressTicket_Array(
                CustomerNumber,
                DBReusables.getInstance()
                    .getTicket_uuid(i2tPTicket_id, DBReusables.getInstance().ci2tTable));
    Assert.assertEquals(
        (WebServiceOperations.getInstance()
            .convertStringToJson(Gunda.getInstance().Gunda_GetCustomer(CustomerNumber))
            .getString("notExecutedTickets[" + num + "].productIdentifier")),
        SourceTrancheIdentifier,
        "Gunda TrancheIdentifier is not correct");
    Assert.assertEquals(
        (WebServiceOperations.getInstance()
            .convertStringToJson(Gunda.getInstance().Gunda_GetCustomer(CustomerNumber))
            .getString("notExecutedTickets[" + num + "].ticketType")),
        "INTEREST_TO_TRANSIT",
        "Gunda ticketType is not correct");
    Assert.assertEquals(
        (WebServiceOperations.getInstance()
            .convertStringToJson(Gunda.getInstance().Gunda_GetCustomer(CustomerNumber))
            .getString("notExecutedTickets[" + num + "].ticketState")),
        "CREATED",
        "Gunda ticketState is not correct");

    int num1 =
        GundaServices.getInstance()
            .getInprogressTicket_Array(
                CustomerNumber,
                DBReusables.getInstance()
                    .getTicket_uuid(i2tPTicket_id, DBReusables.getInstance().ct2cTable));
    Assert.assertEquals(
        (WebServiceOperations.getInstance()
            .convertStringToJson(Gunda.getInstance().Gunda_GetCustomer(CustomerNumber))
            .getString("notExecutedTickets[" + num1 + "].productIdentifier")),
        SourceTrancheIdentifier,
        "Gunda TrancheIdentifier is not correct");
    Assert.assertEquals(
        (WebServiceOperations.getInstance()
            .convertStringToJson(Gunda.getInstance().Gunda_GetCustomer(CustomerNumber))
            .getString("notExecutedTickets[" + num1 + "].ticketType")),
        "TRANSIT_TO_CUSTOMER",
        "Gunda ticketType is not correct");
    Assert.assertEquals(
        (WebServiceOperations.getInstance()
            .convertStringToJson(Gunda.getInstance().Gunda_GetCustomer(CustomerNumber))
            .getString("notExecutedTickets[" + num1 + "].ticketState")),
        "CREATED",
        "Gunda ticketState is not correct");

    // Gunda Cancel
    TestLogger.logMsg("Step-5: Cancel Payin from Gunda");
    GundaPO.getInstance()
        .gundaCancel(
            i2tPTicket_id,
            "INTEREST_TO_TRANSIT",
            DBReusables.getInstance().ci2tTable,
            CustomerNumber);

    // DB Validation
    TestLogger.logMsg("Step-6: Validate Customer Ticket in DB after cancellation");
    TestLogger.logInfo("***i2t Principal PayOut ticket validation***");
    Assert.assertEquals(
        DBReusables.getInstance()
            .getTicketState(i2tPTicket_id, DBReusables.getInstance().ci2tTable),
        "CANCELLED",
        "Customer ticket state is not cancelled ");
    TestLogger.logInfo("***t2c Principal PayOut ticket validation***");
    Assert.assertEquals(
        DBReusables.getInstance()
            .getTicketState(t2cPTicket_id, DBReusables.getInstance().ct2cTable),
        "CANCELLED",
        "Customer ticket state is not cancelled ");

    // Gunda validation
    TestLogger.logMsg("Step-7: Validate Inprogress ticket in Gunda after cancellation");
    JsonPath js = new JsonPath(Gunda.getInstance().Gunda_GetCustomer(CustomerNumber));
    Assert.assertEquals(js.getInt("notExecutedTickets.size()"), 0);
    // Shop validation
    TestLogger.logMsg("Step-8: Validate Inprogress ticket in Shop after cancellation");
    ShopLoginLogoutPO.getInstance().shopCache();
    MeineAnlagenPO.getInstance()
        .validateNegativeShopBookings(
            2,
            DateTimeFormatter.ofPattern("dd.MM.yyyy")
                    .format(
                        LocalDate.parse(
                            (CharSequence)
                                DBReusables.getInstance()
                                    .getTrancheStartDate(SourceTrancheIdentifier)))
                + " vorgemerkt Auszahlung -"
                + FormatedPayOutAmount);
    TestLogger.logMsg("==========" + testName + " Completed==========");
  }

  @AfterMethod(alwaysRun = true)
  public void teardown(ITestResult result) {
    if (ITestResult.FAILURE == result.getStatus()) {
      takeScreenshot(result.getName());
    }
    TestLogger.logInfo("Executing Browser tearDown method");
    ShopLoginLogoutPO.getInstance().closeAllBrowsers();
  }

  @AfterTest(alwaysRun = true)
  public void cleanup() throws SQLException {
    DBReusables.getInstance().closeDBCon();
  }
}
