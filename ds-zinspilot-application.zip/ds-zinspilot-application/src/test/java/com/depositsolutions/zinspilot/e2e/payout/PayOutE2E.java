package com.depositsolutions.zinspilot.e2e.payout;

import static com.depositsolutions.common.reusables.TestConstants.SHOP_URL_CONFIG_KEY;

import com.depositsolutions.common.reusables.DBReusables;
import com.depositsolutions.common.reusables.PaymentServices;
import com.depositsolutions.common.ui.helpers.BaseTestClassUI;
import com.depositsolutions.common.ui.zpuipageobjects.ShopLoginLogoutPO;
import com.depositsolutions.common.utils.ConfigManager;
import com.depositsolutions.common.utils.TestLogger;
import java.awt.AWTException;
import java.lang.reflect.Method;
import java.sql.SQLException;
import org.testng.ITestResult;
import org.testng.annotations.*;

public class PayOutE2E extends BaseTestClassUI {
  private String testDataInjection = ConfigManager.getInstance().getString("testDataInjection");
  String CustomerEmail,
      TargetTrancheIdentifier,
      SourceTrancheIdentifier,
      PayOutType = null,
      PayOutAmount = null;

  @BeforeTest(alwaysRun = true)
  public void setupDB() {
    DBReusables.getInstance().dbConnect();
  }

  @BeforeMethod(alwaysRun = true)
  public void preLoadSQLTestData() {
    if (testDataInjection.equalsIgnoreCase("Yes")) {
      DBReusables.getInstance().executeSqlScript("TruncateAllTables.sql");
      DBReusables.getInstance().executeSqlScript("serviceBank-sutor.sql");
    } else {
      // Truncate sps Tables
      DBReusables.getInstance().executeSqlScript("TruncateSPSTables.sql");
    }
    setUpForTest(ConfigManager.getInstance().getString(SHOP_URL_CONFIG_KEY));
  }
  /*
   * Feature: Partial PayOut from Shop without Interest and Tax booking
   * Product Type:Call
   * TestRail Link: https://depositsolutions.testrail.io/index.php?/cases/view/5282
   * Author: deepthi.gorre
   */
  @Test(
      enabled = true,
      groups = {"PayOut", "Regression"})
  @Parameters({"sourceTrancheIdentifier", "payOutAmount", "customerEmail", "payOutType"})
  public void C5282_Shop_PartialPayOut_Call(
      Method methodName,
      String sSourceTrancheIdentifier,
      String sPayOutAmount,
      String sCustomerEmail,
      String sPayOutType)
      throws SQLException, ClassNotFoundException, InterruptedException, AWTException {
    if (testDataInjection.equalsIgnoreCase("Yes")) {
      // Test Data Injection for Product Bank
      DBReusables.getInstance().executeSqlScript("productBank-BUCUROBUwithTG.sql");
      // Test Data Injection for Customer with Deposit
      DBReusables.getInstance().executeSqlScript("customerWithPayIn-BUCUROBU-TG.sql");
      // Getting customer details
      CustomerEmail = DBReusables.getInstance().getCustomerEmail();
      // Getting Product Details
      SourceTrancheIdentifier = DBReusables.getInstance().getTrancheIdentifier("TG");
      PayOutType = "PartialPayOut";
      PayOutAmount = "513.00";
    } else {
      CustomerEmail = sCustomerEmail;
      SourceTrancheIdentifier = sSourceTrancheIdentifier;
      PayOutAmount = sPayOutAmount;
      PayOutType = sPayOutType;
    }
    String testName = methodName.getName();

    TestLogger.logMsg("==========" + testName + " Started==========");
    // Calling PayOut method
    PaymentServices.getInstance()
        .CallPayOut(testName, SourceTrancheIdentifier, PayOutAmount, CustomerEmail, PayOutType);
    TestLogger.logMsg("==========" + testName + " Completed==========");
  }
  /*
   * Feature: Partial PayOut from Gunda without Interest and Tax booking
   * Product Type:Call
   * TestRail Link: https://depositsolutions.testrail.io/index.php?/cases/view/11985
   * Author: deepthi.gorre
   */
  @Test(
      enabled = true,
      groups = {"PayOut", "Regression"})
  @Parameters({"sourceTrancheIdentifier", "payOutAmount", "customerEmail", "payOutType"})
  public void C11985_Gunda_PartialPayOut_Call(
      Method methodName,
      String sSourceTrancheIdentifier,
      String sPayOutAmount,
      String sCustomerEmail,
      String sPayOutType)
      throws SQLException, ClassNotFoundException, InterruptedException, AWTException {
    if (testDataInjection.equalsIgnoreCase("Yes")) {
      // Test Data Injection for Product Bank
      DBReusables.getInstance().executeSqlScript("productBank-BUCUROBUwithTG.sql");
      // Test Data Injection for Customer with Deposit
      DBReusables.getInstance().executeSqlScript("customerWithPayIn-BUCUROBU-TG.sql");
      // Getting customer details
      CustomerEmail = DBReusables.getInstance().getCustomerEmail();
      // Getting Product Details
      SourceTrancheIdentifier = DBReusables.getInstance().getTrancheIdentifier("TG");
      PayOutType = "PartialPayOut";
      PayOutAmount = "513.00";
    } else {
      CustomerEmail = sCustomerEmail;
      SourceTrancheIdentifier = sSourceTrancheIdentifier;
      PayOutAmount = sPayOutAmount;
      PayOutType = sPayOutType;
    }
    String testName = methodName.getName();

    TestLogger.logMsg("==========" + testName + " Started==========");
    // Calling PayOut method
    PaymentServices.getInstance()
        .CallPayOut(testName, SourceTrancheIdentifier, PayOutAmount, CustomerEmail, PayOutType);
    TestLogger.logMsg("==========" + testName + " Completed==========");
  }

  /*
  BUG: Call CIA is closed after i2t processed
   * Feature: Full PayOut from Shop without Interest and Tax booking
   * Product Type:Call
   * TestRail Link: https://depositsolutions.testrail.io/index.php?/cases/view/11984
   * Author: deepthi.gorre

  @Test(
          enabled = true,
          groups = {"PayOut", "Regression"})
  @Parameters({"sourceTrancheIdentifier", "payOutAmount", "customerEmail", "payOutType"})
  public void C11984_Shop_FullPayOut_Call(
          Method methodName,
          String sSourceTrancheIdentifier,
          String sPayOutAmount,
          String sCustomerEmail,

          String sPayOutType)
          throws SQLException, ClassNotFoundException, InterruptedException, AWTException {
      if (testDataInjection.equalsIgnoreCase("Yes")) {
          // Test Data Injection for Product Bank
          DBReusables.getInstance().executeSqlScript("productBank-BUCUROBUwithTG.sql");
          // Test Data Injection for Customer with Deposit
          DBReusables.getInstance().executeSqlScript("customerWithPayIn-BUCUROBU-TG.sql");
          // Getting customer details
          CustomerEmail = DBReusables.getInstance().getCustomerEmail();
          // Getting Product Details
          SourceTrancheIdentifier = DBReusables.getInstance().getTrancheIdentifier("TG");
          PayOutType = "FullPayOut";
          PayOutAmount = "513.00";
      } else {
          CustomerEmail = sCustomerEmail;
          SourceTrancheIdentifier = sSourceTrancheIdentifier;
          PayOutAmount = sPayOutAmount;
          PayOutType = sPayOutType;
      }
      String testName = methodName.getName();

      TestLogger.logMsg("==========" + testName + " Started==========");
      // Calling PayOut method
      PaymentServices.getInstance()
              .CallPayOut(
                      testName, SourceTrancheIdentifier, PayOutAmount, CustomerEmail, PayOutType);
      TestLogger.logMsg("==========" + testName + " Completed==========");
  }
  */

  /*
     BUG: Call CIA is closed after i2t processed
      * Feature: Full PayOut from Gunda without Interest and Tax booking
      * Product Type:Call
      * TestRail Link: https://depositsolutions.testrail.io/index.php?/cases/view/11986
      * Author: deepthi.gorre

     @Test(
             enabled = true,
             groups = {"PayOut", "Regression"})
     @Parameters({"sourceTrancheIdentifier", "payOutAmount", "customerEmail", "payOutType"})
     public void C11986_Gunda_FullPayOut_Call(
             Method methodName,
             String sSourceTrancheIdentifier,
             String sPayOutAmount,
             String sCustomerEmail,

             String sPayOutType)
             throws SQLException, ClassNotFoundException, InterruptedException, AWTException {
         if (testDataInjection.equalsIgnoreCase("Yes")) {
             // Test Data Injection for Product Bank
             DBReusables.getInstance().executeSqlScript("productBank-BUCUROBUwithTG.sql");
             // Test Data Injection for Customer with Deposit
             DBReusables.getInstance().executeSqlScript("customerWithPayIn-BUCUROBU-TG.sql");
             // Getting customer details
             CustomerEmail = DBReusables.getInstance().getCustomerEmail();
             // Getting Product Details
             SourceTrancheIdentifier = DBReusables.getInstance().getTrancheIdentifier("TG");
             PayOutType = "FullPayOut";
             PayOutAmount = "513.00";
         } else {
             CustomerEmail = sCustomerEmail;
             SourceTrancheIdentifier = sSourceTrancheIdentifier;
             PayOutAmount = sPayOutAmount;
             PayOutType = sPayOutType;
         }
         String testName = methodName.getName();

         TestLogger.logMsg("==========" + testName + " Started==========");
         // Calling PayOut method
         PaymentServices.getInstance()
                 .CallPayOut(
                         testName, SourceTrancheIdentifier, PayOutAmount, CustomerEmail, PayOutType);
         TestLogger.logMsg("==========" + testName + " Completed==========");
     }

  */

  /*
   * Feature: Partial PayOut from Shop
   * Product Type:Call-a-Like
   * TestRail Link: https://depositsolutions.testrail.io/index.php?/cases/view/6998
   * Author: deepthi.gorre
   */
  @Test(
      enabled = true,
      groups = {"PayOut", "Regression"})
  @Parameters({"sourceTrancheIdentifier", "payOutAmount", "customerEmail", "payOutType"})
  public void C6998_Shop_PartialPayOut_Call_A_Like(
      Method methodName,
      String sSourceTrancheIdentifier,
      String sPayOutAmount,
      String sCustomerEmail,
      String sPayOutType)
      throws SQLException, ClassNotFoundException, InterruptedException, AWTException {
    if (testDataInjection.equalsIgnoreCase("Yes")) {
      // Test Data Injection for Product Bank
      DBReusables.getInstance().executeSqlScript("productBank_CreditPlus.sql");
      DBReusables.getInstance().executeSqlScript("Tranche-CreditPlus-TG.sql");
      // Test Data Injection for Customer with Deposit
      DBReusables.getInstance().executeSqlScript("customerWithPayIn-CreditPlus-TG.sql");
      // Getting customer details
      CustomerEmail = DBReusables.getInstance().getCustomerEmail();
      // Getting Product Details
      SourceTrancheIdentifier = DBReusables.getInstance().getTrancheIdentifier("TG");
      PayOutType = "PartialPayOut";
      PayOutAmount = "513.00";
    } else {
      CustomerEmail = sCustomerEmail;
      SourceTrancheIdentifier = sSourceTrancheIdentifier;
      PayOutAmount = sPayOutAmount;
      PayOutType = sPayOutType;
    }
    String testName = methodName.getName();

    TestLogger.logMsg("==========" + testName + " Started==========");
    // Calling PayOut method
    PaymentServices.getInstance()
        .PayOut(testName, SourceTrancheIdentifier, PayOutAmount, CustomerEmail, PayOutType, null);
    TestLogger.logMsg("==========" + testName + " Completed==========");
  }

  /*
   * Feature: Partial PayOut from Gunda
   * Product Type:Call-a-Like
   * TestRail Link:https://depositsolutions.testrail.io/index.php?/cases/view/11880
   * Author: deepthi.gorre
   */
  @Test(
      enabled = true,
      groups = {"PayOut", "Regression"})
  @Parameters({"sourceTrancheIdentifier", "payOutAmount", "customerEmail", "payOutType"})
  public void C11880_Gunda_PartialPayOut_Call_A_Like(
      Method methodName,
      String sSourceTrancheIdentifier,
      String sPayOutAmount,
      String sCustomerEmail,
      String sPayOutType)
      throws SQLException, ClassNotFoundException, InterruptedException, AWTException {
    if (testDataInjection.equalsIgnoreCase("Yes")) {
      // Test Data Injection for Product Bank
      DBReusables.getInstance().executeSqlScript("productBank_CreditPlus.sql");
      DBReusables.getInstance().executeSqlScript("Tranche-CreditPlus-TG.sql");
      // Test Data Injection for Customer with Deposit
      DBReusables.getInstance().executeSqlScript("customerWithPayIn-CreditPlus-TG.sql");
      // Getting customer details
      CustomerEmail = DBReusables.getInstance().getCustomerEmail();
      // Getting Product Details
      SourceTrancheIdentifier = DBReusables.getInstance().getTrancheIdentifier("TG");
      PayOutType = "PartialPayOut";
      PayOutAmount = "513.00";
    } else {
      CustomerEmail = sCustomerEmail;
      SourceTrancheIdentifier = sSourceTrancheIdentifier;
      PayOutAmount = sPayOutAmount;
      PayOutType = sPayOutType;
    }
    String testName = methodName.getName();

    TestLogger.logMsg("==========" + testName + " Started==========");
    // Calling PayOut method
    PaymentServices.getInstance()
        .PayOut(testName, SourceTrancheIdentifier, PayOutAmount, CustomerEmail, PayOutType, null);
    TestLogger.logMsg("==========" + testName + " Completed==========");
  }

  /*
   * Feature: Full PayOut from Shop
   * Product Type:Call-a-Like
   * TestRail Link:https://depositsolutions.testrail.io/index.php?/cases/view/11878
   * Author: deepthi.gorre
   */
  @Test(
      enabled = true,
      groups = {"PayOut", "Regression", "e2e"})
  @Parameters({"sourceTrancheIdentifier", "payOutAmount", "customerEmail", "payOutType"})
  public void C11878_Shop_FullPayOut_Call_A_Like(
      Method methodName,
      String sSourceTrancheIdentifier,
      String sPayOutAmount,
      String sCustomerEmail,
      String sPayOutType)
      throws SQLException, ClassNotFoundException, InterruptedException, AWTException {
    if (testDataInjection.equalsIgnoreCase("Yes")) {
      // Test Data Injection for Product Bank
      DBReusables.getInstance().executeSqlScript("productBank_CreditPlus.sql");
      DBReusables.getInstance().executeSqlScript("Tranche-CreditPlus-TG.sql");
      // Test Data Injection for Customer with Deposit
      DBReusables.getInstance().executeSqlScript("customerWithPayIn-CreditPlus-TG.sql");
      // Getting customer details
      CustomerEmail = DBReusables.getInstance().getCustomerEmail();
      // Getting Product Details
      SourceTrancheIdentifier = DBReusables.getInstance().getTrancheIdentifier("TG");
      PayOutType = "FullPayOut";
    } else {
      CustomerEmail = sCustomerEmail;
      SourceTrancheIdentifier = sSourceTrancheIdentifier;
      PayOutAmount = sPayOutAmount;
      PayOutType = sPayOutType;
    }
    String testName = methodName.getName();

    TestLogger.logMsg("==========" + testName + " Started==========");
    // Calling PayOut method
    PaymentServices.getInstance()
        .PayOut(testName, SourceTrancheIdentifier, PayOutAmount, CustomerEmail, PayOutType, null);
    TestLogger.logMsg("==========" + testName + " Completed==========");
  }
  /*
   * Feature: Full PayOut from Gunda
   * Product Type:Call-a-Like
   * TestRail Link:https://depositsolutions.testrail.io/index.php?/cases/view/11882
   * Author: deepthi.gorre
   */
  @Test(
      enabled = true,
      groups = {"PayOut", "Regression"})
  @Parameters({"sourceTrancheIdentifier", "payOutAmount", "customerEmail", "payOutType"})
  public void C11882_Gunda_FullPayOut_Call_A_Like(
      Method methodName,
      String sSourceTrancheIdentifier,
      String sPayOutAmount,
      String sCustomerEmail,
      String sPayOutType)
      throws SQLException, ClassNotFoundException, InterruptedException, AWTException {
    if (testDataInjection.equalsIgnoreCase("Yes")) {
      // Test Data Injection for Product Bank
      DBReusables.getInstance().executeSqlScript("productBank_CreditPlus.sql");
      DBReusables.getInstance().executeSqlScript("Tranche-CreditPlus-TG.sql");
      // Test Data Injection for Customer with Deposit
      DBReusables.getInstance().executeSqlScript("customerWithPayIn-CreditPlus-TG.sql");
      // Getting customer details
      CustomerEmail = DBReusables.getInstance().getCustomerEmail();
      // Getting Product Details
      SourceTrancheIdentifier = DBReusables.getInstance().getTrancheIdentifier("TG");
      PayOutType = "FullPayOut";
    } else {
      CustomerEmail = sCustomerEmail;
      SourceTrancheIdentifier = sSourceTrancheIdentifier;
      PayOutAmount = sPayOutAmount;
      PayOutType = sPayOutType;
    }
    String testName = methodName.getName();

    TestLogger.logMsg("==========" + testName + " Started==========");
    // Calling PayOut method
    PaymentServices.getInstance()
        .PayOut(testName, SourceTrancheIdentifier, PayOutAmount, CustomerEmail, PayOutType, null);
    TestLogger.logMsg("==========" + testName + " Completed==========");
  }

  /*
   * Feature: Partial PayOut or Partial Prolongation from Shop
   * Product Type:Fixed Term
   * TestRail Link:https://depositsolutions.testrail.io/index.php?/cases/view/6997
   * Author: deepthi.gorre
   */
  @Test(
      enabled = true,
      groups = {"PayOut", "Prolongation", "Regression", "e2e"})
  @Parameters({
    "sourceTrancheIdentifier",
    "payOutAmount",
    "customerEmail",
    "payOutType",
    "targetTrancheIdentifier"
  })
  public void C6997_Shop_PartialPayOut_PartialProlongation_FixedTerm(
      Method methodName,
      String sSourceTrancheIdentifier,
      String sPayOutAmount,
      String sCustomerEmail,
      String sPayOutType,
      String sTargetTrancheIdentifier)
      throws SQLException, ClassNotFoundException, InterruptedException, AWTException {
    if (testDataInjection.equalsIgnoreCase("Yes")) {
      // Test Data Injection for Product Bank
      DBReusables.getInstance().executeSqlScript("productBank_CreditPlus.sql");
      DBReusables.getInstance().executeSqlScript("Tranche-CreditPlus-FG1Y.sql");
      // Test Data Injection for Customer with Deposit
      DBReusables.getInstance().executeSqlScript("customerWithPayIn-CreditPlus-FG1Y.sql");
      // Getting customer details
      CustomerEmail = DBReusables.getInstance().getCustomerEmail();
      // Getting Product Details
      SourceTrancheIdentifier = DBReusables.getInstance().getPreviousTrancheIdentifier("FG");
      TargetTrancheIdentifier = DBReusables.getInstance().getTrancheIdentifier("FG");
      PayOutType = "PartialPayOut";
      PayOutAmount = "513.00";
    } else {
      CustomerEmail = sCustomerEmail;
      SourceTrancheIdentifier = sSourceTrancheIdentifier;
      TargetTrancheIdentifier = sTargetTrancheIdentifier;
      PayOutAmount = sPayOutAmount;
      PayOutType = sPayOutType;
    }
    String testName = methodName.getName();

    TestLogger.logMsg("==========" + testName + " Started==========");
    // Calling PayOut method
    PaymentServices.getInstance()
        .PayOut(
            testName,
            SourceTrancheIdentifier,
            PayOutAmount,
            CustomerEmail,
            PayOutType,
            TargetTrancheIdentifier);
    TestLogger.logMsg("==========" + testName + " Completed==========");
  }
  /*
   * Feature: Partial PayOut and Partial Prolongation from Gunda
   * Product Type:Fixed Term
   * TestRail Link:https://depositsolutions.testrail.io/index.php?/cases/view/11879
   * Author: deepthi.gorre
   */
  @Test(
      enabled = true,
      groups = {"PayOut", "Prolongation", "Regression"})
  @Parameters({
    "sourceTrancheIdentifier",
    "payOutAmount",
    "customerEmail",
    "payOutType",
    "targetTrancheIdentifier"
  })
  public void C11879_Gunda_PartialPayOut_PartialProlongation_FixedTerm(
      Method methodName,
      String sSourceTrancheIdentifier,
      String sPayOutAmount,
      String sCustomerEmail,
      String sPayOutType,
      String sTargetTrancheIdentifier)
      throws SQLException, ClassNotFoundException, InterruptedException, AWTException {
    if (testDataInjection.equalsIgnoreCase("Yes")) {
      // Test Data Injection for Product Bank
      DBReusables.getInstance().executeSqlScript("productBank_CreditPlus.sql");
      DBReusables.getInstance().executeSqlScript("Tranche-CreditPlus-FG1Y.sql");
      // Test Data Injection for Customer with Deposit
      DBReusables.getInstance().executeSqlScript("customerWithPayIn-CreditPlus-FG1Y.sql");
      // Getting customer details
      CustomerEmail = DBReusables.getInstance().getCustomerEmail();
      // Getting Product Details
      SourceTrancheIdentifier = DBReusables.getInstance().getPreviousTrancheIdentifier("FG");
      TargetTrancheIdentifier = DBReusables.getInstance().getTrancheIdentifier("FG");
      PayOutType = "PartialPayOut";
      PayOutAmount = "513.00";
    } else {
      CustomerEmail = sCustomerEmail;
      SourceTrancheIdentifier = sSourceTrancheIdentifier;
      TargetTrancheIdentifier = sTargetTrancheIdentifier;
      PayOutAmount = sPayOutAmount;
      PayOutType = sPayOutType;
    }
    String testName = methodName.getName();

    TestLogger.logMsg("==========" + testName + " Started==========");
    // Calling PayOut method
    PaymentServices.getInstance()
        .PayOut(
            testName,
            SourceTrancheIdentifier,
            PayOutAmount,
            CustomerEmail,
            PayOutType,
            TargetTrancheIdentifier);
    TestLogger.logMsg("==========" + testName + " Completed==========");
  }

  /*
   * Feature: Full PayOut and NoProlongation from Shop
   * Product Type:Fixed Term
   * TestRail Link:https://depositsolutions.testrail.io/index.php?/cases/view/11877
   * Author: deepthi.gorre
   */
  @Test(
      enabled = true,
      groups = {"PayOut", "Regression"})
  @Parameters({
    "sourceTrancheIdentifier",
    "payOutAmount",
    "customerEmail",
    "payOutType",
    "targetTrancheIdentifier"
  })
  public void C11877_Shop_FullPayOut_NoProlongation_FixedTerm(
      Method methodName,
      String sSourceTrancheIdentifier,
      String sPayOutAmount,
      String sCustomerEmail,
      String sPayOutType,
      String sTargetTrancheIdentifier)
      throws SQLException, ClassNotFoundException, InterruptedException, AWTException {
    if (testDataInjection.equalsIgnoreCase("Yes")) {
      // Test Data Injection for Product Bank
      DBReusables.getInstance().executeSqlScript("productBank_CreditPlus.sql");
      DBReusables.getInstance().executeSqlScript("Tranche-CreditPlus-FG1Y.sql");
      // Test Data Injection for Customer with Deposit
      DBReusables.getInstance().executeSqlScript("customerWithPayIn-CreditPlus-FG1Y.sql");
      // Getting customer details
      CustomerEmail = DBReusables.getInstance().getCustomerEmail();
      // Getting Product Details
      SourceTrancheIdentifier = DBReusables.getInstance().getPreviousTrancheIdentifier("FG");
      TargetTrancheIdentifier = DBReusables.getInstance().getTrancheIdentifier("FG");
      PayOutType = "FullPayOut";
    } else {
      CustomerEmail = sCustomerEmail;
      SourceTrancheIdentifier = sSourceTrancheIdentifier;
      TargetTrancheIdentifier = sTargetTrancheIdentifier;
      PayOutAmount = sPayOutAmount;
      PayOutType = sPayOutType;
    }
    String testName = methodName.getName();

    TestLogger.logMsg("==========" + testName + " Started==========");
    // Calling PayOut method
    PaymentServices.getInstance()
        .PayOut(
            testName,
            SourceTrancheIdentifier,
            PayOutAmount,
            CustomerEmail,
            PayOutType,
            TargetTrancheIdentifier);

    TestLogger.logMsg("==========" + testName + " Completed==========");
  }

  /*
   * Feature: Full PayOut and NoProlongation from Gunda
   * Product Type:Fixed Term
   * TestRail Link:https://depositsolutions.testrail.io/index.php?/cases/view/11881
   * Author: deepthi.gorre
   */
  @Test(
      enabled = true,
      groups = {"PayOut", "Regression"})
  @Parameters({
    "sourceTrancheIdentifier",
    "payOutAmount",
    "customerEmail",
    "payOutType",
    "targetTrancheIdentifier"
  })
  public void C11881_Gunda_FullPayOut_NoProlongation_FixedTerm(
      Method methodName,
      String sSourceTrancheIdentifier,
      String sPayOutAmount,
      String sCustomerEmail,
      String sPayOutType,
      String sTargetTrancheIdentifier)
      throws SQLException, ClassNotFoundException, InterruptedException, AWTException {
    if (testDataInjection.equalsIgnoreCase("Yes")) {
      // Test Data Injection for Product Bank
      DBReusables.getInstance().executeSqlScript("productBank_CreditPlus.sql");
      DBReusables.getInstance().executeSqlScript("Tranche-CreditPlus-FG1Y.sql");
      // Test Data Injection for Customer with Deposit
      DBReusables.getInstance().executeSqlScript("customerWithPayIn-CreditPlus-FG1Y.sql");
      // Getting customer details
      CustomerEmail = DBReusables.getInstance().getCustomerEmail();
      // Getting Product Details
      SourceTrancheIdentifier = DBReusables.getInstance().getPreviousTrancheIdentifier("FG");
      TargetTrancheIdentifier = DBReusables.getInstance().getTrancheIdentifier("FG");
      PayOutType = "FullPayOut";
    } else {
      CustomerEmail = sCustomerEmail;
      SourceTrancheIdentifier = sSourceTrancheIdentifier;
      TargetTrancheIdentifier = sTargetTrancheIdentifier;
      PayOutAmount = sPayOutAmount;
      PayOutType = sPayOutType;
    }
    String testName = methodName.getName();

    TestLogger.logMsg("==========" + testName + " Started==========");
    // Calling PayOut method
    PaymentServices.getInstance()
        .PayOut(
            testName,
            SourceTrancheIdentifier,
            PayOutAmount,
            CustomerEmail,
            PayOutType,
            TargetTrancheIdentifier);
    TestLogger.logMsg("==========" + testName + " Completed==========");
  }

  /*
   * Feature: Default Prolongation Strategy-PAYOUT
   * Product Type:Fixed Term
   * TestRail Link:https://depositsolutions.testrail.io/index.php?/cases/view/2063
   * Author: deepthi.gorre
   */
  @Test(
      enabled = true,
      groups = {"Payout", "Regression"})
  @Parameters({
    "sourceTrancheIdentifier",
    "payOutAmount",
    "customerEmail",
    "payOutType",
    "targetTrancheIdentifier"
  })
  public void C2063_DefaultProlongationStrategy_Payout(
      Method methodName,
      String sSourceTrancheIdentifier,
      String sPayOutAmount,
      String sCustomerEmail,
      String sPayOutType,
      String sTargetTrancheIdentifier)
      throws SQLException, ClassNotFoundException, InterruptedException, AWTException {
    if (testDataInjection.equalsIgnoreCase("Yes")) {
      // Test Data Injection for Product Bank
      DBReusables.getInstance().executeSqlScript("productBank_CreditPlus.sql");
      DBReusables.getInstance().executeSqlScript("Tranche-CreditPlus-FG1Y.sql");
      // Test Data Injection for Customer with Deposit
      DBReusables.getInstance().executeSqlScript("customerWithPayIn-CreditPlus-FG1Y.sql");
      // Getting customer details
      CustomerEmail = DBReusables.getInstance().getCustomerEmail();
      // Getting Product Details
      SourceTrancheIdentifier = DBReusables.getInstance().getPreviousTrancheIdentifier("FG");
      TargetTrancheIdentifier = DBReusables.getInstance().getTrancheIdentifier("FG");
      PayOutType = "FullPayOut";
    } else {
      CustomerEmail = sCustomerEmail;
      SourceTrancheIdentifier = sSourceTrancheIdentifier;
      TargetTrancheIdentifier = sTargetTrancheIdentifier;
      PayOutAmount = sPayOutAmount;
      PayOutType = sPayOutType;
    }
    String testName = methodName.getName();

    TestLogger.logMsg("==========" + testName + " Started==========");
    DBReusables.getInstance().updateProlongationStrategy(SourceTrancheIdentifier, "PAYOUT");
    // Calling PayOut method
    PaymentServices.getInstance()
        .PayOut(
            testName,
            SourceTrancheIdentifier,
            PayOutAmount,
            CustomerEmail,
            PayOutType,
            TargetTrancheIdentifier);
    TestLogger.logMsg("==========" + testName + " Completed==========");
  }

  /*
   * Feature: Full-PAYOUT for CACF
   * Product Type:Call-a-like
   * TestRail Link:https://depositsolutions.testrail.io/index.php?/cases/view/9482
   * Author: deepthi.gorre
   */
  @Test(
      enabled = true,
      groups = {"Payout", "Regression"})
  @Parameters({
    "sourceTrancheIdentifier",
    "payOutAmount",
    "customerEmail",
    "payOutType",
    "targetTrancheIdentifier"
  })
  public void C9482_Shop_FullPayOut_Call_A_Like_CACF(
      Method methodName,
      String sSourceTrancheIdentifier,
      String sPayOutAmount,
      String sCustomerEmail,
      String sPayOutType,
      String sTargetTrancheIdentifier)
      throws SQLException, ClassNotFoundException, InterruptedException, AWTException {
    if (testDataInjection.equalsIgnoreCase("Yes")) {
      // Test Data Injection for Product Bank
      DBReusables.getInstance().executeSqlScript("productBank-CACF.sql");
      DBReusables.getInstance().executeSqlScript("Tranche-CACF-TG.sql");
      // Test Data Injection for Customer with Deposit
      DBReusables.getInstance().executeSqlScript("customerWithPayIn-CACF-TG.sql");
      // Getting customer details
      CustomerEmail = DBReusables.getInstance().getCustomerEmail();
      // Getting Product Details
      SourceTrancheIdentifier = DBReusables.getInstance().getTrancheIdentifier("TG");
      PayOutType = "FullPayOut";
    } else {
      CustomerEmail = sCustomerEmail;
      SourceTrancheIdentifier = sSourceTrancheIdentifier;
      TargetTrancheIdentifier = sTargetTrancheIdentifier;
      PayOutAmount = sPayOutAmount;
      PayOutType = sPayOutType;
    }
    String testName = methodName.getName();

    TestLogger.logMsg("==========" + testName + " Started==========");
    DBReusables.getInstance().updateProlongationStrategy(SourceTrancheIdentifier, "PAYOUT");
    // Calling PayOut method
    PaymentServices.getInstance()
        .PayOut(
            testName,
            SourceTrancheIdentifier,
            PayOutAmount,
            CustomerEmail,
            PayOutType,
            TargetTrancheIdentifier);
    TestLogger.logMsg("==========" + testName + " Completed==========");
  }

  @AfterMethod(alwaysRun = true)
  public void teardown(ITestResult result) {
    if (ITestResult.FAILURE == result.getStatus()) {
      takeScreenshot(result.getName());
    }
    TestLogger.logInfo("Executing Browser tearDown method");
    ShopLoginLogoutPO.getInstance().closeAllBrowsers();
  }

  @AfterTest(alwaysRun = true)
  public void cleanup() throws SQLException {
    DBReusables.getInstance().closeDBCon();
  }
}
